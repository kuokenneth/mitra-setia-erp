// src/pages/OrderDetail.jsx - Corporate Minimalist Design
import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { api, openPrintDocument, uploadFiles } from "../api";
import { useAuth } from "../AuthContext";
import { useLiveRefresh } from "../liveUpdates";
import { openProtectedFile, ProtectedFilePreview, ProtectedImage } from "../components/ProtectedFile";
import LoadingState from "../components/LoadingState";
import {
  FiActivity,
  FiArrowLeft,
  FiCalendar,
  FiCheck,
  FiClock,
  FiExternalLink,
  FiFile,
  FiFileText,
  FiAlertTriangle,
  FiMapPin,
  FiPackage,
  FiPlus,
  FiPrinter,
  FiSearch,
  FiTruck,
  FiUploadCloud,
  FiUser,
  FiX,
} from "react-icons/fi";
import "./OrderDetailRedesign.css";
import "./OrdersProgress.css";
import "./OrderDetailHeader.css";
import "./OrderTripModal.css";
import "./MaterialInvoice.css";
import useDialogLifecycle from "../components/useDialogLifecycle";

//////////////////////
// THEME - CORPORATE MINIMALIST
//////////////////////

const BRAND = {
  primary: "#0D7C3D",
  primaryDark: "#0A6331",
  primaryLight: "#10A050",
  secondary: "#F5F9F7",
  accent: "#D4E8DC",
  text: "#1A1A1A",
  textLight: "#4A4A4A",
  textMuted: "#6B7280",
  white: "#FFFFFF",
  border: "#E5E7EB",
  warning: "#F59E0B",
  warningBg: "#FFFBEB",
  success: "#10B981",
  successBg: "#ECFDF5",
  danger: "#EF4444",
  dangerBg: "#FEF2F2",
  info: "#3B82F6",
  infoBg: "#EFF6FF",
};

//////////////////////
// HELPERS
//////////////////////

function fmtDate(d) {
  if (!d) return "-";
  const dt = new Date(d);
  if (Number.isNaN(dt.getTime())) return "-";
  const dd = String(dt.getDate()).padStart(2, "0");
  const mm = String(dt.getMonth() + 1).padStart(2, "0");
  const yy = dt.getFullYear();
  return `${dd}/${mm}/${yy}`;
}

function fmtDateTime(d) {
  if (!d) return "-";
  const dt = new Date(d);
  if (Number.isNaN(dt.getTime())) return "-";
  return dt.toLocaleString("id-ID");
}

function fmtNum(n) {
  const x = Number(n);
  if (!Number.isFinite(x)) return "-";
  return x % 1 === 0 ? String(x) : x.toFixed(2);
}

function useIsNarrow(breakpoint = 980) {
  const [narrow, setNarrow] = useState(() => (typeof window !== "undefined" ? window.innerWidth < breakpoint : false));
  useEffect(() => {
    const onResize = () => setNarrow(window.innerWidth < breakpoint);
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, [breakpoint]);
  return narrow;
}

//////////////////////
// UI COMPONENTS
//////////////////////

function StatusBadge({ status, type = "order" }) {
  const s = String(status || "").toUpperCase();
  const orderMap = {
    COMPLETED: { bg: BRAND.successBg, fg: BRAND.success },
    IN_PROGRESS: { bg: BRAND.accent, fg: BRAND.primary },
    CONFIRMED: { bg: BRAND.infoBg, fg: BRAND.info },
    CANCELLED: { bg: "#F3F4F6", fg: BRAND.textMuted },
    DRAFT: { bg: BRAND.secondary, fg: BRAND.textLight },
  };
  const tripMap = {
    COMPLETED: { bg: BRAND.successBg, fg: BRAND.success },
    ARRIVED: { bg: BRAND.infoBg, fg: BRAND.info },
    DISPATCHED: { bg: "#FFF3D6", fg: "#B45309" },
    CANCELLED: { bg: "#F3F4F6", fg: BRAND.textMuted },
  };
  const map = type === "trip" ? tripMap : orderMap;
  const c = map[s] || { bg: "#F3F4F6", fg: BRAND.textMuted };

  return (
    <span
      style={{
        padding: "6px 12px",
        borderRadius: 4,
        background: c.bg,
        color: c.fg,
        fontWeight: 600,
        fontSize: 12,
        textTransform: "uppercase",
        letterSpacing: "0.3px",
      }}
    >
      {s.replaceAll("_", " ") || "—"}
    </span>
  );
}

function Button({ variant = "secondary", children, icon: Icon, size = "default", ...props }) {
  const styles = {
    primary: { background: BRAND.primary, color: BRAND.white, border: "none" },
    secondary: { background: BRAND.white, color: BRAND.textLight, border: `1px solid ${BRAND.border}` },
    danger: { background: BRAND.dangerBg, color: BRAND.danger, border: `1px solid ${BRAND.danger}20` },
  };

  const sizeStyles = {
    small: { padding: "6px 12px", fontSize: 13 },
    default: { padding: "10px 16px", fontSize: 14 },
  };

  const baseStyle = {
    display: "inline-flex",
    alignItems: "center",
    gap: 6,
    borderRadius: 6,
    fontWeight: 500,
    cursor: props.disabled ? "not-allowed" : "pointer",
    transition: "all 0.2s ease",
    opacity: props.disabled ? 0.6 : 1,
    ...styles[variant],
    ...sizeStyles[size],
  };

  return (
    <button
      style={baseStyle}
      onMouseEnter={(e) => {
        if (!props.disabled) {
          e.currentTarget.style.transform = "translateY(-1px)";
          e.currentTarget.style.boxShadow = "0 4px 12px rgba(0,0,0,0.1)";
        }
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = "translateY(0)";
        e.currentTarget.style.boxShadow = "none";
      }}
      {...props}
    >
      {Icon && <Icon size={size === "small" ? 14 : 16} />}
      {children}
    </button>
  );
}

function Card({ children, style = {} }) {
  return (
    <div style={{ background: BRAND.white, borderRadius: 8, border: `1px solid ${BRAND.border}`, ...style }}>
      {children}
    </div>
  );
}

function InfoTile({ icon, label, value, sub }) {
  const TileIcon = icon;
  return (
    <div style={{ border: `1px solid ${BRAND.border}`, borderRadius: 10, padding: 16, background: BRAND.white, minWidth: 0 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, color: BRAND.textMuted, fontSize: 12, marginBottom: 9 }}>
        <span style={{ width: 28, height: 28, borderRadius: 8, display: "inline-flex", alignItems: "center", justifyContent: "center", color: BRAND.primary, background: BRAND.secondary }}>
          <TileIcon size={14} />
        </span>
        {label}
      </div>
      <div style={{ color: BRAND.text, fontSize: 15, fontWeight: 600, overflowWrap: "anywhere" }}>{value || "—"}</div>
      {sub ? <div style={{ color: BRAND.textMuted, fontSize: 12, marginTop: 5 }}>{sub}</div> : null}
    </div>
  );
}

function Input({ style = {}, ...props }) {
  return (
    <input
      style={{
        width: "100%",
        height: 44,
        padding: "0 14px",
        borderRadius: 6,
        border: `1px solid ${BRAND.border}`,
        outline: "none",
        fontSize: 14,
        fontWeight: 500,
        color: BRAND.text,
        background: BRAND.white,
        boxSizing: "border-box",
        ...style,
      }}
      {...props}
    />
  );
}

function Select({ children, style = {}, ...props }) {
  return (
    <select
      style={{
        width: "100%",
        height: 44,
        padding: "0 14px",
        paddingRight: 36,
        borderRadius: 6,
        border: `1px solid ${BRAND.border}`,
        outline: "none",
        fontSize: 14,
        fontWeight: 500,
        color: BRAND.text,
        background: BRAND.white,
        appearance: "none",
        backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='%236B7280' viewBox='0 0 16 16'%3E%3Cpath d='M8 11L3 6h10l-5 5z'/%3E%3C/svg%3E")`,
        backgroundRepeat: "no-repeat",
        backgroundPosition: "right 12px center",
        cursor: props.disabled ? "not-allowed" : "pointer",
        boxSizing: "border-box",
        opacity: props.disabled ? 0.7 : 1,
        ...style,
      }}
      {...props}
    >
      {children}
    </select>
  );
}

function Modal({ open, title, subtitle, onClose, children, width = 1100 }) {
  const { dialogRef, titleId } = useDialogLifecycle(open, onClose);
  if (!open) return null;
  return (
    <div className="order-trip-overlay"
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0, 0, 0, 0.4)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 20,
        zIndex: 9999,
      }}
      onMouseDown={onClose}
    >
      <div ref={dialogRef} role="dialog" aria-modal="true" aria-labelledby={titleId} tabIndex={-1} className="order-trip-modal"
        style={{
          width: "100%",
          maxWidth: width,
          maxHeight: "90vh",
          background: BRAND.white,
          borderRadius: 12,
          boxShadow: "0 20px 60px rgba(0,0,0,0.2)",
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
        }}
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="order-trip-modal-head"
          style={{
            padding: "16px 20px",
            borderBottom: `1px solid ${BRAND.border}`,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-start",
          }}
        >
          <div>
            <span className="order-trip-modal-eyebrow">TRIP OPERASIONAL</span>
            <h3 id={titleId} style={{ margin: 0, fontSize: 18, fontWeight: 600, color: BRAND.text }}>{title}</h3>
            {subtitle && <p style={{ margin: "4px 0 0", fontSize: 13, color: BRAND.textMuted }}>{subtitle}</p>}
          </div>
          <button className="order-trip-modal-close" type="button" onClick={onClose} aria-label="Tutup"><FiX /></button>
        </div>
        <div className="order-trip-modal-body" style={{ padding: 20, overflow: "auto", flex: 1 }}>{children}</div>
      </div>
    </div>
  );
}

function TabButton({ active, children, onClick }) {
  return (
    <button
      className={active ? "order-detail-tab active" : "order-detail-tab"}
      onClick={onClick}
      style={{
        padding: "10px 16px",
        borderRadius: 6,
        border: `1px solid ${active ? BRAND.primary : BRAND.border}`,
        background: active ? BRAND.accent : BRAND.white,
        color: active ? BRAND.primary : BRAND.textLight,
        fontWeight: 500,
        fontSize: 14,
        cursor: "pointer",
        transition: "all 0.2s ease",
      }}
    >
      {children}
    </button>
  );
}

//////////////////////
// MAIN COMPONENT
//////////////////////

export default function OrderDetail() {
  const { id } = useParams();
  const nav = useNavigate();
  const { user } = useAuth();
  const role = user?.role || "UNKNOWN";
  const canWrite = role === "OWNER" || role === "ADMIN" || role === "STAFF";

  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [order, setOrder] = useState(null);
  const [dispatchBusyId, setDispatchBusyId] = useState("");

  // tab
  const [tab, setTab] = useState("TRIPS");

  // assign trip modal
  const [showAssign, setShowAssign] = useState(false);
  const [truckQ, setTruckQ] = useState("");
  const [trucks, setTrucks] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [assigning, setAssigning] = useState(false);
  const [assignErr, setAssignErr] = useState("");
  const [selectedTruckId, setSelectedTruckId] = useState("");
  const [selectedDriverId, setSelectedDriverId] = useState("");
  const [plannedDepartAt, setPlannedDepartAt] = useState("");
  const [tripAllocationCandidates, setTripAllocationCandidates] = useState([]);
  const [tripLoadRows, setTripLoadRows] = useState([]);
  const [additionalOrderId, setAdditionalOrderId] = useState("");

  // proofs upload
  const [uploadingProofs, setUploadingProofs] = useState(false);
  const [uploadProofErr, setUploadProofErr] = useState("");
  const [materialInvoiceForm, setMaterialInvoiceForm] = useState({ tripId: "", number: "", customerId: "", destinationLocationId: "", stopSequence: 1, notes: "" });
  const [materialDestinations, setMaterialDestinations] = useState([]);
  const [materialCustomers, setMaterialCustomers] = useState([]);
  const [materialAvailable, setMaterialAvailable] = useState([]);
  const [materialSelected, setMaterialSelected] = useState({});
  const [savingMaterialInvoice, setSavingMaterialInvoice] = useState(false);
  const [materialInvoiceError, setMaterialInvoiceError] = useState("");

  const trips = useMemo(() => order?.trips || [], [order?.trips]);
  const proofs = order?.proofs || [];
  const materialInvoices = order?.materialInvoices || [];
  const isNarrow = useIsNarrow(980);

  async function load() {
    try {
      setErr("");
      setLoading(true);
      const [data, locationData, customerData] = await Promise.all([api(`/orders/${id}`), api("/operational-locations"), api("/customers")]);
      setOrder(data);
      setMaterialDestinations((locationData?.items || []).filter((location) => location.isActive));
      setMaterialCustomers(customerData?.items || []);
    } catch (e) {
      setErr(e?.message || "Gagal memuat order");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);
  useLiveRefresh(load);

  async function createMaterialInvoice(event) {
    event.preventDefault();
    setMaterialInvoiceError("");
    setSavingMaterialInvoice(true);
    try {
      const selectedStocks = materialAvailable.filter((item) => materialSelected[item.key]?.checked);
      if (!selectedStocks.length) throw new Error("Pilih minimal satu material");
      const lines = selectedStocks.map((stock) => ({ itemName: stock.itemName, unit: stock.unit, locationId: stock.locationId, qty: Number(materialSelected[stock.key]?.qty) }));
      if (lines.some((line) => !(line.qty > 0))) throw new Error("Jumlah setiap material terpilih wajib diisi");
      await api("/material-stock/allocate", { method: "POST", body: JSON.stringify({
        customerId: materialInvoiceForm.customerId, tripId: materialInvoiceForm.tripId, orderId: id,
        destinationLocationId: materialInvoiceForm.destinationLocationId, stopSequence: materialInvoiceForm.stopSequence,
        notes: materialInvoiceForm.notes, lines,
      }) });
      try {
        await api(`/dispatch/trips/${materialInvoiceForm.tripId}`, {
          method: "POST",
          body: JSON.stringify({ city: "Medan", companyName: "CV. MITRA SETIA", companyAddress: "JLN. CEMARA NO. 40 TELP. (061) 6642646. FAX. (061) 6642647\nDs. Sampali Kec. Percut Sei Tuan Kab. Deli Serdang", companyPhone: "Telp. (061) 6642646" }),
        });
      } catch (dispatchError) {
        setMaterialInvoiceError(`Faktur Muatan berhasil disimpan, tetapi surat jalannya gagal dibuat: ${dispatchError?.message || "Kesalahan tidak diketahui"}`);
      }
      setMaterialInvoiceForm((form) => ({ ...form, number: "", customerId: "", destinationLocationId: "", stopSequence: 1, notes: "" }));
      setMaterialAvailable([]);
      setMaterialSelected({});
      await load();
    } catch (error) {
      setMaterialInvoiceError(error.message || "Gagal menyimpan faktur muatan");
    } finally {
      setSavingMaterialInvoice(false);
    }
  }

  async function selectOrderMaterialCustomer(customerId) {
    setMaterialInvoiceForm((form) => ({ ...form, customerId }));
    setMaterialAvailable([]);
    setMaterialSelected({});
    if (!customerId) return;
    try {
      const result = await api("/material-stock/available/" + customerId);
      setMaterialAvailable(result?.groups || []);
    } catch (error) {
      setMaterialInvoiceError(error.message || "Gagal memuat material customer");
    }
  }

  function toggleOrderMaterial(stock, checked) {
    setMaterialSelected((selected) => ({ ...selected, [stock.key]: { checked, qty: checked ? (selected[stock.key]?.qty || "") : "" } }));
  }

  function updateOrderMaterialQty(stockKey, qty) {
    setMaterialSelected((selected) => ({ ...selected, [stockKey]: { checked: true, qty } }));
  }

  async function loadDrivers() {
    const data = await api(`/drivers`);
    const items = data?.items || data || [];
    const only = items.filter((u) => u.isActive !== false);
    setDrivers(only);
  }

  async function loadTrucks(q) {
    const data = await api(`/trucks${q ? `?q=${encodeURIComponent(q)}` : ""}`);
    const items = data?.items || data || [];
    const normalize = (value) => String(value || "").trim().toLocaleLowerCase("id-ID");
    const origin = normalize(order?.pickupLocation?.name || order?.fromText);
    const available = items.filter((truck) => ["READY", "MAINTENANCE"].includes(truck.status)).map((truck) => {
      const current = normalize(truck.gpsLocation?.name || truck.currentLocation);
      const atPickup = current === origin || (order?.pickupLocation?.id && truck.gpsLocation?.id === order.pickupLocation.id);
      return { ...truck, atPickup };
    }).sort((a, b) => Number(b.atPickup) - Number(a.atPickup)
      || String(a.plateNumber || "").localeCompare(String(b.plateNumber || ""), "id-ID", { numeric: true }));
    setTrucks(available);
  }

  async function openAssignModal() {
    setAssignErr("");
    setShowAssign(true);
    setSelectedTruckId("");
    setSelectedDriverId("");
    setPlannedDepartAt("");
    setTruckQ("");
    setAdditionalOrderId("");
    setTripLoadRows(order?.cargoCategory === "MATERIAL" ? [] : [{ orderId: id, sackCount: "", kgPerSack: "50", primary: true }]);

    try {
      const [, , candidateData] = await Promise.all([
        loadDrivers(),
        loadTrucks(""),
        order?.cargoCategory === "MATERIAL" ? Promise.resolve({ items: [] }) : api(`/orders/${id}/trip-allocation-candidates`).catch(async () => {
          const fallback = await api("/orders?statuses=DRAFT,CONFIRMED,IN_PROGRESS");
          const items = (fallback?.items || []).filter((candidate) => candidate.id !== id
            && candidate.pickupLocationId === order?.pickupLocationId
            && candidate.cargoCategory === order?.cargoCategory);
          return { items: items.map((candidate) => ({ ...candidate, remainingQty: candidate.qtyRemaining })) };
        }),
      ]);
      setTripAllocationCandidates(candidateData?.items || []);
    } catch (e) {
      setAssignErr(e?.message || "Gagal memuat drivers/trucks");
    }
  }

  const filteredTrucks = useMemo(() => {
    const q = truckQ.trim().toLowerCase();
    if (!q) return trucks;
    return trucks.filter((t) => String(t.plateNumber || "").toLowerCase().includes(q));
  }, [trucks, truckQ]);

  const selectedTruck = useMemo(() => trucks.find((t) => t.id === selectedTruckId) || null, [trucks, selectedTruckId]);

  const usedPlanned = useMemo(() => {
    return (trips || [])
      .filter((t) => String(t.status || "").toUpperCase() !== "CANCELLED")
      .reduce((sum, t) => sum + (Number(t.qtyPlanned) || 0), 0);
  }, [trips]);

  const remaining = useMemo(() => {
    if (order?.cargoCategory === "MATERIAL" || !(Number(order?.qty) > 0)) return null;
    const rem = Number(order.qty) - usedPlanned;
    return Number.isFinite(rem) ? Math.max(0, rem) : null;
  }, [order?.cargoCategory, order?.qty, usedPlanned]);
  const isMaterialShipment = order?.cargoCategory === "MATERIAL" || (!(Number(order?.qty) > 0) && order?.cargoCategory !== "CANGKANG");
  const hasPlannedQty = !isMaterialShipment && Number(order?.qty) > 0;

  async function createTrip() {
    try {
      setAssignErr("");
      setAssigning(true);

      if (!selectedTruckId) throw new Error("Please select a truck");
      if (!selectedDriverId) throw new Error("Please select a driver");

      const tripPayload = {
        truckId: selectedTruckId,
        driverUserId: selectedDriverId,
        plannedDepartAt: plannedDepartAt ? new Date(plannedDepartAt).toISOString() : null,
        allocations: tripLoadRows.map(({ orderId, sackCount, kgPerSack }) => ({ orderId, sackCount, kgPerSack })),
      };

      const createdTrip = await api(`/orders/${id}/trips`, {
        method: "POST",
        body: JSON.stringify(tripPayload),
      });

      setShowAssign(false);
      await load();
      try {
        await api(`/dispatch/trips/${createdTrip.id}`, {
          method: "POST",
          body: JSON.stringify({
            city: "Medan",
            companyName: "CV. MITRA SETIA",
            companyAddress: "JLN. CEMARA NO. 40 TELP. (061) 6642646. FAX. (061) 6642647\nDs. Sampali Kec. Percut Sei Tuan Kab. Deli Serdang",
            companyPhone: "Telp. (061) 6642646",
          }),
        });
        await load();
      } catch (dispatchError) {
        setErr(`Trip berhasil dibuat, tetapi surat jalan gagal dibuat: ${dispatchError?.message || "Kesalahan tidak diketahui"}`);
      }
    } catch (e) {
      setAssignErr(e?.message || "Gagal membuat trip");
    } finally {
      setAssigning(false);
    }
  }

  async function generateDispatch(tripId) {
    if (dispatchBusyId) return;
    setDispatchBusyId(tripId);
    setErr("");
    try {
      await api(`/dispatch/trips/${tripId}`, {
        method: "POST",
        body: JSON.stringify({
          city: "Medan",
          companyName: "CV. MITRA SETIA",
          companyAddress:
            "JLN. CEMARA NO. 40 TELP. (061) 6642646. FAX. (061) 6642647\nDs. Sampali Kec. Percut Sei Tuan Kab. Deli Serdang",
          companyPhone: "Telp. (061) 6642646",
        }),
      });
      await load();
    } catch (e) {
      setErr(e?.message || "Gagal membuat ulang surat jalan");
    } finally {
      setDispatchBusyId("");
    }
  }

  async function patchOrderStatus(nextStatus) {
    if (nextStatus === "CANCELLED" && !window.confirm("Batalkan pesanan ini? Semua trip aktif yang hanya terkait pesanan ini juga akan otomatis dibatalkan.")) return;
    try {
      await api(`/orders/${id}`, {
        method: "PATCH",
        body: JSON.stringify({ status: nextStatus }),
      });
      await load();
    } catch (e) {
      alert(e?.message || "Gagal memperbarui order");
    }
  }

  if (loading && !order) {
    return (
      <div data-testid="order-detail-loading">
        <LoadingState label="Menyiapkan detail pesanan" note="Mengambil trip, bukti, dan alokasi muatan…" rows={5} />
      </div>
    );
  }

  if (err) {
    return (
      <div data-testid="order-detail-error">
        <Card style={{ padding: 24 }}>
          <div style={{ color: BRAND.danger, fontWeight: 600, marginBottom: 16 }}>{err}</div>
          <Button variant="secondary" icon={FiArrowLeft} onClick={() => nav("/orders")}>
            Back
          </Button>
        </Card>
      </div>
    );
  }

  if (!order) return null;

  const customerName = order.customer?.name || order.customerName || "-";
  const cargo = `${order.cargoName || "-"}${hasPlannedQty ? ` • ${order.qty} ${order.unit || ""}` : ""}`;
  const route = `${order.pickupLocation?.name || order.fromText || "-"} → ${order.destinationLocation?.name || order.toText || "-"}`;
  const completedQty = trips
    .filter((t) => String(t.status || "").toUpperCase() === "COMPLETED")
    .reduce((sum, t) => sum + Number(t.qtyActual ?? t.qtyPlanned ?? 0), 0);
  const processingQty = trips
    .filter((t) => !["COMPLETED", "CANCELLED"].includes(String(t.status || "").toUpperCase()))
    .reduce((sum, t) => sum + Number(t.qtyPlanned || 0), 0);
  const completedTrips = trips.filter((t) => String(t.status || "").toUpperCase() === "COMPLETED").length;
  const materialLines = materialInvoices.flatMap((invoice) =>
    invoice.lines?.length
      ? invoice.lines
      : invoice.materialName
        ? [{ itemName: invoice.materialName, qty: invoice.qty, unit: invoice.unit, totalKg: null }]
        : []
  );
  const materialTotalKg = materialLines.reduce((sum, line) => sum + (Number(line.totalKg) || 0), 0);
  const materialCargoLabel = materialLines.length
    ? `${materialLines.length} jenis barang dari faktur muatan`
    : "Muatan belum diisi";
  const tripCompletionLabel = isMaterialShipment
    ? `${completedTrips} dari ${trips.length} trip selesai`
    : `${fmtNum(completedQty)} ${order.unit || ""} selesai diangkut`;
  const completionPct = order.qty
    ? Math.max(0, Math.min(100, Math.round((completedQty / Number(order.qty)) * 100)))
    : order.status === "COMPLETED" ? 100 : 0;
  const processingPct = order.qty
    ? Math.max(0, Math.min(100 - completionPct, (processingQty / Number(order.qty)) * 100))
    : 0;

  return (
    <div className="order-detail-v3" data-testid="order-detail-page">
      {/* Header */}
      <div
        className="order-detail-v3-head"
        style={{
          marginBottom: 24,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          flexWrap: "wrap",
          gap: 16,
        }}
      >
        <div className="order-detail-v3-title">
          <span className="order-detail-v3-eyebrow">PESANAN ANGKUTAN</span>
          <div className="order-detail-v3-title-row">
            <h1 style={{ margin: 0, fontSize: 28, fontWeight: 700, color: BRAND.text }}>{order.orderNo}</h1>
            <StatusBadge status={order.status} />
            {order.orderType && (
              <span
                style={{
                  padding: "6px 12px",
                  borderRadius: 4,
                  background: BRAND.secondary,
                  color: BRAND.textLight,
                  fontWeight: 500,
                  fontSize: 12,
                }}
              >
                {String(order.orderType).replaceAll("_", " ")}
              </span>
            )}
          </div>
          <h2 className="order-detail-v3-customer">{customerName}</h2>
          <div className="order-detail-v3-route-line">
            <span><FiMapPin /><small>MUAT</small><b>{order.fromText || "Belum dipilih"}</b></span>
            <i>→</i>
            <span><FiMapPin /><small>BONGKAR</small><b>{order.toText || "Belum dipilih"}</b></span>
          </div>
          <div className="order-detail-v3-meta-line">
            <span><FiPackage /> {order.cargoName || "Muatan belum diisi"}{hasPlannedQty ? ` · ${fmtNum(order.qty)} ${order.unit || ""}` : ""}</span>
            <span><FiCalendar /> Rencana {fmtDate(order.plannedAt)}</span>
            {hasPlannedQty && <span><FiActivity /> Sisa {fmtNum(remaining)} {order.unit || ""}</span>}
          </div>
        </div>

        <div className="order-detail-v3-actions" style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          <Button className="order-detail-back" variant="secondary" icon={FiArrowLeft} onClick={() => nav("/orders")}>
            Kembali
          </Button>

          {canWrite && (
            <>
              <Button className="order-detail-create-trip" variant="primary" icon={FiPlus} onClick={openAssignModal} disabled={order.status === "CANCELLED"}>
                Buat Trip
              </Button>

              {order.status === "CANCELLED" ? (
                <Button variant="secondary" onClick={() => patchOrderStatus("DRAFT")}>
                  Buka Kembali
                </Button>
              ) : (
                <>
                  {order.status === "DRAFT" && <Button variant="secondary" icon={FiCheck} onClick={() => patchOrderStatus("CONFIRMED")}>Konfirmasi</Button>}
                  <Button className="order-detail-cancel"
                    variant="danger"
                    icon={FiX}
                    onClick={() => patchOrderStatus("CANCELLED")}
                    disabled={order.status === "COMPLETED"}
                  >
                    Batalkan
                  </Button>
                </>
              )}
            </>
          )}
        </div>
      </div>

      <div className="order-detail-v3-overview">
        <article><span><FiPackage /></span><div><small>PROGRES MUATAN</small><strong>{hasPlannedQty ? `${fmtNum(completedQty)} / ${fmtNum(order.qty)} ${order.unit || ""} selesai` : `${trips.length} trip`}</strong><i className="order-load-progress"><b className="completed" style={{ width: `${completionPct}%` }} /><b className="processing" style={{ width: `${processingPct}%` }} /></i><em>{hasPlannedQty ? `${fmtNum(processingQty)} ${order.unit || ""} sedang diproses · ${fmtNum(remaining)} ${order.unit || ""} belum dialokasikan` : "Jumlah mengikuti faktur muatan"}</em></div></article>
        <article><span><FiMapPin /></span><div><small>LOKASI MUAT</small><strong>{order.pickupLocation?.name || order.fromText || "Belum dipilih"}</strong><em>{order.pickupLocation?.address || "Master Lokasi"}</em></div></article>
        <article><span><FiMapPin /></span><div><small>TUJUAN BONGKAR</small><strong>{order.destinationLocation?.name || order.toText || "Belum dipilih"}</strong><em>{order.destinationLocation?.address || "Master Lokasi"}</em></div></article>
        <article><span><FiActivity /></span><div><small>PROGRES TRIP</small><strong>{completedTrips} / {trips.length} selesai</strong><em>{trips.filter((trip) => ["PLANNED", "DISPATCHED", "ARRIVED"].includes(trip.status)).length} masih aktif</em></div></article>
      </div>

      <Card style={{ borderRadius: 16 }}>
        {/* Tabs */}
        <div className="order-detail-v3-tabs" style={{ padding: "16px 20px", borderBottom: `1px solid ${BRAND.border}`, display: "flex", gap: 10, flexWrap: "wrap" }}>
          <TabButton active={tab === "INFO"} onClick={() => setTab("INFO")}>
            Ringkasan
          </TabButton>
          <TabButton active={tab === "PROOFS"} onClick={() => setTab("PROOFS")}>
            Bukti ({proofs.length})
          </TabButton>
          <TabButton active={tab === "TRIPS"} onClick={() => setTab("TRIPS")}>
            Trip ({trips.length})
          </TabButton>
          <TabButton active={tab === "MATERIAL_INVOICES"} onClick={() => setTab("MATERIAL_INVOICES")}>
            Faktur Muatan ({materialInvoices.length})
          </TabButton>
        </div>

        {/* Tab Content */}
        <div className="order-detail-v3-content" style={{ padding: 20 }}>
          {tab === "INFO" && (
            <div>
              <div style={{ padding: isNarrow ? 18 : 22, borderRadius: 12, background: "linear-gradient(135deg, #F5FAF7 0%, #EDF6F1 100%)", border: "1px solid #DFEBE4" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 16, flexWrap: "wrap" }}>
                  <div>
                    <div style={{ color: BRAND.primary, fontSize: 11, fontWeight: 700, letterSpacing: 1 }}>RINGKASAN PESANAN</div>
                    <div style={{ color: BRAND.text, fontSize: 20, fontWeight: 650, marginTop: 7 }}>{isMaterialShipment ? materialCargoLabel : (order.cargoName || "Muatan belum diisi")}</div>
                    <div style={{ color: BRAND.textMuted, fontSize: 13, marginTop: 5 }}>{route}</div>
                  </div>
                  <StatusBadge status={order.status} />
                </div>

                {hasPlannedQty ? (
                  <div style={{ marginTop: 22 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", gap: 12, fontSize: 12, color: BRAND.textMuted, marginBottom: 8 }}>
                      <span>Realisasi muatan</span>
                      <span><strong style={{ color: BRAND.text }}>{fmtNum(completedQty)} / {fmtNum(order.qty)} {order.unit || ""}</strong> · {completionPct}%</span>
                    </div>
                    <div className="order-load-progress order-load-progress-large">
                      <b className="completed" style={{ width: `${completionPct}%` }} /><b className="processing" style={{ width: `${processingPct}%` }} />
                    </div>
                    <div style={{ display: "flex", justifyContent: "space-between", gap: 12, marginTop: 8, fontSize: 12, color: BRAND.textMuted }}>
                      <span><b style={{ color: BRAND.success }}>{fmtNum(completedQty)} selesai</b> · <b style={{ color: BRAND.warning }}>{fmtNum(processingQty)} diproses</b></span>
                      <span>Sisa: {fmtNum(remaining)} {order.unit || ""}</span>
                    </div>
                  </div>
                ) : isMaterialShipment && materialLines.length ? (
                  <div style={{ display: "flex", gap: 18, flexWrap: "wrap", marginTop: 18, fontSize: 13, color: BRAND.textMuted }}>
                    <span><strong style={{ color: BRAND.text }}>{materialLines.length}</strong> baris barang tercatat</span>
                    {materialTotalKg > 0 && <span><strong style={{ color: BRAND.text }}>{fmtNum(materialTotalKg)} kg</strong> total muatan</span>}
                    <span><strong style={{ color: BRAND.text }}>{completedTrips}/{trips.length}</strong> trip selesai</span>
                  </div>
                ) : null}
              </div>

              <div style={{ display: "grid", gridTemplateColumns: isNarrow ? "1fr" : "repeat(3, minmax(0, 1fr))", gap: 12, marginTop: 14 }}>
                <InfoTile icon={FiUser} label="Pelanggan" value={customerName} sub={order.customer?.phone || undefined} />
                <InfoTile icon={FiFileText} label="Nomor DO" value={order.deliveryOrderNo || "-"} sub="Delivery Order" />
                <InfoTile icon={FiFileText} label="Nomor SPK" value={order.spkNo || "-"} sub="Surat Perintah Kerja" />
                <InfoTile icon={FiPackage} label="Muatan" value={isMaterialShipment ? materialCargoLabel : cargo} sub={isMaterialShipment ? `${materialInvoices.length} faktur muatan` : (order.orderType ? String(order.orderType).replaceAll("_", " ") : undefined)} />
                <InfoTile icon={FiMapPin} label="Rute" value={route} sub="Lokasi asal dan tujuan" />
                <InfoTile icon={FiCalendar} label="Jadwal" value={fmtDate(order.plannedAt)} sub="Deadline selesai pengiriman" />
                <InfoTile icon={FiActivity} label="Perjalanan" value={`${trips.length} trip`} sub={tripCompletionLabel} />
                <InfoTile icon={FiClock} label="Dibuat oleh" value={order.createdBy?.name || order.createdBy?.email || "Data lama"} sub={fmtDateTime(order.createdAt)} />
              </div>

              <div style={{ marginTop: 14, padding: 16, border: `1px solid ${BRAND.border}`, borderRadius: 10, background: BRAND.white }}>
                <div style={{ color: BRAND.textMuted, fontSize: 12, marginBottom: 7 }}>Catatan</div>
                <div style={{ color: BRAND.textLight, fontSize: 14, lineHeight: 1.6 }}>{order.notes || "Tidak ada catatan tambahan."}</div>
              </div>
            </div>
          )}

          {tab === "PROOFS" && (
            <div>
              {canWrite && (
                <div style={{ marginBottom: 18 }}>
                  <label style={{ display: "flex", alignItems: "center", gap: 14, padding: "16px 18px", borderRadius: 10, border: `1.5px dashed ${uploadingProofs ? BRAND.primary : "#B7D8C5"}`, background: "linear-gradient(135deg, #F7FBF8 0%, #EEF7F1 100%)", cursor: uploadingProofs ? "not-allowed" : "pointer", opacity: uploadingProofs ? 0.7 : 1 }}>
                    <span style={{ width: 42, height: 42, borderRadius: 10, display: "grid", placeItems: "center", flex: "0 0 auto", color: BRAND.primary, background: BRAND.white, boxShadow: "0 3px 10px rgba(13,124,61,.10)" }}><FiUploadCloud size={21}/></span>
                    <span style={{ display: "grid", gap: 3 }}><strong style={{ fontSize: 14, color: BRAND.text }}>{uploadingProofs ? "Sedang mengunggah..." : "Tambah gambar atau PDF"}</strong><span style={{ fontSize: 12, color: BRAND.textMuted }}>Bisa memilih beberapa file · maksimal 15 MB per file</span></span>
                    <input
                      type="file"
                      multiple
                      accept="image/*,application/pdf"
                      disabled={uploadingProofs}
                      onChange={async (e) => {
                        try {
                          setUploadProofErr("");
                          const files = Array.from(e.target.files || []);
                          if (!files.length) return;

                          setUploadingProofs(true);
                          const uploaded = await uploadFiles(files);

                          await api(`/orders/${id}/proofs`, {
                            method: "POST",
                            body: JSON.stringify({
                              proofs: uploaded.map((u) => ({
                                url: u.url,
                                fileName: u.fileName || null,
                                mimeType: u.mimeType || null,
                                size: typeof u.size === "number" ? u.size : null,
                              })),
                            }),
                          });

                          e.target.value = "";
                          await load();
                        } catch (err) {
                          setUploadProofErr(err?.message || "Gagal mengunggah");
                        } finally {
                          setUploadingProofs(false);
                        }
                      }}
                      style={{ position: "absolute", width: 1, height: 1, opacity: 0, pointerEvents: "none" }}
                    />
                  </label>
                  {uploadProofErr && <div style={{ marginTop: 10, color: BRAND.danger, fontWeight: 500 }}>{uploadProofErr}</div>}
                </div>
              )}

              {proofs.length === 0 ? (
                <div style={{ color: BRAND.textMuted, fontSize: 14 }}>Belum ada bukti pesanan.</div>
              ) : (
                <div style={{ display: "flex", flexWrap: "wrap", gap: 12 }}>
                  {proofs.map((p) => {
                    const isPdf =
                      String(p.mimeType || "").toLowerCase().includes("pdf") ||
                      String(p.url || "").toLowerCase().includes(".pdf");

                    return (
                      <div
                        key={p.id}
                        style={{
                          display: "grid",
                          gap: 8,
                          width: 190,
                          maxWidth: "100%",
                          padding: 8,
                          boxSizing: "border-box",
                          overflow: "hidden",
                          borderRadius: 10,
                          border: `1px solid ${BRAND.border}`,
                          background: BRAND.white,
                          boxShadow: "0 4px 14px rgba(17,24,39,.06)",
                        }}
                      >
                        {isPdf ? (
                          <div style={{ height: 112, display: "grid", placeItems: "center", gap: 4, borderRadius: 8, background: "#F3F7F4" }}>
                            <FiFile size={30} color={BRAND.primary} />
                            <button type="button" onClick={() => openProtectedFile(p.url).catch((e) => setErr(e.message))} style={{ border: 0, background: "transparent", cursor: "pointer", color: BRAND.primary, fontSize: 12, fontWeight: 600 }}>Buka PDF</button>
                          </div>
                        ) : (
                          <ProtectedImage url={p.url} alt={p.fileName || "Bukti pesanan"} style={{ display: "block", width: "100%", height: 112, objectFit: "cover", borderRadius: 8, background: BRAND.secondary }} />
                        )}

                        <div style={{ minWidth: 0, padding: "2px 4px 3px" }}><div title={p.fileName || "Bukti"} style={{ fontSize: 12, fontWeight: 600, color: BRAND.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{p.fileName || "Bukti"}</div><div style={{ marginTop: 3, fontSize: 11, color: BRAND.textMuted }}>{fmtDateTime(p.createdAt)}</div></div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {tab === "TRIPS" && (
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {trips.length === 0 ? (
                <div style={{ padding: 20, borderRadius: 6, border: `1px dashed ${BRAND.border}`, color: BRAND.textMuted, textAlign: "center" }}>
                  Belum ada perjalanan. Klik "Tetapkan Perjalanan" untuk membuatnya.
                </div>
              ) : (
                trips.map((t) => (
                  <div className="order-detail-v3-trip"
                    key={t.id}
                    style={{
                      padding: 16,
                      borderRadius: 6,
                      border: `1px solid ${BRAND.border}`,
                      background: BRAND.secondary,
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      gap: 16,
                      flexWrap: "wrap",
                    }}
                  >
                    <div>
                      <div style={{ fontSize: 15, fontWeight: 600, color: BRAND.text }}>
                        {t.truck?.plateNumber || t.plateNumberSnap || "-"} — {t.driverUser?.name || t.driverNameSnap || "-"}
                      </div>
                      <div style={{ marginTop: 8, display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
                        <StatusBadge status={t.status} type="trip" />
                        {t.qtyPlanned != null && (
                          <span style={{ fontSize: 13, color: BRAND.textMuted }}>
                            Qty: {fmtNum(t.qtyPlanned)} {t.unitSnap || order.unit || ""}
                          </span>
                        )}
                        <span style={{ fontSize: 13, color: BRAND.textMuted }}>Planned: {fmtDateTime(t.plannedDepartAt)}</span>
                        {t.dispatchedAt && <span style={{ fontSize: 13, color: BRAND.textMuted }}>Dispatched: {fmtDateTime(t.dispatchedAt)}</span>}
                      </div>

                      {(t.dispatchDocuments || []).length ? (
                        <div style={{ marginTop: 8, display: "grid", gap: 5, fontSize: 13 }}>
                          {(t.dispatchDocuments || []).map((document) => <div key={document.id}><button type="button" onClick={() => openProtectedFile(document.pdfUrl).catch((e) => setErr(e.message))} style={{ border: 0, padding: 0, background: "transparent", cursor: "pointer", color: BRAND.primary, fontWeight: 600 }}>{document.number}</button><span style={{ color: BRAND.textMuted }}> · {document.recipientName || document.destination || "Muatan"}</span></div>)}
                        </div>
                      ) : (
                        <div style={{ marginTop: 8, fontSize: 13, color: BRAND.textMuted }}>Surat jalan belum dibuat.</div>
                      )}
                    </div>

                    <div style={{ display: "flex", gap: 10 }}>
                      <Button variant="secondary" size="small" icon={FiExternalLink} onClick={() => nav(`/trips/${t.id}`)}>
                        Buka Trip
                      </Button>
                      {canWrite && (
                        <Button variant="primary" size="small" disabled={Boolean(dispatchBusyId)} onClick={() => generateDispatch(t.id)}>
                          {dispatchBusyId === t.id ? ((t.dispatchDocuments || []).length ? "Membuat ulang…" : "Membuat…") : `${(t.dispatchDocuments || []).length ? "Buat Ulang" : "Buat"} Surat Jalan`}
                        </Button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {tab === "MATERIAL_INVOICES" && (
            <div className="material-invoice-page">
              <div className="material-invoice-hero"><div><span>FAKTUR MUATAN</span><h2>Muatan tambahan & tujuan bongkar</h2><p>Catat pemilik tagihan, tujuan, urutan pemberhentian, barang, dan nilai muatan.</p></div>{materialInvoices.length > 0 && <Button type="button" variant="secondary" size="small" icon={FiPrinter} onClick={() => openPrintDocument(`/orders/${id}/material-invoices/print`).catch((error) => setErr(error.message))}>Cetak Semua Faktur</Button>}</div>
              {canWrite && (trips.length ? (
                <form className="material-invoice-form" onSubmit={createMaterialInvoice}>
                  <div className="material-invoice-section-title"><span>1</span><div><strong>Customer dan tujuan</strong><small>Customer adalah pihak yang ditagih; tujuan adalah lokasi fisik bongkar.</small></div></div>
                  <label style={{ display: "block", marginBottom: 14, fontSize: 12, color: BRAND.textMuted }}>Customer pemilik &amp; yang ditagih<select required className="material-invoice-control" value={materialInvoiceForm.customerId} onChange={(e) => selectOrderMaterialCustomer(e.target.value)}><option value="">Pilih dari Master Customer</option>{materialCustomers.map((customer) => <option key={customer.id} value={customer.id}>{customer.name}</option>)}</select></label>
                  <div style={{ display: "grid", gridTemplateColumns: isNarrow ? "1fr" : "2fr 1fr", gap: 12, marginBottom: 14 }}>
                    <label style={{ fontSize: 12, color: BRAND.textMuted }}>Tujuan bongkar<select required className="material-invoice-control" value={materialInvoiceForm.destinationLocationId} onChange={(e) => setMaterialInvoiceForm((form) => ({ ...form, destinationLocationId: e.target.value }))}><option value="">Pilih tujuan dari Master Lokasi</option>{materialDestinations.map((location) => <option key={location.id} value={location.id}>{location.name}</option>)}</select></label>
                    <label style={{ fontSize: 12, color: BRAND.textMuted }}>Urutan tujuan<Input required type="number" min="1" step="1" value={materialInvoiceForm.stopSequence} onChange={(e) => setMaterialInvoiceForm((form) => ({ ...form, stopSequence: e.target.value }))} style={{ marginTop: 6 }} /></label>
                  </div>
                  <div className="material-invoice-section-title"><span>2</span><div><strong>Armada dan dokumen</strong><small>Pilih trip yang membawa muatan ini.</small></div></div>
                  <div style={{ display: "grid", gridTemplateColumns: isNarrow ? "1fr" : "repeat(3, minmax(0, 1fr))", gap: 12 }}>
                    <label style={{ fontSize: 12, color: BRAND.textMuted }}>Truk<select required value={materialInvoiceForm.tripId} onChange={(e) => { const trip = trips.find((item) => item.id === e.target.value); setMaterialInvoiceForm((f) => ({ ...f, tripId: e.target.value, number: trip?.dispatchLetter?.number || "" })); }} style={{ width: "100%", marginTop: 6, height: 42, borderRadius: 6, border: `1px solid ${BRAND.border}`, padding: "0 10px" }}><option value="">Pilih truk</option>{trips.map((trip) => <option key={trip.id} value={trip.id}>{trip.truck?.plateNumber || trip.plateNumberSnap || "-"} · {trip.dispatchLetter?.number || "Surat jalan belum dibuat"}</option>)}</select></label>
                    <label style={{ fontSize: 12, color: BRAND.textMuted }}>No. Surat Jalan<Input readOnly value={materialInvoiceForm.number} placeholder="Pilih trip yang sudah memiliki surat jalan" style={{ marginTop: 6, background: BRAND.secondary, color: BRAND.primary, fontWeight: 700 }} /></label>
                    <label style={{ fontSize: 12, color: BRAND.textMuted }}>Tanggal<Input required type="date" value={materialInvoiceForm.issuedAt} onChange={(e) => setMaterialInvoiceForm((f) => ({ ...f, issuedAt: e.target.value }))} style={{ marginTop: 6 }} /></label>
                  </div>
                  <div className="material-invoice-section-title"><span>3</span><div><strong>Pilih material masuk</strong><small>Centang material yang tersedia dan isi jumlah yang akan diangkut.</small></div></div>
                  <div className="order-material-picker">
                    <div className="order-material-picker-head"><strong>Material tersedia</strong><span>{Object.values(materialSelected).filter((item) => item.checked).length} dipilih</span></div>
                    {!materialInvoiceForm.customerId ? <div className="order-material-picker-empty">Pilih customer terlebih dahulu.</div> : !materialAvailable.length ? <div className="order-material-picker-empty">Customer ini belum memiliki saldo material.</div> : <div className="order-material-picker-list">
                      <div className="order-material-picker-row heading"><span></span><span>Material</span><span>Tersedia</span><span>Jumlah diangkut</span></div>
                      {materialAvailable.map((item) => { const chosen = Boolean(materialSelected[item.key]?.checked); return <label className={"order-material-picker-row " + (chosen ? "selected" : "")} key={item.key}><input type="checkbox" checked={chosen} onChange={(e) => toggleOrderMaterial(item, e.target.checked)} /><span><strong>{item.itemName}</strong><small>{item.location?.name || "Tanpa lokasi"}</small></span><b>{fmtNum(item.availableQty)} {item.unit}</b><input disabled={!chosen} required={chosen} type="number" min="0.01" step="any" max={item.availableQty} value={materialSelected[item.key]?.qty || ""} onChange={(e) => updateOrderMaterialQty(item.key, e.target.value)} placeholder="0" /></label> })}
                    </div>}
                  </div>
                  <label style={{ display: "block", marginTop: 12, fontSize: 12, color: BRAND.textMuted }}>Catatan<Input value={materialInvoiceForm.notes} onChange={(e) => setMaterialInvoiceForm((f) => ({ ...f, notes: e.target.value }))} placeholder="Catatan opsional" style={{ marginTop: 6 }} /></label>
                  {materialInvoiceError && <div style={{ marginTop: 10, color: BRAND.danger, fontSize: 13 }}>{materialInvoiceError}</div>}
                  <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 14 }}><Button type="submit" variant="primary" disabled={savingMaterialInvoice}>{savingMaterialInvoice ? "Menyimpan..." : "Simpan Faktur"}</Button></div>
                </form>
              ) : <div style={{ padding: 16, border: `1px dashed ${BRAND.border}`, color: BRAND.textMuted, borderRadius: 8, marginBottom: 18 }}>Tetapkan truk ke pesanan terlebih dahulu sebelum memasukkan faktur muatan.</div>)}
              {materialInvoices.length ? <div style={{ overflowX: "auto" }}><table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}><thead><tr style={{ textAlign: "left", color: BRAND.textMuted, borderBottom: `1px solid ${BRAND.border}` }}><th style={{ padding: 10 }}>Tanggal</th><th style={{ padding: 10 }}>Customer Tagihan</th><th style={{ padding: 10 }}>No. GRN / Surat Jalan</th><th style={{ padding: 10 }}>Truk</th><th style={{ padding: 10 }}>Rincian Muatan</th><th style={{ padding: 10 }}>Bukti</th><th style={{ padding: 10 }}>Catatan</th></tr></thead><tbody>{materialInvoices.map((invoice) => <tr key={invoice.id} style={{ borderBottom: `1px solid ${BRAND.border}` }}><td style={{ padding: 10, verticalAlign: "top" }}>{fmtDate(invoice.issuedAt)}</td><td style={{ padding: 10, verticalAlign: "top", fontWeight: 650 }}>{invoice.billingCustomerName || order.customer?.name || order.customerName || "-"}</td><td style={{ padding: 10, fontWeight: 600, verticalAlign: "top" }}>{invoice.number}</td><td style={{ padding: 10, verticalAlign: "top" }}>{invoice.trip?.truck?.plateNumber || "-"}</td><td style={{ padding: 10 }}>{invoice.lines?.length ? <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}><thead><tr style={{ color: BRAND.textMuted }}><th style={{ textAlign: "left" }}>PP</th><th style={{ textAlign: "left" }}>PO</th><th style={{ textAlign: "left" }}>Barang</th><th style={{ textAlign: "right" }}>Qty</th><th style={{ textAlign: "right" }}>Kg</th><th style={{ textAlign: "right" }}>Rp</th></tr></thead><tbody>{invoice.lines.map((line) => <tr key={line.id}><td>{line.ppNumber || "-"}</td><td>{line.poNumber || "-"}</td><td>{line.itemName}</td><td style={{ textAlign: "right" }}>{fmtNum(line.qty)} {line.unit}</td><td style={{ textAlign: "right" }}>{line.totalKg != null ? fmtNum(line.totalKg) : "-"}</td><td style={{ textAlign: "right" }}>{line.totalAmount != null ? Number(line.totalAmount).toLocaleString("id-ID") : "-"}</td></tr>)}</tbody></table> : `${invoice.materialName} — ${fmtNum(invoice.qty)} ${invoice.unit}`}</td><td style={{ padding: 10, verticalAlign: "top" }}>{invoice.proofUrl ? <ProtectedFilePreview url={invoice.proofUrl} mimeType={invoice.proofMimeType} fileName={invoice.proofFileName || "Bukti faktur"} imageStyle={{ width: 110, height: 72, objectFit: "cover", borderRadius: 7 }} onError={(e) => setErr(e.message)} /> : "-"}</td><td style={{ padding: 10, color: BRAND.textMuted, verticalAlign: "top" }}>{invoice.notes || "-"}</td></tr>)}</tbody></table></div> : <div style={{ padding: 20, color: BRAND.textMuted, textAlign: "center" }}>Belum ada faktur muatan.</div>}
            </div>
          )}

        </div>
      </Card>

      {/* Assign Trip Modal */}
      <Modal
        open={showAssign}
        title="Rencanakan Trip"
        subtitle="Pilih armada siap pakai dan pengemudi. Trip tidak dibuat otomatis dari pesanan."
        onClose={() => setShowAssign(false)}
      >
        {assignErr && (
          <div
            style={{
              marginBottom: 16,
              padding: 12,
              borderRadius: 6,
              background: BRAND.dangerBg,
              color: BRAND.danger,
              fontWeight: 500,
              fontSize: 14,
            }}
          >
            {assignErr}
          </div>
        )}

        <div className="order-detail-trip-builder" style={{ display: "grid", gridTemplateColumns: isNarrow ? "1fr" : "1.15fr 0.85fr", gap: 16 }}>
          {/* LEFT - Truck Picker */}
          <Card>
            <div className="order-trip-picker" style={{ padding: 16 }}>
              <div className="order-trip-section-title"><div><span>LANGKAH 1</span><strong>Pilih Armada</strong></div><b>{filteredTrucks.length}</b></div>
              <div style={{ fontSize: 13, color: BRAND.textMuted, marginBottom: 12 }}>Armada READY dan MAINTENANCE dapat dipilih untuk pencatatan trip yang terlambat. Armada di luar radius <strong>{order?.fromText || "lokasi muat"}</strong> akan diberi warning.</div>
              <label className="order-trip-search"><FiSearch/><Input placeholder="Cari BK atau nomor polisi…" value={truckQ} onChange={(e) => setTruckQ(e.target.value)} /></label>

              <div style={{ marginTop: 12, maxHeight: isNarrow ? 200 : 350, overflow: "auto" }}>
                {filteredTrucks.map((t) => {
                  const active = selectedTruckId === t.id;
                  return (
                    <button type="button"
                      key={t.id}
                      className={`order-trip-truck ${active ? "active" : ""} ${!t.atPickup || t.status === "MAINTENANCE" ? "warning" : ""}`}
                      style={{
                        padding: 14,
                        borderRadius: 6,
                        border: `1px solid ${active ? BRAND.primary : BRAND.border}`,
                        background: active ? BRAND.accent : BRAND.white,
                        marginTop: 8,
                        cursor: "pointer",
                        transition: "all 0.15s ease",
                      }}
                      onClick={() => {
                        setSelectedTruckId(t.id);
                        if (t.driverUserId) setSelectedDriverId(t.driverUserId);
                      }}
                    >
                      <i className="order-trip-truck-icon"><FiTruck/></i><div className="order-trip-truck-main"><div style={{ fontSize: 16, fontWeight: 600, color: BRAND.text }}>{t.plateNumber}</div>
                      <div style={{ fontSize: 13, color: BRAND.textMuted, marginTop: 4 }}>
                        {t.brand || "-"} {t.model ? `• ${t.model}` : ""} • {t.status}
                      </div>
                      <div style={{ fontSize: 12, color: BRAND.primary, marginTop: 4, fontWeight: 600 }}>
                        <FiMapPin/> {t.gpsLocation?.name || t.currentLocation || "Belum diatur"}
                      </div>
                      {t.status === "MAINTENANCE" && <div className="order-trip-location-warning"><FiAlertTriangle/> Sedang maintenance · pilih untuk pencatatan trip terlambat</div>}
                      {!t.atPickup && <div className="order-trip-location-warning"><FiAlertTriangle/> Belum berada di lokasi asal muatan</div>}</div>
                    </button>
                  );
                })}

                {filteredTrucks.length === 0 && (
                  <div style={{ padding: 12, color: BRAND.textMuted, fontSize: 14 }}>Tidak ada kendaraan READY atau MAINTENANCE.</div>
                )}
              </div>
            </div>
          </Card>

          {/* RIGHT - Informasi Perjalanan */}
          <Card>
            <div className="order-trip-details" style={{ padding: 16 }}>
              <div className="order-trip-section-title"><div><span>LANGKAH 2</span><strong>Informasi Perjalanan</strong></div></div>
              <div style={{ fontSize: 13, color: BRAND.textMuted, marginBottom: 12 }}>Tentukan muatan setiap order. Total kilogram dihitung dari jumlah sak × berat per sak.</div>

              {order?.cargoCategory !== "MATERIAL" && <div style={{ border: `1px solid ${BRAND.border}`, borderRadius: 10, padding: 12, marginBottom: 14, background: "#FAFCFB" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8, marginBottom: 10 }}><strong style={{ fontSize: 13 }}>Alokasi order dalam trip</strong><span style={{ fontSize: 12, color: BRAND.primary, fontWeight: 700 }}>{tripLoadRows.reduce((sum, row) => sum + Number(row.sackCount || 0) * Number(row.kgPerSack || 0), 0).toLocaleString("id-ID")} kg</span></div>
                <div style={{ display: "grid", gap: 8 }}>
                  {tripLoadRows.map((row, index) => {
                    const rowOrder = row.primary ? order : tripAllocationCandidates.find((item) => item.id === row.orderId);
                    return <div key={row.orderId} style={{ border: `1px solid ${BRAND.border}`, borderRadius: 8, padding: 9, background: BRAND.white }}>
                      <div style={{ display: "flex", justifyContent: "space-between", gap: 8, marginBottom: 7 }}><span style={{ minWidth: 0 }}><strong style={{ display: "block", fontSize: 12 }}>{rowOrder?.orderNo || "Order"} · DO {rowOrder?.deliveryOrderNo || "-"}</strong><small style={{ color: BRAND.textMuted }}>{rowOrder?.customer?.name || rowOrder?.customerName || "Tanpa customer"} · sisa {row.primary ? fmtNum(remaining) : fmtNum(rowOrder?.remainingQty)} {rowOrder?.unit || ""}</small></span>{!row.primary && <button type="button" aria-label="Hapus order tambahan" onClick={() => setTripLoadRows((rows) => rows.filter((_, rowIndex) => rowIndex !== index))} style={{ border: 0, background: "transparent", color: BRAND.danger, cursor: "pointer" }}><FiX/></button>}</div>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr auto", gap: 7, alignItems: "end" }}><label style={{ fontSize: 11, color: BRAND.textMuted }}>Jumlah sak<Input required type="number" min="1" step="1" value={row.sackCount} onChange={(event) => setTripLoadRows((rows) => rows.map((item, rowIndex) => rowIndex === index ? { ...item, sackCount: event.target.value } : item))}/></label><label style={{ fontSize: 11, color: BRAND.textMuted }}>Kg per sak<Input required type="number" min="0.01" step="any" value={row.kgPerSack} onChange={(event) => setTripLoadRows((rows) => rows.map((item, rowIndex) => rowIndex === index ? { ...item, kgPerSack: event.target.value } : item))}/></label><strong style={{ paddingBottom: 10, color: BRAND.primary, whiteSpace: "nowrap", fontSize: 12 }}>{(Number(row.sackCount || 0) * Number(row.kgPerSack || 0)).toLocaleString("id-ID")} kg</strong></div>
                    </div>;
                  })}
                </div>
                <div style={{ display: "flex", gap: 7, marginTop: 9 }}><Select value={additionalOrderId} onChange={(event) => setAdditionalOrderId(event.target.value)}><option value="">Tambah order pupuk berdasarkan DO</option>{tripAllocationCandidates.filter((candidate) => (candidate.remainingQty == null || candidate.remainingQty > 0) && !tripLoadRows.some((row) => row.orderId === candidate.id)).map((candidate) => <option key={candidate.id} value={candidate.id}>DO {candidate.deliveryOrderNo || "-"} · {candidate.orderNo} · {candidate.customer?.name || candidate.customerName || "Tanpa customer"} · sisa {fmtNum(candidate.remainingQty)} {candidate.unit || ""}</option>)}</Select><Button type="button" variant="secondary" icon={FiPlus} disabled={!additionalOrderId} onClick={() => { setTripLoadRows((rows) => [...rows, { orderId: additionalOrderId, sackCount: "", kgPerSack: "50", primary: false }]); setAdditionalOrderId(""); }}>Tambah</Button></div>
              </div>}

              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                <Select
                  value={selectedDriverId}
                  onChange={(e) => setSelectedDriverId(e.target.value)}
                >
                  <option value="">
                    Pilih Pengemudi (Aktif)
                  </option>
                  {drivers.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name || d.email}
                    </option>
                  ))}
                </Select>

                {selectedTruck?.driverUserId && (
                  <div style={{ fontSize: 13, color: BRAND.textMuted }}>
                    Pengemudi bawaan truk:{" "}
                    <span style={{ color: BRAND.text, fontWeight: 500 }}>
                      {drivers.find((x) => x.id === selectedTruck.driverUserId)?.name || "Pengemudi yang ditugaskan"}
                    </span>
                    {" "}— dapat diganti untuk perjalanan ini saja.
                  </div>
                )}

                <Input
                  type="datetime-local"
                  value={plannedDepartAt}
                  onChange={(e) => setPlannedDepartAt(e.target.value)}
                />

                {selectedTruckId && <div className="order-trip-route-summary"><span>RUTE TRIP</span><strong>{selectedTruck?.gpsLocation?.name || selectedTruck?.currentLocation || "Posisi armada"} <b>→</b> {order?.fromText || "Lokasi muat"} <b>→</b> {order?.toText || "Tujuan"}</strong><small>{selectedTruck?.atPickup ? "Armada sudah berada di lokasi muat" : "Perjalanan kosong ke lokasi muat akan tercatat dalam trip yang sama"}</small></div>}
                {selectedTruck && !selectedTruck.atPickup && <div style={{ padding: "11px 12px", border: "1px solid #F0D29A", borderRadius: 8, background: "#FFF8E8", color: "#8A5600", fontSize: 13, lineHeight: 1.45 }}><strong>Armada tidak berada di lokasi asal.</strong><span style={{ display: "block", marginTop: 3 }}>Trip tetap dapat dibuat. Setelah bergerak, GPS akan mencatat perjalanan menuju {order?.fromText || "lokasi muat"} terlebih dahulu.</span></div>}
              </div>

              <div className="order-trip-actions" style={{ marginTop: 20, display: "flex", justifyContent: "flex-end", gap: 12 }}>
                <Button variant="secondary" onClick={() => setShowAssign(false)} disabled={assigning}>
                  Batal
                </Button>
                <Button
                  variant="primary"
                  onClick={createTrip}
                  disabled={
                    assigning ||
                    !selectedTruckId ||
                    !selectedDriverId ||
                    (order?.cargoCategory !== "MATERIAL" && tripLoadRows.some((row) => !(Number(row.sackCount) > 0) || !(Number(row.kgPerSack) > 0)))
                  }
                >
                  {assigning ? "Membuat..." : "Buat Perjalanan"}
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </Modal>
    </div>
  );
}
