import { useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { FiCheck, FiChevronLeft, FiChevronRight, FiFileText, FiPackage, FiPlus, FiPrinter, FiRefreshCw, FiSearch, FiShoppingCart, FiUploadCloud, FiXCircle } from "react-icons/fi";
import { api, openPrintDocument, uploadFiles } from "../api";
import { useAuth } from "../AuthContext";
import { useLiveRefresh } from "../liveUpdates";
import "./Purchasing.css";
import LoadingState from "../components/LoadingState";
import { ProtectedFilePreview } from "../components/ProtectedFile";
import ImageAnnotationEditor from "../components/ImageAnnotationEditor";
import UploadProgress from "../components/UploadProgress";
import "./PurchasingForm.css";

const money = n => new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(n || 0);
const localDateKey = value => {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
};
const label = s => ({ OPEN: "Belum dibayar", WAITING_APPROVAL: "Menunggu approval", WAITING_PAYMENT_APPROVAL: "Menunggu approval pembayaran", PAID: "Dibayar", PARTIALLY_PAID: "Dibayar sebagian", APPROVED: "Disetujui", REJECTED: "Ditolak", DRAFT: "Draft", PARTIALLY_RECEIVED: "Diterima sebagian", FULLY_RECEIVED: "Diterima penuh", SENT_TO_SUPPLIER: "Dikirim ke supplier", CANCELLED: "Dibatalkan" }[s] || s);
const poTotal = po => po.items.reduce((sum, i) => sum + i.qty * i.unitPrice, 0) + po.tax + po.shippingCost - po.discount;
const poRequestNumbers = po => (po.requestLinks?.length ? po.requestLinks.map(link => link.request?.number) : [po.request?.number]).filter(Boolean);
const isCountedPurchaseOrder = po => !["REJECTED", "CANCELLED"].includes(po.status) && !["REJECTED", "CANCELLED"].includes(po.request?.status);
const isActiveReceiptItem = item => item.condition !== "RETURNED_TO_SUPPLIER";
const billedReceiptItemQty = item => (item.supplierBillItems || []).reduce((sum, line) => sum + Number(line.qty || 0), 0);
const remainingReceiptItemQty = item => Math.max(0, Number(item.qty || 0) - billedReceiptItemQty(item));
const isReceiptItemFullyBilled = item => remainingReceiptItemQty(item) <= 0;
const receiptGroupKey = (supplierId, receipt) => {
  const proofKey = receipt.deliveryNoteProofUrl || receipt.deliveryNoteFileName;
  return proofKey ? `${supplierId}:${proofKey}` : `${supplierId}:${receipt.deliveryNote || receipt.id}`;
};
const receiptValue = receipt => receipt.items.filter(isActiveReceiptItem).reduce((sum, row) => sum + Number(row.qty) * Number(row.purchaseOrderItem?.unitPrice || 0), 0);
const receiptTargetTruck = (po, trucks) => {
  const serviceDirect = (po?.request?.directUse || po?.request?.purpose === "MAINTENANCE_STOCK_REQUEST") && po?.request?.maintenance;
  return serviceDirect ? po.request.maintenance.truck : po?.request?.purpose === "TRUCK" ? trucks.find(truck => truck.id === po.request.truckId) : null;
};
const PURCHASE_REQUEST_DRAFT_KEY = "erp:purchasing:request-draft";
const emptyPurchaseRequestForm = { urgency: "NORMAL", purpose: "STOCK", truckId: "", reason: "", itemId: "", retreadUnitId: "", qty: 1 };
const emptyPurchaseItemForm = { sku: "", name: "", unit: "PCS", isSerialized: false };
const newPurchaseLine = () => ({ key: `${Date.now()}-${Math.random()}`, itemId: "", qty: 1 });
const activeOrdersForRequest = (requestId, orders) => orders.filter(order =>
  (order.requestId === requestId || order.request?.id === requestId || order.requestLinks?.some(link => link.requestId === requestId || link.request?.id === requestId))
  && !["CANCELLED", "REJECTED"].includes(order.status)
);
function readPurchaseRequestDraft() {
  try { return JSON.parse(sessionStorage.getItem(PURCHASE_REQUEST_DRAFT_KEY) || "null") || {}; }
  catch { return {}; }
}
const requestProgress = (request, orders) => {
  if (request.status === "CANCELLED") return { text: "Dibatalkan", className: "CANCELLED" };
  if (request.status === "REJECTED") return { text: "Ditolak", className: "REJECTED" };
  if (request.status === "WAITING_APPROVAL") return { text: "Menunggu persetujuan", className: "WAITING_APPROVAL" };
  if (request.status === "DRAFT") return { text: "Draft", className: "DRAFT" };
  const activeOrders = activeOrdersForRequest(request.id, orders);
  if (!activeOrders.length) return { text: "Disetujui · siap dibuat PO", className: "APPROVED" };
  if (activeOrders.every(order => order.status === "FULLY_RECEIVED")) return { text: "Barang sudah tiba", className: "FULLY_RECEIVED", orderNumber: activeOrders.map(order => order.number).join(", ") };
  if (activeOrders.some(order => order.status === "PARTIALLY_RECEIVED" || order.status === "FULLY_RECEIVED")) return { text: "Diterima sebagian", className: "PARTIALLY_RECEIVED", orderNumber: activeOrders.map(order => order.number).join(", ") };
  if (activeOrders.some(order => order.status === "SENT_TO_SUPPLIER")) return { text: "Sudah dipesan · menunggu tiba", className: "SENT_TO_SUPPLIER", orderNumber: activeOrders.map(order => order.number).join(", ") };
  return { text: "PO dibuat · belum dikirim", className: "APPROVED", orderNumber: activeOrders.map(order => order.number).join(", ") };
};

function CatalogItemSearch({ items, value, onChange, disabled, loading }) {
  const selected = items.find(item => item.id === value);
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const normalized = query.trim().toLocaleLowerCase("id-ID");
  const results = useMemo(() => items.filter(item => !normalized || `${item.sku || ""} ${item.name || ""} ${item.unit || ""}`.toLocaleLowerCase("id-ID").includes(normalized)).slice(0, 80), [items, normalized]);

  function choose(item) {
    onChange(item.id);
    setQuery("");
    setOpen(false);
  }

  return <div className="catalog-item-search">
    <div className={`catalog-item-search-input ${open ? "focused" : ""}`}>
      <FiSearch />
      <input
        disabled={disabled}
        value={query}
        onFocus={() => setOpen(true)}
        onBlur={() => setOpen(false)}
        onChange={event => { setQuery(event.target.value); setOpen(true); if (value) onChange(""); }}
        placeholder={loading ? "Memuat katalog barang..." : selected ? `${selected.sku} — ${selected.name}` : "Cari nama sparepart atau SKU..."}
        aria-label="Cari barang dari katalog inventory"
        autoComplete="off"
      />
      {selected && !query && <button type="button" aria-label="Hapus pilihan barang" onClick={() => { onChange(""); setOpen(true); }}>×</button>}
    </div>
    {selected && !query && <div className="catalog-item-selected"><span><strong>{selected.name}</strong><small>{selected.sku} · {selected.unit || "PCS"}</small></span><b>{Number(selected.qtyTotal || 0).toLocaleString("id-ID")} tersedia</b></div>}
    {open && !disabled && <div className="catalog-item-results">
      {results.map(item => <button type="button" key={item.id} className={item.id === value ? "selected" : ""} onMouseDown={event => event.preventDefault()} onClick={() => choose(item)}><span><strong>{item.name}</strong><small>{item.sku} · {item.unit || "PCS"}</small></span><b>{Number(item.qtyTotal || 0).toLocaleString("id-ID")}</b></button>)}
      {!results.length && <div>Tidak ada sparepart yang cocok.</div>}
    </div>}
  </div>;
}

export default function Purchasing() {
  const { user } = useAuth(); const owner = ["OWNER", "ADMIN"].includes(user?.role);
  const canCreateDirectOrder = user?.role === "OWNER";
  const [searchParams, setSearchParams] = useSearchParams();
  const emailApprovalHandled = useRef(false);
  const initialRequestDraft = useMemo(readPurchaseRequestDraft, []);
  const [data, setData] = useState({ requests: [], orders: [], items: [], suppliers: [], locations: [], retreadingUnits: [], repairingUnits: [], bills: [], trucks: [], nonSerializedRepairQueue: [], directRetreadReceipts: [], repairBillCandidates: [] });
  const [tab, setTab] = useState("requests"); const [modal, setModal] = useState(""); const [busy, setBusy] = useState(false);
  const [requestBusy, setRequestBusy] = useState(false);
  const [requestDamagePhotos, setRequestDamagePhotos] = useState([]);
  const [requestPhotoEditorIndex, setRequestPhotoEditorIndex] = useState(null);
  const [showRequestPhotoEditor, setShowRequestPhotoEditor] = useState(false);
  const [requestUploadProgress, setRequestUploadProgress] = useState(null);
  const [stockAcknowledged, setStockAcknowledged] = useState(Boolean(initialRequestDraft.stockAcknowledged));
  const [form, setForm] = useState({ ...emptyPurchaseRequestForm, ...(initialRequestDraft.form || {}) });
  const [requestLines, setRequestLines] = useState(initialRequestDraft.requestLines?.length ? initialRequestDraft.requestLines : [newPurchaseLine()]);
  const [newItem, setNewItem] = useState(Boolean(initialRequestDraft.newItem));
  const [retreadRequest, setRetreadRequest] = useState(Boolean(initialRequestDraft.retreadRequest));
  const [selectedRetreadIds, setSelectedRetreadIds] = useState(initialRequestDraft.selectedRetreadIds || []);
  const [retreadSearch, setRetreadSearch] = useState(initialRequestDraft.retreadSearch || "");
  const [repairRequest, setRepairRequest] = useState(Boolean(initialRequestDraft.repairRequest));
  const [selectedRepairUnitIds, setSelectedRepairUnitIds] = useState(initialRequestDraft.selectedRepairUnitIds || []);
  const [repairUnitSearch, setRepairUnitSearch] = useState(initialRequestDraft.repairUnitSearch || "");
  const [receiptTab, setReceiptTab] = useState("purchases");
  const [itemForm, setItemForm] = useState({ ...emptyPurchaseItemForm, ...(initialRequestDraft.itemForm || {}) });
  const [formError, setFormError] = useState("");
  const [itemsLoading, setItemsLoading] = useState(false);
  const [itemsError, setItemsError] = useState("");
  const [poRequest, setPoRequest] = useState(null);
  const [poRequestIds, setPoRequestIds] = useState([]);
  const [newSupplier, setNewSupplier] = useState(false);
  const [supplierForm, setSupplierForm] = useState({ name: "", phone: "", email: "", address: "" });
  const [poForm, setPoForm] = useState({ supplierId: "", quantities: {}, prices: {}, tax: 0, shippingCost: 0, discount: 0, paymentTerms: "30 hari", deliveryAddress: "", estimatedArrival: "" });
  const [directForm, setDirectForm] = useState({ itemId: "", supplierId: "", qty: 1, reason: "", notes: "", paymentTerms: "Ditagihkan kemudian", deliveryAddress: "", estimatedArrival: "" });
  const [directLines, setDirectLines] = useState([newPurchaseLine()]);
  const [directBusy, setDirectBusy] = useState(false);
  const [receiptPo, setReceiptPo] = useState(null);
  const [receiptRepairOnly, setReceiptRepairOnly] = useState(false);
  const [receiptPoIds, setReceiptPoIds] = useState([]);
  const [receiptForm, setReceiptForm] = useState({ locationId: "", locationName: "Gudang Utama", quantities: {}, prices: {}, serials: {}, retreadUnitIds: {}, repairUnitIds: {}, deliveryNote: "", notes: "" });
  const [receiptProofFile, setReceiptProofFile] = useState(null);
  const [receiptUploadProgress, setReceiptUploadProgress] = useState(null);
  const [paymentPo, setPaymentPo] = useState(null);
  const [paymentForm, setPaymentForm] = useState({ amount: "", method: "BANK_TRANSFER", reference: "" });
  const [paymentProofFile, setPaymentProofFile] = useState(null);
  const [billForm, setBillForm] = useState({ supplierId: "", invoiceNumber: "", invoiceDate: "", dueDate: "", notes: "", receiptIds: [], itemIds: [], itemPrices: {}, itemQuantities: {}, repairMovementIds: [] });
  const [billReceiptPeriod, setBillReceiptPeriod] = useState({ from: "", to: "" });
  const [billProofFiles, setBillProofFiles] = useState([]);
  const [listFilters, setListFilters] = useState({ requests: "", orders: "", receipts: "", payments: "" });
  const [listStatuses, setListStatuses] = useState({ requests: "PROCESSING", orders: "PROCESSING", receipts: "PROCESSING", repairReceipts: "PROCESSING", payments: "PROCESSING" });
  const [listPages, setListPages] = useState({ requests: 1, orders: 1, receipts: 1, payments: 1 });
  const [cancelPo, setCancelPo] = useState(null);
  const [cancellationReason, setCancellationReason] = useState("");
  const [supplierChangePo, setSupplierChangePo] = useState(null);
  const [replacementSupplierId, setReplacementSupplierId] = useState("");
  const [repairReceipt, setRepairReceipt] = useState(null);
  const [selectedRepairIds, setSelectedRepairIds] = useState([]);
  const [repairReceiptForm, setRepairReceiptForm] = useState({ locationId: "", notes: "", items: {} });
  const [retreadReceiptForm, setRetreadReceiptForm] = useState({ locationId: "", prices: {}, outcomes: {}, scrapReasons: {} });
  async function load(options = {}) {
    const background = options?.background === true;
    const showLoading = !background || (!data.requests.length && !data.orders.length && !data.bills.length);
    if (showLoading) setBusy(true);
    try {
      const [overview, inventory] = await Promise.all([
        api("/purchasing/overview"),
        api("/inventory/items"),
      ]);
      setData(current => ({ ...current, ...overview, items: inventory.items || overview.items || [], trucks: overview.trucks || [] }));
    } finally { if (showLoading) setBusy(false); }
  }
  useEffect(() => {
    sessionStorage.setItem(PURCHASE_REQUEST_DRAFT_KEY, JSON.stringify({ form, requestLines, itemForm, newItem, retreadRequest, selectedRetreadIds, retreadSearch, repairRequest, selectedRepairUnitIds, repairUnitSearch, stockAcknowledged }));
  }, [form, requestLines, itemForm, newItem, retreadRequest, selectedRetreadIds, retreadSearch, repairRequest, selectedRepairUnitIds, repairUnitSearch, stockAcknowledged]);
  useEffect(() => { load();
  // Initial data load is intentionally limited to mount.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useLiveRefresh(load);
  useEffect(() => {
    setRequestLines(lines => lines.map((line, index) => index === 0 ? { ...line, itemId: form.itemId, qty: form.qty } : line));
  }, [form.itemId, form.qty]);

  function openRepairReceipt(repair) {
    setFormError("");
    setRepairReceipt(repair);
    setSelectedRepairIds([repair.id]);
    setRepairReceiptForm({ locationId: repair.toLocationId || data.locations[0]?.id || "", notes: "", items: { [repair.id]: { qty: String(repair.remainingQty || ""), unitPrice: "" } } });
    setModal("repair-receipt");
  }

  function openSelectedRepairReceipts() {
    const rows = (data.nonSerializedRepairQueue || []).filter(row => selectedRepairIds.includes(row.id));
    if (!rows.length) return;
    setRepairReceipt(rows[0]); setFormError("");
    setRepairReceiptForm({ locationId: rows[0].toLocationId || data.locations[0]?.id || "", notes: "", items: Object.fromEntries(rows.map(row => [row.id, { qty: String(row.remainingQty || ""), unitPrice: "" }])) });
    setModal("repair-receipt");
  }

  function toggleRepairSelection(repair) {
    setFormError("");
    setSelectedRepairIds(current => {
      if (current.includes(repair.id)) return current.filter(id => id !== repair.id);
      const selected = (data.nonSerializedRepairQueue || []).filter(row => current.includes(row.id));
      const selectedSupplier = selected[0]?.repairSupplierId || selected[0]?.repairVendor;
      const repairSupplier = repair.repairSupplierId || repair.repairVendor;
      if (selected.length && selectedSupplier !== repairSupplier) { setFormError("Checklist hanya boleh dari supplier tempat perbaikan yang sama."); return current; }
      return [...current, repair.id];
    });
  }

  async function receiveNonSerializedRepair(event) {
    event.preventDefault();
    if (!selectedRepairIds.length) return;
    setBusy(true); setFormError("");
    try {
      const items = selectedRepairIds.map(movementId => ({ movementId, ...repairReceiptForm.items[movementId] }));
      await api("/purchasing/repairs/non-serialized/receive-batch", { method: "POST", body: JSON.stringify({ items, locationId: repairReceiptForm.locationId, notes: repairReceiptForm.notes }) });
      setModal(""); setRepairReceipt(null); setSelectedRepairIds([]); await load();
    } catch (error) { setFormError(error.message || "Gagal menerima hasil perbaikan"); }
    finally { setBusy(false); }
  }
  useEffect(() => {
    const requestId = searchParams.get("approveRequest");
    if (!requestId || busy || emailApprovalHandled.current || !data.requests.length) return;
    emailApprovalHandled.current = true;
    const request = data.requests.find(row => row.id === requestId);
    const clearAction = () => setSearchParams(current => {
      const next = new URLSearchParams(current);
      next.delete("approveRequest");
      return next;
    }, { replace: true });
    if (!owner) {
      window.alert("Hanya OWNER atau ADMIN yang dapat menyetujui permintaan pembelian.");
      clearAction();
      return;
    }
    if (!request || request.status !== "WAITING_APPROVAL") {
      window.alert(request ? `Permintaan ${request.number} sudah diproses sebelumnya.` : "Permintaan pembelian tidak ditemukan.");
      clearAction();
      return;
    }
    setBusy(true);
    api(`/purchasing/requests/${request.id}/approval`, {
      method: "PATCH",
      body: JSON.stringify({
        approved: true,
        acknowledgeAvailableStock: true,
        quantities: Object.fromEntries(request.items.map(item => [item.id, item.originalQty])),
      }),
    }).then(() => {
      window.alert(`${request.number} berhasil disetujui.`);
      return load();
    }).catch(error => {
      window.alert(error.message || "Permintaan gagal disetujui.");
    }).finally(() => {
      clearAction();
      setBusy(false);
    });
  // Loading again here is a consequence of the approval action, not an effect dependency.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [busy, data.requests, owner, searchParams, setSearchParams]);
  async function loadInventoryItems() {
    setItemsLoading(true); setItemsError("");
    try {
      const inventory = await api("/inventory/items");
      const items = Array.isArray(inventory?.items) ? inventory.items : [];
      setData(current => ({ ...current, items }));
      if (!items.length) setItemsError("Endpoint Inventory berhasil dimuat, tetapi tidak mengirim item.");
      return items;
    } catch (err) {
      setItemsError(`Gagal memuat sparepart: ${err.message}`);
      return [];
    } finally { setItemsLoading(false); }
  }
  async function openRequestForm() {
    setModal("request"); setFormError("");
    await loadInventoryItems();
  }
  async function openDirectOrderForm() {
    setFormError("");
    setNewSupplier(!data.suppliers.length);
    setSupplierForm({ name: "", phone: "", email: "", address: "" });
    setDirectForm({ itemId: "", supplierId: data.suppliers[0]?.id || "", qty: 1, reason: "", notes: "", paymentTerms: "Ditagihkan kemudian", deliveryAddress: "", estimatedArrival: "" });
    setDirectLines([newPurchaseLine()]);
    setModal("direct-order");
    await loadInventoryItems();
  }
  function openSupplierForm() {
    setSupplierForm({ name: "", phone: "", email: "", address: "" });
    setFormError("");
    setModal("supplier");
  }
  async function createStandaloneSupplier(event) {
    event.preventDefault(); setBusy(true); setFormError("");
    try {
      const name = supplierForm.name.trim();
      if (!name) throw new Error("Nama supplier atau vendor wajib diisi");
      await api("/purchasing/suppliers", { method: "POST", body: JSON.stringify({ ...supplierForm, name, phone: supplierForm.phone.trim() || null, email: supplierForm.email.trim() || null, address: supplierForm.address.trim() || null }) });
      setModal(""); setSupplierForm({ name: "", phone: "", email: "", address: "" }); await load();
    } catch (error) { setFormError(error.message || "Gagal menambahkan supplier"); }
    finally { setBusy(false); }
  }
  const selectedRequestItem = useMemo(() => data.items.find(item => item.id === requestLines[0]?.itemId) || null, [data.items, requestLines]);
  const selectedRequestStock = Number(selectedRequestItem?.qtyTotal || 0);
  const requestStockItems = useMemo(() => requestLines.map(line => data.items.find(item => item.id === line.itemId)).filter(item => Number(item?.qtyTotal || 0) > 0), [data.items, requestLines]);
  const filteredRetreadingUnits = useMemo(() => {
    const query = retreadSearch.trim().toLocaleLowerCase("id-ID");
    return (data.retreadingUnits || []).filter(unit => !query || [unit.serialNumber, unit.barcode, unit.item?.sku, unit.item?.name, unit.tireRetreads?.[0]?.toItem?.sku, unit.tireRetreads?.[0]?.toItem?.name].filter(Boolean).join(" ").toLocaleLowerCase("id-ID").includes(query));
  }, [data.retreadingUnits, retreadSearch]);
  const filteredRepairingUnits = useMemo(() => {
    const query = repairUnitSearch.trim().toLocaleLowerCase("id-ID");
    return (data.repairingUnits || []).filter(unit => !query || [unit.serialNumber, unit.barcode, unit.item?.sku, unit.item?.name, unit.partRepairs?.[0]?.maintenance?.truck?.plateNumber, unit.partRepairs?.[0]?.maintenance?.number, unit.partRepairs?.[0]?.maintenance?.title].filter(Boolean).join(" ").toLocaleLowerCase("id-ID").includes(query));
  }, [data.repairingUnits, repairUnitSearch]);
  const receiptOrderOptions = useMemo(() => receiptPo ? data.orders.filter(po => po.supplierId === receiptPo.supplierId && ["SENT_TO_SUPPLIER", "PARTIALLY_RECEIVED"].includes(po.status) && (!receiptRepairOnly || po.items.some(item => item.tireRetreadId || item.partRepairId))) : [], [data.orders, receiptPo, receiptRepairOnly]);
  const selectedReceiptOrders = useMemo(() => receiptOrderOptions.filter(po => receiptPoIds.includes(po.id)), [receiptOrderOptions, receiptPoIds]);
  const directReceiptOrders = useMemo(() => selectedReceiptOrders.filter(po => receiptTargetTruck(po, data.trucks)), [selectedReceiptOrders, data.trucks]);
  const poCandidates = useMemo(() => data.requests.filter(request => request.status === "APPROVED" && !activeOrdersForRequest(request.id, data.orders).length), [data.requests, data.orders]);
  const selectedPoRequests = useMemo(() => poCandidates.filter(request => poRequestIds.includes(request.id)), [poCandidates, poRequestIds]);
  const stats = useMemo(() => {
    const countedOrders = data.orders.filter(isCountedPurchaseOrder);
    return {
      waiting: data.requests.filter(x => x.status === "WAITING_APPROVAL").length,
      open: countedOrders.filter(x => x.status !== "FULLY_RECEIVED").length,
      spend: countedOrders.reduce((total, order) => total + poTotal(order), 0),
    };
  }, [data]);
  async function createRequest(e) {
    e.preventDefault();
    if (!newItem && !retreadRequest && !repairRequest && requestStockItems.length > 0 && !stockAcknowledged) {
      setStockAcknowledged(true);
      setFormError(`Peringatan: ${requestStockItems.map(item => `${item.name} masih tersedia ${Number(item.qtyTotal).toLocaleString("id-ID")} ${item.unit}`).join(", ")}. Periksa Inventory terlebih dahulu, atau klik Tetap Kirim Permintaan jika pembelian memang diperlukan.`);
      return;
    }
    setRequestBusy(true); setFormError("");
    try {
      if (!newItem && !retreadRequest && !repairRequest && (!requestLines.length || requestLines.some(line => !line.itemId))) throw new Error("Pilih barang pada setiap baris");
      if (!newItem && !retreadRequest && !repairRequest && new Set(requestLines.map(line => line.itemId)).size !== requestLines.length) throw new Error("Barang yang sama tidak boleh dimasukkan dua kali");
      if (retreadRequest && !selectedRetreadIds.length) throw new Error("Pilih minimal satu ban masak");
      if (repairRequest && !selectedRepairUnitIds.length) throw new Error("Pilih minimal satu barang perbaikan");
      if (requestDamagePhotos.length) setRequestUploadProgress(0);
      const damageProofs = requestDamagePhotos.length ? await uploadFiles(requestDamagePhotos, { onProgress: setRequestUploadProgress }) : [];
      const damageProof = damageProofs[0];
      let itemId = form.itemId;
      if (newItem) {
        const created = await api("/inventory/items", { method: "POST", body: JSON.stringify(itemForm) });
        itemId = created.item.id;
      }
      const requestItems = retreadRequest
        ? selectedRetreadIds.map(retreadUnitId => ({ retreadUnitId, qty: 1 }))
        : repairRequest
          ? selectedRepairUnitIds.map(stockUnitId => ({ partRepairId: data.repairingUnits.find(unit => unit.id === stockUnitId)?.partRepairs?.[0]?.id, qty: 1 }))
        : newItem
          ? [{ itemId, qty: form.purpose === "STOCK" ? undefined : form.qty }]
          : requestLines.map((line, index) => ({ itemId: line.itemId, qty: form.purpose === "STOCK" ? undefined : index === 0 ? form.qty : line.qty }));
      await api("/purchasing/requests", { method: "POST", body: JSON.stringify({ ...form, truckId: form.purpose === "TRUCK" ? form.truckId : undefined, acknowledgeAvailableStock: stockAcknowledged, damageProofs: damageProofs.map(file => ({ url: file.url, fileName: file.fileName, mimeType: file.mimeType, size: file.size })), damageProofUrl: damageProof?.url, damageProofFileName: damageProof?.fileName, damageProofMimeType: damageProof?.mimeType, damageProofSize: damageProof?.size, items: requestItems }) });
      sessionStorage.removeItem(PURCHASE_REQUEST_DRAFT_KEY);
      setModal(""); setForm({ ...emptyPurchaseRequestForm });
      setRequestLines([newPurchaseLine()]); setItemForm({ ...emptyPurchaseItemForm }); setNewItem(false); setRetreadRequest(false); setRepairRequest(false); setSelectedRetreadIds([]); setSelectedRepairUnitIds([]); setRetreadSearch(""); setRepairUnitSearch(""); setStockAcknowledged(false); setRequestDamagePhotos([]); await load();
    } catch (err) {
      if (String(err.message || "").startsWith("Stok masih tersedia:")) setStockAcknowledged(true);
      setFormError(err.message);
    } finally { setRequestBusy(false); setRequestUploadProgress(null); }
  }

  async function receiveRetreadsDirectly(e) {
    e.preventDefault();
    setRequestBusy(true); setFormError("");
    try {
      if (!selectedRetreadIds.length) throw new Error("Pilih minimal satu ban masak");
      const items = selectedRetreadIds.map(unitId => {
        const outcome = retreadReceiptForm.outcomes[unitId] || "RECEIVED";
        if (outcome === "SCRAPPED") {
          const scrapReason = String(retreadReceiptForm.scrapReasons[unitId] || "").trim();
          if (!scrapReason) throw new Error("Isi alasan untuk setiap ban yang di-scrap");
          return { unitId, outcome, scrapReason };
        }
        return { unitId, outcome };
      });
      await api("/purchasing/retreads/create-order", { method: "POST", body: JSON.stringify({ items }) });
      sessionStorage.removeItem(PURCHASE_REQUEST_DRAFT_KEY);
      setModal(""); setSelectedRetreadIds([]); setRetreadSearch(""); setRetreadRequest(false); setRetreadReceiptForm({ locationId: "", prices: {}, outcomes: {}, scrapReasons: {} }); await load();
    } catch (err) {
      setFormError(err.message);
    } finally { setRequestBusy(false); }
  }
  async function approve(r, approved) {
    const available = approved
      ? r.items.map(row => {
          const catalogItem = data.items.find(item => item.id === row.itemId);
          return { item: catalogItem || row.item, qty: Number(catalogItem?.qtyTotal || 0), special: Boolean(row.tireRetreadId || row.partRepairId) };
        }).filter(row => !row.special && row.qty > 0)
      : [];
    let acknowledgeAvailableStock = false;
    if (available.length) {
      const stockList = available.map(row => `${row.item.name}: ${row.qty.toLocaleString("id-ID")} ${row.item.unit}`).join("\n");
      acknowledgeAvailableStock = window.confirm(`PERINGATAN STOK\n\nBarang berikut masih tersedia di Inventory:\n${stockList}\n\nApakah Anda tetap ingin menyetujui permintaan pembelian ini?`);
      if (!acknowledgeAvailableStock) return;
    }

    const submitApproval = (acknowledged) => api(`/purchasing/requests/${r.id}/approval`, {
      method: "PATCH",
      body: JSON.stringify({ approved, acknowledgeAvailableStock: acknowledged, quantities: Object.fromEntries(r.items.map(i => [i.id, i.originalQty])) }),
    });

    try {
      await submitApproval(acknowledgeAvailableStock);
      await load();
    } catch (err) {
      const message = String(err.message || "Gagal memproses persetujuan");
      if (approved && message.startsWith("Stok masih tersedia:")) {
        const confirmed = window.confirm(`PERINGATAN STOK TERBARU\n\n${message}\n\nTetap setujui permintaan pembelian?`);
        if (confirmed) {
          await submitApproval(true);
          await load();
        }
        return;
      }
      window.alert(message);
    }
  }
  function openPoForm(request) {
    setPoRequest(request); setFormError(""); setNewSupplier(!data.suppliers.length);
    const retreadSupplierId = request.items.find(i => i.tireRetread?.supplierId)?.tireRetread?.supplierId;
    setPoRequestIds([request.id]);
    setPoForm({ supplierId: retreadSupplierId || data.suppliers[0]?.id || "", quantities: Object.fromEntries(poCandidates.flatMap(candidate => candidate.items.map(item => [item.id, item.tireRetreadId || item.partRepairId ? 1 : candidate.purpose === "STOCK" ? "" : (item.approvedQty ?? item.originalQty)]))), prices: {}, tax: 0, shippingCost: 0, discount: 0, paymentTerms: "Ditagihkan kemudian", deliveryAddress: "", estimatedArrival: "" });
    setModal("po");
  }
  async function createPurchaseOrder(e) {
    e.preventDefault(); setBusy(true); setFormError("");
    try {
      let supplierId = poForm.supplierId;
      if (newSupplier) {
        const created = await api("/purchasing/suppliers", { method: "POST", body: JSON.stringify(supplierForm) });
        supplierId = created.supplier.id;
      }
      if (!selectedPoRequests.length) throw new Error("Pilih minimal satu permintaan");
      await api("/purchasing/orders/bulk", { method: "POST", body: JSON.stringify({ ...poForm, supplierId, orders: selectedPoRequests.map(request => ({ requestId: request.id, items: request.items.map(item => ({ purchaseRequestItemId: item.id, qty: item.tireRetreadId || item.partRepairId ? 1 : request.purpose === "STOCK" ? poForm.quantities[item.id] : (item.approvedQty ?? item.originalQty) })) })) }) });
      setModal(""); setPoRequest(null); setPoRequestIds([]); setSupplierForm({ name: "", phone: "", email: "", address: "" }); setTab("orders"); await load();
    } catch (err) { setFormError(err.message); } finally { setBusy(false); }
  }
  async function createDirectOrder(event) {
    event.preventDefault();
    setDirectBusy(true); setFormError("");
    try {
      if (!directLines.length || directLines.some(line => !line.itemId)) throw new Error("Pilih barang pada setiap baris");
      if (directLines.some(line => !(Number(line.qty) > 0))) throw new Error("Jumlah setiap barang wajib lebih dari 0");
      if (new Set(directLines.map(line => line.itemId)).size !== directLines.length) throw new Error("Barang yang sama tidak boleh dimasukkan dua kali");
      const availableItems = directLines.map(line => data.items.find(item => item.id === line.itemId)).filter(item => Number(item?.qtyTotal || 0) > 0);
      if (availableItems.length && !window.confirm(`Stok berikut masih tersedia:\n${availableItems.map(item => `${item.name}: ${Number(item.qtyTotal).toLocaleString("id-ID")} ${item.unit}`).join("\n")}\n\nTetap buat PO langsung?`)) return;
      let supplierId = directForm.supplierId;
      if (newSupplier) {
        if (!supplierForm.name.trim()) throw new Error("Nama supplier wajib diisi");
        const created = await api("/purchasing/suppliers", { method: "POST", body: JSON.stringify(supplierForm) });
        supplierId = created.supplier.id;
      }
      await api("/purchasing/orders/direct", { method: "POST", body: JSON.stringify({ ...directForm, itemId: undefined, qty: undefined, items: directLines.map(line => ({ itemId: line.itemId, qty: Number(line.qty) })), supplierId }) });
      setModal(""); setSupplierForm({ name: "", phone: "", email: "", address: "" }); setTab("orders"); await load();
    } catch (err) { setFormError(err.message); }
    finally { setDirectBusy(false); }
  }
  async function changePoStatus(po, status) {
    setBusy(true); try { await api(`/purchasing/orders/${po.id}/status`, { method: "PATCH", body: JSON.stringify({ status }) }); await load(); } catch (err) { setFormError(err.message); } finally { setBusy(false); }
  }
  function openCancelPo(po) {
    setCancelPo(po); setCancellationReason(""); setFormError(""); setModal("cancel-po");
  }
  function openSupplierChange(po) {
    setSupplierChangePo(po); setReplacementSupplierId(""); setFormError(""); setModal("change-po-supplier");
  }
  async function changePurchaseOrderSupplier(event) {
    event.preventDefault(); setBusy(true); setFormError("");
    try {
      await api(`/purchasing/orders/${supplierChangePo.id}/supplier`, { method: "PATCH", body: JSON.stringify({ supplierId: replacementSupplierId }) });
      setModal(""); setSupplierChangePo(null); setReplacementSupplierId(""); await load();
    } catch (error) { setFormError(error.message || "Gagal mengganti supplier"); }
    finally { setBusy(false); }
  }
  async function cancelPurchaseOrder(event) {
    event.preventDefault(); setBusy(true); setFormError("");
    try {
      await api(`/purchasing/orders/${cancelPo.id}/cancel`, { method: "PATCH", body: JSON.stringify({ reason: cancellationReason }) });
      setModal(""); setCancelPo(null); setCancellationReason(""); await load();
    } catch (err) { setFormError(err.message); }
    finally { setBusy(false); }
  }
  function openReceiptForm(po, repairOnly = false) {
    setReceiptPo(po); setFormError("");
    setReceiptRepairOnly(repairOnly);
    const candidates = data.orders.filter(order => order.supplierId === po.supplierId && ["SENT_TO_SUPPLIER", "PARTIALLY_RECEIVED"].includes(order.status) && (!repairOnly || order.items.some(item => item.tireRetreadId || item.partRepairId)));
    const candidateItems = candidates.flatMap(order => order.items);
    setReceiptPoIds([po.id]);
    setReceiptForm({ locationId: data.locations[0]?.id || "", locationName: "Gudang Utama", quantities: Object.fromEntries(candidateItems.map(i => [i.id, i.qty - i.receivedQty])), prices: Object.fromEntries(candidateItems.map(i => [i.id, i.unitPrice > 0 ? String(i.unitPrice) : ""])), serials: Object.fromEntries(candidateItems.map(i => [i.id, ""])), retreadUnitIds: Object.fromEntries(candidateItems.map(i => [i.id, i.tireRetread?.stockUnitId ? [i.tireRetread.stockUnitId] : []])), repairUnitIds: Object.fromEntries(candidateItems.map(i => [i.id, i.partRepair?.stockUnitId ? [i.partRepair.stockUnitId] : []])), deliveryNote: "", notes: "" });
    setReceiptProofFile(null);
    setModal("receipt");
  }
  function toggleReceiptOrder(poId) {
    setReceiptPoIds(current => current.includes(poId) ? current.filter(id => id !== poId) : [...current, poId]);
  }
  function toggleAllReceiptOrders() {
    setReceiptPoIds(current => receiptOrderOptions.length > 0 && receiptOrderOptions.every(po => current.includes(po.id)) ? [] : receiptOrderOptions.map(po => po.id));
  }
  async function createReceipt(e) {
    e.preventDefault(); setBusy(true); setFormError("");
    try {
      let locationId = receiptForm.locationId;
      if (!locationId) { const created = await api("/inventory/locations", { method: "POST", body: JSON.stringify({ name: receiptForm.locationName }) }); locationId = created.location.id; }
      if (receiptProofFile) setReceiptUploadProgress(0);
      const proof = receiptProofFile ? (await uploadFiles([receiptProofFile], { onProgress: setReceiptUploadProgress }))[0] : null;
      if (!selectedReceiptOrders.length) throw new Error("Pilih minimal satu PO yang diterima");
      const receiptItems = po => po.items.map(i => ({
          purchaseOrderItemId: i.id,
          qty: Number(receiptForm.quantities[i.id] || 0),
          unitPrice: Number(receiptForm.prices[i.id] || 0),
          condition: "GOOD",
          units: i.item.isSerialized ? [
            ...(receiptForm.retreadUnitIds[i.id] || []).map(retreadUnitId => ({ retreadUnitId })),
            ...(receiptForm.repairUnitIds[i.id] || []).map(repairUnitId => ({ repairUnitId })),
            ...String(receiptForm.serials[i.id] || "").split("\n").slice(0, Math.max(0, Math.floor(Number(receiptForm.quantities[i.id] || 0)))).map(x => x.trim()).filter(Boolean).map(serialNumber => ({ serialNumber })),
          ] : undefined,
        })).filter(i => i.qty > 0);
      await api("/purchasing/receipts/batch", { method: "POST", body: JSON.stringify({ locationId, deliveryNote: receiptForm.deliveryNote, deliveryNoteProofUrl: proof?.url, deliveryNoteFileName: proof?.fileName, deliveryNoteMimeType: proof?.mimeType, deliveryNoteSize: proof?.size, notes: receiptForm.notes, receipts: selectedReceiptOrders.map(po => ({ purchaseOrderId: po.id, items: receiptItems(po) })) }) });
      setModal(""); setReceiptPo(null); setReceiptPoIds([]); setTab("receipts"); if (receiptRepairOnly) setReceiptTab("repairs"); await load();
    } catch (err) { setFormError(err.message); } finally { setBusy(false); setReceiptUploadProgress(null); }
  }
  function openBillForm() {
    const first = data.suppliers.find(supplier => data.orders.some(po => po.supplierId === supplier.id && po.receipts.some(receipt => receipt.items.some(item => !isReceiptItemFullyBilled(item)))) || data.repairBillCandidates.some(row => row.repairSupplierId === supplier.id && !row.supplierBillRepairItem));
    setBillForm({ supplierId: first?.id || "", invoiceNumber: "", invoiceDate: new Date().toISOString().slice(0, 10), dueDate: "", notes: "", receiptIds: [], itemIds: [], itemPrices: {}, itemQuantities: {}, repairMovementIds: [] });
    setBillReceiptPeriod({ from: "", to: "" });
    setBillProofFiles([]); setFormError(""); setModal("bill");
  }
  function changeBillReceiptPeriod(field, value) {
    setBillReceiptPeriod(current => {
      const next = { ...current, [field]: value };
      if (field === "from" && value && next.to && value > next.to) next.to = "";
      if (field === "to" && value && next.from && value < next.from) next.from = "";
      return next;
    });
    setBillForm(current => ({ ...current, receiptIds: [], itemIds: [], itemPrices: {}, itemQuantities: {} }));
  }
  function resetBillReceiptPeriod() {
    setBillReceiptPeriod({ from: "", to: "" });
    setBillForm(current => ({ ...current, receiptIds: [], itemIds: [], itemPrices: {}, itemQuantities: {} }));
  }
  function toggleRepairBillItem(movementId) {
    setBillForm(current => ({ ...current, repairMovementIds: current.repairMovementIds.includes(movementId) ? current.repairMovementIds.filter(id => id !== movementId) : [...current.repairMovementIds, movementId] }));
  }
  function toggleBillReceiptGroup(entries) {
    const receipts = entries.map(({receipt}) => receipt);
    setBillForm(current => {
      const removing = receipts.every(receipt => current.receiptIds.includes(receipt.id));
      const receiptIdSet = new Set(receipts.map(receipt => receipt.id));
      const availableItems = receipts.flatMap(receipt => receipt.items.filter(item => !isReceiptItemFullyBilled(item) && item.condition !== "RETURNED_TO_SUPPLIER"));
      const availableItemIds = new Set(availableItems.map(item => item.id));
      const receiptIds = removing ? current.receiptIds.filter(id => !receiptIdSet.has(id)) : [...new Set([...current.receiptIds, ...receiptIdSet])];
      const itemIds = removing ? current.itemIds.filter(id => !availableItemIds.has(id)) : [...new Set([...current.itemIds, ...availableItemIds])];
      const itemPrices = { ...current.itemPrices };
      const itemQuantities = { ...current.itemQuantities };
      availableItems.forEach(item => {
        if (removing) { delete itemPrices[item.id]; delete itemQuantities[item.id]; }
        else {
          itemPrices[item.id] = item.purchaseOrderItem?.unitPrice > 0 ? String(item.purchaseOrderItem.unitPrice) : "";
          itemQuantities[item.id] = String(remainingReceiptItemQty(item));
        }
      });
      return { ...current, receiptIds, itemIds, itemPrices, itemQuantities };
    });
  }
  function toggleAllBillReceipts() {
    setBillForm(current => {
      const allSelected = selectableBillReceipts.length > 0 && selectableBillReceipts.every(({ receipt }) => current.receiptIds.includes(receipt.id));
      if (allSelected) return { ...current, receiptIds: [], itemIds: [], itemPrices: {}, itemQuantities: {} };
      const availableItems = selectableBillReceipts.flatMap(({ receipt }) => receipt.items.filter(item => !isReceiptItemFullyBilled(item) && item.condition !== "RETURNED_TO_SUPPLIER"));
      return {
        ...current,
        receiptIds: selectableBillReceipts.map(({ receipt }) => receipt.id),
        itemIds: availableItems.map(item => item.id),
        itemPrices: Object.fromEntries(availableItems.map(item => [item.id, item.purchaseOrderItem?.unitPrice > 0 ? String(item.purchaseOrderItem.unitPrice) : ""])),
        itemQuantities: Object.fromEntries(availableItems.map(item => [item.id, String(remainingReceiptItemQty(item))])),
      };
    });
  }
  function setBillItemGroupPrice(group, value) {
    setBillForm(current => ({
      ...current,
      itemPrices: {
        ...current.itemPrices,
        ...Object.fromEntries(group.rows.filter(({ item }) => current.itemIds.includes(item.id)).map(({ item }) => [item.id, value])),
      },
    }));
  }
  function setBillItemGroupQuantity(group, rawValue) {
    setBillForm(current => {
      let quantityLeft = Math.max(0, Number(rawValue || 0));
      const groupIds = new Set(group.rows.map(({ item }) => item.id));
      const itemIds = current.itemIds.filter(id => !groupIds.has(id));
      const itemPrices = { ...current.itemPrices };
      const itemQuantities = { ...current.itemQuantities };
      const fifoRows = [...group.rows].sort((a, b) => new Date(a.receipt?.receivedAt || 0) - new Date(b.receipt?.receivedAt || 0) || String(a.receipt?.number || "").localeCompare(String(b.receipt?.number || "")));
      fifoRows.forEach(({ item }) => {
        const allocated = Math.min(quantityLeft, remainingReceiptItemQty(item));
        if (allocated > 0) {
          itemIds.push(item.id);
          itemQuantities[item.id] = String(allocated);
          if (itemPrices[item.id] === undefined || itemPrices[item.id] === "") itemPrices[item.id] = item.purchaseOrderItem?.unitPrice > 0 ? String(item.purchaseOrderItem.unitPrice) : "";
          quantityLeft -= allocated;
        } else delete itemQuantities[item.id];
      });
      return { ...current, itemIds: [...new Set(itemIds)], itemPrices, itemQuantities };
    });
  }
  async function createBill(e) {
    e.preventDefault(); setBusy(true); setFormError("");
    let printPopup = null;
    let billSaved = false;
    try {
      if (!billProofFiles.length) throw new Error("Lampirkan minimal satu invoice supplier untuk proses pencocokan");
      printPopup = window.open("", "_blank");
      if (printPopup) {
        printPopup.document.open();
        printPopup.document.write('<!doctype html><html><head><meta charset="utf-8"><title>Menyimpan tagihan…</title></head><body style="font-family:Arial,sans-serif;padding:24px;color:#334c3e">Menyimpan tagihan dan menyiapkan bukti penerimaan…</body></html>');
        printPopup.document.close();
      }
      const proofs = await uploadFiles(billProofFiles);
      const result = await api("/purchasing/bills", { method: "POST", body: JSON.stringify({ ...billForm, proofs }) });
      billSaved = true;
      setModal(""); setTab("payments"); await load();
      if (printPopup) await openPrintDocument(`/purchasing/bills/${result.bill.id}/receipt-print`, printPopup);
    } catch (err) {
      printPopup?.close();
      if (billSaved) window.alert(`Tagihan berhasil disimpan, tetapi dokumen cetak gagal dibuka: ${err.message}`);
      else setFormError(err.message);
    } finally { setBusy(false); }
  }
  function openPaymentForm(bill) {
    const committed = bill.payments.filter(p => p.status !== "UNPAID").reduce((sum, p) => sum + p.amount, 0);
    setPaymentPo(bill); setFormError(""); setPaymentForm({ amount: String(Math.max(0, bill.amount - committed)), method: "BANK_TRANSFER", reference: "" }); setPaymentProofFile(null); setModal("payment");
  }
  async function createPayment(e) {
    e.preventDefault(); setBusy(true); setFormError("");
    try { if (!paymentProofFile) throw new Error("Bukti pembayaran wajib dipilih"); const proof=(await uploadFiles([paymentProofFile]))[0]; await api("/purchasing/payments", { method: "POST", body: JSON.stringify({ ...paymentForm, supplierBillId: paymentPo.id, proofUrl:proof?.url, proofFileName:proof?.fileName, proofMimeType:proof?.mimeType, proofSize:proof?.size }) }); setModal(""); setPaymentPo(null); setPaymentProofFile(null); setTab("payments"); await load(); }
    catch (err) { setFormError(err.message); } finally { setBusy(false); }
  }
  async function approvePayment(payment) {
    setBusy(true); try { await api(`/purchasing/payments/${payment.id}/approve`, { method: "PATCH" }); await load(); } finally { setBusy(false); }
  }
  const billReceipts = data.orders.filter(po=>po.supplierId===billForm.supplierId).flatMap(po=>po.receipts.map(receipt=>({receipt,po}))).filter(({receipt})=>billForm.receiptIds.includes(receipt.id));
  const selectableBillReceipts = data.orders.filter(po=>po.supplierId===billForm.supplierId).flatMap(po=>po.receipts.map(receipt=>({receipt,po}))).filter(({receipt})=>{
    const receivedDate = localDateKey(receipt.receivedAt);
    const insidePeriod = (!billReceiptPeriod.from || receivedDate >= billReceiptPeriod.from) && (!billReceiptPeriod.to || receivedDate <= billReceiptPeriod.to);
    return insidePeriod && receipt.items.some(item=>!isReceiptItemFullyBilled(item)&&item.condition!=="RETURNED_TO_SUPPLIER");
  }).sort((a,b)=>new Date(a.receipt.receivedAt)-new Date(b.receipt.receivedAt)||String(a.receipt.number).localeCompare(String(b.receipt.number)));
  const selectableBillReceiptGroups = [...selectableBillReceipts.reduce((groups, entry) => {
    const key = receiptGroupKey(entry.po.supplierId, entry.receipt);
    const group = groups.get(key) || { key, entries: [] };
    group.entries.push(entry);
    groups.set(key, group);
    return groups;
  }, new Map()).values()];
  const allBillReceiptsSelected = selectableBillReceipts.length > 0 && selectableBillReceipts.every(({receipt})=>billForm.receiptIds.includes(receipt.id));
  const billItemCandidates = billReceipts.flatMap(({receipt,po})=>receipt.items.filter(item=>!isReceiptItemFullyBilled(item)&&item.condition!=="RETURNED_TO_SUPPLIER").map(item=>({item,receipt,po})));
  const billItemGroups = [...billItemCandidates.reduce((groups, row) => {
    const catalogItem = row.item.purchaseOrderItem?.item;
    const itemKey = row.item.purchaseOrderItem?.itemId || catalogItem?.sku || row.item.id;
    const rawPrice = billForm.itemPrices[row.item.id];
    const priceKey = rawPrice === undefined || rawPrice === "" ? "EMPTY" : String(Number(rawPrice));
    const key = `${receiptGroupKey(row.po.supplierId, row.receipt)}::${itemKey}::${priceKey}`;
    const group = groups.get(key) || { key, item: catalogItem, rows: [] };
    group.rows.push(row);
    groups.set(key, group);
    return groups;
  }, new Map()).values()].sort((a,b)=>new Date(a.rows[0]?.receipt?.receivedAt||0)-new Date(b.rows[0]?.receipt?.receivedAt||0)||String(a.rows[0]?.receipt?.number||"").localeCompare(String(b.rows[0]?.receipt?.number||""))||String(a.item?.name||"").localeCompare(String(b.item?.name||""),"id"));
  const billItemReceiptGroups = [...billItemGroups.reduce((groups, itemGroup) => {
    const receipt = itemGroup.rows[0]?.receipt;
    const po = itemGroup.rows[0]?.po;
    const key = receiptGroupKey(po?.supplierId, receipt);
    const receipts = billReceipts.filter(entry => receiptGroupKey(entry.po.supplierId, entry.receipt) === key).map(entry => entry.receipt);
    const group = groups.get(key) || { key, receipts, itemGroups: [] };
    group.itemGroups.push(itemGroup);
    groups.set(key, group);
    return groups;
  }, new Map()).values()];
  const billItems = billItemCandidates.filter(({item})=>billForm.itemIds.includes(item.id));
  const selectableRepairBillItems = (data.repairBillCandidates||[]).filter(row=>row.repairSupplierId===billForm.supplierId&&!row.supplierBillRepairItem);
  const selectedRepairBillItems = selectableRepairBillItems.filter(row=>billForm.repairMovementIds.includes(row.id));
  const billTotal = billItems.reduce((sum,row)=>sum+Number(billForm.itemQuantities[row.item.id]||0)*Number(billForm.itemPrices[row.item.id]||0),0)+selectedRepairBillItems.reduce((sum,row)=>sum+Number(row.totalCost||0),0);
  const billPricesValid = (billItems.length > 0 || selectedRepairBillItems.length > 0) && billItems.every(({item}) => {
    const value = billForm.itemPrices[item.id];
    const price = Number(value);
    const quantity = Number(billForm.itemQuantities[item.id]);
    return value !== undefined && value !== "" && Number.isFinite(price) && price >= 0 && (item.purchaseOrderItem?.partRepairId || price > 0) && Number.isFinite(quantity) && quantity > 0 && quantity <= remainingReceiptItemQty(item);
  });
  const renderBillItemGroup = group => {
    const selectedRows = group.rows.filter(({item})=>billForm.itemIds.includes(item.id));
    const selectedQty = selectedRows.reduce((sum,{item})=>sum+Number(billForm.itemQuantities[item.id]||0),0);
    const selected = selectedQty > 0;
    const unitPrice = selectedRows.length ? billForm.itemPrices[selectedRows[0].item.id] ?? "" : "";
    const availableQty = group.rows.reduce((sum,{item})=>sum+remainingReceiptItemQty(item),0);
    const unit = group.item?.unit || "unit";
    const stableGroupKey = group.rows.map(({item})=>item.id).sort().join("|");
    return <div className={`supplier-bill-flat-row ${selected?"is-selected":"is-unselected"}`} key={stableGroupKey}><span><strong>{group.item?.name||"Barang tanpa nama"}</strong><small>{group.item?.sku||"Tanpa SKU"} · tersedia {availableQty.toLocaleString("id-ID")} {unit}</small></span><div className="supplier-bill-qty-input"><label className="supplier-bill-qty-check"><input type="checkbox" checked={selected} onChange={()=>setBillItemGroupQuantity(group,selected?0:availableQty)} aria-label={`${selected?"Batalkan":"Pilih"} ${group.item?.name||"barang"}`}/><i>{selected?<FiCheck/>:null}</i></label><input aria-label={`Qty ditagih ${group.item?.name||"barang"}`} min="0" max={availableQty} step="0.01" type="number" value={selectedQty||""} onChange={event=>setBillItemGroupQuantity(group,event.target.value)} placeholder="0"/><span>{unit}</span></div><input aria-label={`Harga satuan ${group.item?.name||"barang"}`} disabled={!selected} required={selected} min={group.rows.some(({item})=>item.purchaseOrderItem?.partRepairId)?"0":"1"} step="1" type="number" value={unitPrice} onChange={event=>setBillItemGroupPrice(group,event.target.value)} placeholder="Masukkan harga"/><strong>{selected?money(selectedQty*Number(unitPrice||0)):"—"}</strong></div>;
  };
  const activeListKey = tab === "receipts" && receiptTab === "repairs" ? "repairReceipts" : tab;
  const activeStatus = listStatuses[activeListKey] || "PROCESSING";
  const normalizedQuery = String(listFilters[activeListKey] || "").trim().toLocaleLowerCase("id-ID");
  const matchesQuery = values => !normalizedQuery || values.flat(Infinity).filter(Boolean).join(" ").toLocaleLowerCase("id-ID").includes(normalizedQuery);
  const statusMatches = bucket => activeStatus === "ALL" || bucket === activeStatus;
  const requestBucket = row => {
    const progress = requestProgress(row, data.orders).className;
    if (["FULLY_RECEIVED", "CANCELLED", "REJECTED"].includes(progress)) return "COMPLETED";
    // Setelah PO aktif dibuat, pekerjaan di tahap Permintaan Pembelian selesai.
    // Kelanjutan pemesanan dan penerimaan dipantau di tab berikutnya.
    if (activeOrdersForRequest(row.id, data.orders).length) return "COMPLETED";
    return "PROCESSING";
  };
  const orderBucket = row => ["FULLY_RECEIVED", "CANCELLED", "REJECTED"].includes(row.status) ? "COMPLETED" : "PROCESSING";
  const filteredRequests = data.requests.filter(row => statusMatches(requestBucket(row)) && matchesQuery([row.number,row.reason,row.purpose,row.status,row.maintenance?.truck?.plateNumber,row.items.map(item=>[item.item?.name,item.item?.sku])]));
  const filteredOrders = data.orders.filter(row => statusMatches(orderBucket(row)) && matchesQuery([row.number,row.status,row.supplier?.name,poRequestNumbers(row),row.items.map(item=>[item.item?.name,item.item?.sku])]));
  const receiptGroups = [...data.orders.flatMap(po=>po.receipts.map(gr=>({po,gr}))).reduce((groups, entry) => {
    const key = receiptGroupKey(entry.po.supplierId, entry.gr);
    const group = groups.get(key) || { key, entries: [] };
    group.entries.push(entry);
    groups.set(key, group);
    return groups;
  }, new Map()).values()];
  const receiptBucket = group => {
    const activeItems = group.entries.flatMap(({gr})=>gr.items.filter(isActiveReceiptItem));
    return activeItems.length > 0 && activeItems.every(isReceiptItemFullyBilled) ? "COMPLETED" : "PROCESSING";
  };
  const filteredReceipts = receiptGroups.filter(group=>statusMatches(receiptBucket(group))&&group.entries.some(({gr})=>gr.items.some(isActiveReceiptItem))&&matchesQuery(group.entries.map(({po,gr})=>[gr.number,gr.deliveryNote,gr.notes,gr.location?.name,po.number,po.supplier?.name,gr.items.filter(isActiveReceiptItem).map(item=>[item.purchaseOrderItem?.item?.name,item.purchaseOrderItem?.item?.sku])])));
  const pendingRepairOrders = data.orders.filter(po=>["SENT_TO_SUPPLIER","PARTIALLY_RECEIVED"].includes(po.status)&&po.items.some(item=>item.tireRetreadId||item.partRepairId)&&matchesQuery([po.number,po.supplier?.name,po.request?.number,po.items.map(item=>[item.item?.name,item.item?.sku,item.tireRetread?.stockUnit?.serialNumber,item.partRepair?.stockUnit?.serialNumber])]));
  const repairBucket = row => row.status === "COMPLETED" ? "COMPLETED" : "PROCESSING";
  const filteredRepairReceipts = (data.nonSerializedRepairQueue || []).filter(row=>statusMatches(repairBucket(row))&&matchesQuery([row.item?.sku,row.item?.name,row.maintenance?.number,row.maintenance?.title,row.maintenance?.truck?.plateNumber,row.status,row.note]));
  const billBucket = row => row.status === "PAID" ? "COMPLETED" : "PROCESSING";
  const filteredBills = data.bills.filter(row => statusMatches(billBucket(row)) && matchesQuery([row.number,row.invoiceNumber,row.status,row.supplier?.name,row.receipts.map(item=>item.receipt?.number),row.items?.map(item=>item.receiptItem?.purchaseOrderItem?.item?.name)]));
  const activeRows = ({ requests: data.requests, orders: data.orders, receipts: receiptGroups, repairReceipts: data.nonSerializedRepairQueue || [], payments: data.bills })[activeListKey] || [];
  const activeBucket = ({ requests: requestBucket, orders: orderBucket, receipts: receiptBucket, repairReceipts: repairBucket, payments: billBucket })[activeListKey];
  const statusCounts = activeRows.reduce((counts,row)=>{const bucket=activeBucket(row);counts[bucket]=(counts[bucket]||0)+1;return counts;},{PROCESSING:0,COMPLETED:0});
  const processingCounts = {
    requests: data.requests.filter(row=>requestBucket(row)==="PROCESSING").length,
    orders: data.orders.filter(row=>orderBucket(row)==="PROCESSING").length,
    receipts: receiptGroups.filter(group=>receiptBucket(group)==="PROCESSING").length,
    payments: data.bills.filter(row=>billBucket(row)==="PROCESSING").length,
  };
  const PAGE_SIZE = 10;
  const pageSlice = (rows,key=activeListKey) => rows.slice((Math.max(1,listPages[key]||1)-1)*PAGE_SIZE,Math.max(1,listPages[key]||1)*PAGE_SIZE);
  const pagedRequests = pageSlice(filteredRequests,"requests"), pagedOrders = pageSlice(filteredOrders,"orders"), pagedReceipts = pageSlice(filteredReceipts,"receipts"), pagedRepairReceipts = pageSlice(filteredRepairReceipts,"repairReceipts"), pagedBills = pageSlice(filteredBills,"payments");
  const currentTotal = ({requests:filteredRequests.length,orders:filteredOrders.length,receipts:filteredReceipts.length,repairReceipts:filteredRepairReceipts.length,payments:filteredBills.length})[activeListKey]||0;
  const searchPlaceholder = ({requests:"Cari nomor permintaan, barang, alasan, atau kendaraan…",orders:"Cari nomor PO, supplier, permintaan, atau barang…",receipts:"Cari nomor penerimaan, PO, supplier, surat jalan, atau barang…",repairReceipts:"Cari barang perbaikan, servis, atau kendaraan…",payments:"Cari nomor invoice, supplier, penerimaan, atau barang…"})[activeListKey];
  return <div className="purchasing">
    <header className="p-head"><div><div className="eyebrow">BENGKEL & PEMBELIAN</div><h1>Pembelian</h1><p>Kelola permintaan, pemesanan, penerimaan, hingga tagihan supplier.</p></div><div className="p-head-actions"><button className="p-direct-order" onClick={openSupplierForm}><FiPlus/> Tambah Supplier</button>{canCreateDirectOrder&&<button className="p-direct-order" onClick={openDirectOrderForm}><FiShoppingCart/> Buat PO Langsung</button>}<button className="primary p-new-request" onClick={openRequestForm}><FiPlus/> Buat Permintaan</button></div></header>
    <section className="p-stats"><article><div className="p-stat-icon"><FiFileText/></div><div><span>Perlu persetujuan</span><strong>{stats.waiting}</strong><small>Permintaan menunggu tindakan</small></div></article><article><div className="p-stat-icon"><FiShoppingCart/></div><div><span>PO berjalan</span><strong>{stats.open}</strong><small>Belum diterima penuh</small></div></article><article><div className="p-stat-icon"><FiPackage/></div><div><span>Nilai pembelian</span><strong>{money(stats.spend)}</strong><small>PO valid, tidak termasuk ditolak/dibatalkan</small></div></article></section>
    <nav className="p-tabs"><button className={tab==="requests"?"active":""} onClick={()=>setTab("requests")}>Permintaan Pembelian <i>{processingCounts.requests}</i></button><button className={tab==="orders"?"active":""} onClick={()=>setTab("orders")}>Pesanan Pembelian <i>{processingCounts.orders}</i></button><button onClick={()=>setTab("receipts")} className={tab==="receipts"?"active":""}>Penerimaan Barang <i>{processingCounts.receipts}</i></button><button onClick={()=>setTab("payments")} className={tab==="payments"?"active":""}>Tagihan & Pembayaran <i>{processingCounts.payments}</i></button><button className="refresh" onClick={load}><FiRefreshCw className={busy?"spin":""}/></button></nav>
    <section className={`p-panel ${busy && !data.requests.length && !data.orders.length ? "initial-loading" : ""}`}>
      {busy && !data.requests.length && !data.orders.length && <LoadingState label="Memuat pembelian" note="Menyiapkan permintaan, PO, penerimaan, dan pembayaran…" rows={5} />}
      {tab==="receipts"&&<nav className="receipt-subtabs"><button type="button" className={receiptTab==="purchases"?"active":""} onClick={()=>setReceiptTab("purchases")}><FiPackage/> Penerimaan PO</button><button type="button" className={receiptTab==="repairs"?"active":""} onClick={()=>setReceiptTab("repairs")}><FiRefreshCw/> Barang Perbaikan <i>{(data.nonSerializedRepairQueue||[]).filter(row=>row.remainingQty>0).length}</i></button></nav>}
      <div className="p-status-filters" role="group" aria-label="Filter status proses">{[["PROCESSING","Proses"],["COMPLETED","Selesai"]].map(([value,text])=><button type="button" key={value} className={activeStatus===value?"active":""} onClick={()=>{setListStatuses(current=>({...current,[activeListKey]:value}));setListPages(current=>({...current,[activeListKey]:1}))}}>{text}<i>{statusCounts[value]||0}</i></button>)}</div>
      <div className="p-list-tools"><label><FiSearch/><input value={listFilters[activeListKey]||""} onChange={e=>{setListFilters(current=>({...current,[activeListKey]:e.target.value}));setListPages(current=>({...current,[activeListKey]:1}))}} placeholder={searchPlaceholder}/></label><span>Maksimal 10 data per halaman</span></div>
      {tab==="requests" && <div className="table-wrap purchase-request-table-wrap"><table className="request-table purchase-request-table"><colgroup><col className="request-number-col"/><col className="request-needs-col"/><col className="request-photo-col"/><col className="request-target-col"/><col className="request-urgency-col"/><col className="request-status-col"/><col className="request-action-col"/></colgroup><thead><tr><th>Nomor</th><th>Kebutuhan</th><th>Bukti foto</th><th>Untuk</th><th>Urgensi</th><th>Status proses</th><th>Aksi</th></tr></thead><tbody>{pagedRequests.map(r=>{const progress=requestProgress(r,data.orders);const hasPo=activeOrdersForRequest(r.id,data.orders).length>0;const requestTruck=data.trucks.find(truck=>truck.id===r.truckId);const damageProofs=r.damageProofs?.length?r.damageProofs:r.damageProofUrl?[{id:"legacy",url:r.damageProofUrl,mimeType:r.damageProofMimeType,fileName:r.damageProofFileName}]:[];return <tr key={r.id} className={r.maintenance?"direct-maintenance-row":""}><td><b>{r.number}</b><small>{new Date(r.createdAt).toLocaleDateString("id-ID")}</small>{r.maintenance&&<span className="direct-use-badge">UNTUK SERVIS</span>}{r.approvalNotes?.startsWith("Pembelian langsung")&&<span className="direct-use-badge">PO LANGSUNG</span>}</td><td>{r.items.map(i=><div key={i.id}>{i.item.name} · {r.purpose==="STOCK"&&!i.tireRetreadId&&!i.partRepairId&&Number(i.originalQty)<=0?"Jumlah saat PO":`${i.approvedQty??i.originalQty} ${i.item.unit}`}</div>)}<small>{r.reason}</small></td><td>{damageProofs.length?<div className="request-row-proofs"><div>{damageProofs.map((proof,index)=><ProtectedFilePreview key={proof.id||`${proof.url}-${index}`} url={proof.url} mimeType={proof.mimeType} fileName={proof.fileName||`Bukti kerusakan ${index+1}`} imageStyle={{width:48,height:38,objectFit:"cover",borderRadius:7}} onError={error=>setFormError(error.message)}/>)}</div><small>{damageProofs.length} foto bukti</small></div>:<span className="request-proof-empty">Tidak ada bukti</span>}</td><td>{r.maintenance?<><b>Servis {r.maintenance?.truck?.plateNumber||"kendaraan"}</b><small>{r.maintenance?.title}</small></>:r.purpose==="TRUCK"?<><b>Truk {requestTruck?.plateNumber||"tertentu"}</b>{requestTruck&&<small>{[requestTruck.brand,requestTruck.model].filter(Boolean).join(" ")}</small>}</>:"Persediaan umum"}</td><td><span className={`urg ${r.urgency}`}>{r.urgency}</span></td><td><span className={`status ${progress.className}`}>{progress.text}</span>{progress.orderNumber&&<small className="request-progress-order">{progress.orderNumber}</small>}{r.status==="APPROVED"&&r.approvedBy?.name&&<small className="approval-person">Disetujui oleh {r.approvedBy.name}</small>}</td><td className="request-action-cell">{owner&&r.status==="WAITING_APPROVAL"&&<div className="actions request-decision-actions"><button type="button" className="approve" onClick={()=>approve(r,true)}><FiCheck/> Setujui</button><button type="button" className="reject" onClick={()=>approve(r,false)}>Tolak</button></div>}{r.status==="APPROVED"&&!hasPo&&<button type="button" className="create-po-btn" onClick={()=>openPoForm(r)}><FiShoppingCart/> Buat PO</button>}{hasPo&&<button type="button" className="view-po-btn" onClick={()=>setTab("orders")}>Lihat PO <FiChevronRight/></button>}</td></tr>})}</tbody></table>{!filteredRequests.length&&<Empty text={normalizedQuery?"Permintaan tidak ditemukan":"Belum ada permintaan pembelian"}/>}</div>}
      {tab==="orders" && <div className="cards">{pagedOrders.map(po=>{const total=poTotal(po);return <article className={`po-card ${po.status==="CANCELLED"?"cancelled":""}`} key={po.id}><div><span className={`status ${po.status}`}>{label(po.status)}</span><h3>{po.number}</h3><p>{po.supplier.name} · dari {po.request.number}</p>{po.status==="CANCELLED"&&<small className="po-cancellation-note">Alasan: {po.cancellationReason}</small>}</div><div className="po-items">{po.items.map(i=><span key={i.id}>{i.item.name}<b>{i.receivedQty}/{i.qty} {i.item.unit}</b></span>)}</div><div className="po-progress"><span style={{width:`${Math.min(100,po.items.reduce((s,i)=>s+i.receivedQty,0)/Math.max(1,po.items.reduce((s,i)=>s+i.qty,0))*100)}%`}}/></div><footer><div><strong>{total>0?money(total):"Harga menyusul"}</strong><small>{total>0?"Sesuai tagihan supplier":po.paymentTerms||"Ditagihkan kemudian"}</small></div></footer><div className="po-actions"><button type="button" onClick={()=>openPrintDocument(`/purchasing/orders/${po.id}/print`).catch(err=>setFormError(err.message))}><FiPrinter/> Print PO</button>{owner&&["DRAFT","APPROVED"].includes(po.status)&&<button type="button" onClick={()=>changePoStatus(po,"SENT_TO_SUPPLIER")}>Tandai dikirim</button>}{owner&&["DRAFT","APPROVED","SENT_TO_SUPPLIER"].includes(po.status)&&!po.receipts.length&&!po.payments.length&&<button type="button" className="change-supplier-btn" onClick={()=>openSupplierChange(po)}><FiRefreshCw/> Ganti Supplier</button>}{owner&&["DRAFT","APPROVED","SENT_TO_SUPPLIER"].includes(po.status)&&!po.receipts.length&&<button type="button" className="cancel-po-btn" onClick={()=>openCancelPo(po)}><FiXCircle/> Batalkan PO</button>}{["SENT_TO_SUPPLIER","PARTIALLY_RECEIVED"].includes(po.status)&&<button type="button" className="receive" onClick={()=>openReceiptForm(po)}><FiPackage/> Terima barang</button>}</div></article>})}{!filteredOrders.length&&<Empty text={normalizedQuery?"Pesanan tidak ditemukan":"PO akan tampil setelah permintaan disetujui"}/>}</div>}
      {tab==="receipts" && receiptTab==="purchases" && <div className="receipt-list">{pagedReceipts.map(group=>{const activeEntries=group.entries.filter(({gr})=>gr.items.some(isActiveReceiptItem));const first=activeEntries[0];const allItems=activeEntries.flatMap(({gr,po})=>gr.items.filter(isActiveReceiptItem).map(item=>({item,gr,po})));const allBilled=allItems.length>0&&allItems.every(({item})=>isReceiptItemFullyBilled(item));const someBilled=allItems.some(({item})=>billedReceiptItemQty(item)>0);const invoiceCount=new Set(activeEntries.flatMap(({gr})=>gr.supplierBillLines.map(line=>line.bill?.id).filter(Boolean))).size;const totalValue=activeEntries.reduce((sum,{gr})=>sum+receiptValue(gr),0);const poNumbers=[...new Set(activeEntries.map(({po})=>po.number))];return <article className="receipt-card" key={group.key}>
        <header className="receipt-card-head"><div className="receipt-card-identity"><span className="receipt-card-icon"><FiPackage/></span><div><span className="status FULLY_RECEIVED">Barang diterima</span><h3>Surat jalan {first.gr.deliveryNote||"—"}</h3><p>{activeEntries.length} penerimaan · {poNumbers.join(", ")} · {first.po.supplier.name}</p></div></div><div className="receipt-card-date"><small>TANGGAL TERIMA</small><time>{new Date(first.gr.receivedAt).toLocaleDateString("id-ID",{day:"numeric",month:"long",year:"numeric"})}</time><span>{[...new Set(activeEntries.map(({gr})=>gr.location?.name).filter(Boolean))].join(", ")||"Lokasi tidak dicatat"}</span></div></header>
        <div className="receipt-card-body"><section className="receipt-goods"><header><span>Barang diterima</span><b>{allItems.length} barang · {activeEntries.length} GR</b></header><div className="receipt-goods-table"><div className="receipt-goods-heading"><span>Nama barang / Penerimaan</span><span>Jumlah</span></div>{allItems.map(({item,gr,po})=><div className="receipt-goods-row" key={item.id}><span><strong>{item.purchaseOrderItem?.item?.name}</strong><small>{item.purchaseOrderItem?.item?.sku||"Tanpa SKU"} · {gr.number} · {po.number}</small></span><b>{item.qty} {item.purchaseOrderItem?.item?.unit}</b></div>)}</div></section>
          <aside className="receipt-summary"><div className="receipt-summary-row"><span><small>STATUS TAGIHAN</small><strong>{allBilled?`${invoiceCount} invoice · lengkap`:someBilled?`${invoiceCount} invoice · sebagian`:"Belum ditagihkan"}</strong></span><FiFileText/></div><div className="receipt-summary-row"><span><small>NILAI PENERIMAAN</small><strong>{totalValue>0?money(totalValue):"Harga belum tersedia"}</strong></span></div>{first.gr.deliveryNoteProofUrl&&<div className="receipt-proof"><div className="receipt-proof-preview"><ProtectedFilePreview url={first.gr.deliveryNoteProofUrl} mimeType={first.gr.deliveryNoteMimeType} fileName={first.gr.deliveryNoteFileName||"Bukti surat penerimaan"} imageStyle={{width:"100%",height:126,objectFit:"cover"}} onError={e=>setFormError(e.message)}/></div><span><small>BUKTI PENERIMAAN</small><strong title={first.gr.deliveryNoteFileName||"Foto tersimpan"}>{first.gr.deliveryNoteFileName||"Foto tersimpan"}</strong></span></div>}</aside>
        </div>
        <footer className="receipt-card-foot"><span>GR: <b>{activeEntries.map(({gr})=>gr.number).join(", ")}</b>{activeEntries.some(({gr})=>gr.notes)&&<em>· {activeEntries.map(({gr})=>gr.notes).filter(Boolean).join(" · ")}</em>}</span><button type="button" onClick={()=>openPrintDocument(`/purchasing/receipts/group/print?ids=${encodeURIComponent(activeEntries.map(({gr})=>gr.id).join(","))}`).catch(err=>setFormError(err.message))}><FiPrinter/> Cetak penerimaan</button></footer>
      </article>})}{!filteredReceipts.length&&<Empty icon={<FiPackage/>} text={normalizedQuery?"Penerimaan tidak ditemukan":"Belum ada penerimaan barang"}/>}</div>}
      {tab==="receipts" && receiptTab==="repairs" && <div className="repair-receiving-content">
        {!!(data.directRetreadReceipts||[]).length&&<section className="serialized-repair-orders"><header><span><strong>Riwayat penerimaan ban masak langsung</strong><small>Ban sudah diterima ke Inventory dan tersedia untuk dicocokkan dengan tagihan supplier.</small></span><b>{(data.directRetreadReceipts||[]).length} unit diterima</b></header><div>{(data.directRetreadReceipts||[]).map(row=><article key={row.id}><span><b>{row.item?.name} · Serial {row.retreadSerialNumber||"-"}</b><small>{row.repairVendor} · {row.toLocation?.name||"Inventory"} · {new Date(row.createdAt).toLocaleString("id-ID")}</small></span><span className={`status ${row.supplierBillRepairItem?"PAID":"OPEN"}`}>{row.supplierBillRepairItem?`Masuk tagihan ${row.supplierBillRepairItem.bill?.invoiceNumber||"supplier"}`:"Belum ditagihkan"}</span><b>{money(row.totalCost)}</b></article>)}</div></section>}
        <section className="serialized-repair-orders"><header><span><strong>Ban masak & sparepart berseri</strong><small>Pilih salah satu pengiriman, lalu centang beberapa PO dari tempat perbaikan yang sama.</small></span><b>{pendingRepairOrders.reduce((sum,po)=>sum+po.items.filter(item=>(item.tireRetreadId||item.partRepairId)&&item.receivedQty<item.qty).length,0)} unit menunggu</b></header><div>{pendingRepairOrders.map(po=><article key={po.id}><span><b>{po.number} · {po.supplier?.name}</b><small>{po.items.filter(item=>item.tireRetreadId||item.partRepairId).map(item=>`${item.tireRetread?"BAN MASAK":"PERBAIKAN"} ${item.tireRetread?.stockUnit?.serialNumber||item.partRepair?.stockUnit?.serialNumber||item.item?.name}`).join(" · ")}</small></span><button type="button" className="receive" onClick={()=>openReceiptForm(po,true)}><FiCheck/> Pilih & terima</button></article>)}</div>{!pendingRepairOrders.length&&<div className="serialized-repair-empty">Belum ada Ban Masak atau sparepart berseri yang siap diterima.</div>}</section>
        <div className="table-wrap"><div className="repair-receipt-toolbar"><span><b>{selectedRepairIds.length}</b> baris dipilih · total <b>{(data.nonSerializedRepairQueue||[]).filter(row=>selectedRepairIds.includes(row.id)).reduce((sum,row)=>sum+Number(row.remainingQty||0),0).toLocaleString("id-ID")}</b> unit</span><button type="button" className="receive" disabled={!selectedRepairIds.length} onClick={openSelectedRepairReceipts}><FiPackage/> Terima yang dipilih</button></div><table className="request-table repair-receipt-table"><colgroup><col className="repair-select-col"/><col className="repair-place-col"/><col className="repair-item-col"/><col className="repair-service-col"/><col className="repair-qty-col"/><col className="repair-status-col"/><col className="repair-result-col"/><col className="repair-action-col"/></colgroup><thead><tr><th aria-label="Pilih baris"></th><th>Dikirim / Tempat</th><th>Barang non-serial</th><th>Servis / Armada</th><th>Jumlah</th><th>Status</th><th>Hasil Penerimaan</th><th>Aksi</th></tr></thead><tbody>{pagedRepairReceipts.map(repair=><tr key={repair.id}><td><input type="checkbox" disabled={repair.remainingQty<=0} checked={selectedRepairIds.includes(repair.id)} onChange={()=>toggleRepairSelection(repair)}/></td><td>{new Date(repair.createdAt).toLocaleDateString("id-ID",{day:"numeric",month:"long",year:"numeric"})}<small>{repair.repairVendor}</small></td><td><b>{repair.item?.name}</b><small>{repair.item?.sku} → {String(repair.item?.sku||"ITEM").endsWith("_SECOND")?repair.item?.sku:`${repair.item?.sku||"ITEM"}_SECOND`}</small></td><td><b>{repair.maintenance?.truck?.plateNumber||repair.fromTruck?.plateNumber||"—"}</b><small>{repair.maintenance?.number||repair.maintenance?.title||"—"}</small></td><td><b>{repair.receivedQty} / {repair.qty} {repair.item?.unit}</b><small>Sisa {repair.remainingQty} {repair.item?.unit}</small></td><td><span className={`status ${repair.status}`}>{repair.status==="COMPLETED"?"Selesai":repair.status==="PARTIALLY_RECEIVED"?"Diterima sebagian":"Dalam perbaikan"}</span></td><td>{repair.receipts?.length?repair.receipts.map(receipt=><small key={receipt.id}>{receipt.qty} {repair.item?.unit} · {money(receipt.unitPrice)}/unit · {receipt.toLocation?.name}</small>):<small>Belum diterima</small>}</td><td>{repair.remainingQty>0?<button type="button" className="receive" onClick={()=>openRepairReceipt(repair)}><FiPackage/> Terima hasil</button>:<FiCheck/>}</td></tr>)}</tbody></table>{!filteredRepairReceipts.length&&<Empty icon={<FiPackage/>} text={normalizedQuery?"Barang perbaikan tidak ditemukan":"Belum ada barang non-serial dalam perbaikan"}/>}</div>
      </div>}
      {tab==="payments" && <div className="supplier-billing"><div className="supplier-billing-toolbar"><div><strong>Tagihan supplier</strong><small>Pantau nilai tagihan, pembayaran, dan dokumen penerimaan dalam satu tempat.</small></div><button className="primary supplier-bill-create" onClick={openBillForm}><span><FiPlus/></span><b>Catat Tagihan Supplier</b></button></div><div className="supplier-bill-list">{pagedBills.map(bill=>{const paid=bill.payments.filter(row=>row.status==="PAID").reduce((sum,row)=>sum+row.amount,0);const remaining=Math.max(0,bill.amount-paid);const waiting=bill.payments.filter(row=>row.status==="WAITING_PAYMENT_APPROVAL");const approvals=bill.payments.filter(pay=>pay.status==="PAID"&&pay.approvedBy?.name);return <article className="supplier-bill-card" key={bill.id}><header className="supplier-bill-head"><div className="supplier-bill-mark"><FiFileText/></div><div className="supplier-bill-identity"><div><span className={`status ${bill.status}`}>{label(bill.status)}</span><time>{new Date(bill.invoiceDate).toLocaleDateString("id-ID",{day:"numeric",month:"short",year:"numeric"})}</time></div><h3>{bill.invoiceNumber||"Tanpa nomor invoice"}</h3><p>{bill.supplier.name}</p></div></header><div className="supplier-bill-values"><div><small>Total tagihan</small><strong>{money(bill.amount)}</strong></div><div><small>Sudah dibayar</small><strong>{money(paid)}</strong></div><div className={remaining>0?"has-balance":"is-settled"}><small>Sisa tagihan</small><strong>{money(remaining)}</strong></div></div><div className="supplier-bill-meta"><span><FiPackage/><b>{bill.receipts.length}</b> penerimaan</span><span><FiCheck/><b>{bill.items?.length||0}</b> barang dicocokkan</span></div>{approvals.length>0&&<div className="supplier-bill-approvals">{approvals.map(pay=><span key={pay.id}><FiCheck/> {money(pay.amount)} disetujui oleh <b>{pay.approvedBy.name}</b></span>)}</div>}<footer className="supplier-bill-actions"><button type="button" className="bill-print" onClick={()=>openPrintDocument(`/purchasing/bills/${bill.id}/receipt-print`).catch(err=>setFormError(err.message))}><FiPrinter/> Cetak penerimaan</button>{bill.status!=="PAID"&&!waiting.length&&<button className="bill-pay" onClick={()=>openPaymentForm(bill)}>Ajukan pembayaran</button>}{waiting.map(pay=>owner?<div className="payment-approval-proof" key={pay.id}>{pay.proofUrl&&<ProtectedFilePreview url={pay.proofUrl} mimeType={pay.proofMimeType} fileName={pay.proofFileName||"Bukti pembayaran"} imageStyle={{width:72,height:48,objectFit:"cover",borderRadius:7}} onError={e=>setFormError(e.message)}/>}<button className="bill-pay" onClick={()=>approvePayment(pay)}><FiCheck/> Setujui {money(pay.amount)}</button></div>:null)}</footer></article>})}{!filteredBills.length&&<Empty icon={<FiShoppingCart/>} text={normalizedQuery?"Tagihan tidak ditemukan":"Belum ada tagihan dari supplier"}/>}</div></div>}
      <ListPager total={currentTotal} page={listPages[activeListKey]||1} pageSize={PAGE_SIZE} onPage={page=>setListPages(current=>({...current,[activeListKey]:page}))}/>
    </section>
    {modal==="supplier"&&<div className="overlay" onMouseDown={()=>!busy&&setModal("")}><form className="modal purchase-request-modal transaction-modal" onSubmit={createStandaloneSupplier} onMouseDown={event=>event.stopPropagation()}><div className="modal-heading"><span className="eyebrow">MASTER SUPPLIER & VENDOR</span><h2>Tambah Supplier / Vendor</h2><p>Supplier ini tersedia untuk PO, masak ban, dan perbaikan sparepart.</p></div><div className="po-form-body"><label>Nama supplier / vendor<input required autoFocus value={supplierForm.name} onChange={event=>setSupplierForm(form=>({...form,name:event.target.value}))} placeholder="Contoh: Bengkel Pump ABC"/></label><div className="grid2"><label>Nomor telepon<input value={supplierForm.phone} onChange={event=>setSupplierForm(form=>({...form,phone:event.target.value}))} placeholder="0812..."/></label><label>Email<input type="email" value={supplierForm.email} onChange={event=>setSupplierForm(form=>({...form,email:event.target.value}))} placeholder="supplier@email.com"/></label></div><label>Alamat<textarea rows="3" value={supplierForm.address} onChange={event=>setSupplierForm(form=>({...form,address:event.target.value}))} placeholder="Alamat supplier atau tempat perbaikan"/></label>{formError&&<div className="form-error">{formError}</div>}</div><div className="modal-actions"><button type="button" className="secondary-btn" disabled={busy} onClick={()=>setModal("")}>Batal</button><button className="primary" disabled={busy}>{busy?"Menyimpan...":"Simpan Supplier"}</button></div></form></div>}
    {modal==="repair-receipt"&&repairReceipt&&<div className="overlay" onMouseDown={()=>setModal("")}><form className="modal purchase-request-modal transaction-modal repair-batch-modal" onSubmit={receiveNonSerializedRepair} onMouseDown={e=>e.stopPropagation()}><div className="modal-heading"><span className="eyebrow">PENERIMAAN HASIL PERBAIKAN</span><h2>{selectedRepairIds.length} barang · {repairReceipt.repairVendor}</h2><p>Isi jumlah dan harga perbaikan setiap barang.</p></div><div className="po-form-body"><div className="po-cancel-warning"><FiPackage/><span><strong>{repairReceipt.repairVendor}</strong><small>Seluruh pilihan berasal dari tempat perbaikan yang sama. Harga stok SECOND hanya memakai biaya perbaikan.</small></span></div><div className="repair-batch-lines">{(data.nonSerializedRepairQueue||[]).filter(row=>selectedRepairIds.includes(row.id)).map(row=>{const line=repairReceiptForm.items[row.id]||{};return <div className="repair-batch-line" key={row.id}><span><b>{row.item?.name}</b><small>{row.item?.sku} · {row.maintenance?.truck?.plateNumber||row.fromTruck?.plateNumber||"Armada"}</small></span><label>Jumlah<input required min="0.01" max={row.remainingQty} step="0.01" type="number" value={line.qty||""} onChange={e=>setRepairReceiptForm(form=>({...form,items:{...form.items,[row.id]:{...line,qty:e.target.value}}}))}/><small>Maks. {row.remainingQty} {row.item?.unit}</small></label><label>Harga/unit<input required min="1" step="1" type="number" value={line.unitPrice||""} onChange={e=>setRepairReceiptForm(form=>({...form,items:{...form.items,[row.id]:{...line,unitPrice:e.target.value}}}))} placeholder="Rp 0"/></label></div>})}</div><label>Lokasi Inventory<select required value={repairReceiptForm.locationId} onChange={e=>setRepairReceiptForm({...repairReceiptForm,locationId:e.target.value})}><option value="">Pilih lokasi</option>{data.locations.map(location=><option key={location.id} value={location.id}>{location.name}</option>)}</select></label><label>Catatan<input value={repairReceiptForm.notes} onChange={e=>setRepairReceiptForm({...repairReceiptForm,notes:e.target.value})} placeholder="Kondisi hasil perbaikan"/></label>{formError&&<div className="form-error">{formError}</div>}</div><div className="modal-actions"><button className="secondary-btn" type="button" disabled={busy} onClick={()=>setModal("")}>Batal</button><button className="primary" disabled={busy}>{busy?"Menerima...":`Terima ${selectedRepairIds.length} Barang`}</button></div></form></div>}
    {modal==="direct-order"&&<div className="overlay direct-order-overlay" onMouseDown={()=>setModal("")}><form className="modal purchase-request-modal direct-order-modal" onSubmit={createDirectOrder} onMouseDown={e=>e.stopPropagation()}>
      <header className="direct-order-header"><div className="direct-order-header-icon"><FiShoppingCart/></div><div><span>PEMBELIAN LANGSUNG OWNER</span><h2>Buat PO langsung</h2><p>Pesanan langsung dikirim ke supplier tanpa menunggu persetujuan.</p></div><button type="button" onClick={()=>setModal("")} aria-label="Tutup">×</button></header>
      <div className="direct-order-body">
        <section className="direct-order-card direct-order-product"><div className="direct-order-section-title"><b>01</b><span><strong>Barang yang dipesan</strong><small>Tambahkan beberapa barang dan tentukan jumlah masing-masing.</small></span></div><div className="purchase-multi-lines">{directLines.map((line,index)=><div className="purchase-multi-line" key={line.key}><b>{index+1}</b><label><span className="direct-field-label">Barang <em>Wajib</em></span><CatalogItemSearch items={data.items} value={line.itemId} disabled={itemsLoading} loading={itemsLoading} onChange={itemId=>setDirectLines(lines=>lines.map(row=>row.key===line.key?{...row,itemId}:row))}/></label><label><span className="direct-field-label">Jumlah <em>Wajib</em></span><input required min="0.01" step="0.01" inputMode="decimal" type="number" value={line.qty} onChange={e=>setDirectLines(lines=>lines.map(row=>row.key===line.key?{...row,qty:e.target.value}:row))}/></label><button type="button" className="purchase-line-remove" disabled={directLines.length===1} onClick={()=>setDirectLines(lines=>lines.filter(row=>row.key!==line.key))}>×</button></div>)}</div><button type="button" className="purchase-add-line" onClick={()=>setDirectLines(lines=>[...lines,newPurchaseLine()])}><FiPlus/> Tambah barang</button>{itemsError&&<span className="items-error">{itemsError}</span>}<label className="direct-arrival-field"><span className="direct-field-label">Estimasi tiba <small>Opsional</small></span><input type="date" value={directForm.estimatedArrival} onChange={e=>setDirectForm(current=>({...current,estimatedArrival:e.target.value}))}/></label></section>
        <section className="direct-order-card direct-order-supplier"><div className="direct-order-section-title"><b>02</b><span><strong>Supplier</strong><small>Pilih supplier terdaftar atau tambahkan supplier baru.</small></span></div><div className="item-mode direct-supplier-mode"><button type="button" className={!newSupplier?"selected":""} onClick={()=>setNewSupplier(false)}>Supplier terdaftar</button><button type="button" className={newSupplier?"selected":""} onClick={()=>setNewSupplier(true)}><FiPlus/> Supplier baru</button></div>{!newSupplier?<label><span className="direct-field-label">Nama supplier <em>Wajib</em></span><select required value={directForm.supplierId} onChange={e=>setDirectForm(current=>({...current,supplierId:e.target.value}))}><option value="">Pilih supplier</option>{data.suppliers.map(supplier=><option key={supplier.id} value={supplier.id}>{supplier.name}</option>)}</select></label>:<div className="direct-new-supplier"><label><span className="direct-field-label">Nama supplier <em>Wajib</em></span><input required value={supplierForm.name} onChange={e=>setSupplierForm(current=>({...current,name:e.target.value}))} placeholder="Nama perusahaan / toko"/></label><div className="grid2"><label><span className="direct-field-label">Telepon <small>Opsional</small></span><input value={supplierForm.phone} onChange={e=>setSupplierForm(current=>({...current,phone:e.target.value}))} placeholder="Contoh: 0812 3456 7890"/></label><label><span className="direct-field-label">Email <small>Opsional</small></span><input type="email" value={supplierForm.email} onChange={e=>setSupplierForm(current=>({...current,email:e.target.value}))} placeholder="supplier@email.com"/></label></div></div>}</section>
        <section className="direct-order-card direct-order-details"><div className="direct-order-section-title"><b>03</b><span><strong>Detail PO & pengiriman</strong><small>Lengkapi informasi yang akan dicantumkan pada PO.</small></span></div><div className="direct-order-detail-fields"><label><span className="direct-field-label">Termin pembayaran</span><input value={directForm.paymentTerms} onChange={e=>setDirectForm(current=>({...current,paymentTerms:e.target.value}))} placeholder="Contoh: Ditagihkan kemudian"/></label><label><span className="direct-field-label">Alamat pengiriman <small>Opsional</small></span><input value={directForm.deliveryAddress} onChange={e=>setDirectForm(current=>({...current,deliveryAddress:e.target.value}))} placeholder="Gudang atau bengkel tujuan"/></label><label className="direct-order-notes-field"><span className="direct-field-label">Keterangan <small>Opsional</small></span><textarea rows="2" value={directForm.reason} onChange={e=>setDirectForm(current=>({...current,reason:e.target.value}))} placeholder="Contoh: Pembelian stok rutin"/></label></div></section>
        {formError&&<div className="form-error direct-order-error">{formError}</div>}<div className="direct-order-notice"><i><FiCheck/></i><span><strong>Siap diproses tanpa approval</strong><small>Sistem tetap menyimpan jejak permintaan, lalu PO langsung berstatus “Dikirim ke supplier”.</small></span></div>
      </div>
      <footer className="direct-order-footer"><span><FiCheck/> Setelah disimpan, langkah berikutnya hanya menerima barang.</span><div><button className="secondary-btn" type="button" disabled={directBusy} onClick={()=>setModal("")}>Batal</button><button className="primary" disabled={directBusy||itemsLoading}><FiShoppingCart/>{directBusy?"Membuat PO...":"Buat PO & Kirim"}</button></div></footer>
    </form></div>}
    {modal==="request"&&<div className="overlay" onMouseDown={()=>setModal("")}><form className={`modal purchase-request-modal request-redesign-modal${retreadRequest?" retread-request-modal":""}`} onSubmit={retreadRequest?receiveRetreadsDirectly:createRequest} onMouseDown={e=>e.stopPropagation()}>
      <div className="modal-heading request-modal-heading"><div className="request-heading-icon">{retreadRequest?<FiRefreshCw/>:<FiShoppingCart/>}</div><div><span className="eyebrow">{retreadRequest?"HASIL BAN MASAK":"PERMINTAAN PEMBELIAN"}</span><h2>{retreadRequest?"Buat PO hasil ban masak":"Buat permintaan barang"}</h2><p>{retreadRequest?"Ban berhasil masuk PO dan baru menambah stok setelah diterima seperti pesanan biasa.":"Pilih barang yang dibutuhkan, lalu kirim untuk persetujuan."}</p></div><button type="button" className="request-close" onClick={()=>setModal("")}>×</button></div>
      <div className="request-modal-body">
        <section className="request-form-section"><div className="request-section-title"><b>01</b><span><strong>Sumber barang</strong><small>Pilih katalog, ban masak, barang perbaikan, atau barang baru.</small></span></div><div className="item-mode request-item-mode"><button type="button" className={!newItem&&!retreadRequest&&!repairRequest?"selected":""} onClick={()=>{setNewItem(false);setRetreadRequest(false);setRepairRequest(false);setStockAcknowledged(false);setFormError("");}}><FiPackage/> Katalog inventory</button><button type="button" className={retreadRequest?"selected":""} onClick={()=>{setNewItem(false);setRetreadRequest(true);setRepairRequest(false);setStockAcknowledged(false);setFormError("");}}><FiRefreshCw/> Ban masak</button><button type="button" className={repairRequest?"selected":""} onClick={()=>{setNewItem(false);setRetreadRequest(false);setRepairRequest(true);setStockAcknowledged(false);setFormError("");}}><FiPackage/> Barang perbaikan</button><button type="button" className={newItem?"selected":""} onClick={()=>{setNewItem(true);setRetreadRequest(false);setRepairRequest(false);setStockAcknowledged(false);setFormError("");}}><FiPlus/> Barang baru</button></div>
          <div className="request-item-fields">{retreadRequest ? <div className="retread-checklist"><header><span><strong>Pilih ban selesai dimasak</strong><small>Centang beberapa nomor serial sekaligus.</small></span><b>{selectedRetreadIds.length} dipilih</b></header><div className="unit-checklist-search"><FiSearch/><input type="search" value={retreadSearch} onChange={event=>setRetreadSearch(event.target.value)} placeholder="Cari nomor seri, barcode, SKU, atau nama ban…"/></div>{filteredRetreadingUnits.map(unit=>{const active=unit.tireRetreads?.[0];const selected=selectedRetreadIds.includes(unit.id);return <label key={unit.id} className={selected?"selected":""}><input type="checkbox" checked={selected} onChange={()=>setSelectedRetreadIds(current=>current.includes(unit.id)?current.filter(id=>id!==unit.id):[...current,unit.id])}/><i>{selected&&<FiCheck/>}</i><span><strong>{unit.serialNumber||unit.barcode||unit.id}</strong><small>{unit.item?.name} → {active?.toItem?.name}</small></span></label>})}{!data.retreadingUnits?.length?<small className="field-help">Belum ada ban berstatus retreading.</small>:!filteredRetreadingUnits.length&&<small className="field-help">Nomor seri Ban Masak tidak ditemukan.</small>}<small className="items-loaded">Item tujuan mengikuti pilihan saat Lepas & Masak.</small></div> : repairRequest ? <div className="retread-checklist"><header><span><strong>Pilih barang dalam perbaikan</strong><small>Centang beberapa nomor serial sekaligus.</small></span><b>{selectedRepairUnitIds.length} dipilih</b></header><div className="unit-checklist-search"><FiSearch/><input type="search" value={repairUnitSearch} onChange={event=>setRepairUnitSearch(event.target.value)} placeholder="Cari nomor seri, barcode, barang, atau armada…"/></div>{filteredRepairingUnits.map(unit=>{const active=unit.partRepairs?.[0];const selected=selectedRepairUnitIds.includes(unit.id);return <label key={unit.id} className={selected?"selected":""}><input type="checkbox" checked={selected} onChange={()=>setSelectedRepairUnitIds(current=>current.includes(unit.id)?current.filter(id=>id!==unit.id):[...current,unit.id])}/><i>{selected&&<FiCheck/>}</i><span><strong>{unit.serialNumber||unit.barcode||unit.id}</strong><small>{unit.item?.name}{active?.maintenance?.truck?.plateNumber?` · ${active.maintenance.truck.plateNumber}`:""}</small></span></label>})}{!data.repairingUnits?.length?<small className="field-help">Belum ada barang perbaikan yang menunggu permintaan.</small>:!filteredRepairingUnits.length&&<small className="field-help">Nomor seri barang perbaikan tidak ditemukan.</small>}<small className="items-loaded">Satu checklist mewakili satu unit berseri.</small></div> : !newItem ? <label>Pilih barang<CatalogItemSearch items={data.items} value={form.itemId} disabled={itemsLoading} loading={itemsLoading} onChange={itemId=>{setStockAcknowledged(false);setFormError("");setForm(current=>({...current,itemId}));}}/>{itemsError&&<span className="items-error">{itemsError}<button type="button" onClick={loadInventoryItems}>Muat ulang</button></span>}{!itemsLoading&&!itemsError&&data.items.length>0&&<small className="items-loaded">{data.items.length} barang tersedia termasuk stok kosong.</small>}{selectedRequestStock > 0 && <span className="stock-available-warning">⚠ Stok masih tersedia: <b>{selectedRequestStock.toLocaleString("id-ID")} {selectedRequestItem.unit}</b>. Periksa Inventory sebelum membeli.</span>}</label> : <div className="new-item-box"><div className="grid2"><label>Kode / SKU<input required placeholder="Contoh: BRK-HINO-01" value={itemForm.sku} onChange={e=>setItemForm({...itemForm,sku:e.target.value})}/></label><label>Satuan<select value={itemForm.unit} onChange={e=>setItemForm({...itemForm,unit:e.target.value})}><option>PCS</option><option>SET</option><option>UNIT</option><option>LITER</option></select></label></div><label>Nama barang<input required placeholder="Contoh: Kampas rem Hino" value={itemForm.name} onChange={e=>setItemForm({...itemForm,name:e.target.value})}/></label><label className="check-label"><input type="checkbox" checked={itemForm.isSerialized} onChange={e=>setItemForm({...itemForm,isSerialized:e.target.checked})}/> Barang memiliki nomor serial</label></div>}</div>
        </section>
        {retreadRequest?<section className="request-form-section retread-direct-receipt"><div className="request-section-title"><b>02</b><span><strong>Hasil pemeriksaan ban</strong><small>Ban berhasil akan dibuatkan PO; ban gagal langsung dicatat sebagai scrap.</small></span></div><div className="retread-direct-prices">{selectedRetreadIds.map(unitId=>{const unit=data.retreadingUnits.find(row=>row.id===unitId);const active=unit?.tireRetreads?.[0];const outcome=retreadReceiptForm.outcomes[unitId]||"RECEIVED";return <div className={`retread-result-row ${outcome==="SCRAPPED"?"is-scrapped":""}`} key={unitId}><span className="retread-result-name"><strong>{unit?.serialNumber||unit?.barcode||unitId}</strong><small>{active?.toItem?.name||unit?.item?.name}</small></span><div className="retread-outcome"><button type="button" className={outcome==="RECEIVED"?"selected":""} onClick={()=>setRetreadReceiptForm(current=>({...current,outcomes:{...current.outcomes,[unitId]:"RECEIVED"}}))}>Masuk PO</button><button type="button" className={outcome==="SCRAPPED"?"selected scrap":""} onClick={()=>setRetreadReceiptForm(current=>({...current,outcomes:{...current.outcomes,[unitId]:"SCRAPPED"}}))}>Tidak bisa · Scrap</button></div>{outcome==="SCRAPPED"?<input required className="retread-scrap-reason" value={retreadReceiptForm.scrapReasons[unitId]??""} onChange={e=>setRetreadReceiptForm(current=>({...current,scrapReasons:{...current.scrapReasons,[unitId]:e.target.value}}))} placeholder="Alasan scrap, contoh: casing retak / kawat putus"/>:<small className="items-loaded">Harga dan lokasi diisi saat Terima Barang.</small>}</div>})}{!selectedRetreadIds.length&&<small className="field-help">Pilih ban terlebih dahulu untuk membuat PO.</small>}</div></section>:<section className="request-form-section"><div className="request-section-title"><b>02</b><span><strong>Detail kebutuhan</strong><small>{form.purpose==="STOCK"&&!repairRequest?"Jumlah persediaan umum ditentukan saat membuat PO.":"Tentukan jumlah, tujuan, dan tingkat urgensinya."}</small></span></div><div className="request-details"><div className="grid2">{(form.purpose!=="STOCK"||repairRequest)&&<label>Jumlah dibutuhkan<input required min="0" step="1" inputMode="numeric" type="number" disabled={repairRequest} value={repairRequest?selectedRepairUnitIds.length:form.qty} onChange={e=>setForm({...form,qty:e.target.value})}/>{repairRequest&&<small className="items-loaded">Otomatis dari jumlah unit yang dicentang.</small>}</label>}<label>Urgensi<select value={form.urgency} onChange={e=>setForm({...form,urgency:e.target.value})}><option value="NORMAL">Normal</option><option value="URGENT">Mendesak</option><option value="CRITICAL">Kritis</option></select></label></div><label>Tujuan permintaan<select value={form.purpose} onChange={e=>setForm({...form,purpose:e.target.value,truckId:e.target.value==="TRUCK"?form.truckId:""})}><option value="STOCK">Persediaan umum</option><option value="TRUCK">Kebutuhan truk tertentu</option></select></label>{form.purpose==="TRUCK"&&<label>Truk tujuan<select required value={form.truckId} onChange={e=>setForm({...form,truckId:e.target.value})}><option value="">Pilih truk</option>{data.trucks.map(truck=><option key={truck.id} value={truck.id}>{truck.plateNumber}{truck.brand||truck.model?` — ${[truck.brand,truck.model].filter(Boolean).join(" ")}`:""}</option>)}</select></label>}<label>Alasan permintaan<textarea required rows="3" placeholder={repairRequest?"Contoh: penerimaan kembali sparepart selesai diperbaiki":"Jelaskan alasan dan kebutuhan barang ini..."} value={form.reason} onChange={e=>setForm({...form,reason:e.target.value})}/></label></div></section>}
        {!retreadRequest&&<label className={`request-damage-proof ${requestDamagePhotos.length?"has-file":""}`}><input multiple type="file" accept="image/*" capture="environment" onChange={e=>{const files=Array.from(e.target.files||[]);if(files.length){const firstNewIndex=requestDamagePhotos.length;setRequestDamagePhotos(current=>[...current,...files]);setRequestPhotoEditorIndex(firstNewIndex);if(files.length===1)setShowRequestPhotoEditor(true);}e.target.value="";}}/><span className="request-proof-icon"><FiUploadCloud/></span><span className="request-proof-copy"><strong>{requestDamagePhotos.length?`Tambah foto lagi · ${requestDamagePhotos.length} foto dipilih`:"Tambah foto barang rusak (opsional)"}</strong><small>Boleh dilewati · gunakan kamera atau pilih foto dari galeri</small></span></label>}
        {!retreadRequest&&!!requestDamagePhotos.length&&<div className="request-proof-list">{requestDamagePhotos.map((file,index)=><div key={`${file.name}-${file.size}-${file.lastModified}-${index}`}><span><b>{index+1}</b><strong title={file.name}>{file.name}</strong></span><button type="button" onClick={()=>{setRequestPhotoEditorIndex(index);setShowRequestPhotoEditor(true);}}>Tandai</button><button type="button" className="remove" onClick={()=>setRequestDamagePhotos(files=>files.filter((_,fileIndex)=>fileIndex!==index))}>Hapus</button></div>)}</div>}
        {!retreadRequest&&<UploadProgress progress={requestUploadProgress} label="Mengunggah bukti barang rusak" />}
        {!newItem&&!retreadRequest&&!repairRequest&&<section className="request-extra-items"><header><span><strong>Barang dalam permintaan</strong><small>Barang pertama dipilih di atas. Tambahkan barang lain bila diperlukan.</small></span><b>{requestLines.length} barang</b></header>{requestLines.slice(1).map((line,index)=><div className="purchase-multi-line" key={line.key}><b>{index+2}</b><label><CatalogItemSearch items={data.items} value={line.itemId} disabled={itemsLoading} loading={itemsLoading} onChange={itemId=>{setStockAcknowledged(false);setRequestLines(lines=>lines.map(row=>row.key===line.key?{...row,itemId}:row));}}/></label>{form.purpose==="TRUCK"&&<label>Jumlah<input required min="0.01" step="0.01" type="number" value={line.qty} onChange={event=>setRequestLines(lines=>lines.map(row=>row.key===line.key?{...row,qty:event.target.value}:row))}/></label>}<button type="button" className="purchase-line-remove" onClick={()=>setRequestLines(lines=>lines.filter(row=>row.key!==line.key))}>×</button></div>)}<button type="button" className="purchase-add-line" onClick={()=>setRequestLines(lines=>[...lines,newPurchaseLine()])}><FiPlus/> Tambah barang lain</button></section>}
        {formError&&<div className="form-error">{formError}</div>}
      </div><div className="modal-actions"><span className="request-footer-note">{retreadRequest?"Harga dan lokasi penerimaan diisi saat barang diterima dari PO.":"Permintaan akan masuk ke daftar persetujuan."}</span><button className="secondary-btn" type="button" disabled={requestBusy} onClick={()=>setModal("")}>Batal</button><button className="primary" disabled={requestBusy||itemsLoading}><FiCheck/>{requestBusy?(retreadRequest?"Membuat PO...":"Mengirim..."):retreadRequest?`Buat PO ${selectedRetreadIds.length} Ban`:stockAcknowledged?"Tetap Kirim Permintaan":"Kirim Permintaan"}</button></div></form></div>}
    {modal==="po"&&poRequest&&<div className="overlay" onMouseDown={()=>setModal("")}><form className="modal purchase-request-modal po-modal" onSubmit={createPurchaseOrder} onMouseDown={e=>e.stopPropagation()}><div className="modal-heading"><span className="eyebrow">KONSOLIDASI PESANAN</span><h2>Buat satu PO</h2><p>Gabungkan beberapa permintaan untuk supplier yang sama ke dalam satu nomor PO.</p></div><div className="po-form-body">
      <div className="item-mode"><button type="button" className={!newSupplier?"selected":""} onClick={()=>setNewSupplier(false)}>Supplier terdaftar</button><button type="button" className={newSupplier?"selected":""} onClick={()=>setNewSupplier(true)}><FiPlus/> Supplier baru</button></div>
      {!newSupplier?<label>Supplier<select required value={poForm.supplierId} onChange={e=>setPoForm({...poForm,supplierId:e.target.value})}><option value="">Pilih supplier</option>{data.suppliers.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></label>:<div className="new-item-box"><label>Nama supplier<input required value={supplierForm.name} onChange={e=>setSupplierForm({...supplierForm,name:e.target.value})} placeholder="Nama perusahaan / toko"/></label><div className="grid2"><label>Telepon<input value={supplierForm.phone} onChange={e=>setSupplierForm({...supplierForm,phone:e.target.value})} placeholder="08..."/></label><label>Email<input type="email" value={supplierForm.email} onChange={e=>setSupplierForm({...supplierForm,email:e.target.value})} placeholder="supplier@email.com"/></label></div></div>}
      <section className="bulk-po-requests"><header><span><strong>Pilih permintaan</strong><small>{selectedPoRequests.length?"1 PO akan dibuat":"Pilih minimal 1 permintaan"}</small></span></header><div className="bulk-po-scroll" role="region" aria-label="Daftar permintaan pembelian" tabIndex="0">{poCandidates.map(request=><label key={request.id} className={poRequestIds.includes(request.id)?"selected":""}><input type="checkbox" checked={poRequestIds.includes(request.id)} onChange={()=>setPoRequestIds(current=>current.includes(request.id)?current.filter(id=>id!==request.id):[...current,request.id])}/><span><b>{request.number}</b><small>{request.items.map(item=>item.item.name).join(", ")}</small></span></label>)}</div></section>
      <div className="po-price-list" role="region" aria-label="Daftar barang yang dipesan" tabIndex="0"><div className="section-label">BARANG YANG DIPESAN · {selectedPoRequests.flatMap(request=>request.items).length} ITEM</div>{selectedPoRequests.flatMap(request=>request.items.map(i=><div className="po-price-row" key={i.id}><div><strong>{i.item.name}</strong><small>{request.number} · {i.item.sku}</small></div>{request.purpose==="STOCK"&&!i.tireRetreadId&&!i.partRepairId?<label>Jumlah PO<input required min="0.01" step="0.01" inputMode="decimal" type="number" value={poForm.quantities[i.id]??""} onChange={e=>setPoForm({...poForm,quantities:{...poForm.quantities,[i.id]:e.target.value}})} placeholder="Masukkan jumlah"/><small>{i.item.unit}</small></label>:<b>{i.approvedQty??i.originalQty} {i.item.unit}</b>}</div>))}</div>
      <div className="approval-note"><span className="approval-note-icon"><FiFileText/></span><span><strong>Harga menyusul dari tagihan supplier</strong><small>PO mencatat barang dan jumlah. Harga dicocokkan per barang setelah invoice supplier datang.</small></span></div>
      <div className="grid2"><label>Termin pembayaran<input value={poForm.paymentTerms} onChange={e=>setPoForm({...poForm,paymentTerms:e.target.value})} placeholder="Contoh: 30 hari"/></label><label>Estimasi tiba<input type="date" value={poForm.estimatedArrival} onChange={e=>setPoForm({...poForm,estimatedArrival:e.target.value})}/></label></div><label>Alamat pengiriman<textarea rows="2" value={poForm.deliveryAddress} onChange={e=>setPoForm({...poForm,deliveryAddress:e.target.value})} placeholder="Alamat bengkel / gudang"/></label>
      {formError&&<div className="form-error">{formError}</div>}</div><div className="modal-actions"><button className="secondary-btn" type="button" onClick={()=>setModal("")}>Batal</button><button className="primary" disabled={busy||!selectedPoRequests.length}>{busy?"Membuat PO...":"Buat 1 PO"}</button></div></form></div>}
    {modal==="cancel-po"&&cancelPo&&<div className="overlay" onMouseDown={()=>setModal("")}><form className="modal purchase-request-modal po-cancel-modal" onSubmit={cancelPurchaseOrder} onMouseDown={e=>e.stopPropagation()}><div className="modal-heading"><span className="eyebrow">PEMBATALAN PESANAN PEMBELIAN</span><h2>Batalkan {cancelPo.number}</h2><p>PO tetap tersimpan sebagai riwayat dan tidak akan dapat menerima barang.</p></div><div className="po-form-body"><div className="po-cancel-warning"><FiXCircle/><span><strong>{cancelPo.supplier?.name}</strong><small>{cancelPo.items?.map(item=>`${item.item?.name} · ${item.qty} ${item.item?.unit}`).join(", ")}</small></span></div><label>Alasan pembatalan<textarea required minLength="3" rows="4" value={cancellationReason} onChange={event=>setCancellationReason(event.target.value)} placeholder="Contoh: kebutuhan dibatalkan atau supplier tidak dapat memenuhi pesanan"/></label>{formError&&<div className="form-error">{formError}</div>}</div><div className="modal-actions"><button className="secondary-btn" type="button" disabled={busy} onClick={()=>setModal("")}>Kembali</button><button className="danger-btn" disabled={busy||cancellationReason.trim().length<3}>{busy?"Membatalkan...":"Batalkan PO"}</button></div></form></div>}
    {modal==="change-po-supplier"&&supplierChangePo&&<div className="overlay" onMouseDown={()=>setModal("")}><form className="modal purchase-request-modal po-supplier-change-modal" onSubmit={changePurchaseOrderSupplier} onMouseDown={e=>e.stopPropagation()}><div className="modal-heading"><span className="eyebrow">PERUBAHAN SUPPLIER PO</span><h2>Ganti supplier {supplierChangePo.number}</h2><p>Nomor PO dan daftar barang tetap sama. PO berikutnya akan dicetak menggunakan supplier baru.</p></div><div className="po-form-body"><div className="po-supplier-change-summary"><FiRefreshCw/><span><small>SUPPLIER SAAT INI</small><strong>{supplierChangePo.supplier?.name}</strong></span></div><label>Supplier baru<select required value={replacementSupplierId} onChange={event=>setReplacementSupplierId(event.target.value)}><option value="">Pilih supplier pengganti</option>{data.suppliers.filter(supplier=>supplier.id!==supplierChangePo.supplierId).map(supplier=><option key={supplier.id} value={supplier.id}>{supplier.name}</option>)}</select></label><small className="po-supplier-change-note">Supplier hanya dapat diganti sebelum ada barang diterima atau pembayaran dibuat.</small>{formError&&<div className="form-error">{formError}</div>}</div><div className="modal-actions"><button className="secondary-btn" type="button" disabled={busy} onClick={()=>setModal("")}>Batal</button><button className="primary" disabled={busy||!replacementSupplierId}>{busy?"Mengganti...":"Simpan Supplier Baru"}</button></div></form></div>}
    {modal==="receipt"&&receiptPo&&<div className="overlay" onMouseDown={()=>setModal("")}><form className="modal purchase-request-modal transaction-modal batch-receipt-modal" onSubmit={createReceipt} onMouseDown={e=>e.stopPropagation()}><div className="modal-heading"><span className="eyebrow">PENERIMAAN BARANG GABUNGAN</span><h2>Terima barang dari {receiptPo.supplier.name}</h2><p>Pilih beberapa PO dari supplier yang sama. Satu surat jalan dan satu bukti dapat digunakan untuk seluruh penerimaan ini.</p></div><div className="po-form-body">
      <section className="batch-receipt-orders"><header><span><small>PILIH PESANAN</small><strong>PO dalam pengiriman yang sama</strong></span><div className="batch-receipt-selection-actions"><button type="button" onClick={toggleAllReceiptOrders}>{receiptOrderOptions.length>0&&selectedReceiptOrders.length===receiptOrderOptions.length?"Batalkan semua":"Pilih semua"}</button><b>{selectedReceiptOrders.length} dipilih</b></div></header><div>{receiptOrderOptions.map(po=>{const selected=receiptPoIds.includes(po.id);const targetTruck=receiptTargetTruck(po,data.trucks);return <label key={po.id} className={selected?"selected":""}><input type="checkbox" checked={selected} onChange={()=>toggleReceiptOrder(po.id)}/><i>{selected&&<FiCheck/>}</i><span><strong>{po.number}{targetTruck?` · UNTUK ${targetTruck.plateNumber||"MOBIL"}`:""}</strong><small>{po.items.map(item=>`${item.item.name} · ${item.qty-item.receivedQty} ${item.item.unit}`).join(", ")}</small>{targetTruck&&<small>Otomatis masuk ke stok mobil{po.request.maintenance?.title?`: ${po.request.maintenance.title}`:""}</small>}</span></label>})}</div></section>
      {data.locations.length?<label>Lokasi gudang<select required value={receiptForm.locationId} onChange={e=>setReceiptForm({...receiptForm,locationId:e.target.value})}>{data.locations.map(l=><option key={l.id} value={l.id}>{l.name}</option>)}</select></label>:<label>Lokasi gudang baru<input required value={receiptForm.locationName} onChange={e=>setReceiptForm({...receiptForm,locationName:e.target.value})}/><small className="items-loaded">Lokasi ini akan dibuat otomatis.</small></label>}
      <div className="po-price-list receipt-entry-table"><div className="receipt-table-title"><span><small>RINCIAN PENERIMAAN</small><strong>Jumlah diterima sekarang</strong></span><b>{selectedReceiptOrders.reduce((sum,po)=>sum+po.items.length,0)} barang · {selectedReceiptOrders.length} PO</b></div><div className="receipt-table-head"><span>Barang</span><span>Sisa PO</span><span>Qty diterima</span><span>Harga satuan sementara</span></div>{selectedReceiptOrders.flatMap(po=>po.items.map(i=>{
        const remaining=i.qty-i.receivedQty;
        const serialQty=Math.max(0,Math.floor(Number(receiptForm.quantities[i.id]||0)));
        const serialRows=Array.from({length:serialQty},(_,index)=>String(receiptForm.serials[i.id]||"").split("\n")[index]||"");
        const typedSerialCount=serialRows.map(x=>x.trim()).filter(Boolean).length;
        const requiredSerials=false;
        const fixedRetreadPrice=Boolean(i.tireRetread&&String(po.supplier?.name||"").trim().toLocaleUpperCase("id-ID")==="PERSAUDARAAN");
        return <div className={`po-price-row receipt-item-row ${i.item.isSerialized?"serialized-receipt-row":""}`} key={i.id}><div className="receipt-item-identity"><strong>{i.item.name}</strong><small>{po.number} · {i.item.sku||"Tanpa SKU"}</small><div><span>PO {i.qty} {i.item.unit}</span><span>Sudah diterima {i.receivedQty}</span>{i.item.isSerialized&&<em>BERSERIAL</em>}</div></div><div className="receipt-remaining"><strong>{remaining}</strong><small>{i.item.unit}</small></div><label className="receipt-qty-field"><span>Qty diterima</span><input required min="0" max={remaining} step={i.item.isSerialized?"1":"0.01"} type="number" value={receiptForm.quantities[i.id]??0} onChange={e=>setReceiptForm({...receiptForm,quantities:{...receiptForm.quantities,[i.id]:e.target.value}})}/></label><label className="receipt-price-field"><span>{fixedRetreadPrice?"Harga tetap ban masak":"Harga satuan sementara"}</span><div><span>Rp</span><input required={Number(receiptForm.quantities[i.id]||0)>0} disabled={fixedRetreadPrice||!(Number(receiptForm.quantities[i.id]||0)>0)} min="1" step="1" type="number" value={fixedRetreadPrice?"900000":receiptForm.prices[i.id]??""} onChange={e=>setReceiptForm({...receiptForm,prices:{...receiptForm.prices,[i.id]:e.target.value}})} placeholder="0"/></div></label>
          {i.item.isSerialized&&<div className="serial-entry">
            {!i.tireRetread&&!i.partRepair&&<small className="field-help">Nomor seri boleh dikosongkan saat penerimaan dan diisi ketika unit akan dipasang.</small>}
            {i.tireRetread?<div className="retread-purchase-picker"><strong>Ban selesai retreading</strong><div className="retread-unit-option selected"><span><b>{i.tireRetread.stockUnit?.serialNumber||i.tireRetread.stockUnit?.barcode||i.tireRetread.stockUnitId}</b><small>{i.tireRetread.fromItem?.name} → {i.tireRetread.toItem?.name}</small></span></div><small>Serial sudah ditentukan dari Permintaan Pembelian dan akan masuk stok setelah penerimaan disetujui.</small></div>:i.partRepair?<div className="retread-purchase-picker"><strong>Sparepart selesai diperbaiki</strong><div className="retread-unit-option selected"><span><b>{i.partRepair.stockUnit?.serialNumber||i.partRepair.stockUnit?.barcode||i.partRepair.stockUnitId}</b><small>Unit yang sama akan kembali ke Inventory berstatus tersedia.</small></span></div><small>Tidak membuat unit baru; riwayat perbaikan tetap terhubung ke servis asal.</small></div>:<div className="receipt-serial-table"><div className="receipt-serial-heading"><span><strong>DAFTAR SERIAL BARU</strong><small>Satu serial untuk setiap unit yang diterima</small></span><b className={typedSerialCount===serialQty&&serialQty>0?"complete":""}>{typedSerialCount} / {serialQty} terisi</b></div>{serialQty>0?<div className="receipt-serial-rows">{serialRows.map((serial,index)=><label key={index}><span>{index+1}</span><input required={requiredSerials} value={serial} onChange={event=>{const next=[...serialRows];next[index]=event.target.value;setReceiptForm(current=>({...current,serials:{...current.serials,[i.id]:next.join("\n")}}));}} placeholder={`${i.item.sku||"SERIAL"}-${String(index+1).padStart(4,"0")}`}/></label>)}</div>:<div className="receipt-serial-empty">Isi Qty diterima untuk menampilkan tabel serial.</div>}</div>}
          </div>}
        </div>}))}<div className="receipt-table-note"><span>i</span><p><strong>Harga ini masih sementara.</strong> Nilainya dipakai untuk biaya armada sampai invoice supplier dicocokkan.</p></div></div>
      <div className="grid2"><label>Nomor surat jalan<input value={receiptForm.deliveryNote} onChange={e=>setReceiptForm({...receiptForm,deliveryNote:e.target.value})} placeholder="SJ-..."/></label><label>Catatan<input value={receiptForm.notes} onChange={e=>setReceiptForm({...receiptForm,notes:e.target.value})} placeholder="Kondisi barang baik"/></label></div><label className="receipt-upload"><input type="file" accept="image/jpeg,image/png,image/webp" capture="environment" onChange={e=>setReceiptProofFile(e.target.files?.[0]||null)}/><span className="receipt-upload-icon"><FiUploadCloud/></span><span><strong>{receiptProofFile?receiptProofFile.name:"Foto surat penerimaan / surat jalan (opsional)"}</strong><small>{receiptProofFile?"Foto siap disimpan · klik untuk mengganti":"Boleh dilewati · JPG, PNG, atau WEBP"}</small></span></label><UploadProgress progress={receiptUploadProgress} label="Mengunggah bukti penerimaan barang" />{formError&&<div className="form-error">{formError}</div>}
      </div><div className="modal-actions"><button className="secondary-btn" type="button" onClick={()=>setModal("")}>Batal</button><button className="primary" disabled={busy||!selectedReceiptOrders.length}><FiPackage/> {busy?"Menyimpan...":directReceiptOrders.length?`Terima ${selectedReceiptOrders.length} PO & masukkan ke mobil`:`Terima ${selectedReceiptOrders.length} PO & tambah stok`}</button></div></form></div>}
    <ImageAnnotationEditor file={requestPhotoEditorIndex==null?null:requestDamagePhotos[requestPhotoEditorIndex]} open={showRequestPhotoEditor} onClose={()=>{setShowRequestPhotoEditor(false);setRequestPhotoEditorIndex(null);}} onSave={file=>{setRequestDamagePhotos(files=>files.map((saved,index)=>index===requestPhotoEditorIndex?file:saved));setShowRequestPhotoEditor(false);setRequestPhotoEditorIndex(null);}}/>
    {modal==="bill"&&<div className="overlay supplier-bill-overlay" onMouseDown={()=>setModal("")}><form className="modal purchase-request-modal transaction-modal supplier-bill-modal" onSubmit={createBill} onMouseDown={e=>e.stopPropagation()}>
      <div className="modal-heading supplier-bill-heading"><div><span className="eyebrow">REKONSILIASI TAGIHAN SUPPLIER</span><h2>Cocokkan invoice dengan barang diterima</h2><p>Pilih surat penerimaan, lalu masukkan harga tiap barang sesuai invoice supplier.</p></div><button className="supplier-bill-close" type="button" aria-label="Tutup rekonsiliasi tagihan" onClick={()=>setModal("")}>×</button></div>
      <div className="po-form-body"><label>Supplier<select required value={billForm.supplierId} onChange={e=>setBillForm({...billForm,supplierId:e.target.value,receiptIds:[],itemIds:[],itemPrices:{},itemQuantities:{},repairMovementIds:[]})}><option value="">Pilih supplier</option>{data.suppliers.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></label>
        <section className="bill-receipt-section"><header><span><small>LANGKAH 1</small><strong>Pilih Penerimaan yang Ditagihkan</strong></span><div className="bill-select-all"><button type="button" disabled={!selectableBillReceipts.length} onClick={toggleAllBillReceipts}>{allBillReceiptsSelected?"Batalkan semua":"Pilih semua dalam periode"}</button><b>{billForm.receiptIds.length} GR dipilih</b></div></header><div className="bill-receipt-period"><span><b>Periode penerimaan</b><small>Tampilkan penerimaan berdasarkan tanggal barang diterima.</small></span><label>Dari tanggal<input type="date" value={billReceiptPeriod.from} onChange={e=>changeBillReceiptPeriod("from",e.target.value)}/></label><label>Sampai tanggal<input type="date" value={billReceiptPeriod.to} onChange={e=>changeBillReceiptPeriod("to",e.target.value)}/></label><button type="button" disabled={!billReceiptPeriod.from&&!billReceiptPeriod.to} onClick={resetBillReceiptPeriod}>Reset</button></div><div className="bill-receipt-picker">{selectableBillReceiptGroups.map(group=>{const receipts=group.entries.map(({receipt})=>receipt);const selected=receipts.every(receipt=>billForm.receiptIds.includes(receipt.id));const first=receipts[0];const itemCount=receipts.reduce((sum,receipt)=>sum+receipt.items.filter(item=>!isReceiptItemFullyBilled(item)&&item.condition!=="RETURNED_TO_SUPPLIER").length,0);return <label key={group.key} className={selected?"selected":""}><input type="checkbox" checked={selected} onChange={()=>toggleBillReceiptGroup(group.entries)}/><i>{selected&&<FiCheck/>}</i><span><strong>Surat jalan {first.deliveryNote||"-"}</strong><small>{new Date(first.receivedAt).toLocaleDateString("id-ID",{day:"numeric",month:"long",year:"numeric"})}</small><em className="bill-delivery-note">{receipts.length} penerimaan · {receipts.map(receipt=>receipt.number).join(", ")}</em></span><span className="bill-receipt-proof">{first.deliveryNoteProofUrl?<ProtectedFilePreview url={first.deliveryNoteProofUrl} mimeType={first.deliveryNoteMimeType} fileName={first.deliveryNoteFileName||`Bukti ${first.number}`} imageStyle={{width:96,height:68,objectFit:"cover",borderRadius:8}} onError={e=>setFormError(e.message)}/>:<FiFileText/>}</span><b>{itemCount} barang</b></label>})}{billForm.supplierId&&!selectableBillReceiptGroups.length&&<div className="bill-receipt-empty"><FiCheck/><span><strong>Tidak ada penerimaan pada periode ini</strong><small>Ubah rentang tanggal atau pilih supplier lain.</small></span></div>}</div></section>
        {!!selectableRepairBillItems.length&&<section className="bill-receipt-section"><header><span><small>JASA PERBAIKAN</small><strong>Pilih pekerjaan yang ditagihkan</strong></span><b>{selectedRepairBillItems.length} dipilih</b></header><div className="bill-receipt-picker">{selectableRepairBillItems.map(row=>{const selected=billForm.repairMovementIds.includes(row.id);return <label key={row.id} className={selected?"selected":""}><input type="checkbox" checked={selected} onChange={()=>toggleRepairBillItem(row.id)}/><i>{selected&&<FiCheck/>}</i><span><strong>{row.item?.name}</strong><small>{row.maintenance?.truck?.plateNumber||"-"} · {row.maintenance?.number||"Perbaikan"}</small><em>{new Date(row.createdAt).toLocaleDateString("id-ID",{day:"numeric",month:"long",year:"numeric"})}</em></span><b>{money(row.totalCost)}</b></label>})}</div></section>}
        <div className="grid3"><label>Nomor invoice<input required value={billForm.invoiceNumber} onChange={e=>setBillForm({...billForm,invoiceNumber:e.target.value})}/></label><label>Tanggal invoice<input required type="date" value={billForm.invoiceDate} onChange={e=>setBillForm({...billForm,invoiceDate:e.target.value})}/></label><label>Jatuh tempo<input type="date" value={billForm.dueDate} onChange={e=>setBillForm({...billForm,dueDate:e.target.value})}/></label></div>
        <div className="supplier-bill-flat-details" data-testid="supplier-bill-item-details"><div className="supplier-bill-flat-head"><span><small>LANGKAH 2 · PER PENERIMAAN</small><strong>Masukkan Jumlah yang Ditagih</strong></span><b>{billItems.length} baris penerimaan digunakan</b></div><div className="supplier-bill-flat-scroll">{billItemReceiptGroups.length?billItemReceiptGroups.map(({key,receipts,itemGroups})=>{const first=receipts[0];return <section className="supplier-bill-receipt-group" key={key}><header><span><small>PENERIMAAN</small><strong>Surat jalan {first.deliveryNote||"—"}</strong></span><span><b>{new Date(first.receivedAt).toLocaleDateString("id-ID",{day:"numeric",month:"long",year:"numeric"})}</b><small>{receipts.length} GR · {receipts.map(receipt=>receipt.number).join(", ")}</small></span><em>{itemGroups.length} barang</em></header><div className="supplier-bill-flat-columns"><span>Barang</span><span>Qty ditagih</span><span>Harga satuan</span><span>Subtotal</span></div>{itemGroups.map(renderBillItemGroup)}</section>}):<div className="supplier-bill-flat-empty"><FiFileText/><span><strong>Belum ada rincian barang</strong><small>Pilih penerimaan pada Langkah 1.</small></span></div>}</div></div>
        <section className="bill-summary"><header><small>LANGKAH 3</small><strong>Ringkasan Tagihan</strong></header><div><span>Subtotal barang dan jasa</span><b>{money(billTotal)}</b></div><div className="bill-summary-total"><span>Total tagihan invoice</span><strong>{money(billTotal)}</strong></div></section>
        <label className="receipt-upload required-proof bill-multi-upload"><input required={!billProofFiles.length} multiple type="file" accept="image/jpeg,image/png,image/webp,application/pdf" onChange={e=>{const incoming=[...(e.target.files||[])];setBillProofFiles(current=>[...current,...incoming.filter(file=>!current.some(saved=>saved.name===file.name&&saved.size===file.size&&saved.lastModified===file.lastModified))]);e.target.value=""}}/><span className="receipt-upload-icon"><FiUploadCloud/></span><span><strong>{billProofFiles.length?`${billProofFiles.length} file invoice dipilih`:"Lampirkan invoice supplier"}</strong><small>Klik lagi untuk menambahkan file · JPG, PNG, WEBP atau PDF</small></span></label>{!!billProofFiles.length&&<div className="bill-upload-list">{billProofFiles.map((file,index)=><div key={`${file.name}-${file.size}-${file.lastModified}`}><span><b>{index+1}</b><strong title={file.name}>{file.name}</strong><small>{(file.size/1024/1024).toLocaleString("id-ID",{maximumFractionDigits:2})} MB</small></span><button type="button" onClick={()=>setBillProofFiles(files=>files.filter((_,fileIndex)=>fileIndex!==index))} aria-label={`Hapus ${file.name}`}>×</button></div>)}</div>}<label>Catatan<textarea rows="2" value={billForm.notes} onChange={e=>setBillForm({...billForm,notes:e.target.value})}/></label>{formError&&<div className="form-error">{formError}</div>}
      </div><div className="modal-actions"><button className="secondary-btn" type="button" onClick={()=>setModal("")}>Batal</button><button className="primary" disabled={busy||!billPricesValid||!billProofFiles.length}>{busy?"Mencocokkan...":"Cocok & Simpan Tagihan"}</button></div></form></div>}
    {modal==="payment"&&paymentPo&&<div className="overlay" onMouseDown={()=>setModal("")}><form className="modal purchase-request-modal transaction-modal payment-modal" onSubmit={createPayment} onMouseDown={e=>e.stopPropagation()}><div className="modal-heading"><span className="eyebrow">PENGAJUAN PEMBAYARAN</span><h2>Ajukan pembayaran</h2><p>{paymentPo.invoiceNumber} <span>•</span> {paymentPo.supplier.name}</p></div><div className="po-form-body"><div className="payment-summary"><span>Sisa tagihan<small>Total yang masih harus dibayar</small></span><strong>{money(paymentPo.amount-paymentPo.payments.filter(p=>p.status!=="UNPAID").reduce((s,p)=>s+p.amount,0))}</strong></div><label className="payment-amount-field">Jumlah dibayar<div className="money-input"><span>Rp</span><input required min="1" step="1" type="number" value={paymentForm.amount} onChange={e=>setPaymentForm({...paymentForm,amount:e.target.value})}/></div></label><div className="grid2 payment-form-grid"><label><span className="payment-field-label">Metode pembayaran</span><select value={paymentForm.method} onChange={e=>setPaymentForm({...paymentForm,method:e.target.value})}><option value="BANK_TRANSFER">Transfer bank</option><option value="CASH">Tunai</option><option value="OTHER">Lainnya</option></select></label><label><span className="payment-field-label">Nomor referensi <small>Opsional</small></span><input value={paymentForm.reference} onChange={e=>setPaymentForm({...paymentForm,reference:e.target.value})} placeholder="Nomor transfer / kuitansi"/></label></div><label className="receipt-upload required-proof"><input required type="file" accept="image/jpeg,image/png,image/webp,application/pdf" onChange={e=>setPaymentProofFile(e.target.files?.[0]||null)}/><span className="receipt-upload-icon"><FiUploadCloud/></span><span><strong>{paymentProofFile?paymentProofFile.name:"Lampirkan bukti pembayaran"}</strong><small>Wajib · foto transfer, kuitansi, atau PDF pembayaran</small></span></label><div className="approval-note"><span className="approval-note-icon"><FiCheck/></span><span><strong>Memerlukan persetujuan Pemilik</strong><small>Pengajuan belum dianggap dibayar sebelum disetujui.</small></span></div>{formError&&<div className="form-error">{formError}</div>}</div><div className="modal-actions"><button className="secondary-btn" type="button" onClick={()=>setModal("")}>Batal</button><button className="primary" disabled={busy||!paymentProofFile}>{busy?"Mengajukan...":"Ajukan pembayaran"}</button></div></form></div>}
  </div>;
}
function ListPager({total,page,pageSize,onPage}) { const pages=Math.max(1,Math.ceil(total/pageSize));const current=Math.min(page,pages);if(total<=pageSize)return null;return <nav className="p-list-pager" aria-label="Navigasi halaman"><span>Menampilkan {(current-1)*pageSize+1}–{Math.min(current*pageSize,total)} dari {total}</span><div><button type="button" disabled={current<=1} onClick={()=>onPage(current-1)}><FiChevronLeft/> Sebelumnya</button><b>Halaman {current} / {pages}</b><button type="button" disabled={current>=pages} onClick={()=>onPage(current+1)}>Berikutnya <FiChevronRight/></button></div></nav> }
function Empty({icon,text}) { return <div className="empty">{icon||<FiShoppingCart/>}<h3>{text}</h3><p>Data dan aktivitas akan muncul di sini.</p></div> }
