import { useEffect, useMemo, useRef, useState } from "react";
import { FiActivity, FiAlertTriangle, FiChevronRight, FiMap, FiMapPin, FiNavigation, FiRefreshCw, FiSearch, FiTruck } from "react-icons/fi";
import { api } from "../api";
import { GOOGLE_MAPS_API_KEY, GOOGLE_MAPS_MAP_ID, loadGoogleMaps } from "../googleMaps";
import { useLiveRefresh } from "../liveUpdates";
import LoadingState from "../components/LoadingState";
import "./FleetMap.css";
import "./FleetMapGoogle.css";
import "./FleetMapRedesign.css";
import "./FleetMapToolbarFix.css";

const DEFAULT_CENTER = { lat: 2.4, lng: 99.3 };
function validPosition(truck) {
  if (truck.lastGpsLatitude == null || truck.lastGpsLongitude == null) return null;
  const lat = Number(truck.lastGpsLatitude);
  const lng = Number(truck.lastGpsLongitude);
  if (!Number.isFinite(lat) || !Number.isFinite(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180 || (lat === 0 && lng === 0)) return null;
  return { lat, lng };
}

function normalizeRegionName(name) {
  const normalized = name
    ?.replace(/^(Kota|Kabupaten)\s+/i, "")
    .replace(/\s+(Regency|City)$/i, "")
    .replace(/\s+/g, " ")
    .trim();
  if (!normalized) return null;
  const direction = normalized.match(/^(North|South|West|East|Central)\s+(.+)$/i);
  if (!direction) return normalized;
  const translations = { north: "Utara", south: "Selatan", west: "Barat", east: "Timur", central: "Tengah" };
  const place = direction[2].replace(/^Sumatra$/i, "Sumatera");
  return `${place} ${translations[direction[1].toLowerCase()]}`;
}

function cityFromGeocode(response) {
  const results = Array.isArray(response) ? response : response?.results;
  const components = (results || []).flatMap((result) => result.address_components || []);
  const find = (type) => components.find((item) => item.types?.includes(type))?.long_name;
  return normalizeRegionName(find("administrative_area_level_2") || find("locality") || find("administrative_area_level_1"));
}

function markerColor(truck) {
  if (truck.gpsLocation?.type === "WARNING" || truck.gpsStopWarning?.severity === "CRITICAL") return "#c2413b";
  if (truck.gpsStopWarning || truck.status === "MAINTENANCE") return "#d38219";
  if (truck.status === "PLANNED") return "#6366f1";
  if (truck.status === "DISPATCH") return "#2563a8";
  return "#157347";
}

function markerElement(truck) {
  const marker = document.createElement("button");
  marker.type = "button";
  marker.className = "google-fleet-marker";
  marker.style.setProperty("--marker-color", markerColor(truck));
  marker.style.setProperty("--marker-heading", `${Number(truck.gpsTelemetry?.heading || 0)}deg`);
  const vehicle = document.createElement("span");
  vehicle.className = "google-fleet-vehicle";
  vehicle.innerHTML = '<svg viewBox="0 0 28 44" aria-hidden="true"><path d="M8.5 3.5h11l4.5 9v22.5c0 3-2 5.5-5 5.5H9c-3 0-5-2.5-5-5.5V12.5l4.5-9Z"/><path class="glass" d="m9.5 7-2.4 7h13.8l-2.4-7h-9Z"/><path class="glass" d="M7.2 18h13.6v10H7.2z"/><circle cx="8" cy="34.5" r="2"/><circle cx="20" cy="34.5" r="2"/></svg>';
  const plate = document.createElement("span");
  plate.className = "google-fleet-plate";
  plate.textContent = truck.plateNumber || "TRUK";
  marker.append(vehicle, plate);
  return marker;
}

function statusLabel(status) {
  return ({ READY: "Siap", DISPATCH: "Dalam perjalanan", PLANNED: "Terjadwal", MAINTENANCE: "Perawatan", INACTIVE: "Tidak aktif" })[status] || status || "-";
}

function directionLabel(heading) {
  if (heading == null || !Number.isFinite(Number(heading))) return "Belum terbaca";
  return ["Utara", "Timur Laut", "Timur", "Tenggara", "Selatan", "Barat Daya", "Barat", "Barat Laut"][Math.round(Number(heading) / 45) % 8];
}

function popupContent(truck) {
  const root = document.createElement("div");
  root.className = "fleet-map-popup google-popup";
  const eyebrow = document.createElement("small");
  eyebrow.className = "google-popup-eyebrow";
  eyebrow.textContent = "DETAIL ARMADA";
  const title = document.createElement("strong");
  title.textContent = truck.plateNumber || "Kendaraan";
  const vehicle = document.createElement("span");
  vehicle.textContent = [truck.brand, truck.model].filter(Boolean).join(" ") || "Kendaraan";
  const details = document.createElement("dl");
  const detailRows = [
    ["Status", statusLabel(truck.status)],
    ["Lokasi", truck.gpsLocation?.name || "Dalam perjalanan"],
    ["Kecepatan", truck.lastGpsSpeed == null ? "-" : `${Number(truck.lastGpsSpeed).toFixed(0)} km/jam`],
    ["Arah", directionLabel(truck.gpsTelemetry?.heading)],
    ["Kontak mesin", truck.lastGpsIgnition == null ? "-" : truck.lastGpsIgnition ? "Menyala" : "Mati"],
    ["Pengemudi", truck.driverUser?.name || "Belum ditugaskan"],
    ["Update GPS", truck.lastGpsAt ? new Date(truck.lastGpsAt).toLocaleString("id-ID") : "-"],
  ];
  detailRows.forEach(([label, value]) => {
    const row = document.createElement("div");
    const term = document.createElement("dt");
    const description = document.createElement("dd");
    term.textContent = label;
    description.textContent = value;
    row.append(term, description);
    details.appendChild(row);
  });
  const link = document.createElement("a");
  link.href = `https://www.google.com/maps?q=${truck.position.lat},${truck.position.lng}`;
  link.target = "_blank";
  link.rel = "noreferrer";
  link.textContent = "Buka navigasi Google Maps";
  const coordinates = document.createElement("code");
  coordinates.textContent = `${truck.position.lat.toFixed(5)}, ${truck.position.lng.toFixed(5)}`;
  root.append(eyebrow, title, vehicle, details, coordinates, link);
  return root;
}

function GoogleFleetMap({ trucks, focusTruckId, onError }) {
  const containerRef = useRef(null);
  const mapRef = useRef(null);
  const markersRef = useRef([]);
  const infoWindowRef = useRef(null);

  useEffect(() => {
    let active = true;
    loadGoogleMaps().then(async (maps) => {
      if (!active || !containerRef.current) return;
      await maps.importLibrary("marker");
      if (!mapRef.current) {
        mapRef.current = new maps.Map(containerRef.current, {
          center: DEFAULT_CENTER,
          zoom: 7,
          mapId: GOOGLE_MAPS_MAP_ID,
          mapTypeControl: true,
          mapTypeControlOptions: { mapTypeIds: ["roadmap", "satellite", "hybrid"] },
          streetViewControl: false,
          fullscreenControl: true,
          gestureHandling: "greedy",
        });
        infoWindowRef.current = new maps.InfoWindow();
      }
      markersRef.current.forEach(({ marker }) => { marker.map = null; });
      markersRef.current = [];
      const bounds = new maps.LatLngBounds();
      trucks.forEach((truck) => {
        const marker = new maps.marker.AdvancedMarkerElement({ map: mapRef.current, position: truck.position, title: truck.plateNumber, content: markerElement(truck) });
        marker.addListener("click", () => {
          infoWindowRef.current.setContent(popupContent(truck));
          infoWindowRef.current.open({ map: mapRef.current, anchor: marker });
        });
        markersRef.current.push({ truck, marker });
        bounds.extend(truck.position);
      });
      if (trucks.length === 1) {
        mapRef.current.setCenter(trucks[0].position);
        mapRef.current.setZoom(15);
      } else if (trucks.length > 1) mapRef.current.fitBounds(bounds, 55);
      const focused = markersRef.current.find(({ truck }) => truck.id === focusTruckId);
      if (focused) {
        mapRef.current.panTo(focused.truck.position);
        mapRef.current.setZoom(16);
        infoWindowRef.current.setContent(popupContent(focused.truck));
        infoWindowRef.current.open({ map: mapRef.current, anchor: focused.marker });
      }
    }).catch((error) => { if (active) onError(error.message); });
    return () => { active = false; };
  }, [trucks, focusTruckId, onError]);

  return <div ref={containerRef} className="fleet-google-map" />;
}

export default function FleetMap() {
  const [trucks, setTrucks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [mapError, setMapError] = useState("");
  const [query, setQuery] = useState("");
  const [mapFilter, setMapFilter] = useState("ALL");
  const [focusTruckId, setFocusTruckId] = useState(null);
  const [cityByTruck, setCityByTruck] = useState({});
  const cityCacheRef = useRef(new Map());

  async function load({ background = false } = {}) {
    if (!background) setLoading(true);
    try {
      const result = await api("/trucks");
      setTrucks(result.items || []);
      setError("");
    } catch (err) {
      setError(err.message || "Gagal memuat posisi armada");
    } finally {
      if (!background) setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);
  useLiveRefresh(load, { interval: 60000 });

  const mapped = useMemo(() => trucks.map((truck) => ({ ...truck, position: validPosition(truck) })).filter((truck) => truck.position), [trucks]);
  const unmapped = trucks.length - mapped.length;
  const searched = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase("id-ID");
    if (!needle) return mapped;
    return mapped.filter((truck) => [truck.plateNumber, truck.brand, truck.model, truck.driverUser?.name].some((value) => String(value || "").toLocaleLowerCase("id-ID").includes(needle)));
  }, [mapped, query]);
  const movingAll = useMemo(() => mapped.filter((truck) => truck.status === "DISPATCH" || Number(truck.lastGpsSpeed || 0) > 5), [mapped]);
  const attentionAll = useMemo(() => mapped.filter((truck) => truck.gpsStopWarning || truck.gpsLocation?.type === "WARNING" || truck.status === "MAINTENANCE"), [mapped]);
  const visible = useMemo(() => searched.filter((truck) => mapFilter === "MOVING" ? (truck.status === "DISPATCH" || Number(truck.lastGpsSpeed || 0) > 5) : mapFilter === "ATTENTION" ? (truck.gpsStopWarning || truck.gpsLocation?.type === "WARNING" || truck.status === "MAINTENANCE") : true), [searched, mapFilter]);
  const moving = useMemo(() => visible.filter((truck) => truck.status === "DISPATCH" || Number(truck.lastGpsSpeed || 0) > 5).sort((a, b) => Number(b.lastGpsSpeed || 0) - Number(a.lastGpsSpeed || 0)), [visible]);
  useEffect(() => {
    if (!GOOGLE_MAPS_API_KEY || !mapped.length) return;
    let active = true;
    loadGoogleMaps().then(async (maps) => {
      const geocoder = new maps.Geocoder();
      for (const truck of mapped) {
        if (!active) break;
        const key = `${truck.position.lat.toFixed(3)},${truck.position.lng.toFixed(3)}`;
        let city = cityCacheRef.current.get(key);
        if (city === undefined) {
          try {
            city = cityFromGeocode(await geocoder.geocode({ location: truck.position, language: "id", region: "ID" })) || "Lokasi belum dikenali";
            if (city !== "Lokasi belum dikenali") cityCacheRef.current.set(key, city);
          } catch {
            city = "Lokasi belum dikenali";
          }
        }
        if (active) setCityByTruck((current) => current[truck.id] === city ? current : { ...current, [truck.id]: city });
      }
    }).catch(() => {});
    return () => { active = false; };
  }, [mapped]);
  const cityGroups = useMemo(() => {
    const groups = new Map();
    visible.forEach((truck) => {
      const city = normalizeRegionName(cityByTruck[truck.id]) || "Mengenali lokasi…";
      const key = city.toLocaleLowerCase("id-ID");
      if (!groups.has(key)) groups.set(key, { city, trucks: [] });
      groups.get(key).trucks.push(truck);
    });
    return [...groups.values()].map(({ city, trucks: cityTrucks }) => ({ city, trucks: cityTrucks.sort((a,b) => String(a.plateNumber).localeCompare(String(b.plateNumber))), moving: cityTrucks.filter((truck) => truck.status === "DISPATCH" || Number(truck.lastGpsSpeed || 0) > 5).length })).sort((a,b) => b.trucks.length-a.trucks.length || a.city.localeCompare(b.city));
  }, [visible, cityByTruck]);

  return (
    <main className="fleet-map-page google-map-page">
      <header className="fleet-map-head"><div><span>LIVE FLEET CONTROL</span><h1>Peta Armada</h1><p>Pantau posisi, pergerakan, dan perhatian GPS seluruh armada dalam satu layar.</p></div><button onClick={() => load()} disabled={loading}><FiRefreshCw className={loading ? "spin" : ""}/> {loading ? "Memuat…" : "Sinkronkan GPS"}</button></header>
      <section className="fleet-map-stats"><article><FiTruck /><div><small>TOTAL ARMADA</small><strong>{trucks.length}</strong><span>Terdaftar</span></div></article><article><FiMapPin /><div><small>TERHUBUNG GPS</small><strong>{mapped.length}</strong><span>Memiliki koordinat</span></div></article><article><FiNavigation /><div><small>SEDANG JALAN</small><strong>{movingAll.length}</strong><span>Dispatch / bergerak</span></div></article><article className={attentionAll.length ? "warning" : ""}><FiAlertTriangle /><div><small>PERLU PERHATIAN</small><strong>{attentionAll.length + unmapped}</strong><span>{unmapped} tanpa GPS</span></div></article></section>
      {error && <div className="fleet-map-error">{error}</div>}
      <section className="fleet-map-card google-map-card">
        <div className="fleet-map-toolbar"><div><h2>Live Position</h2><p>{visible.length} armada ditampilkan · pembaruan setiap 1 menit</p></div><div className="fleet-map-filters"><button className={mapFilter === "ALL" ? "active" : ""} onClick={() => setMapFilter("ALL")}><FiTruck/> Semua</button><button className={mapFilter === "MOVING" ? "active" : ""} onClick={() => setMapFilter("MOVING")}><FiNavigation/> Bergerak</button><button className={mapFilter === "ATTENTION" ? "attention active" : "attention"} onClick={() => setMapFilter("ATTENTION")}><FiActivity/> Perhatian</button></div><label><FiSearch /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Cari BK, pengemudi…" /></label></div>
        <div className="fleet-map-canvas">
          {loading && <LoadingState variant="overlay" label="Menyiapkan peta armada" note="Menyinkronkan posisi GPS terbaru…" />}
          {GOOGLE_MAPS_API_KEY ? <GoogleFleetMap trucks={visible} focusTruckId={focusTruckId} onError={setMapError} /> : <div className="google-map-setup"><FiMapPin /><h3>Google Maps belum dikonfigurasi</h3><p>Tambahkan <code>VITE_GOOGLE_MAPS_API_KEY</code> pada environment frontend, lalu aktifkan Maps JavaScript API dan billing di Google Cloud.</p></div>}
          {!loading && GOOGLE_MAPS_API_KEY && moving.length > 0 && <aside className="moving-fleet-panel"><header><span><FiNavigation /></span><div><strong>Armada Bergerak</strong><small>{moving.length} kendaraan terdeteksi jalan</small></div></header><div className="moving-fleet-list">{moving.map((truck) => <button type="button" key={truck.id} className={focusTruckId === truck.id ? "active" : ""} onClick={() => setFocusTruckId(truck.id)}><i /><span><strong>{truck.plateNumber}</strong><small>{truck.gpsLocation?.name || "Dalam perjalanan"}</small></span><b>{Number(truck.lastGpsSpeed || 0).toFixed(0)}<small>km/j</small></b><FiChevronRight /></button>)}</div></aside>}
          {mapError && <div className="fleet-map-error google-map-runtime-error">{mapError}</div>}
          {!loading && GOOGLE_MAPS_API_KEY && !visible.length && <div className="fleet-map-empty">Belum ada armada dengan koordinat GPS yang cocok.</div>}
        </div>
      </section>
      <section className="fleet-city-section">
        <header><div><span>SEBARAN LOKASI</span><h2>Lokasi Armada per Kota</h2><p>Pengelompokan otomatis dari koordinat GPS terbaru kendaraan.</p></div><b><FiMap/> {cityGroups.filter((group)=>group.city!=="Mengenali lokasi…").length} wilayah</b></header>
        {loading ? <LoadingState label="Memuat lokasi armada" note="Mengenali kota dari posisi GPS…" rows={3}/> : cityGroups.length ? <div className="fleet-city-grid">{cityGroups.map((group)=><article key={group.city} className={group.city==="Mengenali lokasi…"?"resolving":""}><div className="fleet-city-title"><span><FiMapPin/></span><div><small>KOTA / KABUPATEN</small><h3>{group.city}</h3></div><b>{group.trucks.length} armada</b></div><div className="fleet-city-summary"><span>{group.moving} bergerak</span><span>{group.trucks.length-group.moving} berhenti / standby</span></div><div className="fleet-city-trucks">{group.trucks.map((truck)=><button type="button" key={truck.id} onClick={()=>{setFocusTruckId(truck.id);document.querySelector('.fleet-map-card')?.scrollIntoView({behavior:'smooth',block:'start'});}}><i style={{background:markerColor(truck)}}/><span><strong>{truck.plateNumber}</strong><small>{truck.driverUser?.name||"Belum ada pengemudi"}</small></span><em>{Number(truck.lastGpsSpeed||0).toFixed(0)} km/j</em><FiChevronRight/></button>)}</div></article>)}</div> : <div className="fleet-city-empty"><FiMapPin/><p>Belum ada armada dengan koordinat GPS.</p></div>}
      </section>
    </main>
  );
}
