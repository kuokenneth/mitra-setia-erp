// src/pages/Expenses.jsx - Corporate Minimalist Design
import { Fragment, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { api, getAccessToken, openPrintDocument } from "../api";
import { useAuth } from "../AuthContext";
import { useLiveRefresh } from "../liveUpdates";
import { ProtectedFilePreview } from "../components/ProtectedFile";
import LoadingState from "../components/LoadingState";
import PageHeader, { ActionGroup, ActionToolbar } from "../components/PageHeader";
import { FiArrowRight, FiCalendar, FiCheckCircle, FiClipboard, FiClock, FiCornerUpLeft, FiCreditCard, FiDownload, FiFileText, FiPlus, FiPrinter, FiSearch, FiTruck, FiX } from "react-icons/fi";
import "./Expenses.css";

// Corporate Green Color Palette (matching Landing/Dashboard)
const BRAND = {
  primary: "#0D7C3D",
  primaryDark: "#0A6331",
  primaryLight: "#10A050",
  secondary: "#F5F9F7",
  accent: "#D4E8DC",
  text: "#1A1A1A",
  textMuted: "#6B7280",
  white: "#FFFFFF",
  border: "#E5E7EB",
  borderLight: "#F3F4F6",
  danger: "#DC2626",
  dangerLight: "#FEE2E2",
  warning: "#F59E0B",
  warningLight: "#FEF3C7",
  info: "#3B82F6",
  infoLight: "#DBEAFE",
};

const EXPENSE_CATEGORIES = {
  PANJAR: "Panjar",
  TRIP_ALLOWANCE: "Uang Jalan",
  REMAINING_TRIP_ALLOWANCE: "Sisa Uang Jalan",
  UNLOADING_FEE: "Uang Bongkar",
  FUEL_LOAN: "Pinjaman Minyak",
  LOADING_LOAN: "Pinjaman Muat",
  DRIVER_SALARY: "Gaji Sopir",
  FUEL: "BBM",
  TOLL_PARKING: "Tol & Parkir",
  LOADING_UNLOADING: "Bongkar Muat",
  REPAIR_MAINTENANCE: "Perbaikan & Perawatan",
  SPAREPART: "Sparepart",
  OFFICE_OPERATIONAL: "Operasional Kantor",
  EMPLOYEE_SALARY: "Gaji Karyawan",
  OPERATIONAL_COST: "Biaya Operasional",
  ELECTRICITY: "Listrik",
  WATER: "Air",
  TELECOMMUNICATION: "Telkom / Komunikasi",
  OFFICE_EQUIPMENT: "Peralatan Kantor",
  COMMISSION_FEE: "Komisi / Fee",
  DOCUMENT_ADMINISTRATION: "Pengurusan Surat",
  BPJS: "BPJS",
  TAX: "Pajak",
  EMPLOYEE_RECEIVABLE: "Piutang Karyawan",
  FINANCE_DEBT_PAYMENT: "Pembayaran Utang Finance",
  OTHER: "Lainnya",
};

const EXPENSE_CATEGORY_GROUPS = [
  { label: "Perjalanan & Armada", values: ["PANJAR", "TRIP_ALLOWANCE", "REMAINING_TRIP_ALLOWANCE", "UNLOADING_FEE", "FUEL_LOAN", "LOADING_LOAN", "DRIVER_SALARY", "FUEL", "TOLL_PARKING", "LOADING_UNLOADING", "REPAIR_MAINTENANCE", "SPAREPART"] },
  { label: "Kantor & Utilitas", values: ["OFFICE_OPERATIONAL", "OPERATIONAL_COST", "ELECTRICITY", "WATER", "TELECOMMUNICATION", "OFFICE_EQUIPMENT"] },
  { label: "Karyawan & Kewajiban", values: ["EMPLOYEE_SALARY", "EMPLOYEE_RECEIVABLE", "FINANCE_DEBT_PAYMENT", "COMMISSION_FEE", "BPJS", "TAX", "DOCUMENT_ADMINISTRATION"] },
  { label: "Lainnya", values: ["OTHER"] },
];

function todayInJakarta() {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Jakarta",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
}

function expenseMonthLabel(value) {
  if (!/^\d{4}-\d{2}$/.test(value || "")) return "bulan ini";
  const [year, month] = value.split("-").map(Number);
  return new Intl.DateTimeFormat("id-ID", { month: "long", year: "numeric" }).format(new Date(year, month - 1, 1));
}

function normalizedExpenseMonth(value) {
  const match = String(value || "").trim().match(/^(\d{4})-(\d{1,2})/);
  if (!match) return "";
  const month = Number(match[2]);
  return month >= 1 && month <= 12 ? `${match[1]}-${String(month).padStart(2, "0")}` : "";
}

function expenseDateKey(item) {
  const value = item?.expenseDate || item?.createdAt;
  if (!value) return "unknown";
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Jakarta",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date(value));
}

export default function Expenses() {
  const { user } = useAuth();
  const role = user?.role || "UNKNOWN";
  const allowed = role === "OWNER" || role === "ADMIN" || role === "STAFF";
  const canUploadProof = role === "OWNER" || role === "ADMIN" || role === "STAFF";
  const canApprove = role === "OWNER";

  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [pendingApprovalTotal, setPendingApprovalTotal] = useState(0);
  const [statusCounts, setStatusCounts] = useState({ SUBMITTED: 0, PAID: 0, APPROVED: 0 });
  const [approveAllBusy, setApproveAllBusy] = useState(false);
  const [loading, setLoading] = useState(false);
  const [actionBusy, setActionBusy] = useState({});
  const [err, setErr] = useState("");
  const [trips, setTrips] = useState([]);
  const [expenseTrucks, setExpenseTrucks] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [employeeParties, setEmployeeParties] = useState([]);
  const [financeDebts, setFinanceDebts] = useState([]);
  const [financeDebtOpen, setFinanceDebtOpen] = useState(false);
  const [returnOpen, setReturnOpen] = useState(false);
  const [returnSaving, setReturnSaving] = useState(false);
  const [expenseReturns, setExpenseReturns] = useState([]);
  const [returnForm, setReturnForm] = useState({ returnDate: todayInJakarta(), truckId: "", amount: "", paymentMethod: "BANK_TRANSFER", reason: "", notes: "" });
  const [financeDebtSaving, setFinanceDebtSaving] = useState(false);
  const [financeDebtForm, setFinanceDebtForm] = useState({ leasingName: "", contractNumber: "", originalAmount: "", notes: "" });
  const [allocationMode, setAllocationMode] = useState("GENERAL");
  const [tripSearch, setTripSearch] = useState("");
  const [truckSearch, setTruckSearch] = useState("");
  const [tripLoading, setTripLoading] = useState(false);
  const [emptyReturnOpen, setEmptyReturnOpen] = useState(false);
  const [eligibleTrucks, setEligibleTrucks] = useState([]);
  const [emptyReturnLoading, setEmptyReturnLoading] = useState(false);
  const [emptyReturnSaving, setEmptyReturnSaving] = useState(false);
  const [emptyReturnForm, setEmptyReturnForm] = useState({ truckId: "", plannedDepartAt: "", reason: "Kembali ke Medan tanpa muatan" });

  const [q, setQ] = useState("");
  const [methodFilter, setMethodFilter] = useState("");
  const loadSequenceRef = useRef(0);

  const [isMobile, setIsMobile] = useState(() =>
    window.matchMedia("(max-width: 900px)").matches
  );

  useEffect(() => {
    const mq = window.matchMedia("(max-width: 900px)");
    const onChange = () => setIsMobile(mq.matches);
    if (mq.addEventListener) mq.addEventListener("change", onChange);
    else mq.addListener(onChange);
    return () => {
      if (mq.removeEventListener) mq.removeEventListener("change", onChange);
      else mq.removeListener(onChange);
    };
  }, []);

  const [form, setForm] = useState({
    expenseDate: todayInJakarta(),
    tripId: "",
    truckId: "",
    category: "TRIP_ALLOWANCE",
    paymentMethod: "BANK_TRANSFER",
    bankName: "",
    accountName: "",
    accountNumber: "",
    giroIssuedAt: "",
    giroDueAt: "",
    amount: "",
    currency: "IDR",
    reason: "",
    clientName: "",
    notes: "",
    employeeId: "",
    employeePartyId: "",
    employeeIsNew: false,
    employeeName: "",
    employeePhone: "",
    financeDebtId: "",
  });

  const [submitting, setSubmitting] = useState(false);
  const [reportBusy, setReportBusy] = useState(false);
  const [exportBusy, setExportBusy] = useState(false);
  const [reportFeedback, setReportFeedback] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const [detailItem, setDetailItem] = useState(null);
  const [pasteTarget, setPasteTarget] = useState(null);
  const [pasteBusy, setPasteBusy] = useState(false);
  const [pasteError, setPasteError] = useState("");
  const [reportMonth, setReportMonth] = useState(() => {
    const d = new Date();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    return `${d.getFullYear()}-${m}`;
  });

  const API_BASE = (import.meta.env.VITE_API_URL || "http://localhost:4000").replace(/\/$/, "");

  function setRowBusy(id, action) {
    setActionBusy(current => {
      if (action) return { ...current, [id]: action };
      const next = { ...current };
      delete next[id];
      return next;
    });
  }

  function updateRow(id, updated) {
    setItems(current => current.map(item => item.id === id ? { ...item, ...updated } : item));
  }

  async function prepareProofFile(file) {
    if (!file?.type?.startsWith("image/") || file.size < 900 * 1024 || typeof createImageBitmap !== "function") return file;
    try {
      const bitmap = await createImageBitmap(file);
      const maxSide = 1800;
      const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(bitmap.width * scale);
      canvas.height = Math.round(bitmap.height * scale);
      canvas.getContext("2d").drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      bitmap.close?.();
      const blob = await new Promise(resolve => canvas.toBlob(resolve, "image/jpeg", 0.82));
      if (!blob || blob.size >= file.size) return file;
      return new File([blob], `${file.name.replace(/\.[^.]+$/, "") || "bukti"}.jpg`, { type: "image/jpeg", lastModified: Date.now() });
    } catch {
      return file;
    }
  }

  function resetForm() {
    setAllocationMode("GENERAL");
    setTripSearch("");
    setTruckSearch("");
    setForm({
      expenseDate: todayInJakarta(),
      tripId: "",
      truckId: "",
      category: "TRIP_ALLOWANCE",
      paymentMethod: "BANK_TRANSFER",
      bankName: "",
      accountName: "",
      accountNumber: "",
      giroIssuedAt: "",
      giroDueAt: "",
      amount: "",
      currency: "IDR",
      reason: "",
      clientName: "",
      notes: "",
      employeeId: "",
      employeePartyId: "",
      employeeIsNew: false,
      employeeName: "",
      employeePhone: "",
      financeDebtId: "",
    });
  }

  function selectAllocationMode(mode) {
    setAllocationMode(mode);
    setForm((current) => ({
      ...current,
      tripId: mode === "TRIP" ? current.tripId : "",
      truckId: mode === "TRUCK" ? current.truckId : "",
    }));
  }

  function onChangeForm(field, value) {
    if (field === "paymentMethod") {
      setForm((f) => ({
        ...f,
        paymentMethod: value,
        bankName: value === "BANK_TRANSFER" || value === "GIRO" ? f.bankName : "",
        accountName: value === "BANK_TRANSFER" || value === "GIRO" ? f.accountName : "",
        accountNumber: value === "BANK_TRANSFER" || value === "GIRO" ? f.accountNumber : "",
        giroIssuedAt: value === "GIRO" ? f.giroIssuedAt : "",
        giroDueAt: value === "GIRO" ? f.giroDueAt : "",
      }));
      return;
    }
    setForm((f) => ({ ...f, [field]: value }));
  }

  const load = useCallback(async () => {
    const requestId = ++loadSequenceRef.current;
    setLoading(true);
    setErr("");
    try {
      const params = new URLSearchParams();
      if (q.trim()) params.set("q", q.trim());
      if (methodFilter) params.set("paymentMethod", methodFilter);
      const selectedMonth = normalizedExpenseMonth(reportMonth);
      if (selectedMonth) params.set("month", selectedMonth);
      params.set("all", "true");

      const data = await api(`/expenses?${params.toString()}`);
      if (requestId !== loadSequenceRef.current) return;
      setItems(data.items || []);
      setTotal(data.total || 0);
      setPendingApprovalTotal(data.pendingApprovalTotal || 0);
      setStatusCounts({ SUBMITTED: 0, PAID: 0, APPROVED: 0, ...(data.statusCounts || {}) });
    } catch (e) {
      if (requestId !== loadSequenceRef.current) return;
      setErr(e.message || "Gagal memuat expenses");
    } finally {
      if (requestId === loadSequenceRef.current) setLoading(false);
    }
  }, [methodFilter, q, reportMonth]);

  async function loadTrips(search = "") {
    setTripLoading(true);
    try {
      const params = new URLSearchParams();
      if (search.trim()) params.set("q", search.trim());
      const data = await api(`/trips?${params.toString()}`);
      setTrips((data.items || []).filter((trip) => !["COMPLETED", "CANCELLED"].includes(trip.status)));
    } catch (e) {
      setErr(e.message || "Gagal memuat trips");
    } finally {
      setTripLoading(false);
    }
  }

  async function loadExpenseTrucks() {
    try {
      const data = await api("/trucks");
      setExpenseTrucks(data.items || []);
    } catch (e) {
      setErr(e.message || "Gagal memuat Master Armada");
    }
  }

  async function loadReturns() {
    try { const data = await api("/expenses/returns"); setExpenseReturns(data.items || []); }
    catch (e) { setErr(e.message || "Gagal memuat retur pengeluaran"); }
  }

  function openReturn() {
    setReturnForm({ returnDate: todayInJakarta(), truckId: expenseTrucks[0]?.id || "", amount: "", paymentMethod: "BANK_TRANSFER", reason: "", notes: "" });
    setReturnOpen(true); void loadReturns();
  }

  async function createReturn(e) {
    e.preventDefault(); setReturnSaving(true); setErr("");
    try {
      await api("/expenses/returns", { method: "POST", body: JSON.stringify({ ...returnForm, amount: Number(returnForm.amount || 0) }) });
      await Promise.all([loadReturns(), load()]);
      setReturnForm({ returnDate: todayInJakarta(), truckId: returnForm.truckId, amount: "", paymentMethod: "BANK_TRANSFER", reason: "", notes: "" });
      setReportFeedback("Retur pengeluaran berhasil dicatat");
    } catch (error) { setErr(error.message || "Gagal mencatat retur pengeluaran"); }
    finally { setReturnSaving(false); }
  }

  async function loadEmployees() {
    try {
      const data = await api("/expenses/employees");
      setEmployees(data.employees || []);
      setEmployeeParties(data.employeeParties || []);
    } catch (e) {
      setErr(e.message || "Gagal memuat daftar karyawan");
    }
  }

  async function loadFinanceDebts() {
    try { const data = await api("/expenses/finance-debts"); setFinanceDebts(data.debts || []); }
    catch (e) { setErr(e.message || "Gagal memuat utang finance"); }
  }

  function openFinanceDebts() {
    setFinanceDebtOpen(true);
    loadFinanceDebts();
  }

  async function createFinanceDebt(e) {
    e.preventDefault(); setFinanceDebtSaving(true); setErr("");
    try {
      await api("/expenses/finance-debts", { method: "POST", body: JSON.stringify({ ...financeDebtForm, originalAmount: Number(financeDebtForm.originalAmount || 0) }) });
      setFinanceDebtForm({ leasingName: "", contractNumber: "", originalAmount: "", notes: "" });
      await loadFinanceDebts();
    } catch (error) { setErr(error.message || "Gagal menambah utang finance"); }
    finally { setFinanceDebtSaving(false); }
  }

  async function openEmptyReturn() {
    setEmptyReturnOpen(true);
    setEmptyReturnLoading(true);
    setErr("");
    try {
      const data = await api("/trucks");
      const outsideMedan = (data.items || []).filter((truck) => {
        const location = String(truck.currentLocation || "").trim().toLocaleLowerCase("id-ID");
        return truck.status === "WAITING_BACKHAUL" && location && !location.includes("medan");
      });
      setEligibleTrucks(outsideMedan);
      setEmptyReturnForm({ truckId: outsideMedan[0]?.id || "", plannedDepartAt: new Date().toISOString().slice(0, 16), reason: "Kembali ke Medan tanpa muatan" });
    } catch (e) {
      setErr(e.message || "Gagal memuat truk di luar Medan");
    } finally {
      setEmptyReturnLoading(false);
    }
  }

  async function createEmptyReturnTrip() {
    if (!emptyReturnForm.truckId) return setErr("Pilih truk yang akan kembali kosong");
    setEmptyReturnSaving(true);
    setErr("");
    try {
      const trip = await api("/trips/empty-return", {
        method: "POST",
        body: JSON.stringify({
          expenseDate: form.expenseDate,
          truckId: emptyReturnForm.truckId,
          plannedDepartAt: emptyReturnForm.plannedDepartAt || null,
          reason: emptyReturnForm.reason,
        }),
      });
      await loadTrips("");
      setForm((value) => ({ ...value, tripId: trip.id }));
      setTripSearch("");
      setEmptyReturnOpen(false);
    } catch (e) {
      setErr(e.message || "Gagal membuat trip kembali kosong");
    } finally {
      setEmptyReturnSaving(false);
    }
  }
  useLiveRefresh(load);

  useEffect(() => {
    if (!allowed) return;
    loadExpenseTrucks();
    loadReturns();
    loadEmployees();
    loadFinanceDebts();
  }, [allowed]);

  useEffect(() => {
    if (!allowed) return;
    const t = setTimeout(() => {
      load();
    }, q.trim() ? 250 : 0);
    return () => clearTimeout(t);
  }, [allowed, load, q]);

  useEffect(() => {
    if (!allowed) return;
    const t = setTimeout(() => {
      loadTrips(tripSearch);
    }, 250);
    return () => clearTimeout(t);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tripSearch]);

  async function onSubmit(e) {
    e.preventDefault();
    setSubmitting(true);
    try {
      await api("/expenses", {
        method: "POST",
        body: JSON.stringify({
          expenseDate: form.expenseDate,
          tripId: form.tripId || undefined,
          truckId: form.truckId || undefined,
          category: form.category,
          paymentMethod: form.paymentMethod,
          bankName: form.bankName,
          accountName: form.accountName,
          accountNumber: form.accountNumber,
          giroIssuedAt: form.giroIssuedAt,
          giroDueAt: form.giroDueAt,
          amount: Number(form.amount || 0),
          currency: form.currency || "IDR",
          reason: form.reason,
          clientName: form.clientName,
          notes: form.notes,
          employeeId: form.category === "EMPLOYEE_RECEIVABLE" ? form.employeeId : undefined,
          employeePartyId: form.category === "EMPLOYEE_RECEIVABLE" ? form.employeePartyId : undefined,
          employeeName: form.category === "EMPLOYEE_RECEIVABLE" && form.employeeIsNew ? form.employeeName : undefined,
          employeePhone: form.category === "EMPLOYEE_RECEIVABLE" && form.employeeIsNew ? form.employeePhone : undefined,
          financeDebtId: form.category === "FINANCE_DEBT_PAYMENT" ? form.financeDebtId : undefined,
        }),
      });
      resetForm();
      load();
      loadFinanceDebts();
      setShowModal(false);
    } catch (e) {
      setErr(e.message || "Gagal membuat expense");
    } finally {
      setSubmitting(false);
    }
  }

  async function onDelete(id) {
    if (!confirm("Delete this expense?")) return;
    try {
      await api(`/expenses/${id}`, { method: "DELETE" });
      load();
    } catch (e) {
      setErr(e.message || "Gagal menghapus expense");
    }
  }

  async function uploadProof(expenseId, file, replace = false) {
    const uploadFile = await prepareProofFile(file);
    const formData = new FormData();
    formData.append("files", uploadFile);

    const token = getAccessToken();
    const res = await fetch(`${API_BASE}/api/uploads`, {
      method: "POST",
      body: formData,
      credentials: "include",
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data?.error || data?.message || "Gagal mengunggah");
    const item = data.items?.[0];
    if (!item?.url) throw new Error("Gagal mengunggah");

    const updated = await api(`/expenses/${expenseId}/proof`, {
      method: replace ? "PATCH" : "POST",
      body: JSON.stringify({
        proofUrl: item.url,
        proofFileName: item.fileName,
        proofMimeType: item.mimeType,
        proofSize: item.size,
      }),
    });
    return updated.expense || updated;
  }

  async function uploadProofForTarget(file) {
    if (!pasteTarget || pasteBusy || !file) return;
    const target = pasteTarget;
    setPasteBusy(true);
    setPasteError("");
    setRowBusy(target.id, target.status === "PAID" ? "replace" : "upload");
    try {
      const updated = await uploadProof(target.id, file, target.status === "PAID");
      updateRow(target.id, updated);
      setReportFeedback("Bukti pembayaran berhasil diunggah");
      setPasteTarget(null);
    } catch (error) {
      setPasteError(error.message || "Gagal mengunggah bukti pembayaran");
    } finally {
      setRowBusy(target.id, "");
      setPasteBusy(false);
    }
  }

  async function onPasteProof(event) {
    event.preventDefault();
    const clipboardItems = Array.from(event.clipboardData?.items || []);
    const imageItem = clipboardItems.find(item => item.kind === "file" && item.type.startsWith("image/"));
    const blob = imageItem?.getAsFile();
    if (!blob) {
      setPasteError("Clipboard belum berisi gambar. Ambil screenshot/snipping lalu tekan Ctrl+V atau Cmd+V di sini.");
      return;
    }
    const extension = blob.type === "image/png" ? "png" : blob.type === "image/webp" ? "webp" : "jpg";
    await uploadProofForTarget(new File([blob], `bukti-${Date.now()}.${extension}`, { type: blob.type, lastModified: Date.now() }));
  }

  async function onApprove(id) {
    setRowBusy(id, "approve");
    try {
      const updated = await api(`/expenses/${id}/approve`, { method: "POST" });
      updateRow(id, updated);
    } catch (e) {
      setErr(e.message || "Failed to approve expense");
    } finally {
      setRowBusy(id, "");
    }
  }

  async function onApproveAll() {
    if (!pendingApprovalTotal || approveAllBusy) return;
    const selectedMonthLabel = expenseMonthLabel(reportMonth);
    if (!window.confirm(`Setujui ${pendingApprovalTotal} pengeluaran yang sudah dibayar pada ${selectedMonthLabel}? Pengeluaran bulan lain tidak akan ikut disetujui.`)) return;
    setApproveAllBusy(true);
    setErr("");
    try {
      const result = await api("/expenses/approve-all", {
        method: "POST",
        body: JSON.stringify({ q: q.trim(), paymentMethod: methodFilter, month: normalizedExpenseMonth(reportMonth) }),
      });
      setReportFeedback(`${result.approvedCount || 0} pengeluaran berhasil disetujui`);
      await load();
    } catch (e) {
      setErr(e.message || "Gagal menyetujui semua pengeluaran");
    } finally {
      setApproveAllBusy(false);
    }
  }

  function printAllCashVouchers() {
    if (!reportMonth) {
      setErr("Pilih periode bulan untuk mencetak semua kas");
      return;
    }
    const params = new URLSearchParams();
    params.set("month", reportMonth);
    if (q.trim()) params.set("q", q.trim());
    if (methodFilter) params.set("paymentMethod", methodFilter);
    const query = params.toString();
    openPrintDocument(`/expenses/vouchers-print${query ? `?${query}` : ""}`).catch((error) => setErr(error.message || "Gagal membuka semua bukti kas keluar"));
  }

  function openDetail(item) {
    setDetailItem(item);
    setDetailOpen(true);
  }

  async function openMonthlyReport(openInSameTab = false) {
    if (!reportMonth) {
      setErr("Select a month first");
      return;
    }
    const reportWindow = openInSameTab ? null : window.open("", "_blank");
    if (!openInSameTab && !reportWindow) {
      setErr("Popup diblokir browser. Izinkan popup untuk mencetak laporan.");
      return;
    }
    setReportBusy(true);
    setReportFeedback("");
    setErr("");
    if (reportWindow) {
      reportWindow.document.write("<p style='font-family:sans-serif;padding:24px'>Menyiapkan laporan…</p>");
    }
    try {
      const token = getAccessToken();
      const res = await fetch(`${API_BASE}/expenses/report?month=${reportMonth}`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
        credentials: "include",
      });
      const html = await res.text();
      if (!res.ok) throw new Error(html || "Failed to generate report");
      if (openInSameTab) {
        document.open();
        document.write(html);
        document.close();
        return;
      }
      reportWindow.document.open();
      reportWindow.document.write(html);
      reportWindow.document.close();
      reportWindow.focus();
    } catch (e) {
      reportWindow?.close();
      setErr(e.message || "Failed to open report");
    } finally {
      setReportBusy(false);
    }
  }

  async function exportAllExpenses() {
    setErr("");
    setReportFeedback("");
    setExportBusy(true);
    try {
      const token = getAccessToken();
      const res = await fetch(`${API_BASE}/expenses/export`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
        credentials: "include",
      });
      if (!res.ok) throw new Error(await res.text() || "Gagal mengekspor pengeluaran");
      const data = await res.arrayBuffer();
      const signature = new Uint8Array(data, 0, Math.min(4, data.byteLength));
      const isXlsx = signature.length === 4 && signature[0] === 0x50 && signature[1] === 0x4b && signature[2] === 0x03 && signature[3] === 0x04;
      if (!isXlsx) throw new Error("Server belum menghasilkan file XLSX yang valid. Jalankan npm install di backend lalu restart atau deploy ulang backend.");
      const blob = new Blob([data], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
      const disposition = res.headers.get("content-disposition") || "";
      const filename = disposition.match(/filename="?([^";]+)"?/i)?.[1] || "semua-pengeluaran.xlsx";
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = filename;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      URL.revokeObjectURL(url);
    } catch (e) {
      setErr(e.message || "Gagal mengekspor pengeluaran");
    } finally {
      setExportBusy(false);
    }
  }

  const s = useMemo(() => makeStyles(isMobile), [isMobile]);

  if (!allowed) {
    return (
      <div style={s.page}>
        <div style={s.panel}>
          <h1 style={s.hTitle}>Pengeluaran</h1>
          <div style={s.hSub}>Anda tidak memiliki izin untuk melihat halaman ini.</div>
        </div>
      </div>
    );
  }

  const showBankFields = form.paymentMethod === "BANK_TRANSFER";
  const showGiroFields = form.paymentMethod === "GIRO";
  const filteredExpenseTrucks = expenseTrucks.filter((truck) => {
    const query = truckSearch.trim().toLocaleLowerCase("id-ID");
    if (!query) return true;
    return [truck.plateNumber, truck.brand, truck.model]
      .filter(Boolean)
      .join(" ")
      .toLocaleLowerCase("id-ID")
      .includes(query);
  });
  const selectedExpenseTruck = expenseTrucks.find((truck) => truck.id === form.truckId) || null;
  const expenseDateGroups = items.reduce((groups, item, index) => {
    const key = expenseDateKey(item);
    const group = groups.get(key) || { firstIndex: index, count: 0, total: 0 };
    group.count += 1;
    group.total += Number(item.amount || 0);
    groups.set(key, group);
    return groups;
  }, new Map());

  return (
    <div style={s.page} className="expense-page">
      {/* Header */}
      <PageHeader
        className="expense-hero"
        eyebrow="KEUANGAN OPERASIONAL"
        title="Pengeluaran"
        description="Kelola biaya perjalanan, armada, dan operasional dalam satu tempat."
      >
        <ActionToolbar className="expense-header-toolbar" ariaLabel="Aksi pengeluaran">
          <ActionGroup className="expense-report-group" purpose="reports">
            <input
              type="month"
              aria-label="Filter bulan pengeluaran"
              title="Filter daftar pengeluaran berdasarkan bulan"
              value={reportMonth}
              onChange={(e) => setReportMonth(e.target.value)}
            />
            <button type="button" className={`expense-report-button ${reportBusy ? "is-busy" : ""}`} style={s.secondaryBtn} disabled={reportBusy || exportBusy} onClick={() => openMonthlyReport(false)} title="Buka laporan bulanan untuk dicetak">
              <FiFileText /> {reportBusy ? "Menyiapkan…" : "Cetak laporan"}
            </button>
            <button type="button" className={`expense-report-button ${exportBusy ? "is-busy" : ""}`} style={s.secondaryBtn} disabled={reportBusy || exportBusy} onClick={exportAllExpenses} title="Unduh seluruh pengeluaran dalam Excel">
              <FiDownload /> {exportBusy ? "Mengunduh…" : "Export Excel"}
            </button>
            <span className={`expense-report-feedback ${reportFeedback ? "visible" : ""}`} role="status" aria-live="polite">{reportFeedback}</span>
          </ActionGroup>
          <ActionGroup purpose="secondary">
            <button type="button" className="expense-finance-button" style={s.secondaryBtn} onClick={openFinanceDebts} aria-expanded={financeDebtOpen}><FiTruck /> Utang Finance</button>
            <button type="button" className="expense-return-button" style={s.secondaryBtn} onClick={openReturn} aria-expanded={returnOpen}><FiCornerUpLeft /> Retur Pengeluaran</button>
          </ActionGroup>
          <ActionGroup purpose="primary">
            <button className="expense-new-button" style={s.primaryBtn} onClick={() => setShowModal(true)}>
              <FiPlus /> Pengeluaran baru
            </button>
          </ActionGroup>
        </ActionToolbar>
      </PageHeader>

      {/* Stats */}
      <div style={s.statsRow}>
        <div style={s.statCard} className="expense-stat-card expense-stat-waiting">
          <span className="expense-stat-icon"><FiClock /></span>
          <div style={s.statLabel}>Diajukan</div>
          <div style={s.statValue}>{statusCounts.SUBMITTED}</div>
          <div className="expense-stat-note">Periode bulan terpilih</div>
        </div>
        <div style={s.statCard} className="expense-stat-card expense-stat-paid">
          <span className="expense-stat-icon"><FiCreditCard /></span>
          <div style={s.statLabel}>Dibayar</div>
          <div style={s.statValue}>{statusCounts.PAID}</div>
          <div className="expense-stat-note">Periode bulan terpilih</div>
        </div>
        <div style={s.statCard} className="expense-stat-card expense-stat-approved">
          <span className="expense-stat-icon"><FiCheckCircle /></span>
          <div style={s.statLabel}>Disetujui</div>
          <div style={s.statValue}>{statusCounts.APPROVED}</div>
          <div className="expense-stat-note">Periode bulan terpilih</div>
        </div>
        <div style={s.statCard} className="expense-stat-card expense-stat-total">
          <span className="expense-stat-icon"><FiFileText /></span>
          <div style={s.statLabel}>Total transaksi</div>
          <div style={s.statValue}>{total}</div>
          <div className="expense-stat-note">Periode bulan terpilih</div>
        </div>
      </div>

      {/* Main Panel */}
      <div style={s.panel} className="expense-panel">
        <div className="expense-panel-heading">
          <div><div className="expense-eyebrow">DAFTAR TRANSAKSI</div><h2>Riwayat pengeluaran</h2></div>
          <div className="expense-panel-heading-actions">{canApprove && pendingApprovalTotal > 0 && <button type="button" className="expense-approve-all" disabled={approveAllBusy} onClick={onApproveAll} title={`Hanya menyetujui pengeluaran pada ${expenseMonthLabel(reportMonth)}`}><FiCheckCircle /> {approveAllBusy ? "Menyetujui…" : `Setujui ${expenseMonthLabel(reportMonth)} (${pendingApprovalTotal})`}</button>}<button type="button" className="expense-print-all" disabled={!total || !reportMonth} onClick={printAllCashVouchers} title="Cetak seluruh bukti kas pada bulan yang dipilih di atas"><FiPrinter /> Cetak Semua Kas per Bulan</button><span className="expense-result-count">{total ? `${total} transaksi` : "0 transaksi"}</span></div>
        </div>
        {/* Filters */}
        <div style={s.filtersRow} className="expense-filters">
          <div className="expense-search-wrap"><FiSearch /><input style={s.searchInput} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari keperluan, referensi, atau bank..." /></div>
          <select
            value={methodFilter}
            onChange={(e) => setMethodFilter(e.target.value)}
            style={s.selectPill}
          >
            <option value="">Semua metode</option>
            <option value="BANK_TRANSFER">Transfer Bank</option>
            <option value="CASH">Tunai</option>
            <option value="GIRO">Giro</option>
            <option value="OTHER">Lainnya</option>
          </select>
        </div>

        {err ? <div style={s.alertErr} className="expense-error">{err}</div> : null}

        {/* Table */}
        <div style={s.tableWrap} className="expense-table-wrap">
          <table style={s.table} className="expense-table erp-data-table">
            <colgroup>
              <col className="expense-col-date" />
              <col className="expense-col-description" />
              <col className="expense-col-allocation" />
              <col className="expense-col-payment" />
              <col className="expense-col-amount" />
              <col className="expense-col-status" />
              <col className="expense-col-actions" />
            </colgroup>
            <thead>
              <tr>
                <th style={s.th} className="expense-date-spacer-heading" aria-label="Tanggal"></th>
                <th style={s.th}>Pengeluaran</th>
                <th style={s.th}>Alokasi</th>
                <th style={s.th}>Pembayaran</th>
                <th style={s.th}>Nominal</th>
                <th style={s.th}>Status</th>
                <th style={s.th}>Tindakan</th>
              </tr>
            </thead>
            <tbody>
              {loading && items.length === 0 && <tr><td colSpan={7} style={{ padding: 14 }}><LoadingState compact label="Memuat pengeluaran" note="Mengambil transaksi dan status pembayaran…" rows={5} /></td></tr>}
              {items.map((x, index) => {
                const dateKey = expenseDateKey(x);
                const dateGroup = expenseDateGroups.get(dateKey);
                return (
                <Fragment key={x.id}>
                {dateGroup?.firstIndex === index ? <tr key={`date-${dateKey}`} className="expense-date-group-row"><td colSpan={7}><div className="expense-date-group-content"><div className="expense-date"><FiCalendar /><strong>{(x.expenseDate || x.createdAt) ? new Date(x.expenseDate || x.createdAt).toLocaleDateString("id-ID", { timeZone: "Asia/Jakarta", day: "2-digit", month: "long", year: "numeric" }) : "-"}</strong></div><span>{dateGroup.count} transaksi</span><b>{new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(dateGroup.total)}</b></div></td></tr> : null}
                <tr key={x.id} style={s.rowClickable} onClick={() => openDetail(x)}>
                  <td style={s.td} className="expense-date-spacer" aria-hidden="true"></td>
                  <td style={s.td}><div className="expense-row-title">{x.reason || "Tanpa keterangan"}</div><div className="expense-row-meta">{EXPENSE_CATEGORIES[x.category] || "Lainnya"}{x.employee?.name ? ` · ${x.employee.name}` : x.employeeParty?.name ? ` · ${x.employeeParty.name}` : x.financeDebt ? ` · ${x.financeDebt.leasingName}` : x.clientName ? ` · ${x.clientName}` : ""}</div></td>
                  <td style={s.td}><div className="expense-allocation"><span><FiTruck /></span><div><strong>{x.allocationLabel || x.trip?.truck?.plateNumber || x.truck?.plateNumber || "Umum"}</strong><small>{x.allocationLabel ? "Pembayaran gabungan armada dan persediaan" : x.trip?.driverUser?.name || x.trip?.driverNameSnap || x.truck?.driverUser?.name || (x.trip ? "Tanpa nama pengemudi" : x.truck ? "Tanpa nama pengemudi" : "Operasional umum")}</small>{!x.allocationLabel && x.trip ? <small>{x.trip.order?.orderNo || "Perjalanan"}</small> : !x.allocationLabel && x.truck ? <small>Biaya armada</small> : null}</div></div></td>
                  <td style={s.td}><div className="expense-row-title">{x.paymentMethod === "BANK_TRANSFER" ? "Transfer bank" : x.paymentMethod === "CASH" ? "Tunai" : x.paymentMethod === "GIRO" ? "Giro" : "Lainnya"}</div><div className="expense-row-meta">{x.bankName || "—"}</div>{["BANK_TRANSFER","GIRO"].includes(x.paymentMethod) ? <div className="expense-row-meta">{x.paymentMethod === "GIRO" ? `No. ${x.accountNumber || "-"} · ${x.accountName || "Penerima belum diisi"}` : `a.n. ${x.accountName || "Nama rekening belum diisi"}`}</div> : null}</td>
                  <td style={s.tdStrong} className="expense-currency-cell">{new Intl.NumberFormat("id-ID", { style: "currency", currency: x.currency || "IDR", maximumFractionDigits: 0 }).format(x.amount || 0)}</td>
                  <td style={s.td}>
                    <div style={s.statusStack}>
                      <span style={{ ...s.statusPill, ...statusVariant(x.status) }}>
                        {x.status === "APPROVED" ? "Disetujui" : x.status === "PAID" ? "Dibayar" : "Diajukan"}
                      </span>
                      {x.status === "APPROVED" && x.approvedBy?.name ? (
                        <small style={s.approverText}>Oleh {x.approvedBy.name}</small>
                      ) : null}
                      {x.duplicateFlag ? (
                        <span style={{ ...s.statusPill, ...s.dupPill }}>
                          Duplikat{typeof x.duplicateCount === "number" ? ` ×${x.duplicateCount}` : ""}
                        </span>
                      ) : null}
                    </div>
                  </td>
                  <td style={s.td} className="expense-actions-cell">
                    <div style={s.actionsRow} className="expense-actions">
                      {x.proofUrl ? (
                        <div onClick={(e) => e.stopPropagation()}>
                          <ProtectedFilePreview url={x.proofUrl} mimeType={x.proofMimeType} fileName={x.proofFileName || "Bukti expense"} imageStyle={{ width: 68, height: 46, objectFit: "cover", borderRadius: 7 }} onError={(e) => setErr(e.message)} />
                        </div>
                      ) : null}
                      {canUploadProof && ["SUBMITTED", "PAID"].includes(x.status) && (
                        <button type="button" className="expense-action-button expense-paste-button" disabled={Boolean(actionBusy[x.id])} onClick={(event) => {
                          event.stopPropagation();
                          setPasteError("");
                          setPasteTarget(x);
                        }}><FiClipboard /> {actionBusy[x.id] ? "Mengunggah…" : "Bukti Pembayaran"}</button>
                      )}
                      {canApprove && x.status === "PAID" && (
                        <button
                          style={s.approveBtn}
                          className={`expense-action-button expense-action-approve ${actionBusy[x.id] ? "is-busy" : ""}`}
                          disabled={Boolean(actionBusy[x.id])}
                          onClick={(e) => {
                            e.stopPropagation();
                            onApprove(x.id);
                          }}
                        >
                          {actionBusy[x.id] === "approve" ? "Menyetujui…" : "Setujui"}
                        </button>
                      )}
                      {x.status === "SUBMITTED" && <button
                        style={s.deleteBtn}
                        onClick={(e) => {
                          e.stopPropagation();
                          onDelete(x.id);
                        }}
                      >
                        Hapus
                      </button>}
                    </div>
                  </td>
                </tr>
                </Fragment>
                );
              })}

              {!loading && items.length === 0 ? (
                <tr>
                  <td style={s.empty} className="expense-empty-cell" colSpan={7}>
                    Belum ada pengeluaran yang sesuai.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>

      </div>

      {pasteTarget && (
        <div style={s.modalOverlay} onClick={() => !pasteBusy && setPasteTarget(null)}>
          <div
            style={{ ...s.modalCard, width: "min(520px, calc(100vw - 28px))" }}
            className="expense-paste-modal"
            onClick={(event) => event.stopPropagation()}
            onPaste={onPasteProof}
            tabIndex={0}
            autoFocus
          >
            <div style={s.modalHeader}>
              <div className="expense-modal-heading"><span className="expense-modal-icon"><FiClipboard /></span><div><div className="expense-eyebrow">BUKTI PEMBAYARAN</div><div style={s.modalTitle}>{pasteTarget.proofUrl ? "Ganti bukti pembayaran" : "Tambahkan bukti pembayaran"}</div><p>{pasteTarget.reason}</p></div></div>
              <button style={s.closeBtn} disabled={pasteBusy} onClick={() => setPasteTarget(null)} aria-label="Tutup"><FiX /></button>
            </div>
            <div className={`expense-paste-zone ${pasteBusy ? "is-busy" : ""}`}>
              <FiClipboard />
              <strong>{pasteBusy ? "Mengunggah gambar…" : "Tekan Ctrl+V atau Cmd+V"}</strong>
              <span>Ambil screenshot dengan Snipping Tool dan tempel di sini, atau pilih file dari perangkat.</span>
              {pasteError ? <em>{pasteError}</em> : null}
            </div>
            <div className="expense-paste-footer"><span>Format file: JPG, PNG, WebP, atau PDF.</span><div><button type="button" style={s.secondaryBtn} disabled={pasteBusy} onClick={() => setPasteTarget(null)}>Batal</button><label className="expense-proof-file-button"><FiFileText /> Pilih File<input type="file" accept="image/jpeg,image/png,image/webp,application/pdf" disabled={pasteBusy} onChange={async (event) => { const file = event.target.files?.[0]; if (file) await uploadProofForTarget(file); event.target.value = ""; }} /></label></div></div>
          </div>
        </div>
      )}

      {/* Create Modal */}
      {returnOpen && (
        <div style={s.modalOverlay} onClick={() => setReturnOpen(false)}>
          <div style={{ ...s.modalCard, width: "min(820px, calc(100vw - 28px))" }} className="expense-return-modal" onClick={(e) => e.stopPropagation()}>
            <div style={s.modalHeader}><div className="expense-modal-heading"><span className="expense-modal-icon expense-return-icon"><FiCornerUpLeft /></span><div><div className="expense-eyebrow">PENGEMBALIAN DANA</div><div style={s.modalTitle}>Retur Pengeluaran / Panjar</div><p>Catat uang panjar atau uang jalan yang dikembalikan supir.</p></div></div><button style={s.closeBtn} onClick={() => setReturnOpen(false)} aria-label="Tutup"><FiX /></button></div>
            <form onSubmit={createReturn} className="expense-return-form">
              <div className="expense-return-notice"><FiCheckCircle /><span><strong>Retur akan mengurangi biaya armada</strong><small>Kas atau bank bertambah dan pengeluaran operasional berkurang secara otomatis.</small></span></div>
              <div className="expense-return-grid">
                <label style={s.label}>Tanggal Retur<input required type="date" style={{ ...s.input, marginTop: 6 }} value={returnForm.returnDate} onChange={(e) => setReturnForm(f => ({ ...f, returnDate: e.target.value }))} /></label>
                <label style={s.label}>Armada<select required style={{ ...s.select, marginTop: 6 }} value={returnForm.truckId} onChange={(e) => setReturnForm(f => ({ ...f, truckId: e.target.value }))}><option value="">Pilih mobil</option>{expenseTrucks.map(truck => <option key={truck.id} value={truck.id}>{truck.plateNumber} · {[truck.brand, truck.model].filter(Boolean).join(" ") || "Armada"}</option>)}</select></label>
                <label style={s.label}>Jumlah Retur<input required min="1" type="number" style={{ ...s.input, marginTop: 6 }} value={returnForm.amount} onChange={(e) => setReturnForm(f => ({ ...f, amount: e.target.value }))} placeholder="Contoh: 500000" /></label>
                <label style={s.label}>Dana Diterima Melalui<select style={{ ...s.select, marginTop: 6 }} value={returnForm.paymentMethod} onChange={(e) => setReturnForm(f => ({ ...f, paymentMethod: e.target.value }))}><option value="BANK_TRANSFER">Transfer Bank</option><option value="CASH">Tunai</option><option value="OTHER">Lainnya</option></select></label>
                <label style={{ ...s.label, gridColumn: "1 / -1" }}>Alasan<input required style={{ ...s.input, marginTop: 6 }} value={returnForm.reason} onChange={(e) => setReturnForm(f => ({ ...f, reason: e.target.value }))} placeholder="Contoh: Sisa panjar perjalanan dikembalikan supir" /></label>
                <label style={{ ...s.label, gridColumn: "1 / -1" }}>Catatan<textarea style={{ ...s.textarea, marginTop: 6 }} rows={2} value={returnForm.notes} onChange={(e) => setReturnForm(f => ({ ...f, notes: e.target.value }))} placeholder="Opsional" /></label>
              </div>
              <div className="expense-return-actions"><button type="button" style={s.secondaryBtn} onClick={() => setReturnOpen(false)}>Tutup</button><button style={s.primaryBtn} disabled={returnSaving}><FiCornerUpLeft /> {returnSaving ? "Menyimpan…" : "Simpan Retur"}</button></div>
            </form>
            <div className="expense-return-history"><div className="expense-eyebrow">RETUR TERAKHIR</div>{expenseReturns.length ? <div className="expense-return-list">{expenseReturns.slice(0, 6).map(item => <div key={item.id}><span><strong>{item.truck?.plateNumber}</strong><small>{new Date(item.returnDate).toLocaleDateString("id-ID")} · {item.reason}</small></span><b>{new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(item.amount)}</b></div>)}</div> : <p className="expense-return-empty">Belum ada retur pengeluaran.</p>}</div>
          </div>
        </div>
      )}

      {financeDebtOpen && (
        <div style={s.modalOverlay} onClick={() => setFinanceDebtOpen(false)}>
          <div style={{ ...s.modalCard, width: "min(920px, calc(100vw - 28px))" }} onClick={(e) => e.stopPropagation()}>
            <div style={s.modalHeader}><div><div className="expense-eyebrow">KEWAJIBAN LEASING</div><div style={s.modalTitle}>Utang Usaha Finance</div><p>Catat pokok utang awal per leasing. Pembayaran dibuat melalui Pengeluaran.</p></div><button style={s.closeBtn} onClick={() => setFinanceDebtOpen(false)}><FiX /></button></div>
            <div style={{ padding: 22, display: "grid", gap: 18 }}>
              <form onSubmit={createFinanceDebt} style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr", gap: 12, padding: 16, background: BRAND.secondary, borderRadius: 12 }}>
                <label style={s.label}>Nama Leasing<input required style={{ ...s.input, marginTop: 6 }} value={financeDebtForm.leasingName} onChange={(e) => setFinanceDebtForm((form) => ({ ...form, leasingName: e.target.value }))} placeholder="Contoh: BCA Finance" /></label>
                <label style={s.label}>Nomor Kontrak<input style={{ ...s.input, marginTop: 6 }} value={financeDebtForm.contractNumber} onChange={(e) => setFinanceDebtForm((form) => ({ ...form, contractNumber: e.target.value }))} placeholder="Opsional" /></label>
                <label style={s.label}>Utang Awal<input required min="1" type="number" style={{ ...s.input, marginTop: 6 }} value={financeDebtForm.originalAmount} onChange={(e) => setFinanceDebtForm((form) => ({ ...form, originalAmount: e.target.value }))} placeholder="300000000" /></label>
                <label style={{ ...s.label, gridColumn: "1 / -1" }}>Catatan<textarea style={{ ...s.textarea, marginTop: 6 }} rows={2} value={financeDebtForm.notes} onChange={(e) => setFinanceDebtForm((form) => ({ ...form, notes: e.target.value }))} /></label>
                <button style={{ ...s.primaryBtn, width: "max-content" }} disabled={financeDebtSaving}><FiPlus /> {financeDebtSaving ? "Menyimpan…" : "Tambah Utang Finance"}</button>
              </form>
              <div style={{ overflowX: "auto" }}><table style={s.table}><thead><tr><th style={s.th}>Leasing</th><th style={s.th}>Utang Awal</th><th style={s.th}>Sudah Dibayar</th><th style={s.th}>Sisa Utang</th></tr></thead><tbody>{financeDebts.map((debt) => <tr key={debt.id}><td style={s.td}><strong>{debt.leasingName}</strong><div className="expense-row-meta">{debt.contractNumber || "Tanpa nomor kontrak"}</div></td><td style={s.tdStrong}>{new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(debt.originalAmount)}</td><td style={s.td}>{new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(debt.paid)}</td><td style={s.tdStrong}>{new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(debt.balance)}</td></tr>)}</tbody></table>{!financeDebts.length && <div style={{ padding: 22, textAlign: "center", color: BRAND.textMuted }}>Belum ada utang finance.</div>}</div>
            </div>
          </div>
        </div>
      )}

      {showModal && (
        <div style={s.modalOverlay} onClick={() => setShowModal(false)}>
          <div style={s.modalCard} className="expense-create-modal" onClick={(e) => e.stopPropagation()}>
            <div style={s.modalHeader} className="expense-create-header">
              <div className="expense-modal-heading">
                <span className="expense-modal-icon"><FiCreditCard /></span>
                <div><div className="expense-eyebrow">PENCATATAN BIAYA</div><div style={s.modalTitle}>Pengeluaran baru</div><p>Pilih alokasi biaya, lengkapi pembayaran, lalu simpan untuk diajukan.</p></div>
              </div>
              <button style={s.closeBtn} onClick={() => setShowModal(false)} aria-label="Close">
                <FiX />
              </button>
            </div>
            <form className="expense-create-form" onSubmit={onSubmit}>
              <div style={s.formGrid} className="expense-create-fields">
                <div className="expense-form-section-title"><span>01</span><div><strong>Alokasi biaya</strong><small>Hubungkan ke perjalanan, armada, atau biarkan sebagai biaya umum.</small></div></div>
                <div className="expense-allocation-picker">
                  <button type="button" className={allocationMode === "TRIP" ? "active" : ""} onClick={() => selectAllocationMode("TRIP")}>
                    <i><FiArrowRight /></i><span><strong>Perjalanan</strong><small>Biaya untuk satu trip</small></span>
                  </button>
                  <button type="button" className={allocationMode === "TRUCK" ? "active" : ""} onClick={() => selectAllocationMode("TRUCK")}>
                    <i><FiTruck /></i><span><strong>Armada</strong><small>Biaya kendaraan langsung</small></span>
                  </button>
                  <button type="button" className={allocationMode === "GENERAL" ? "active" : ""} onClick={() => selectAllocationMode("GENERAL")}>
                    <i><FiFileText /></i><span><strong>Biaya umum</strong><small>Tidak terkait trip/armada</small></span>
                  </button>
                </div>

                {allocationMode === "TRIP" && <div className="expense-allocation-detail">
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: 12, marginBottom: 8 }}>
                    <div>
                      <label style={{ ...s.label, marginBottom: 3 }}>Pilih perjalanan</label>
                      <div style={{ color: BRAND.textMuted, fontSize: 11 }}>Trip dapat dipilih sampai status Tiba; trip Selesai tidak ditampilkan.</div>
                    </div>
                    <button type="button" onClick={openEmptyReturn} style={{ ...s.secondaryBtn, padding: "9px 13px", whiteSpace: "nowrap" }}>
                      + Kembali kosong
                    </button>
                  </div>
                  <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr", gap: 10 }}>
                    <input
                      style={s.input}
                      value={tripSearch}
                      onChange={(e) => setTripSearch(e.target.value)}
                      placeholder="Cari kendaraan, pengemudi, atau tujuan..."
                    />
                    <select
                      value={form.tripId}
                      onChange={(e) => setForm((current) => ({ ...current, tripId: e.target.value, truckId: "" }))}
                      style={s.select}
                    >
                      <option value="">{tripLoading ? "Memuat perjalanan..." : "Pilih perjalanan"}</option>
                      {trips.map((t) => (
                        <option key={t.id} value={t.id}>
                          {(t.purpose === "EMPTY_RETURN" ? "KEMBALI KOSONG • " : "") +
                            (t.driverName || t.driverUser?.name || "Driver") + " • " +
                            (t.truckPlate || t.truck?.plateNumber || "Truck") + " • " +
                            (t.order?.fromText || t.fromText || "-") + " → " +
                            (t.order?.toText || t.toText || "-") + ` • ${t.status}`}
                        </option>
                      ))}
                    </select>
                  </div>
                  {emptyReturnOpen && (
                    <div className="expense-empty-return" style={{ marginTop: 12, padding: isMobile ? 14 : 16, border: `1px solid #CFE1D5`, borderRadius: 12, background: "#F7FBF8" }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12, marginBottom: 12 }}>
                        <div><div style={{ color: BRAND.primary, fontWeight: 750, fontSize: 13 }}>PERJALANAN KEMBALI KOSONG</div><div style={{ color: BRAND.textMuted, fontSize: 11, marginTop: 3 }}>Hanya menampilkan truk yang menunggu backhaul di luar Medan.</div></div>
                        <button type="button" onClick={() => setEmptyReturnOpen(false)} style={{ border: 0, background: "transparent", color: BRAND.textMuted, fontSize: 18, cursor: "pointer", lineHeight: 1 }}>×</button>
                      </div>
                      {emptyReturnLoading ? <div style={{ color: BRAND.textMuted, fontSize: 12 }}>Memuat truk…</div> : eligibleTrucks.length === 0 ? (
                        <div style={{ color: BRAND.textMuted, fontSize: 12, padding: "12px 0" }}>Tidak ada truk berstatus menunggu backhaul di luar Medan.</div>
                      ) : (
                        <>
                          <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "minmax(0, 1.3fr) minmax(210px, .7fr)", gap: 10 }}>
                            <label style={s.label}>Truk dan rute<select style={{ ...s.select, marginTop: 6 }} value={emptyReturnForm.truckId} onChange={(e) => setEmptyReturnForm((value) => ({ ...value, truckId: e.target.value }))}>
                              {eligibleTrucks.map((truck) => <option key={truck.id} value={truck.id}>{truck.plateNumber} • {truck.currentLocation} → {truck.baseLocation || "Medan"} • {truck.driverUser?.name || "Tanpa pengemudi"}</option>)}
                            </select></label>
                            <label style={s.label}>Rencana berangkat<input type="datetime-local" style={{ ...s.input, marginTop: 6 }} value={emptyReturnForm.plannedDepartAt} onChange={(e) => setEmptyReturnForm((value) => ({ ...value, plannedDepartAt: e.target.value }))} /></label>
                          </div>
                          <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "minmax(0, 1fr) auto", gap: 10, alignItems: "end", marginTop: 10 }}>
                            <label style={s.label}>Alasan<input style={{ ...s.input, marginTop: 6 }} value={emptyReturnForm.reason} onChange={(e) => setEmptyReturnForm((value) => ({ ...value, reason: e.target.value }))} placeholder="Contoh: kendaraan rusak" /></label>
                            <button type="button" style={{ ...s.primaryBtn, minWidth: isMobile ? 0 : 170, height: 46 }} disabled={emptyReturnSaving} onClick={createEmptyReturnTrip}>{emptyReturnSaving ? "Membuat…" : "Buat & pilih trip"}</button>
                          </div>
                        </>
                      )}
                    </div>
                  )}
                </div>}

                {allocationMode === "TRUCK" && <div className="expense-allocation-detail">
                  <label style={s.label}>Cari dan pilih armada</label>
                  {selectedExpenseTruck ? <div className="expense-truck-selected">
                    <i><FiTruck /></i>
                    <div><strong>{selectedExpenseTruck.plateNumber}</strong><span>{[selectedExpenseTruck.brand, selectedExpenseTruck.model].filter(Boolean).join(" ") || "Armada"}</span></div>
                    <button type="button" onClick={() => { setForm((current) => ({ ...current, truckId: "" })); setTruckSearch(""); }}><FiX /> Ganti</button>
                  </div> : <>
                    <div className="expense-truck-search"><FiSearch /><input
                      autoFocus
                      value={truckSearch}
                      onChange={(e) => setTruckSearch(e.target.value)}
                      placeholder="Ketik nomor polisi, merek, atau model..."
                      style={s.input}
                    /></div>
                    <div className="expense-truck-results">
                      {filteredExpenseTrucks.slice(0, 8).map((truck) => <button type="button" key={truck.id} onClick={() => {
                        setForm((current) => ({ ...current, truckId: truck.id, tripId: "" }));
                        setTruckSearch("");
                      }}><i><FiTruck /></i><span><strong>{truck.plateNumber}</strong><small>{[truck.brand, truck.model].filter(Boolean).join(" ") || "Armada"}</small></span><FiArrowRight /></button>)}
                      {!filteredExpenseTrucks.length && <div className="expense-truck-empty">Armada tidak ditemukan. Coba kata pencarian lain.</div>}
                    </div>
                  </>}
                  <div style={{ color: BRAND.textMuted, fontSize: 11, marginTop: 6 }}>
                    Pilih ini untuk pajak, servis, sparepart, atau biaya kendaraan yang tidak terkait dengan satu perjalanan tertentu.
                  </div>
                </div>}

                {allocationMode === "GENERAL" && <div className="expense-general-note"><FiCheckCircle /><div><strong>Dicatat sebagai biaya umum</strong><span>Cocok untuk biaya kantor atau transaksi yang tidak perlu dikaitkan ke perjalanan maupun kendaraan.</span></div></div>}

                <div className="expense-form-section-title"><span>02</span><div><strong>Pembayaran</strong><small>Catat tujuan pembayaran dan nilai transaksi.</small></div></div>

                <div>
                  <label style={s.label}>Tanggal Pengeluaran</label>
                  <input
                    required
                    type="date"
                    style={s.input}
                    value={form.expenseDate}
                    onChange={(e) => onChangeForm("expenseDate", e.target.value)}
                  />
                </div>

                <div>
                  <label style={s.label}>Metode Pembayaran</label>
                  <select
                    value={form.paymentMethod}
                    onChange={(e) => onChangeForm("paymentMethod", e.target.value)}
                    style={s.select}
                  >
                    <option value="BANK_TRANSFER">Transfer Bank</option>
                    <option value="CASH">Tunai</option>
                    <option value="GIRO">Giro</option>
                    <option value="OTHER">Lainnya</option>
                  </select>
                </div>

                {showBankFields && (
                  <>
                    <div>
                      <label style={s.label}>Bank</label>
                      <input
                        style={s.input}
                        value={form.bankName}
                        onChange={(e) => onChangeForm("bankName", e.target.value)}
                        placeholder="Nama bank"
                      />
                    </div>
                    <div>
                      <label style={s.label}>Nama Pemilik Rekening</label>
                      <input
                        style={s.input}
                        value={form.accountName}
                        onChange={(e) => onChangeForm("accountName", e.target.value)}
                        placeholder="Nama pemilik rekening"
                      />
                    </div>
                    <div>
                      <label style={s.label}>Nomor Rekening</label>
                      <input
                        style={s.input}
                        value={form.accountNumber}
                        onChange={(e) => onChangeForm("accountNumber", e.target.value)}
                        placeholder="Optional"
                      />
                    </div>
                  </>
                )}
                {showGiroFields && <>
                  <div><label style={s.label}>Bank Penerbit</label><input required style={s.input} value={form.bankName} onChange={(e)=>onChangeForm("bankName",e.target.value)} placeholder="Nama bank penerbit giro"/></div>
                  <div><label style={s.label}>Nomor Giro</label><input required style={s.input} value={form.accountNumber} onChange={(e)=>onChangeForm("accountNumber",e.target.value)} placeholder="Nomor lembar giro"/></div>
                  <div><label style={s.label}>Nama Penerima</label><input required style={s.input} value={form.accountName} onChange={(e)=>onChangeForm("accountName",e.target.value)} placeholder="Nama penerima giro"/></div>
                  <div><label style={s.label}>Tanggal Terbit</label><input required type="date" style={s.input} value={form.giroIssuedAt} onChange={(e)=>onChangeForm("giroIssuedAt",e.target.value)}/></div>
                  <div><label style={s.label}>Tanggal Jatuh Tempo</label><input required type="date" min={form.giroIssuedAt||undefined} style={s.input} value={form.giroDueAt} onChange={(e)=>onChangeForm("giroDueAt",e.target.value)}/></div>
                </>}

                <div>
                  <label style={s.label}>Jumlah</label>
                  <input
                    style={s.input}
                    type="number"
                    min="0"
                    value={form.amount}
                    onChange={(e) => onChangeForm("amount", e.target.value)}
                    placeholder="0"
                  />
                </div>

                <div className="expense-form-section-title"><span>03</span><div><strong>Rincian pengeluaran</strong><small>Berikan kategori dan keterangan agar mudah ditelusuri.</small></div></div>
                <div>
                  <label style={s.label}>Kategori Pengeluaran</label>
                  <select style={s.select} value={form.category} onChange={(e) => onChangeForm("category", e.target.value)}>
                    {EXPENSE_CATEGORY_GROUPS.map((group) => <optgroup key={group.label} label={group.label}>{group.values.map((value) => <option key={value} value={value}>{EXPENSE_CATEGORIES[value]}</option>)}</optgroup>)}
                  </select>
                </div>
                {form.category === "EMPLOYEE_RECEIVABLE" && <div style={{ display: "grid", gap: 8 }}>
                  <label style={s.label}>Nama Karyawan / Orang</label>
                  <select required style={s.select} value={form.employeeIsNew ? "NEW" : form.employeePartyId ? `PARTY:${form.employeePartyId}` : form.employeeId ? `USER:${form.employeeId}` : ""} onChange={(e) => {
                    const value = e.target.value;
                    setForm(current => ({ ...current, employeeId: value.startsWith("USER:") ? value.slice(5) : "", employeePartyId: value.startsWith("PARTY:") ? value.slice(6) : "", employeeIsNew: value === "NEW", employeeName: "", employeePhone: "" }));
                  }}>
                    <option value="">Pilih orang yang akan ditagih</option>
                    <optgroup label="Pengguna ERP">{employees.map((employee) => <option key={employee.id} value={`USER:${employee.id}`}>{employee.name || employee.email} · {employee.role}</option>)}</optgroup>
                    {!!employeeParties.length && <optgroup label="Kontak tanpa akun">{employeeParties.map((person) => <option key={person.id} value={`PARTY:${person.id}`}>{person.name}{person.phone ? ` · ${person.phone}` : ""}</option>)}</optgroup>}
                    <option value="NEW">+ Tambah orang baru tanpa akun</option>
                  </select>
                  {form.employeeIsNew && <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr", gap: 8 }}>
                    <input required autoFocus style={s.input} value={form.employeeName} onChange={(e) => setForm(current => ({ ...current, employeeName: e.target.value }))} placeholder="Nama lengkap" />
                    <input style={s.input} value={form.employeePhone} onChange={(e) => setForm(current => ({ ...current, employeePhone: e.target.value }))} placeholder="Nomor HP (opsional)" />
                  </div>}
                  <small style={{ color: BRAND.textMuted }}>Orang baru hanya dibuat sebagai kontak piutang dan tidak memiliki akses login.</small>
                </div>}
                {form.category === "FINANCE_DEBT_PAYMENT" && <div>
                  <label style={s.label}>Kontrak Leasing</label>
                  <select required style={s.select} value={form.financeDebtId} onChange={(e) => onChangeForm("financeDebtId", e.target.value)}>
                    <option value="">Pilih leasing dan mobil</option>
                    {financeDebts.filter(debt => debt.balance > 0).map((debt) => <option key={debt.id} value={debt.id}>{debt.leasingName}{debt.contractNumber ? ` · ${debt.contractNumber}` : ""} · Sisa {new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(debt.balance)}</option>)}
                  </select>
                </div>}
                <div>
                  <label style={s.label}>Mata Uang</label>
                  <input
                    style={s.input}
                    value={form.currency}
                    onChange={(e) => onChangeForm("currency", e.target.value)}
                    placeholder="IDR"
                  />
                </div>
                <div>
                  <label style={s.label}>Alasan / Keperluan</label>
                  <input
                    style={s.input}
                    value={form.reason}
                    onChange={(e) => onChangeForm("reason", e.target.value)}
                    placeholder="Listrik, suku cadang, dan lainnya"
                  />
                </div>
                <div>
                  <label style={s.label}>Klien / Referensi</label>
                  <input
                    style={s.input}
                    value={form.clientName}
                    onChange={(e) => onChangeForm("clientName", e.target.value)}
                    placeholder="Nama klien (opsional)"
                  />
                </div>
                <div style={{ gridColumn: "1 / -1" }}>
                  <label style={s.label}>Catatan</label>
                  <textarea
                    style={s.textarea}
                    rows={3}
                    value={form.notes}
                    onChange={(e) => onChangeForm("notes", e.target.value)}
                    placeholder="Catatan tambahan"
                  />
                </div>
              </div>
              <div style={s.formActions} className="expense-create-actions">
                <div className="expense-submit-note"><FiCheckCircle /> Disimpan sebagai pengajuan pengeluaran</div>
                <button style={s.secondaryBtn} type="button" onClick={() => setShowModal(false)}>Batal</button>
                <button style={s.primaryBtn} disabled={submitting}>
                  {submitting ? "Menyimpan..." : "Simpan pengeluaran"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {detailOpen && detailItem && (
        <div style={s.modalOverlay} onClick={() => setDetailOpen(false)}>
          <div style={s.modalCard} onClick={(e) => e.stopPropagation()}>
            <div style={s.modalHeader}>
              <div style={s.modalTitle}>Detail Pengeluaran</div>
              <button style={s.closeBtn} onClick={() => setDetailOpen(false)} aria-label="Close">
                ✕
              </button>
            </div>
            <div style={s.detailGrid}>
              <div>
                <div style={s.detailLabel}>Tanggal Pengeluaran</div>
                <div style={s.detailValue}>{new Date(detailItem.expenseDate || detailItem.createdAt).toLocaleDateString("id-ID", { timeZone: "Asia/Jakarta" })}</div>
              </div>
              <div>
                <div style={s.detailLabel}>Perjalanan</div>
                <div style={s.detailValue}>{detailItem.trip?.id || "-"}</div>
              </div>
              <div>
                <div style={s.detailLabel}>Indikasi Duplikat</div>
                <div style={s.detailValue}>{detailItem.duplicateFlag ? "Yes" : "No"}</div>
              </div>
              <div>
                <div style={s.detailLabel}>Rute</div>
                <div style={s.detailValue}>
                  {(detailItem.trip?.order?.fromText || detailItem.trip?.fromText || "-") +
                    " → " +
                    (detailItem.trip?.order?.toText || detailItem.trip?.toText || "-")}
                </div>
              </div>
              <div>
                <div style={s.detailLabel}>Pengemudi</div>
                <div style={s.detailValue}>
                  {detailItem.trip?.driverUser?.name || detailItem.trip?.driverNameSnap || "-"}
                </div>
              </div>
              <div>
                <div style={s.detailLabel}>Kendaraan</div>
                <div style={s.detailValue}>
                  {detailItem.trip?.truck?.plateNumber || detailItem.trip?.plateNumberSnap || detailItem.truck?.plateNumber || "-"}
                </div>
              </div>
              <div>
                <div style={s.detailLabel}>Kategori</div>
                <div style={s.detailValue}>{EXPENSE_CATEGORIES[detailItem.category] || "Lainnya"}</div>
              </div>
              <div>
                <div style={s.detailLabel}>Alasan</div>
                <div style={s.detailValue}>{detailItem.reason || "-"}</div>
              </div>
              <div>
                <div style={s.detailLabel}>Jumlah</div>
                <div style={s.detailValue}>
                  {new Intl.NumberFormat(undefined, {
                    style: "currency",
                    currency: detailItem.currency || "IDR",
                    maximumFractionDigits: 0,
                  }).format(detailItem.amount || 0)}
                </div>
              </div>
              <div>
                <div style={s.detailLabel}>Status</div>
                <div style={s.detailValue}>{detailItem.status || "SUBMITTED"}</div>
              </div>
              {detailItem.status === "APPROVED" ? (
                <div>
                  <div style={s.detailLabel}>Disetujui oleh</div>
                  <div style={s.detailValue}>{detailItem.approvedBy?.name || "-"}</div>
                </div>
              ) : null}
              <div>
                <div style={s.detailLabel}>Metode Pembayaran</div>
                <div style={s.detailValue}>{detailItem.paymentMethod || "-"}</div>
              </div>
              <div>
                <div style={s.detailLabel}>Bank</div>
                <div style={s.detailValue}>{detailItem.bankName || "-"}</div>
              </div>
              <div>
                <div style={s.detailLabel}>Nama Rekening</div>
                <div style={s.detailValue}>{detailItem.accountName || "-"}</div>
              </div>
              <div>
                <div style={s.detailLabel}>Nomor Rekening</div>
                <div style={s.detailValue}>{detailItem.accountNumber || "-"}</div>
              </div>
              {detailItem.paymentMethod === "GIRO" && <><div><div style={s.detailLabel}>Tanggal Terbit Giro</div><div style={s.detailValue}>{detailItem.giroIssuedAt ? new Date(detailItem.giroIssuedAt).toLocaleDateString("id-ID",{timeZone:"Asia/Jakarta"}) : "-"}</div></div><div><div style={s.detailLabel}>Jatuh Tempo Giro</div><div style={s.detailValue}>{detailItem.giroDueAt ? new Date(detailItem.giroDueAt).toLocaleDateString("id-ID",{timeZone:"Asia/Jakarta"}) : "-"}</div></div></>}
              <div>
                <div style={s.detailLabel}>Klien</div>
                <div style={s.detailValue}>{detailItem.clientName || "-"}</div>
              </div>
              <div>
                <div style={s.detailLabel}>Catatan</div>
                <div style={s.detailValue}>{detailItem.notes || "-"}</div>
              </div>
              {detailItem.duplicateFlag && Array.isArray(detailItem.duplicates) ? (
                <div style={{ gridColumn: "1 / -1" }}>
                  <div style={s.detailLabel}>Duplikat Dengan</div>
                  <div style={s.dupList}>
                    {detailItem.duplicates.map((d) => (
                      <div key={d.id} style={s.dupItem}>
                        <div style={s.dupRow}>
                          <span style={s.dupId}>{d.id.slice(0, 8)}</span>
                          <span style={s.dupAmount}>
                            {new Intl.NumberFormat(undefined, {
                              style: "currency",
                              currency: d.currency || "IDR",
                              maximumFractionDigits: 0,
                            }).format(d.amount || 0)}
                          </span>
                        </div>
                        <div style={s.dupMeta}>
                          {(d.expenseDate || d.createdAt) ? new Date(d.expenseDate || d.createdAt).toLocaleDateString("id-ID", { timeZone: "Asia/Jakarta" }) : "-"} •{" "}
                          {d.reason || "-"} • {d.status || "SUBMITTED"}
                        </div>
                        <div style={s.dupMeta}>
                          {(d.bankName || "-") + " / " + (d.accountName || d.accountNumber || "-")}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : null}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function makeStyles(isMobile) {
  return {
    page: {
      minHeight: "100vh",
      padding: 24,
      background: BRAND.secondary,
      color: BRAND.text,
    },
    panel: {
      background: BRAND.white,
      borderRadius: 8,
      border: `1px solid ${BRAND.border}`,
      padding: 24,
    },
    headerRow: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 12,
      marginBottom: 20,
      flexWrap: "wrap",
    },
    headerActions: {
      display: "flex",
      gap: 10,
      alignItems: "center",
      justifyContent: "flex-end",
      width: "100%",
      marginLeft: "auto",
      flexWrap: "wrap",
    },
    reportActions: {
      display: "flex",
      gap: 8,
      alignItems: "center",
      flexWrap: "wrap",
    },
    monthInput: {
      height: 38,
      padding: "0 10px",
      borderRadius: 6,
      border: `1px solid ${BRAND.border}`,
      background: BRAND.white,
      color: BRAND.text,
      fontSize: 13,
    },
    hTitle: {
      fontSize: 28,
      fontWeight: 700,
      margin: 0,
      color: BRAND.text,
    },
    hSub: {
      marginTop: 4,
      color: BRAND.textMuted,
      fontSize: 14,
    },
    pill: {
      display: "inline-flex",
      alignItems: "center",
      padding: "6px 12px",
      borderRadius: 6,
      border: `1px solid ${BRAND.border}`,
      background: BRAND.secondary,
      color: BRAND.text,
      fontWeight: 500,
      fontSize: 13,
    },
    statsRow: {
      display: "grid",
      gridTemplateColumns: isMobile ? "1fr 1fr" : "repeat(4, 1fr)",
      gap: 12,
      marginBottom: 20,
    },
    statCard: {
      background: BRAND.white,
      borderRadius: 8,
      border: `1px solid ${BRAND.border}`,
      padding: 16,
    },
    statLabel: {
      fontSize: 12,
      fontWeight: 500,
      color: BRAND.textMuted,
      textTransform: "uppercase",
    },
    statValue: {
      fontSize: 24,
      fontWeight: 700,
      color: BRAND.text,
      marginTop: 4,
    },
    filtersRow: {
      display: "flex",
      flexWrap: "wrap",
      gap: 12,
      marginBottom: 16,
      alignItems: "center",
    },
    searchInput: {
      height: 42,
      width: isMobile ? "100%" : 260,
      padding: "0 14px",
      borderRadius: 6,
      border: `1px solid ${BRAND.border}`,
      outline: "none",
      background: BRAND.white,
      color: BRAND.text,
      fontWeight: 500,
      fontSize: 14,
      boxSizing: "border-box",
    },
    selectPill: {
      height: 42,
      minWidth: 160,
      padding: "0 36px 0 14px",
      borderRadius: 6,
      border: `1px solid ${BRAND.border}`,
      outline: "none",
      background: BRAND.white,
      color: BRAND.text,
      fontWeight: 500,
      fontSize: 14,
      appearance: "none",
      WebkitAppearance: "none",
      MozAppearance: "none",
      backgroundImage: `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236B7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e")`,
      backgroundPosition: "right 10px center",
      backgroundSize: "16px",
      backgroundRepeat: "no-repeat",
      cursor: "pointer",
    },
    alertErr: {
      marginBottom: 16,
      padding: 12,
      borderRadius: 6,
      background: BRAND.dangerLight,
      border: `1px solid ${BRAND.danger}30`,
      color: BRAND.danger,
      fontWeight: 500,
      fontSize: 14,
    },
    tableWrap: {
      overflowX: "auto",
      borderRadius: 8,
      border: `1px solid ${BRAND.border}`,
    },
    table: {
      width: "100%",
      borderCollapse: "separate",
      borderSpacing: 0,
      minWidth: 860,
    },
    rowClickable: {
      cursor: "pointer",
    },
    th: {
      textAlign: "left",
      padding: "12px 14px",
      fontSize: 12,
      color: BRAND.textMuted,
      background: BRAND.secondary,
      borderBottom: `1px solid ${BRAND.border}`,
      fontWeight: 600,
      textTransform: "uppercase",
      letterSpacing: "0.5px",
    },
    td: {
      padding: "12px 14px",
      borderBottom: `1px solid ${BRAND.borderLight}`,
      verticalAlign: "middle",
      fontWeight: 500,
      fontSize: 14,
      color: BRAND.text,
    },
    tdSoft: {
      padding: "12px 14px",
      borderBottom: `1px solid ${BRAND.borderLight}`,
      verticalAlign: "middle",
      fontWeight: 500,
      fontSize: 14,
      color: BRAND.textMuted,
    },
    tdStrong: {
      padding: "12px 14px",
      borderBottom: `1px solid ${BRAND.borderLight}`,
      verticalAlign: "middle",
      fontWeight: 600,
      fontSize: 14,
      color: BRAND.text,
    },
    empty: {
      padding: 24,
      textAlign: "center",
      color: BRAND.textMuted,
    },
    statusPill: {
      display: "inline-block",
      padding: "3px 8px",
      borderRadius: 999,
      fontSize: 10,
      fontWeight: 700,
      lineHeight: 1.35,
      whiteSpace: "nowrap",
    },
    statusStack: {
      display: "flex",
      alignItems: "center",
      gap: 5,
      flexWrap: "wrap",
    },
    dupPill: {
      border: "1px solid rgba(245, 158, 11, 0.4)",
      background: "rgba(245, 158, 11, 0.15)",
      color: "#92400E",
    },
    actionsRow: {
      display: "flex",
      gap: 6,
      flexWrap: "wrap",
      alignItems: "center",
    },
    linkBtn: {
      padding: "6px 9px",
      borderRadius: 8,
      border: `1px solid ${BRAND.border}`,
      background: BRAND.white,
      color: BRAND.text,
      fontWeight: 700,
      fontSize: 10,
      cursor: "pointer",
      textDecoration: "none",
      display: "inline-flex",
      alignItems: "center",
    },
    approveBtn: {
      padding: "6px 9px",
      borderRadius: 8,
      border: `1px solid ${BRAND.primary}30`,
      background: BRAND.accent,
      color: BRAND.primary,
      fontWeight: 700,
      fontSize: 10,
      cursor: "pointer",
    },
    deleteBtn: {
      padding: "6px 9px",
      borderRadius: 8,
      border: `1px solid ${BRAND.danger}30`,
      background: BRAND.dangerLight,
      color: BRAND.danger,
      fontWeight: 700,
      fontSize: 10,
      cursor: "pointer",
    },
    footer: {
      marginTop: 16,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 12,
      flexWrap: "wrap",
    },
    pageInfo: {
      fontSize: 14,
      color: BRAND.textMuted,
    },
    primaryBtn: {
      height: 42,
      padding: "0 16px",
      borderRadius: 6,
      border: `1px solid ${BRAND.primary}`,
      background: BRAND.primary,
      color: BRAND.white,
      fontWeight: 500,
      fontSize: 14,
      cursor: "pointer",
      transition: "all 0.2s ease",
    },
    secondaryBtn: {
      height: 42,
      padding: "0 16px",
      borderRadius: 6,
      border: `1px solid ${BRAND.border}`,
      background: BRAND.white,
      color: BRAND.text,
      fontWeight: 500,
      fontSize: 14,
      cursor: "pointer",
      transition: "all 0.2s ease",
    },
    modalOverlay: {
      position: "fixed",
      inset: 0,
      background: "rgba(0, 0, 0, 0.5)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      zIndex: 999,
      padding: 16,
    },
    modalCard: {
      width: "100%",
      maxWidth: 700,
      background: BRAND.white,
      borderRadius: 8,
      border: `1px solid ${BRAND.border}`,
      boxShadow: "0 20px 40px rgba(0, 0, 0, 0.15)",
      overflow: "hidden",
    },
    modalHeader: {
      padding: 16,
      borderBottom: `1px solid ${BRAND.border}`,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
    },
    modalTitle: {
      fontSize: 18,
      fontWeight: 600,
      color: BRAND.text,
    },
    detailGrid: {
      display: "grid",
      gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr",
      gap: 16,
      padding: 16,
    },
    detailLabel: {
      fontSize: 12,
      color: BRAND.textMuted,
      textTransform: "uppercase",
      letterSpacing: "0.4px",
      marginBottom: 4,
    },
    detailValue: {
      fontSize: 14,
      color: BRAND.text,
      fontWeight: 600,
      lineHeight: 1.4,
      wordBreak: "break-word",
    },
    dupList: {
      display: "grid",
      gap: 10,
      marginTop: 6,
    },
    dupItem: {
      border: `1px solid ${BRAND.border}`,
      borderRadius: 6,
      padding: 10,
      background: BRAND.secondary,
    },
    dupRow: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 12,
    },
    dupId: {
      fontSize: 12,
      fontWeight: 700,
      color: BRAND.textMuted,
    },
    dupAmount: {
      fontSize: 13,
      fontWeight: 700,
      color: BRAND.text,
    },
    dupMeta: {
      marginTop: 4,
      fontSize: 12,
      color: BRAND.textMuted,
    },
    closeBtn: {
      width: 32,
      height: 32,
      borderRadius: 6,
      border: `1px solid ${BRAND.border}`,
      background: BRAND.white,
      color: BRAND.textMuted,
      fontSize: 16,
      cursor: "pointer",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    },
    formGrid: {
      padding: 20,
      display: "grid",
      gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr",
      gap: 16,
    },
    formActions: {
      padding: "16px 20px",
      borderTop: `1px solid ${BRAND.border}`,
      display: "flex",
      justifyContent: "flex-end",
      gap: 10,
    },
    label: {
      display: "block",
      fontSize: 12,
      fontWeight: 600,
      color: BRAND.textMuted,
      marginBottom: 6,
    },
    input: {
      width: "100%",
      height: 42,
      padding: "0 14px",
      borderRadius: 6,
      border: `1px solid ${BRAND.border}`,
      outline: "none",
      background: BRAND.white,
      color: BRAND.text,
      fontWeight: 500,
      fontSize: 14,
      boxSizing: "border-box",
    },
    select: {
      width: "100%",
      height: 42,
      padding: "0 36px 0 14px",
      borderRadius: 6,
      border: `1px solid ${BRAND.border}`,
      outline: "none",
      background: BRAND.white,
      color: BRAND.text,
      fontWeight: 500,
      fontSize: 14,
      boxSizing: "border-box",
      appearance: "none",
      WebkitAppearance: "none",
      MozAppearance: "none",
      backgroundImage: `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236B7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e")`,
      backgroundPosition: "right 10px center",
      backgroundSize: "16px",
      backgroundRepeat: "no-repeat",
      cursor: "pointer",
    },
    textarea: {
      width: "100%",
      padding: 12,
      borderRadius: 6,
      border: `1px solid ${BRAND.border}`,
      outline: "none",
      background: BRAND.white,
      color: BRAND.text,
      fontWeight: 500,
      fontSize: 14,
      boxSizing: "border-box",
      resize: "vertical",
    },
    approverText: {
      color: BRAND.textMuted,
      fontSize: 10,
      fontWeight: 600,
      whiteSpace: "nowrap",
    },
  };
}

function statusVariant(status) {
  if (status === "PAID") {
    return { background: BRAND.infoLight, color: BRAND.info, border: `1px solid ${BRAND.info}30` };
  }
  if (status === "APPROVED") {
    return { background: BRAND.accent, color: BRAND.primary, border: `1px solid ${BRAND.primary}30` };
  }
  return { background: BRAND.warningLight, color: "#92400E", border: `1px solid ${BRAND.warning}30` };
}
