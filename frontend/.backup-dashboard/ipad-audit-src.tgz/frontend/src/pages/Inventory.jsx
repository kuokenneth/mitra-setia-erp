// src/pages/Inventory.jsx - Corporate Minimalist Design
import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { api, openPrintDocument, uploadFiles } from "../api";
import { useAuth } from "../AuthContext";
import { useLiveRefresh } from "../liveUpdates";
import LoadingState from "../components/LoadingState";
import { FiArrowDownCircle, FiArrowUpCircle, FiBox, FiFileText, FiMapPin, FiPlus, FiSearch, FiTruck, FiX } from "react-icons/fi";
import "./Inventory.css";
import useDialogLifecycle from "../components/useDialogLifecycle";

// Corporate Green Color Palette (matching Landing/Dashboard)
const BRAND = {
  primary: "#0D7C3D",
  primaryDark: "#0A6331",
  primaryLight: "#10A050",
  secondary: "#F5F9F7",
  accent: "#D4E8DC",
  text: "#1A1A1A",
  textMuted: "#6B7280",
  white: "#FFFFFF",
  border: "#E5E7EB",
  borderLight: "#F3F4F6",
  danger: "#DC2626",
  dangerLight: "#FEE2E2",
  warning: "#F59E0B",
  warningLight: "#FEF3C7",
};

function localDateTimeValue(date = new Date()) {
  const offset = date.getTimezoneOffset() * 60000;
  return new Date(date.getTime() - offset).toISOString().slice(0, 16);
}

function retreadTarget(sourceItem, items) {
  const sku = String(sourceItem?.sku || "").trim().toUpperCase().replace(/_SECOND$/, "");
  const expectedSku = sku.startsWith("BAN_MASAK_") ? sku : sku.startsWith("BAN_") ? `BAN_MASAK_${sku.slice(4)}` : "";
  return items.find((item) => String(item.sku || "").trim().toUpperCase() === expectedSku);
}

//////////////////////
// STYLES
//////////////////////
const pageBg = {
  minHeight: "100vh",
  padding: 24,
  background: BRAND.secondary,
  color: BRAND.text,
};

const container = {
  maxWidth: 1280,
  margin: "0 auto",
};

const headerTitle = {
  fontSize: 28,
  fontWeight: 700,
  margin: 0,
  color: BRAND.text,
};

const headerSub = {
  marginTop: 4,
  color: BRAND.textMuted,
  fontSize: 14,
};

const wrapCard = {
  marginTop: 24,
  background: BRAND.white,
  borderRadius: 8,
  border: `1px solid ${BRAND.border}`,
  padding: 24,
};

function TruckSearchSelect({ trucks, value, onChange, placeholder = "Cari nomor polisi..." }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  const selected = useMemo(() => {
    return (trucks || []).find((t) => t.id === value) || null;
  }, [trucks, value]);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (selected) setQuery(selected.plateNumber || "");
  }, [selected]);

  const filtered = useMemo(() => {
    const q = (query || "").trim().toLowerCase();
    const list = trucks || [];
    if (!q) return list.slice(0, 10);
    return list
      .filter((t) => {
        const text = `${t.plateNumber || ""} ${t.brand || ""} ${t.model || ""}`.toLowerCase();
        return text.includes(q);
      })
      .slice(0, 10);
  }, [trucks, query]);

  return (
    <div style={{ position: "relative" }}>
      <input
        style={{ ...inputPill, minWidth: 0, width: "100%", boxSizing: "border-box" }}
        value={query}
        placeholder={placeholder}
        onChange={(e) => {
          setQuery(e.target.value);
          setOpen(true);
          if (value) onChange("");
        }}
        onFocus={() => setOpen(true)}
        onBlur={() => setTimeout(() => setOpen(false), 140)}
      />

      {open ? (
        <div
          style={{
            position: "absolute",
            top: "calc(100% + 4px)",
            left: 0,
            right: 0,
            background: BRAND.white,
            border: `1px solid ${BRAND.border}`,
            boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
            borderRadius: 8,
            overflow: "hidden",
            zIndex: 50,
          }}
        >
          {filtered.length === 0 ? (
            <div style={{ padding: 12, fontWeight: 500, color: BRAND.textMuted }}>Kendaraan tidak ditemukan</div>
          ) : (
            filtered.map((t) => (
              <button
                key={t.id}
                type="button"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => {
                  onChange(t.id);
                  setQuery(t.plateNumber || "");
                  setOpen(false);
                }}
                style={{
                  width: "100%",
                  textAlign: "left",
                  padding: "10px 12px",
                  border: "none",
                  background: "transparent",
                  cursor: "pointer",
                  transition: "background 0.15s ease",
                }}
                onMouseEnter={(e) => e.target.style.background = BRAND.secondary}
                onMouseLeave={(e) => e.target.style.background = "transparent"}
              >
                <div style={{ fontWeight: 600, color: BRAND.text }}>{t.plateNumber || "-"}</div>
                <div style={{ marginTop: 2, color: BRAND.textMuted, fontSize: 12 }}>
                  {t.brand ? `${t.brand}` : ""} {t.model ? `${t.model}` : ""}
                </div>
              </button>
            ))
          )}
        </div>
      ) : null}
    </div>
  );
}

function ItemSearchSelect({ items, value, onChange }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [menuStyle, setMenuStyle] = useState(null);
  const controlRef = useRef(null);
  const selected = useMemo(() => (items || []).find((item) => item.id === value) || null, [items, value]);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (selected) setQuery(`${selected.sku || ""} — ${selected.name || ""}`);
    if (!selected && !value) setQuery("");
  }, [selected, value]);

  const filtered = useMemo(() => {
    const selectedLabel = selected ? `${selected.sku || ""} — ${selected.name || ""}` : "";
    const keyword = query === selectedLabel ? "" : query.trim().toLowerCase();
    const list = items || [];
    if (!keyword) return list.slice(0, 30);
    return list.filter((item) => `${item.sku || ""} ${item.name || ""} ${item.unit || ""}`.toLowerCase().includes(keyword)).slice(0, 50);
  }, [items, query, selected]);

  useEffect(() => {
    if (!open) return undefined;

    const positionMenu = () => {
      const rect = controlRef.current?.getBoundingClientRect();
      if (!rect) return;
      const gap = 4;
      const viewportPadding = 12;
      const roomBelow = window.innerHeight - rect.bottom - viewportPadding;
      const roomAbove = rect.top - viewportPadding;
      const openAbove = roomBelow < 220 && roomAbove > roomBelow;
      const available = Math.max(120, Math.min(300, (openAbove ? roomAbove : roomBelow) - gap));
      setMenuStyle({
        position: "fixed",
        left: rect.left,
        top: openAbove ? undefined : rect.bottom + gap,
        bottom: openAbove ? window.innerHeight - rect.top + gap : undefined,
        width: rect.width,
        maxHeight: available,
        overflowY: "auto",
        background: BRAND.white,
        border: `1px solid ${BRAND.border}`,
        boxShadow: "0 14px 34px rgba(12, 42, 25, 0.18)",
        borderRadius: 8,
        zIndex: 1200,
      });
    };

    const animationFrame = window.requestAnimationFrame(positionMenu);
    window.addEventListener("resize", positionMenu);
    window.addEventListener("scroll", positionMenu, true);
    return () => {
      window.cancelAnimationFrame(animationFrame);
      window.removeEventListener("resize", positionMenu);
      window.removeEventListener("scroll", positionMenu, true);
    };
  }, [open]);

  return (
    <div ref={controlRef} style={{ position: "relative", minWidth: 280, flex: "1 1 280px" }}>
      <input
        style={{ ...inputPill, minWidth: 0, width: "100%", boxSizing: "border-box" }}
        value={query}
        placeholder="Cari SKU atau nama item..."
        onChange={(e) => { setQuery(e.target.value); if (!open) setMenuStyle(null); setOpen(true); if (value) onChange(""); }}
        onFocus={(e) => { if (!open) setMenuStyle(null); setOpen(true); e.target.select(); }}
        onBlur={() => setTimeout(() => setOpen(false), 140)}
      />
      {open && menuStyle && createPortal(
        <div style={menuStyle}>
          <button type="button" onMouseDown={(e) => e.preventDefault()} onClick={() => { onChange(""); setQuery(""); setOpen(false); }} style={{ width: "100%", textAlign: "left", padding: "10px 12px", border: "none", borderBottom: `1px solid ${BRAND.border}`, background: BRAND.white, color: BRAND.textMuted, cursor: "pointer" }}>Semua item</button>
          {filtered.length ? filtered.map((item) => (
            <button key={item.id} type="button" onMouseDown={(e) => e.preventDefault()} onClick={() => { onChange(item.id); setQuery(`${item.sku || ""} — ${item.name || ""}`); setOpen(false); }} style={{ width: "100%", textAlign: "left", padding: "10px 12px", border: "none", borderBottom: `1px solid ${BRAND.border}`, background: item.id === value ? BRAND.secondary : BRAND.white, cursor: "pointer" }}>
              <strong>{item.sku || "-"}</strong> — {item.name || "-"} <span style={{ color: BRAND.textMuted }}>({item.unit || "PCS"})</span>
            </button>
          )) : <div style={{ padding: 12, color: BRAND.textMuted }}>Item tidak ditemukan.</div>}
        </div>,
        document.body,
      )}
    </div>
  );
}

const pill = {
  display: "inline-flex",
  alignItems: "center",
  padding: "6px 12px",
  borderRadius: 6,
  border: `1px solid ${BRAND.border}`,
  background: BRAND.secondary,
  color: BRAND.text,
  fontWeight: 500,
  fontSize: 13,
  whiteSpace: "nowrap",
};

const pillGreen = {
  ...pill,
  background: BRAND.accent,
  border: `1px solid ${BRAND.primary}30`,
  color: BRAND.primary,
};

const pillRed = {
  ...pill,
  background: BRAND.dangerLight,
  border: `1px solid ${BRAND.danger}30`,
  color: BRAND.danger,
};

const inputPill = {
  height: 42,
  padding: "0 14px",
  borderRadius: 6,
  border: `1px solid ${BRAND.border}`,
  outline: "none",
  background: BRAND.white,
  color: BRAND.text,
  fontWeight: 500,
  fontSize: 14,
  minWidth: 260,
  transition: "border-color 0.2s ease",
};

const selectPill = {
  ...inputPill,
  minWidth: 200,
  appearance: "none",
  WebkitAppearance: "none",
  MozAppearance: "none",
  paddingRight: 36,
  backgroundImage: `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236B7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e")`,
  backgroundPosition: "right 10px center",
  backgroundSize: "16px",
  backgroundRepeat: "no-repeat",
  cursor: "pointer",
};

const btn = {
  height: 42,
  padding: "0 16px",
  borderRadius: 6,
  border: `1px solid ${BRAND.border}`,
  background: BRAND.white,
  color: BRAND.text,
  fontWeight: 500,
  fontSize: 14,
  cursor: "pointer",
  transition: "all 0.2s ease",
};

const btnPrimary = {
  ...btn,
  background: BRAND.primary,
  border: `1px solid ${BRAND.primary}`,
  color: BRAND.white,
};

const btnDanger = {
  ...btn,
  background: BRAND.dangerLight,
  border: `1px solid ${BRAND.danger}30`,
  color: BRAND.danger,
};

const errorBox = {
  marginTop: 16,
  background: BRAND.dangerLight,
  border: `1px solid ${BRAND.danger}30`,
  borderRadius: 6,
  padding: 16,
};

const tableWrap = { overflowX: "auto", borderRadius: 8 };

const table = {
  width: "100%",
  borderCollapse: "separate",
  borderSpacing: 0,
  minWidth: 900,
};

const th = {
  textAlign: "left",
  padding: "12px 16px",
  fontSize: 12,
  color: BRAND.textMuted,
  background: BRAND.secondary,
  borderBottom: `1px solid ${BRAND.border}`,
  fontWeight: 600,
  textTransform: "uppercase",
  letterSpacing: "0.5px",
};

const td = {
  padding: "12px 16px",
  borderBottom: `1px solid ${BRAND.borderLight}`,
  verticalAlign: "middle",
  fontWeight: 500,
  fontSize: 14,
  color: BRAND.text,
};

const tdSoft = {
  ...td,
  color: BRAND.textMuted,
};

//////////////////////
// HOVER BUTTON SYSTEM
//////////////////////
function Btn({ style, disabled, children, ...props }) {
  const [hover, setHover] = useState(false);

  const finalStyle = {
    ...style,
    transition: "all 0.2s ease",
    ...(hover && !disabled ? { transform: "translateY(-1px)", boxShadow: "0 2px 8px rgba(0,0,0,0.1)" } : null),
    ...(disabled ? { opacity: 0.5, cursor: "not-allowed" } : null),
  };

  return (
    <button
      {...props}
      disabled={disabled}
      style={finalStyle}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      {children}
    </button>
  );
}

//////////////////////
// UI HELPERS
//////////////////////
function Pill({ variant = "grey", children }) {
  const style = variant === "green" ? pillGreen : variant === "red" ? pillRed : pill;
  return <span style={style}>{children}</span>;
}

function Modal({ open, title, eyebrow = "INVENTORY", description, tone = "green", className = "", onClose, children }) {
  const { dialogRef, titleId } = useDialogLifecycle(open, onClose);
  if (!open) return null;
  return (
    <div className="inventory-modal-overlay" onClick={(event) => { if (event.target === event.currentTarget) onClose?.(); }}>
      <div ref={dialogRef} role="dialog" aria-modal="true" aria-labelledby={titleId} tabIndex={-1} className={`inventory-modal inventory-modal--${tone} ${className}`.trim()}>
        <div className="inventory-modal-head">
          <div className="inventory-modal-heading">
            <span>{eyebrow}</span>
            <h2 id={titleId}>{title}</h2>
            {description && <p>{description}</p>}
          </div>
          <button type="button" className="inventory-modal-close" onClick={onClose} aria-label="Tutup"><FiX /></button>
        </div>
        <div className="inventory-modal-body">{children}</div>
      </div>
    </div>
  );
}

function EmergencySearchPicker({ label, placeholder, items, value, onChange, itemLabel, itemMeta, icon = FiTruck }) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const selected = items.find((item) => item.id === value) || null;
  const normalized = query.trim().toLocaleLowerCase("id-ID");
  const results = items.filter((item) => `${itemLabel(item)} ${itemMeta(item)}`.toLocaleLowerCase("id-ID").includes(normalized)).slice(0, 8);
  const Icon = icon;
  function choose(item) { onChange(item.id); setQuery(""); setOpen(false); }
  return <div className={`emergency-picker ${open ? "is-open" : ""}`} onBlur={(event) => { if (!event.currentTarget.contains(event.relatedTarget)) setOpen(false); }}><span>{label}</span>{selected ? <div className="emergency-picker-selected"><i><Icon /></i><div><strong>{itemLabel(selected)}</strong><small>{itemMeta(selected)}</small></div><button type="button" onClick={() => { onChange(""); setQuery(""); setOpen(true); }}><FiX /></button></div> : <div className="emergency-picker-control"><FiSearch/><input value={query} placeholder={placeholder} onFocus={() => setOpen(true)} onChange={(event) => { setQuery(event.target.value); setOpen(true); }}/>{open && <div className="emergency-picker-results">{results.map((item) => <button type="button" key={item.id} onMouseDown={(event) => { event.preventDefault(); choose(item); }} onClick={() => choose(item)}><i><Icon /></i><span><strong>{itemLabel(item)}</strong><small>{itemMeta(item)}</small></span></button>)}{!results.length && <em>Tidak ada hasil yang cocok</em>}</div>}</div>}</div>;
}

function fmtDate(d) {
  if (!d) return "—";
  try {
    return new Intl.DateTimeFormat("id-ID", { timeZone: "Asia/Jakarta", day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }).format(new Date(d));
  } catch {
    return String(d);
  }
}

function buildQuery(paramsObj) {
  const sp = new URLSearchParams();
  Object.entries(paramsObj || {}).forEach(([k, v]) => {
    if (v === undefined || v === null || v === "") return;
    sp.set(k, String(v));
  });
  const s = sp.toString();
  return s ? `?${s}` : "";
}

function sumStocks(stocks) {
  return (stocks || []).reduce((a, s) => a + (Number(s.qty) || 0), 0);
}

export default function Inventory() {
  const { user } = useAuth();
  const role = user?.role || "UNKNOWN";
  const allowed = role === "OWNER" || role === "ADMIN" || role === "STAFF" || role === "SPAREPART_ADMIN";
  const isSparepartAdmin = role === "SPAREPART_ADMIN";

  const [tab, setTab] = useState("ITEMS");
  const [q, setQ] = useState("");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);
  const skipInitialTabRefresh = useRef(true);
  const hasCompletedInitialLoad = useRef(false);

  const [items, setItems] = useState([]);
  const [receiveItems, setReceiveItems] = useState([]);
  const [locations, setLocations] = useState([]);
  const [trucks, setTrucks] = useState([]);
  const [units, setUnits] = useState([]);
  const [movements, setMovements] = useState([]);
  const [batches, setBatches] = useState([]);
  const [itemFlowTarget, setItemFlowTarget] = useState(null);
  const [itemFlowMovements, setItemFlowMovements] = useState([]);
  const [itemFlowStockUnits, setItemFlowStockUnits] = useState([]);
  const [itemFlowLoading, setItemFlowLoading] = useState(false);
  const [itemFlowPagination, setItemFlowPagination] = useState({ page: 1, limit: 20, total: 0, totalPages: 1 });
  const [emergencyDispatches, setEmergencyDispatches] = useState([]);
  const [openEmergency, setOpenEmergency] = useState(false);
  const [installDispatch, setInstallDispatch] = useState(null);
  const [emergencyProof, setEmergencyProof] = useState(null);
  const [installProof, setInstallProof] = useState(null);
  const [emergencyUnits, setEmergencyUnits] = useState([]);
  const [oldAssignments, setOldAssignments] = useState([]);
  const [emergencyBusy, setEmergencyBusy] = useState(false);
  const [emergencyPreparing, setEmergencyPreparing] = useState(false);
  const [emergencyForm, setEmergencyForm] = useState({ targetTruckId: "", carrierTruckId: "", itemId: "", fromLocationId: "", stockUnitId: "", qty: 1, note: "" });
  const [installForm, setInstallForm] = useState({ oldStockUnitId: "", oldPartDisposition: "SCRAPPED", note: "" });
  const [itemPage, setItemPage] = useState(1);
  const [unitPage, setUnitPage] = useState(1);
  const [movementPage, setMovementPage] = useState(1);
  const [batchPage, setBatchPage] = useState(1);
  const [itemPagination, setItemPagination] = useState({ page: 1, limit: 20, total: 0, totalPages: 1 });
  const [unitPagination, setUnitPagination] = useState({ page: 1, limit: 20, total: 0, totalPages: 1 });
  const [movementPagination, setMovementPagination] = useState({ page: 1, limit: 20, total: 0, totalPages: 1 });
  const [batchPagination, setBatchPagination] = useState({ page: 1, limit: 20, total: 0, totalPages: 1 });
  const [stockReportDate, setStockReportDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [printMenuOpen, setPrintMenuOpen] = useState(false);

  const [unitStatus, setUnitStatus] = useState("");
  const [unitItemId, setUnitItemId] = useState("");
  const [unitLocationId, setUnitLocationId] = useState("");

  const [openCreateItem, setOpenCreateItem] = useState(false);
  const [createItemError, setCreateItemError] = useState("");
  const [editItemForm, setEditItemForm] = useState(null);
  const [openReceive, setOpenReceive] = useState(false);
  const [openAssign, setOpenAssign] = useState(false);
  const [openLegacyTire, setOpenLegacyTire] = useState(false);
  const [legacyTireBusy, setLegacyTireBusy] = useState(false);
  const [legacyTireNewItem, setLegacyTireNewItem] = useState(false);
  const [legacyTireForm, setLegacyTireForm] = useState({ truckId: "", itemId: "", installedAt: localDateTimeValue(), note: "", sku: "", name: "" });
  const [legacyTireRows, setLegacyTireRows] = useState([{ serialNumber: "", barcode: "", position: "", installedAt: localDateTimeValue() }]);
  const [openCreateLocation, setOpenCreateLocation] = useState(false);
  const [openConsume, setOpenConsume] = useState(false);
  const [openBarcode, setOpenBarcode] = useState(false);
  const [barcodeForm, setBarcodeForm] = useState({ unitId: "", barcode: "" });

  const [mvFrom, setMvFrom] = useState("");
  const [mvTo, setMvTo] = useState("");

  const [openScrap, setOpenScrap] = useState(false);
  const [scrapForm, setScrapForm] = useState({ unitId: "", note: "" });
  const [openRetread, setOpenRetread] = useState(false);
  const [openCompleteRetread, setOpenCompleteRetread] = useState(false);
  const [retreadOptions, setRetreadOptions] = useState({ items: [], suppliers: [], locations: [] });
  const [retreadForm, setRetreadForm] = useState({ unitId: "", serialNumber: "", toItemId: "", supplierId: "", cost: "", sentAt: "", notes: "" });
  const [completeRetreadForm, setCompleteRetreadForm] = useState({ unitId: "", serialNumber: "", locationId: "", completedAt: "" });

  const [createItemForm, setCreateItemForm] = useState({
    sku: "",
    name: "",
    unit: "PCS",
    isSerialized: false,
    category: "GENERAL_SPAREPART",
  });

  const [receiveForm, setReceiveForm] = useState({
    itemId: "",
    locationId: "",
    qty: 1,
    note: "",
    unitLines: "",
    unitPurchasePrice: "",
    totalPurchasePrice: "",
  });
  const [receiveUnitRows, setReceiveUnitRows] = useState([{ serialNumber: "", purchasePrice: "" }]);
  const [assignForm, setAssignForm] = useState({
    unitId: "",
    serialNumber: "",
    truckId: "",
    installedAt: "",
    note: "",
    maintenanceId: "",
  });

  const [newLocationName, setNewLocationName] = useState("");

  const [consumeForm, setConsumeForm] = useState({
    itemId: "",
    locationId: "",
    qty: 1,
    note: "",
    destinationType: "OPERATIONAL",
    truckId: "",
  });

  const serializedItems = useMemo(() => items.filter((x) => x.isSerialized), [items]);
  const selectedReceiveItem = receiveItems.find((x) => x.id === receiveForm.itemId) || items.find((x) => x.id === receiveForm.itemId);
  const qNorm = (q || "").trim().toLowerCase();

  const filteredItems = useMemo(() => {
    if (!qNorm) return items;
    return items.filter((it) => {
      const text = `${it.sku || ""} ${it.name || ""} ${it.unit || ""}`.toLowerCase();
      return text.includes(qNorm);
    });
  }, [items, qNorm]);

  async function loadLocations() {
    const data = await api("/inventory/locations");
    setLocations(data.locations || []);
  }

  async function loadTrucks() {
    const data = await api("/trucks");
    setTrucks(data.trucks || data.items || []);
  }

  async function loadEmergencyDispatches() {
    const data = await api("/inventory/emergency-dispatches");
    setEmergencyDispatches(data.items || []);
  }

  function openEmergencyForm() {
    setErr("");
    setEmergencyForm({ targetTruckId: "", carrierTruckId: "", itemId: "", fromLocationId: "", stockUnitId: "", qty: 1, note: "" });
    setEmergencyUnits([]); setEmergencyProof(null); setOpenEmergency(true);
    const loaders = [];
    if (!trucks.length) loaders.push(loadTrucks());
    if (!locations.length) loaders.push(loadLocations());
    if (!items.length) loaders.push(loadItems());
    if (loaders.length) {
      setEmergencyPreparing(true);
      Promise.all(loaders).catch((error) => setErr(error.message || "Gagal memuat data pengiriman")).finally(() => setEmergencyPreparing(false));
    }
  }

  async function loadEmergencyUnits(itemId, locationId) {
    if (!itemId || !locationId || !items.find((item) => item.id === itemId)?.isSerialized) return setEmergencyUnits([]);
    const data = await api(`/inventory/units?itemId=${encodeURIComponent(itemId)}&locationId=${encodeURIComponent(locationId)}&status=IN_STOCK&limit=200`);
    setEmergencyUnits(data.units || data.items || []);
  }

  async function createEmergencyDispatch(event) {
    event.preventDefault(); setEmergencyBusy(true); setErr("");
    try {
      if (!emergencyProof) throw new Error("Bukti kerusakan foto atau video wajib dipilih");
      const proof = (await uploadFiles([emergencyProof]))[0];
      await api("/inventory/emergency-dispatches", { method: "POST", body: JSON.stringify({ ...emergencyForm, qty: Number(emergencyForm.qty), damageProofUrl: proof.url, damageProofFileName: proof.fileName, damageProofMimeType: proof.mimeType }) });
      setOpenEmergency(false); await Promise.all([loadEmergencyDispatches(), loadItems(), loadUnits(), loadMovements()]);
    } catch (e) { setErr(e.message || "Gagal membuat pengiriman darurat"); } finally { setEmergencyBusy(false); }
  }

  async function openInstallDispatch(dispatch) {
    setInstallDispatch(dispatch); setInstallProof(null); setInstallForm({ oldStockUnitId: "", oldPartDisposition: "SCRAPPED", note: "" });
    try { const data = await api(`/inventory/trucks/${dispatch.targetTruckId}/spareparts?currentOnly=1`); setOldAssignments(data.rows || []); } catch { setOldAssignments([]); }
  }

  async function confirmEmergencyInstall(event) {
    event.preventDefault(); setEmergencyBusy(true); setErr("");
    try {
      if (!installProof) throw new Error("Bukti pemasangan foto atau video wajib dipilih");
      const proof = (await uploadFiles([installProof]))[0];
      await api(`/inventory/emergency-dispatches/${installDispatch.id}/install`, { method: "POST", body: JSON.stringify({ ...installForm, installProofUrl: proof.url, installProofFileName: proof.fileName, installProofMimeType: proof.mimeType }) });
      setInstallDispatch(null); await Promise.all([loadEmergencyDispatches(), loadUnits(), loadMovements()]);
    } catch (e) { setErr(e.message || "Gagal mengonfirmasi pemasangan"); } finally { setEmergencyBusy(false); }
  }

  async function loadItems(page = itemPage) {
    const qs = buildQuery({ q: q || undefined, page, limit: 20 });
    const data = await api(`/inventory/items${qs}`);
    setItems(data.items || []);
    setItemPagination(data.pagination || { page, limit: 20, total: (data.items || []).length, totalPages: 1 });
  }

  async function loadUnits(page = unitPage) {
    const qs = buildQuery({
      status: unitStatus || undefined,
      itemId: unitItemId || undefined,
      locationId: unitLocationId || undefined,
      q: q || undefined,
      page,
      limit: 20,
    });
    const data = await api(`/inventory/units${qs}`);
    setUnits(data.units || []);
    setUnitPagination(data.pagination || { page, limit: 20, total: (data.units || []).length, totalPages: 1 });
  }

  async function loadMovements(page = movementPage, filters = { from: mvFrom, to: mvTo }) {
    const qs = buildQuery({
      page,
      limit: 20,
      itemId: unitItemId || undefined,
      from: filters.from || undefined,
      to: filters.to || undefined,
      q: q || undefined,
    });
    const data = await api(`/inventory/movements${qs}`);
    setMovements(data.movements || []);
    setMovementPagination(data.pagination || { page, limit:20, total:(data.movements || []).length, totalPages:1 });
  }

  async function loadBatches(page = batchPage) {
    const qs = buildQuery({ itemId: unitItemId || undefined, locationId: unitLocationId || undefined, q: q || undefined, page, limit: 20 });
    const data = await api(`/inventory/batches${qs}`);
    setBatches(data.batches || []);
    setBatchPagination(data.pagination || { page, limit: 20, total: (data.batches || []).length, totalPages: 1 });
  }

  async function loadItemFlow(item, page = 1) {
    setItemFlowLoading(true);
    setErr("");
    try {
      const [data, unitData] = await Promise.all([
        api(`/inventory/movements${buildQuery({ itemId: item.id, page, limit: 20 })}`),
        item.isSerialized
          ? api(`/inventory/units${buildQuery({ itemId: item.id, status: "IN_STOCK", page: 1, limit: 100 })}`)
          : Promise.resolve({ units: [] }),
      ]);
      setItemFlowMovements(data.movements || []);
      setItemFlowStockUnits(unitData.units || unitData.items || []);
      setItemFlowPagination(data.pagination || { page, limit: 20, total: (data.movements || []).length, totalPages: 1 });
    } catch (error) {
      setErr(error.message || "Gagal memuat riwayat barang");
    } finally {
      setItemFlowLoading(false);
    }
  }

  function openItemFlow(item) {
    setItemFlowTarget(item);
    setItemFlowMovements([]);
    setItemFlowStockUnits([]);
    setItemFlowPagination({ page: 1, limit: 20, total: 0, totalPages: 1 });
    loadItemFlow(item, 1);
  }

  async function scrapUnit() {
    setErr("");
    try {
      if (!scrapForm.unitId) throw new Error("Missing unitId");

      await api(`/inventory/units/${scrapForm.unitId}/scrap`, {
        method: "POST",
        body: JSON.stringify({ note: scrapForm.note || undefined }),
      });

      setOpenScrap(false);
      setScrapForm({ unitId: "", note: "" });

      await Promise.all([loadUnits(), loadMovements(), loadItems()]);
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  async function loadRetreadOptions() {
    const data = await api("/inventory/retread-options");
    const options = { items: data.items || [], suppliers: data.suppliers || [], locations: data.locations || [] };
    setRetreadOptions(options);
    return options;
  }

  // Kept for the retread action flow that is conditionally exposed by unit status.
  // eslint-disable-next-line no-unused-vars
  async function openRetreadUnit(unit) {
    setErr("");
    try {
      const options = await loadRetreadOptions();
      setRetreadForm({
        unitId: unit.id,
        serialNumber: unit.serialNumber || "",
        toItemId: retreadTarget(unit.item, options.items)?.id || "",
        supplierId: "",
        cost: "",
        sentAt: "",
        notes: "",
      });
      setOpenRetread(true);
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  async function sendToRetread() {
    setErr("");
    try {
      if (!retreadForm.toItemId) throw new Error("Pilih item tujuan Ban Masak");
      if (retreadForm.cost === "") throw new Error("Masukkan biaya masak ban");
      await api(`/inventory/units/${retreadForm.unitId}/retread`, {
        method: "POST",
        body: JSON.stringify({
          toItemId: retreadForm.toItemId,
          supplierId: retreadForm.supplierId || undefined,
          cost: Number(retreadForm.cost),
          sentAt: retreadForm.sentAt || undefined,
          notes: retreadForm.notes || undefined,
        }),
      });
      setOpenRetread(false);
      await Promise.all([loadUnits(), loadMovements(), loadItems()]);
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  async function openCompleteRetreadUnit(unit) {
    setErr("");
    try {
      const options = await loadRetreadOptions();
      setCompleteRetreadForm({ unitId: unit.id, serialNumber: unit.serialNumber || "", locationId: options.locations[0]?.id || "", completedAt: "" });
      setOpenCompleteRetread(true);
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  async function completeRetread() {
    setErr("");
    try {
      if (!completeRetreadForm.locationId) throw new Error("Pilih lokasi penerimaan");
      await api(`/inventory/units/${completeRetreadForm.unitId}/retread/complete`, {
        method: "POST",
        body: JSON.stringify({ locationId: completeRetreadForm.locationId, completedAt: completeRetreadForm.completedAt || undefined }),
      });
      setOpenCompleteRetread(false);
      await Promise.all([loadUnits(), loadMovements(), loadItems()]);
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  async function refresh(options = {}) {
    const background = options?.background === true;
    const showLoading = !background || !hasCompletedInitialLoad.current;
    if (showLoading) setLoading(true);
    setErr("");
    try {
      if (tab === "ITEMS") await loadItems();
      if (tab === "UNITS") await loadUnits();
      if (tab === "MOVEMENTS") await loadMovements();
      if (tab === "BATCHES") await loadBatches();
      if (tab === "EMERGENCY") await loadEmergencyDispatches();
    } catch (e) {
      setErr(String(e?.message || e));
    } finally {
      if (showLoading) setLoading(false);
    }
  }

  async function changeItemPage(page) {
    setItemPage(page);
    setLoading(true);
    try { await loadItems(page); } catch (e) { setErr(String(e?.message || e)); } finally { setLoading(false); }
  }

  async function changeUnitPage(page) {
    setUnitPage(page);
    setLoading(true);
    try { await loadUnits(page); } catch (e) { setErr(String(e?.message || e)); } finally { setLoading(false); }
  }
  async function changeMovementPage(page) {
    setMovementPage(page);
    setLoading(true);
    try { await loadMovements(page); } catch (e) { setErr(String(e?.message || e)); } finally { setLoading(false); }
  }
  async function changeBatchPage(page) {
    setBatchPage(page);
    setLoading(true);
    try { await loadBatches(page); } catch (e) { setErr(String(e?.message || e)); } finally { setLoading(false); }
  }
  async function applyMovementFilters() {
    setMovementPage(1);
    setLoading(true);
    setErr("");
    try { await loadMovements(1); } catch (e) { setErr(String(e?.message || e)); } finally { setLoading(false); }
  }
  async function resetMovementFilters() {
    setMvFrom("");
    setMvTo("");
    setMovementPage(1);
    setLoading(true);
    setErr("");
    try { await loadMovements(1, { from: "", to: "" }); } catch (e) { setErr(String(e?.message || e)); } finally { setLoading(false); }
  }
  useLiveRefresh(refresh);

  useEffect(() => {
    if (!allowed) return;
    (async () => {
      setLoading(true);
      setErr("");
      try {
        await Promise.all([loadLocations(), loadTrucks(), loadItems()]);
      } catch (e) {
        setErr(String(e?.message || e));
      } finally {
        hasCompletedInitialLoad.current = true;
        setLoading(false);
      }
    })();
  // Bootstrap reference data once access becomes available.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allowed]);

  useEffect(() => {
    if (!allowed) return;
    if (skipInitialTabRefresh.current) {
      skipInitialTabRefresh.current = false;
      return;
    }
    refresh();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  useEffect(() => {
    if (!allowed || tab !== "UNITS") return undefined;
    const timer = setTimeout(async () => {
      setUnitPage(1);
      setLoading(true);
      setErr("");
      try { await loadUnits(1); }
      catch (e) { setErr(String(e?.message || e)); }
      finally { setLoading(false); }
    }, 300);
    return () => clearTimeout(timer);
  // Search is intentionally server-side so it covers units on every page.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allowed, q, tab]);

  async function createItem() {
    setErr("");
    setCreateItemError("");
    try {
      if (!createItemForm.sku.trim() || !createItemForm.name.trim()) {
        throw new Error("SKU and Name are required");
      }

      const sku = createItemForm.sku.trim().toLowerCase();
      const name = createItemForm.name.trim().toLowerCase();
      if (items.some((item) => String(item.sku || "").trim().toLowerCase() === sku)) {
        throw new Error("SKU sudah digunakan");
      }
      if (items.some((item) => String(item.name || "").trim().toLowerCase() === name)) {
        throw new Error("Nama barang sudah digunakan");
      }

      await api("/inventory/items", {
        method: "POST",
        body: JSON.stringify({
          sku: createItemForm.sku.trim(),
          name: createItemForm.name.trim(),
          unit: createItemForm.unit.trim() || "PCS",
          isSerialized: !!createItemForm.isSerialized,
          category: createItemForm.category,
        }),
      });

      setOpenCreateItem(false);
      setCreateItemForm({ sku: "", name: "", unit: "PCS", isSerialized: false, category: "GENERAL_SPAREPART" });
      await loadItems();
    } catch (e) {
      setCreateItemError(String(e?.message || e));
    }
  }

  function openEditItem(item) {
    setErr("");
    setEditItemForm({
      id: item.id,
      sku: item.sku || "",
      name: item.name || "",
      unit: item.unit || "PCS",
      isSerialized: Boolean(item.isSerialized),
      originalSerialized: Boolean(item.isSerialized),
      category: item.category || "GENERAL_SPAREPART",
      totalStock: sumStocks(item.stocks),
    });
  }

  async function updateItem() {
    setErr("");
    try {
      if (!editItemForm?.sku.trim() || !editItemForm?.name.trim() || !editItemForm?.unit.trim()) {
        throw new Error("SKU, nama, dan satuan wajib diisi");
      }
      await api(`/inventory/items/${editItemForm.id}`, {
        method: "PATCH",
        body: JSON.stringify({
          sku: editItemForm.sku.trim(),
          name: editItemForm.name.trim(),
          unit: editItemForm.unit.trim(),
          isSerialized: editItemForm.isSerialized,
          category: editItemForm.category,
        }),
      });
      setEditItemForm(null);
      await loadItems();
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  async function createLocation() {
    setErr("");
    try {
      const name = newLocationName.trim();
      if (!name) throw new Error("Location name is required");

      const res = await api("/inventory/locations", {
        method: "POST",
        body: JSON.stringify({ name }),
      });

      await loadLocations();
      setOpenCreateLocation(false);
      setNewLocationName("");

      const created = res.location;
      if (created?.id) {
        setReceiveForm((p) => ({ ...p, locationId: created.id }));
        setConsumeForm((p) => ({ ...p, locationId: created.id }));
      }
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  async function receiveStock() {
    setErr("");
    try {
      const item = receiveItems.find((x) => x.id === receiveForm.itemId) || items.find((x) => x.id === receiveForm.itemId);
      if (!item) throw new Error("Select an item");
      if (!receiveForm.locationId) throw new Error("Select a location");

      const payload = {
        itemId: receiveForm.itemId,
        locationId: receiveForm.locationId,
        note: receiveForm.note || undefined,
      };

      if (item.isSerialized) {
        const unitsPayload = receiveUnitRows
          .map((row) => ({ serialNumber: String(row.serialNumber || "").trim(), purchasePrice: row.purchasePrice === "" ? undefined : Number(row.purchasePrice) }))
          .filter((row) => row.serialNumber || row.purchasePrice != null);

        const deferredSerials = unitsPayload.length === 0;
        if (deferredSerials) {
          const qty = Number(receiveForm.qty || 0);
          if (!Number.isInteger(qty) || qty <= 0) throw new Error("Jumlah unit harus berupa angka bulat lebih dari nol.");
          payload.qty = qty;
        }
        if (!deferredSerials && unitsPayload.some((unit) => !unit.serialNumber)) throw new Error("Nomor seri tidak boleh kosong pada baris yang diisi.");
        const normalizedSerials = unitsPayload.map((unit) => unit.serialNumber.toLocaleLowerCase("id-ID"));
        if (new Set(normalizedSerials).size !== normalizedSerials.length) throw new Error("Nomor seri tidak boleh duplikat.");
        if (unitsPayload.some((unit) => unit.purchasePrice != null && (!Number.isFinite(unit.purchasePrice) || unit.purchasePrice < 0))) throw new Error("Harga unit harus berupa angka nol atau lebih.");

        const hasAnyUnitPrice = unitsPayload.some(
          (u) => u.purchasePrice != null
        );

        const totalRaw = receiveForm.totalPurchasePrice;
        const hasTotalPrice =
          totalRaw != null && String(totalRaw).trim() !== "";

        if (hasTotalPrice && (!Number.isFinite(Number(totalRaw)) || Number(totalRaw) < 0)) {
          throw new Error("Total harga pembelian harus berupa angka nol atau lebih.");
        }

        if (!hasAnyUnitPrice && !hasTotalPrice) {
          throw new Error("Provide per-unit price OR Total Purchase Price.");
        }

        if (hasAnyUnitPrice && hasTotalPrice) {
          throw new Error("Use either per-unit price OR Total Purchase Price, not both.");
        }
        if (hasAnyUnitPrice && unitsPayload.some((unit) => unit.purchasePrice == null)) throw new Error("Isi harga pada seluruh unit, atau kosongkan semuanya dan gunakan Total Harga Pembelian.");

        payload.units = unitsPayload.map((u) => ({
          serialNumber: u.serialNumber,
          barcode: u.barcode || undefined,
          ...(hasAnyUnitPrice ? { purchasePrice: Number(u.purchasePrice) } : {}),
        }));

        if (hasTotalPrice) payload.totalPurchasePrice = Number(totalRaw);
      } else {
        payload.qty = Number(receiveForm.qty || 0);
        const unitPrice = Number(receiveForm.unitPurchasePrice || 0);
        if (!Number.isFinite(payload.qty) || payload.qty <= 0) throw new Error("Jumlah harus lebih dari nol.");
        if (!Number.isFinite(unitPrice) || unitPrice < 0) throw new Error("Harga per unit harus nol atau lebih.");
        payload.totalPurchasePrice = Math.round(payload.qty * unitPrice);
      }

      await api("/inventory/receive", {
        method: "POST",
        body: JSON.stringify(payload),
      });

      setOpenReceive(false);
      setReceiveForm({
        itemId: "",
        locationId: "",
        qty: 1,
        note: "",
        unitLines: "",
        unitPurchasePrice: "",
        totalPurchasePrice: "",
      });
      setReceiveUnitRows([{ serialNumber: "", purchasePrice: "" }]);

      await Promise.all([loadItems(), loadMovements()]);
      if (tab === "UNITS") await loadUnits();
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  async function assignUnit() {
    setErr("");
    try {
      if (!assignForm.unitId) throw new Error("Missing unitId");
      if (!assignForm.truckId) throw new Error("Pilih kendaraan");

      await api(`/inventory/units/${assignForm.unitId}/assign`, {
        method: "POST",
        body: JSON.stringify({
          truckId: assignForm.truckId,
          serialNumber: assignForm.serialNumber || undefined,
          installedAt: assignForm.installedAt || undefined,
          note: assignForm.note || undefined,
          maintenanceId: assignForm.maintenanceId || undefined,
        }),
      });

      setOpenAssign(false);
      setAssignForm({ unitId: "", serialNumber: "", truckId: "", installedAt: "", note: "", maintenanceId: "" });

      await Promise.all([loadItems(), loadUnits(), loadMovements()]);
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  async function saveLegacyTires(event) {
    event.preventDefault(); setLegacyTireBusy(true); setErr("");
    try {
      const units = legacyTireRows.map((row) => ({ ...row, serialNumber: row.serialNumber.trim(), barcode: row.barcode.trim(), position: row.position.trim(), installedAt:new Date(row.installedAt||legacyTireForm.installedAt).toISOString() })).filter((row) => row.serialNumber);
      if (!units.length) throw new Error("Masukkan minimal satu nomor seri ban");
      await api("/inventory/legacy-tires/assign", { method: "POST", body: JSON.stringify({
        truckId: legacyTireForm.truckId,
        itemId: legacyTireNewItem ? undefined : legacyTireForm.itemId,
        newItem: legacyTireNewItem ? { sku: legacyTireForm.sku, name: legacyTireForm.name } : undefined,
        installedAt: new Date(legacyTireForm.installedAt).toISOString(),
        note: legacyTireForm.note || undefined,
        units,
      }) });
      setOpenLegacyTire(false); setTab("UNITS"); setUnitStatus("ASSIGNED"); setUnitPage(1);
      const [, unitData] = await Promise.all([loadItems(), api("/inventory/units?status=ASSIGNED&page=1&limit=20"), loadMovements()]);
      setUnits(unitData.units || []);
      setUnitPagination(unitData.pagination || { page:1, limit:20, total:(unitData.units || []).length, totalPages:1 });
    } catch (e) { setErr(e.message || "Gagal mengalokasikan ban lama"); }
    finally { setLegacyTireBusy(false); }
  }

  async function updateBarcode() {
    setErr("");
    try {
      if (!barcodeForm.unitId) throw new Error("Missing unitId");
      const bc = String(barcodeForm.barcode || "").trim();
      if (!bc) throw new Error("Barcode is required");

      await api(`/inventory/units/${barcodeForm.unitId}`, {
        method: "PATCH",
        body: JSON.stringify({ barcode: bc }),
      });

      setOpenBarcode(false);
      setBarcodeForm({ unitId: "", barcode: "" });

      await loadUnits();
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  async function consumeStock() {
    setErr("");
    try {
      const item = receiveItems.find((x) => x.id === consumeForm.itemId) || items.find((x) => x.id === consumeForm.itemId);
      if (!item) throw new Error("Select an item");
      if (item.isSerialized) throw new Error("Consume is only for NON-serialized items.");
      if (!consumeForm.locationId) throw new Error("Select a location");
      if (consumeForm.destinationType === "TRUCK" && !consumeForm.truckId) throw new Error("Pilih mobil tujuan");

      const qty = Number(consumeForm.qty);
      if (!Number.isFinite(qty) || qty <= 0) throw new Error("Qty must be more than 0");

      const stockRow = (item.stocks || []).find((s) => s.locationId === consumeForm.locationId);
      const available = Number(stockRow?.qty || 0);
      if (qty > available) {
        throw new Error(`Not enough stock. Available: ${available} ${item.unit || ""}`);
      }

      await api("/inventory/consume", {
        method: "POST",
        body: JSON.stringify({
          itemId: consumeForm.itemId,
          locationId: consumeForm.locationId,
          qty,
          note: consumeForm.note || undefined,
          destinationType: consumeForm.destinationType,
          truckId: consumeForm.destinationType === "TRUCK" ? consumeForm.truckId : undefined,
        }),
      });

      setOpenConsume(false);
      setConsumeForm({ itemId: "", locationId: "", qty: 1, note: "", destinationType: "OPERATIONAL", truckId: "" });

      await Promise.all([loadItems(), loadMovements()]);
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  if (!allowed) {
    return (
      <div style={pageBg}>
        <div style={container}>
          <div style={wrapCard}>
            <h1 style={headerTitle}>Persediaan</h1>
            <div style={headerSub}>Anda tidak memiliki akses ke halaman ini.</div>
          </div>
        </div>
      </div>
    );
  }

  const totalItems = itemPagination.total;

  return (
    <div className="inventory-page">
      <div className="inventory-shell">
        {/* Header */}
        <div className="inventory-hero">
          <div className="inventory-hero-copy">
            <span className="inventory-eyebrow">GUDANG & SUKU CADANG</span>
            <h1>Inventory</h1>
            <p>Pantau ketersediaan barang, penerimaan, dan pemakaian stok dalam satu tempat.</p>
            <div className="inventory-hero-meta"><span><FiBox /> {totalItems} jenis barang</span><span><FiMapPin /> {locations.length} lokasi stok</span></div>
          </div>

          <div className="inventory-hero-actions">

            <div style={{ position: "relative", paddingBottom: printMenuOpen ? 8 : 0, marginBottom: printMenuOpen ? -8 : 0 }} onMouseEnter={() => setPrintMenuOpen(true)} onMouseLeave={() => setPrintMenuOpen(false)}>
              <button className="inventory-action inventory-action--soft" type="button" aria-haspopup="menu" aria-expanded={printMenuOpen} onFocus={() => setPrintMenuOpen(true)}>
                <FiFileText /> Cetak Laporan
              </button>
              {printMenuOpen ? <div role="menu" style={{ position: "absolute", top: "100%", right: 0, zIndex: 30, width: 310, padding: 10, borderRadius: 12, border: `1px solid ${BRAND.border}`, background: BRAND.white, boxShadow: "0 18px 45px rgba(17, 24, 39, .14)" }}>
                <button type="button" onClick={() => openPrintDocument("/inventory/reports/stock?scope=overall").catch((e) => setErr(e.message))} style={{ width: "100%", display: "grid", gridTemplateColumns: "38px 1fr", gap: 11, alignItems: "center", padding: 11, border: 0, borderRadius: 9, background: BRAND.secondary, textAlign: "left", cursor: "pointer" }}>
                  <span style={{ width: 38, height: 38, borderRadius: 9, display: "grid", placeItems: "center", background: BRAND.white, color: BRAND.primary, fontSize: 18 }}>▦</span>
                  <span><strong style={{ display: "block", color: BRAND.text, fontSize: 13 }}>Stok Keseluruhan</strong><small style={{ display: "block", marginTop: 3, color: BRAND.textMuted }}>Posisi stok terkini per lokasi</small></span>
                </button>

                <div style={{ marginTop: 9, padding: 11, borderRadius: 9, border: `1px solid ${BRAND.border}` }}>
                  <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 9 }}>
                    <span style={{ width: 38, height: 38, flex: "0 0 auto", borderRadius: 9, display: "grid", placeItems: "center", background: BRAND.secondary, color: BRAND.primary, fontSize: 17 }}>◷</span>
                    <span><strong style={{ display: "block", color: BRAND.text, fontSize: 13 }}>Stok Harian</strong><small style={{ display: "block", marginTop: 3, color: BRAND.textMuted }}>Saldo dan mutasi tanggal pilihan</small></span>
                  </div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 7 }}>
                    <input type="date" value={stockReportDate} onChange={(e) => setStockReportDate(e.target.value)} style={{ ...inputPill, minWidth: 0, width: "100%", height: 36, padding: "0 9px", boxSizing: "border-box" }} />
                    <Btn style={{ ...btnPrimary, height: 36, padding: "0 12px", fontSize: 12 }} onClick={() => openPrintDocument(`/inventory/reports/stock?scope=daily&date=${encodeURIComponent(stockReportDate)}`).catch((e) => setErr(e.message))}>
                      Cetak
                    </Btn>
                  </div>
                </div>
              </div> : null}
            </div>

            <button className="inventory-action inventory-action--soft" onClick={() => { setCreateItemError(""); setOpenCreateItem(true); }}><FiPlus /> Tambah Item</button>

            <button
              className="inventory-action inventory-action--out"
              onClick={async () => {
                try {
                  setErr("");
                  const [, , itemData] = await Promise.all([loadLocations(), loadTrucks(), api("/inventory/items")]);
                  setReceiveItems(itemData.items || []);
                  setConsumeForm({ itemId: "", locationId: "", qty: 1, note: "", destinationType: "OPERATIONAL", truckId: "" });
                  setOpenConsume(true);
                } catch (e) {
                  setErr(String(e?.message || e));
                }
              }}
            >
              <FiArrowUpCircle /> Gunakan Stok
            </button>

            <button
              className="inventory-action inventory-action--in"
              onClick={() => {
                setErr("");
                setReceiveItems(items);
                setOpenReceive(true);
                Promise.all([loadLocations(), api("/inventory/items")])
                  .then(([, data]) => setReceiveItems(data.items || []))
                  .catch((e) => setErr(String(e?.message || e)));
              }}
            >
              <FiArrowDownCircle /> Terima Stok
            </button>
          </div>
        </div>

        {/* Main Card */}
        <div className="inventory-workspace">
          {/* Tabs + Search */}
          <div className="inventory-toolbar">
            <div className="inventory-tabs">
              <button className={tab === "ITEMS" ? "active" : ""} onClick={() => setTab("ITEMS")}>Daftar Item</button>
              <button className={tab === "UNITS" ? "active" : ""} onClick={() => setTab("UNITS")}>Unit Berseri</button>
              <button className={tab === "MOVEMENTS" ? "active" : ""} onClick={() => setTab("MOVEMENTS")}>Pergerakan</button>
              <button className={tab === "BATCHES" ? "active" : ""} onClick={() => setTab("BATCHES")}>Harga Masuk</button>
              <button className={tab === "EMERGENCY" ? "active" : ""} onClick={() => { setTab("EMERGENCY"); loadEmergencyDispatches(); }}>Pengiriman Darurat</button>
            </div>

            <div className="inventory-search"><FiSearch />
              <input
                value={q}
                onChange={(e) => { setQ(e.target.value); setItemPage(1); setUnitPage(1); setMovementPage(1); setBatchPage(1); }}
                placeholder={tab === "UNITS" ? "Cari nomor seri, barcode, barang, atau nomor polisi..." : "Cari berdasarkan nama / SKU / barcode..."}
                onKeyDown={(e) => {
                  if (e.key === "Enter") refresh();
                }}
              />
            </div>
          </div>

          {err ? (
            <div style={errorBox}>
              <div style={{ fontWeight: 600, color: BRAND.danger }}>Error</div>
              <div style={{ marginTop: 6, whiteSpace: "pre-wrap", color: BRAND.danger }}>{err}</div>
            </div>
          ) : null}

          <div style={{ marginTop: 16 }}>
            {tab === "ITEMS" ? (
              <>
              <ItemsTable
                items={filteredItems}
                loading={loading}
                onEdit={openEditItem}
                onInspect={openItemFlow}
                onUse={(itemId) => {
                  const item = items.find((x) => x.id === itemId);
                  if (!item) return;

                  const firstLocWithStock =
                    (item.stocks || []).find((s) => Number(s.qty || 0) > 0)?.locationId || "";
                  setConsumeForm((p) => ({
                    ...p,
                    itemId,
                    locationId: firstLocWithStock || p.locationId || "",
                    qty: 1,
                    note: "",
                  }));
                  setOpenConsume(true);
                }}
              />
              <Pagination pagination={itemPagination} onChange={changeItemPage} />
              </>
            ) : null}

            {tab === "UNITS" ? (
              <>
              <UnitsTable
                units={units}
                loading={loading}
                items={serializedItems}
                locations={locations}
                unitStatus={unitStatus}
                setUnitStatus={setUnitStatus}
                unitItemId={unitItemId}
                setUnitItemId={setUnitItemId}
                unitLocationId={unitLocationId}
                setUnitLocationId={setUnitLocationId}
                onAssign={(unit) => {
                  setAssignForm((p) => ({ ...p, unitId: unit.id, serialNumber: unit.serialNumber || "" }));
                  setOpenAssign(true);
                }}
                onBarcode={(unit) => {
                  setBarcodeForm({
                    unitId: unit.id,
                    barcode: unit.barcode || "",
                  });
                  setOpenBarcode(true);
                }}
                onScrap={(unit) => {
                  setScrapForm({ unitId: unit.id, note: "" });
                  setOpenScrap(true);
                }}
                onCompleteRetread={openCompleteRetreadUnit}
                onApplyFilters={() => { setUnitPage(1); loadUnits(1); }}
              />
              <Pagination pagination={unitPagination} onChange={changeUnitPage} />
              </>
            ) : null}

            {tab === "MOVEMENTS" ? <><MovementsTable movements={movements} loading={loading} from={mvFrom} to={mvTo} onFromChange={(value)=>{setMvFrom(value);setMovementPage(1)}} onToChange={(value)=>{setMvTo(value);setMovementPage(1)}} onApply={applyMovementFilters} onReset={resetMovementFilters}/>{!loading && <Pagination pagination={movementPagination} onChange={changeMovementPage}/>}</> : null}
            {tab === "BATCHES" ? <><BatchesTable batches={batches} loading={loading} />{!loading && <Pagination pagination={batchPagination} onChange={changeBatchPage} />}</> : null}
            {tab === "EMERGENCY" ? <div className="inventory-emergency"><div className="inventory-emergency-head"><div><h2>Pengiriman Sparepart Darurat</h2><p>Stok keluar saat dikirim dan pemasangan dikonfirmasi saat barang diterima.</p></div><button type="button" onClick={openEmergencyForm}><FiPlus/> Buat Pengiriman</button></div><div className="inventory-emergency-list">{emergencyDispatches.map((dispatch) => <article key={dispatch.id}><span className={dispatch.status.toLowerCase()}>{dispatch.status === "IN_TRANSIT" ? "DALAM PERJALANAN" : "TERPASANG"}</span><h3>{dispatch.item?.name || "Sparepart"} · {dispatch.qty} {dispatch.item?.unit || ""}</h3><p>{dispatch.fromLocation?.name || "Gudang"} → <b>{dispatch.targetTruck?.plateNumber}</b></p><small>Dibawa {dispatch.carrierTruck?.plateNumber || "—"}{dispatch.stockUnit ? ` · Serial ${dispatch.stockUnit.serialNumber || dispatch.stockUnit.barcode}` : ""}</small>{dispatch.status === "IN_TRANSIT" && <button type="button" onClick={() => openInstallDispatch(dispatch)}>Konfirmasi diterima & pasang</button>}</article>)}{!emergencyDispatches.length && <div className="inventory-emergency-empty">Belum ada pengiriman sparepart darurat.</div>}</div></div> : null}
          </div>
        </div>

        {/* MODALS */}
        <Modal
          open={Boolean(itemFlowTarget)}
          className="inventory-modal--item-flow"
          eyebrow="RIWAYAT ALIRAN BARANG"
          title={itemFlowTarget?.name || "Detail Barang"}
          description={itemFlowTarget ? `${itemFlowTarget.sku} · seluruh pergerakan masuk, keluar, dan pemindahan barang` : ""}
          onClose={() => setItemFlowTarget(null)}
        >
          {itemFlowLoading ? <LoadingState compact label="Memuat riwayat barang" note="Menelusuri tujuan pemakaian dan perpindahan stok…" rows={5} /> : <div className="inventory-item-flow">
            <div className="inventory-item-flow-summary"><span><small>TOTAL RIWAYAT</small><strong>{itemFlowPagination.total}</strong></span><span><small>STOK SAAT INI</small><strong>{sumStocks(itemFlowTarget?.stocks)} {itemFlowTarget?.unit || ""}</strong></span></div>
            {itemFlowTarget?.isSerialized && (() => {
              const numberedUnits = itemFlowStockUnits.filter((unit) => unit.serialNumber || unit.barcode);
              const unnumberedByLocation = [...itemFlowStockUnits.filter((unit) => !unit.serialNumber && !unit.barcode).reduce((groups, unit) => {
                const key = unit.locationId || "unknown";
                const current = groups.get(key) || { key, location: unit.location?.name || "Lokasi belum ditentukan", count: 0 };
                current.count += 1;
                groups.set(key, current);
                return groups;
              }, new Map()).values()];
              return <section className="inventory-item-flow-units"><div className="inventory-item-flow-section-head"><span><small>UNIT TERSEDIA DI STOK</small><strong>{itemFlowStockUnits.length} unit tersedia</strong></span><p>Unit tanpa nomor seri diringkas berdasarkan lokasi.</p></div>{itemFlowStockUnits.length ? <div className="inventory-item-flow-unit-grid">{unnumberedByLocation.map((group) => <article className="inventory-item-flow-unit-group" key={`unnumbered-${group.key}`}><span>Belum diberi nomor seri</span><strong>{group.count} unit</strong><small>{group.location} · nomor seri diisi saat dipasang</small></article>)}{numberedUnits.map((unit) => <article key={unit.id}><span>Nomor seri</span><strong>{unit.serialNumber || unit.barcode}</strong><small>{unit.location?.name || "Lokasi belum ditentukan"}{unit.barcode && unit.serialNumber ? ` · Barcode ${unit.barcode}` : ""}</small></article>)}</div> : <div className="inventory-item-flow-unit-empty">Tidak ada unit serial yang tersedia di stok.</div>}</section>;
            })()}
            {itemFlowMovements.length ? <><div className="inventory-item-flow-table" style={tableWrap}><table style={table}><colgroup><col className="flow-type"/><col className="flow-qty"/><col className="flow-from"/><col className="flow-destination"/><col className="flow-unit"/><col className="flow-user"/><col className="flow-date"/></colgroup><thead><tr><th style={th}>Jenis</th><th style={th}>Jumlah</th><th style={th}>Dari</th><th style={th}>Ke / Tujuan</th><th style={th}>No. Seri / Servis</th><th style={th}>Petugas</th><th style={th}>Tanggal</th></tr></thead><tbody>{itemFlowMovements.map((movement) => { const assignmentTruck = movement.stockUnit?.assignments?.[0]?.truck; const destination = movement.toLocation?.name || movement.toTruck?.plateNumber || movement.maintenance?.truck?.plateNumber || assignmentTruck?.plateNumber || (movement.type === "OUT" ? "Pemakaian stok" : "—"); return <tr key={movement.id}><td style={td}><Pill variant={movement.type === "IN" ? "green" : movement.type === "OUT" ? "red" : "grey"}>{movement.type}</Pill></td><td style={td}>{movement.qty} {itemFlowTarget?.unit || ""}</td><td style={tdSoft}>{movement.fromLocation?.name || movement.fromTruck?.plateNumber || "—"}</td><td style={td}><strong>{destination}</strong>{movement.note && <small className="inventory-item-flow-note">{movement.note}</small>}</td><td style={tdSoft}><strong className="inventory-item-flow-serial">{movement.stockUnit?.serialNumber || movement.stockUnit?.barcode || "—"}</strong>{movement.maintenance?.title && <small className="inventory-item-flow-note">{movement.maintenance.title}</small>}</td><td style={tdSoft}>{movement.createdBy?.name || movement.createdBy?.email || "—"}</td><td style={tdSoft}>{fmtDate(movement.createdAt)}</td></tr>; })}</tbody></table></div><Pagination pagination={itemFlowPagination} onChange={(page) => itemFlowTarget && loadItemFlow(itemFlowTarget, page)} /></> : <div className="inventory-item-flow-empty">Belum ada riwayat pergerakan untuk barang ini.</div>}
          </div>}
        </Modal>

        <Modal open={openLegacyTire} eyebrow="MIGRASI DATA LAMA" title="Alokasikan ban langsung ke mobil" description="Catat ban yang sudah terpasang sebelum sistem digunakan. Harga dan stok gudang tidak terpengaruh." onClose={() => !legacyTireBusy && setOpenLegacyTire(false)}>
          <form className="legacy-tire-form" onSubmit={saveLegacyTires}>
            <section><header><b>01</b><span><strong>Mobil dan tanggal default</strong><small>Tanggal setiap ban tetap dapat diubah pada tabel.</small></span></header><div className="legacy-tire-grid"><label>Mobil<TruckSearchSelect trucks={trucks} value={legacyTireForm.truckId} onChange={(truckId) => setLegacyTireForm((form) => ({ ...form, truckId }))} placeholder="Cari nomor polisi..."/></label><label>Tanggal default baris baru<input required type="datetime-local" max={localDateTimeValue()} value={legacyTireForm.installedAt} onChange={(event) => setLegacyTireForm((form) => ({ ...form, installedAt:event.target.value }))}/></label></div></section>
            <section><header><b>02</b><span><strong>Jenis ban</strong><small>Pilih master yang tersedia atau buat jenis ban baru.</small></span></header><div className="legacy-tire-mode"><button type="button" className={!legacyTireNewItem?"active":""} onClick={()=>setLegacyTireNewItem(false)}>Pilih jenis ban</button><button type="button" className={legacyTireNewItem?"active":""} onClick={()=>setLegacyTireNewItem(true)}>Jenis ban baru</button></div>{legacyTireNewItem?<div className="legacy-tire-grid"><label>SKU ban<input required value={legacyTireForm.sku} onChange={(event)=>setLegacyTireForm((form)=>({...form,sku:event.target.value}))} placeholder="Contoh: BAN-1100-R20"/></label><label>Nama / jenis ban<input required value={legacyTireForm.name} onChange={(event)=>setLegacyTireForm((form)=>({...form,name:event.target.value}))} placeholder="Contoh: Ban 11.00 R20"/></label></div>:<label>Jenis ban<select required value={legacyTireForm.itemId} onChange={(event)=>setLegacyTireForm((form)=>({...form,itemId:event.target.value}))}><option value="">Pilih jenis ban...</option>{receiveItems.filter((item)=>item.category==="TIRE"&&item.isSerialized).map((item)=><option key={item.id} value={item.id}>{item.sku} — {item.name}</option>)}</select></label>}</section>
            <section><header><b>03</b><span><strong>Daftar ban terpasang</strong><small>Nomor seri dapat memakai tanggal yang sama maupun berbeda.</small></span></header><div className="legacy-tire-table"><div className="legacy-tire-table-head"><span>No.</span><span>Nomor seri</span><span>Tanggal dipasang</span><span>Barcode</span><span>Posisi</span><span/></div>{legacyTireRows.map((row,index)=><div className="legacy-tire-row" key={index}><b>{index+1}</b><input required value={row.serialNumber} onChange={(event)=>setLegacyTireRows((rows)=>rows.map((current,rowIndex)=>rowIndex===index?{...current,serialNumber:event.target.value}:current))} placeholder="Nomor seri ban"/><input required type="datetime-local" max={localDateTimeValue()} value={row.installedAt} onChange={(event)=>setLegacyTireRows((rows)=>rows.map((current,rowIndex)=>rowIndex===index?{...current,installedAt:event.target.value}:current))}/><input value={row.barcode} onChange={(event)=>setLegacyTireRows((rows)=>rows.map((current,rowIndex)=>rowIndex===index?{...current,barcode:event.target.value}:current))} placeholder="Opsional"/><input value={row.position} onChange={(event)=>setLegacyTireRows((rows)=>rows.map((current,rowIndex)=>rowIndex===index?{...current,position:event.target.value}:current))} placeholder="Depan kiri"/><button type="button" disabled={legacyTireRows.length===1} onClick={()=>setLegacyTireRows((rows)=>rows.filter((_,rowIndex)=>rowIndex!==index))}><FiX/></button></div>)}</div><button className="legacy-tire-add" type="button" onClick={()=>setLegacyTireRows((rows)=>[...rows,{serialNumber:"",barcode:"",position:"",installedAt:legacyTireForm.installedAt}])}><FiPlus/> Tambah ban</button></section>
            <label className="legacy-tire-note">Catatan <em>Opsional</em><textarea rows="2" value={legacyTireForm.note} onChange={(event)=>setLegacyTireForm((form)=>({...form,note:event.target.value}))} placeholder="Kondisi awal atau keterangan data lama..."/></label>
            <footer><span>Tidak membuat harga pembelian maupun saldo gudang.</span><button type="button" disabled={legacyTireBusy} onClick={()=>setOpenLegacyTire(false)}>Batal</button><button disabled={legacyTireBusy||!legacyTireForm.truckId||(!legacyTireNewItem&&!legacyTireForm.itemId)}>{legacyTireBusy?"Menyimpan...":`Simpan ${legacyTireRows.length} Ban`}</button></footer>
          </form>
        </Modal>
        <Modal open={openEmergency} eyebrow="PENGIRIMAN DARURAT" title="Kirim sparepart ke armada" description="Pilih armada dan barang, lalu sertakan bukti kerusakan sebelum stok dikeluarkan." onClose={() => setOpenEmergency(false)}>
          <form className="inventory-emergency-form redesigned" onSubmit={createEmergencyDispatch}>
            {emergencyPreparing && <div className="emergency-form-loading"><span></span> Menyiapkan data kendaraan dan stok…</div>}
            <section><header><b>01</b><div><strong>Rute pengiriman</strong><small>Tentukan kendaraan penerima dan pembawa barang.</small></div></header><div className="emergency-section-grid">
              <EmergencySearchPicker label="Truk tujuan" placeholder="Cari nomor polisi, merek, atau model..." items={trucks} value={emergencyForm.targetTruckId} onChange={(targetTruckId) => setEmergencyForm((form) => ({ ...form, targetTruckId, carrierTruckId: targetTruckId === form.carrierTruckId ? "" : form.carrierTruckId }))} itemLabel={(truck) => truck.plateNumber} itemMeta={(truck) => [truck.brand, truck.model, truck.currentLocation].filter(Boolean).join(" · ") || "Armada"}/>
              <EmergencySearchPicker label="Truk pembawa" placeholder="Cari armada pembawa..." items={trucks.filter((truck) => truck.id !== emergencyForm.targetTruckId)} value={emergencyForm.carrierTruckId} onChange={(carrierTruckId) => setEmergencyForm((form) => ({ ...form, carrierTruckId }))} itemLabel={(truck) => truck.plateNumber} itemMeta={(truck) => [truck.brand, truck.model, truck.currentLocation].filter(Boolean).join(" · ") || "Armada"}/>
            </div></section>
            <section><header><b>02</b><div><strong>Barang dari Inventory</strong><small>Pilih sparepart dan gudang asal stok.</small></div></header><div className="emergency-section-grid">
              <EmergencySearchPicker label="Sparepart" placeholder="Cari SKU atau nama barang..." items={items} value={emergencyForm.itemId} onChange={(itemId) => { setEmergencyForm((form) => ({ ...form, itemId, stockUnitId: "" })); loadEmergencyUnits(itemId, emergencyForm.fromLocationId); }} itemLabel={(item) => item.name} itemMeta={(item) => `${item.sku} · ${item.isSerialized ? "Berserial" : `${Number(item.qtyTotal || 0).toLocaleString("id-ID")} ${item.unit}`}`} icon={FiBox}/>
              <label>Lokasi stok<select required value={emergencyForm.fromLocationId} onChange={(event) => { const fromLocationId=event.target.value; setEmergencyForm((form) => ({ ...form, fromLocationId, stockUnitId:"" })); loadEmergencyUnits(emergencyForm.itemId, fromLocationId); }}><option value="">Pilih gudang asal</option>{locations.map((location) => <option key={location.id} value={location.id}>{location.name}</option>)}</select></label>
              {items.find((item) => item.id === emergencyForm.itemId)?.isSerialized ? <label>Unit serial<select required value={emergencyForm.stockUnitId} onChange={(event) => setEmergencyForm((form) => ({ ...form, stockUnitId:event.target.value, qty:1 }))}><option value="">Pilih serial yang dikirim</option>{emergencyUnits.map((unit) => <option key={unit.id} value={unit.id}>{unit.serialNumber || unit.barcode || unit.id}</option>)}</select></label> : <label>Jumlah<input required type="number" min="0.01" step="0.01" value={emergencyForm.qty} onChange={(event) => setEmergencyForm((form) => ({ ...form, qty:event.target.value }))}/></label>}
            </div></section>
            <section><header><b>03</b><div><strong>Bukti dan keterangan</strong><small>Foto atau video kerusakan wajib sebelum barang dikirim.</small></div></header><label className={`emergency-proof-upload ${emergencyProof ? "has-file" : ""}`}><input required type="file" accept="image/*,video/*" onChange={(event) => setEmergencyProof(event.target.files?.[0] || null)}/><FiFileText/><span><strong>{emergencyProof ? emergencyProof.name : "Pilih foto atau video kerusakan"}</strong><small>{emergencyProof ? "Klik untuk mengganti file" : "Ambil dari kamera atau galeri perangkat"}</small></span></label><label className="emergency-note">Catatan tambahan <em>Opsional</em><textarea rows="2" value={emergencyForm.note} onChange={(event) => setEmergencyForm((form) => ({ ...form, note:event.target.value }))} placeholder="Lokasi kendaraan, kondisi barang, atau instruksi penyerahan..."/></label></section>
            <footer><span>Stok berkurang setelah tombol kirim ditekan.</span><button type="button" onClick={() => setOpenEmergency(false)}>Batal</button><button disabled={emergencyPreparing || emergencyBusy || !emergencyForm.targetTruckId || !emergencyForm.carrierTruckId || !emergencyForm.itemId}>{emergencyBusy ? "Mengirim…" : emergencyPreparing ? "Menyiapkan data…" : "Keluarkan stok & kirim"}</button></footer>
          </form>
        </Modal>
        <Modal open={Boolean(installDispatch)} eyebrow="KONFIRMASI PEMASANGAN" title="Barang diterima dan dipasang" description={installDispatch ? `${installDispatch.item?.name} untuk ${installDispatch.targetTruck?.plateNumber}` : ""} onClose={() => setInstallDispatch(null)}><form className="inventory-emergency-form" onSubmit={confirmEmergencyInstall}><label className="wide">Sparepart lama yang diganti (opsional)<select value={installForm.oldStockUnitId} onChange={(e) => setInstallForm((f) => ({ ...f, oldStockUnitId:e.target.value }))}><option value="">Tidak mengganti unit berserial</option>{oldAssignments.map((assignment) => <option key={assignment.stockUnitId || assignment.id} value={assignment.stockUnitId}>{assignment.stockUnit?.item?.name} · {assignment.stockUnit?.serialNumber || assignment.stockUnit?.barcode}</option>)}</select></label>{installForm.oldStockUnitId && <label className="wide">Tindakan unit lama<select value={installForm.oldPartDisposition} onChange={(e) => setInstallForm((f) => ({ ...f, oldPartDisposition:e.target.value }))}><option value="SCRAPPED">Rusak / Scrap</option><option value="REPAIRING">Kirim untuk perbaikan</option><option value="LOST">Hilang / tidak kembali</option></select></label>}<label className="wide">Bukti pemasangan (foto/video)<input required type="file" accept="image/*,video/*" onChange={(e) => setInstallProof(e.target.files?.[0] || null)}/></label><label className="wide">Catatan pemasangan<input value={installForm.note} onChange={(e) => setInstallForm((f) => ({ ...f, note:e.target.value }))}/></label><footer><button type="button" onClick={() => setInstallDispatch(null)}>Batal</button><button disabled={emergencyBusy}>{emergencyBusy ? "Menyimpan…" : "Konfirmasi terpasang"}</button></footer></form></Modal>
        <Modal open={openBarcode} title="Set / Edit Unit Barcode" onClose={() => setOpenBarcode(false)}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 12 }}>
            <div>
              <Pill variant="green">Unit ID: {barcodeForm.unitId || "-"}</Pill>
            </div>

            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>Barcode</div>
              <input
                style={{ ...inputPill, minWidth: 0, width: "100%", boxSizing: "border-box" }}
                value={barcodeForm.barcode}
                onChange={(e) => setBarcodeForm((p) => ({ ...p, barcode: e.target.value }))}
                placeholder="Pindai / ketik barcode..."
              />
            </div>
          </div>

          <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 16 }}>
            <Btn style={btn} onClick={() => setOpenBarcode(false)}>
              Cancel
            </Btn>
            <Btn style={btnPrimary} onClick={updateBarcode}>
              Save
            </Btn>
          </div>
        </Modal>

        <Modal open={openScrap} title="Scrap / Retire Unit" onClose={() => setOpenScrap(false)}>
          <div style={{ display: "grid", gap: 12 }}>
            <Pill variant="red">Unit ID: {scrapForm.unitId || "-"}</Pill>

            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>Reason / Note</div>
              <input
                style={{ ...inputPill, minWidth: 0, width: "100%", boxSizing: "border-box" }}
                value={scrapForm.note}
                onChange={(e) => setScrapForm((p) => ({ ...p, note: e.target.value }))}
                placeholder="e.g. Broken, punctured, unsafe to use"
              />
            </div>

            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <Btn style={btn} onClick={() => setOpenScrap(false)}>
                Cancel
              </Btn>
              <Btn style={btnDanger} onClick={scrapUnit}>
                Scrap
              </Btn>
            </div>
          </div>
        </Modal>

        <Modal open={openRetread} title="Kirim Ban untuk Dimasak" onClose={() => setOpenRetread(false)}>
          <div style={{ display: "grid", gap: 14 }}>
            <div style={{ padding: 12, borderRadius: 8, background: BRAND.secondary }}>
              <div style={{ fontSize: 12, color: BRAND.textMuted }}>Nomor seri tetap digunakan</div>
              <div style={{ marginTop: 3, fontWeight: 700 }}>{retreadForm.serialNumber || retreadForm.unitId}</div>
            </div>
            <label style={{ display: "grid", gap: 6, fontSize: 12, fontWeight: 600, color: BRAND.textMuted }}>
              Item tujuan (Ban Masak)
              <select style={{ ...selectPill, width: "100%" }} value={retreadForm.toItemId} onChange={(e) => setRetreadForm((p) => ({ ...p, toItemId: e.target.value }))}>
                <option value="">Pilih item Ban Masak</option>
                {retreadOptions.items.map((item) => <option key={item.id} value={item.id}>{item.sku} — {item.name}</option>)}
              </select>
            </label>
            <label style={{ display: "grid", gap: 6, fontSize: 12, fontWeight: 600, color: BRAND.textMuted }}>
              Vendor masak ban
              <select style={{ ...selectPill, width: "100%" }} value={retreadForm.supplierId} onChange={(e) => setRetreadForm((p) => ({ ...p, supplierId: e.target.value }))}>
                <option value="">Tanpa vendor</option>
                {retreadOptions.suppliers.map((supplier) => <option key={supplier.id} value={supplier.id}>{supplier.name}</option>)}
              </select>
            </label>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <label style={{ display: "grid", gap: 6, fontSize: 12, fontWeight: 600, color: BRAND.textMuted }}>
                Biaya masak (Rp)
                <input type="number" min="0" style={{ ...inputPill, minWidth: 0 }} value={retreadForm.cost} onChange={(e) => setRetreadForm((p) => ({ ...p, cost: e.target.value }))} />
              </label>
              <label style={{ display: "grid", gap: 6, fontSize: 12, fontWeight: 600, color: BRAND.textMuted }}>
                Tanggal dikirim
                <input type="datetime-local" style={{ ...inputPill, minWidth: 0 }} value={retreadForm.sentAt} onChange={(e) => setRetreadForm((p) => ({ ...p, sentAt: e.target.value }))} />
              </label>
            </div>
            <label style={{ display: "grid", gap: 6, fontSize: 12, fontWeight: 600, color: BRAND.textMuted }}>
              Catatan
              <input style={{ ...inputPill, minWidth: 0 }} value={retreadForm.notes} onChange={(e) => setRetreadForm((p) => ({ ...p, notes: e.target.value }))} placeholder="Kondisi ban atau pekerjaan vendor" />
            </label>
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}><Btn style={btn} onClick={() => setOpenRetread(false)}>Batal</Btn><Btn style={btnPrimary} onClick={sendToRetread}>Kirim ke Vendor</Btn></div>
          </div>
        </Modal>

        <Modal open={openCompleteRetread} title="Terima Ban Selesai Dimasak" onClose={() => setOpenCompleteRetread(false)}>
          <div style={{ display: "grid", gap: 14 }}>
            <Pill variant="green">Serial: {completeRetreadForm.serialNumber || completeRetreadForm.unitId}</Pill>
            <label style={{ display: "grid", gap: 6, fontSize: 12, fontWeight: 600, color: BRAND.textMuted }}>
              Lokasi penerimaan
              <select style={{ ...selectPill, width: "100%" }} value={completeRetreadForm.locationId} onChange={(e) => setCompleteRetreadForm((p) => ({ ...p, locationId: e.target.value }))}>
                <option value="">Pilih lokasi</option>
                {retreadOptions.locations.map((location) => <option key={location.id} value={location.id}>{location.name}</option>)}
              </select>
            </label>
            <label style={{ display: "grid", gap: 6, fontSize: 12, fontWeight: 600, color: BRAND.textMuted }}>
              Tanggal selesai
              <input type="datetime-local" style={{ ...inputPill, minWidth: 0 }} value={completeRetreadForm.completedAt} onChange={(e) => setCompleteRetreadForm((p) => ({ ...p, completedAt: e.target.value }))} />
            </label>
            <div style={{ padding: 12, borderRadius: 8, background: BRAND.secondary, color: BRAND.textMuted, fontSize: 13 }}>Setelah diterima, unit yang sama masuk stok sebagai item Ban Masak. Nomor seri dan riwayat lama tidak berubah.</div>
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}><Btn style={btn} onClick={() => setOpenCompleteRetread(false)}>Batal</Btn><Btn style={btnPrimary} onClick={completeRetread}>Terima Ban</Btn></div>
          </div>
        </Modal>

        <Modal open={openCreateItem} eyebrow="MASTER BARANG" title="Tambah item baru" description="Buat identitas barang agar stok dapat diterima dan dilacak." onClose={() => setOpenCreateItem(false)}>
          {createItemError ? (
            <div style={{ ...errorBox, marginBottom: 14 }}>
              <div style={{ fontWeight: 600, color: BRAND.danger }}>Tidak dapat membuat item</div>
              <div style={{ marginTop: 6, color: BRAND.danger }}>{createItemError}</div>
            </div>
          ) : null}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>SKU</div>
              <input
                style={{ ...inputPill, minWidth: 0, width: "100%", boxSizing: "border-box" }}
                value={createItemForm.sku}
                onChange={(e) => setCreateItemForm((p) => ({ ...p, sku: e.target.value }))}
              />
            </div>
            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>Unit</div>
              <input
                style={{ ...inputPill, minWidth: 0, width: "100%", boxSizing: "border-box" }}
                value={createItemForm.unit}
                onChange={(e) => setCreateItemForm((p) => ({ ...p, unit: e.target.value }))}
              />
            </div>

            <div style={{ gridColumn: "1 / -1" }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>Nama</div>
              <input
                style={{ ...inputPill, minWidth: 0, width: "100%", boxSizing: "border-box" }}
                value={createItemForm.name}
                onChange={(e) => setCreateItemForm((p) => ({ ...p, name: e.target.value }))}
              />
            </div>

            <label style={{ display: "grid", gap: 6, gridColumn: "1 / -1", color: BRAND.text, fontWeight: 500 }}>
              <span style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted }}>Kategori barang</span>
              <select
                style={{ ...selectPill, width: "100%" }}
                value={createItemForm.category}
                onChange={(e) => setCreateItemForm((p) => ({ ...p, category: e.target.value, isSerialized: e.target.value === "TIRE" ? true : e.target.value === "OIL" ? false : p.isSerialized }))}
              >
                <option value="GENERAL_SPAREPART">Sparepart Umum</option>
                <option value="TIRE">Ban</option>
                <option value="BATTERY">Aki/Baterai</option>
                <option value="OIL">Oli</option>
                <option value="OTHER">Lainnya</option>
              </select>
            </label>

            <label style={{ display: "flex", alignItems: "center", gap: 10, gridColumn: "1 / -1", color: BRAND.text, fontWeight: 500 }}>
              <input
                type="checkbox"
                checked={createItemForm.isSerialized}
                onChange={(e) => setCreateItemForm((p) => ({ ...p, isSerialized: e.target.checked }))}
                disabled={createItemForm.category === "TIRE" || createItemForm.category === "OIL"}
              />
              Gunakan nomor seri untuk setiap unit
            </label>
          </div>

          <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 16 }}>
            <Btn style={btn} onClick={() => setOpenCreateItem(false)}>
              Batal
            </Btn>
            <Btn style={btnPrimary} onClick={createItem}>
              Simpan Item
            </Btn>
          </div>
        </Modal>

        <Modal open={Boolean(editItemForm)} title="Edit Barang" onClose={() => setEditItemForm(null)}>
          {editItemForm ? (
            <>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <div>
                  <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>SKU</div>
                  <input style={{ ...inputPill, minWidth: 0, width: "100%", boxSizing: "border-box" }} value={editItemForm.sku} onChange={(e) => setEditItemForm((p) => ({ ...p, sku: e.target.value }))} />
                </div>
                <div>
                  <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>Satuan</div>
                  <input style={{ ...inputPill, minWidth: 0, width: "100%", boxSizing: "border-box" }} value={editItemForm.unit} onChange={(e) => setEditItemForm((p) => ({ ...p, unit: e.target.value }))} placeholder="PCS / SET / LITER" />
                </div>
                <div style={{ gridColumn: "1 / -1" }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>Nama barang</div>
                  <input
                    style={{ ...inputPill, minWidth: 0, width: "100%", boxSizing: "border-box", background: isSparepartAdmin ? "#F3F4F6" : undefined }}
                    value={editItemForm.name}
                    onChange={(e) => setEditItemForm((p) => ({ ...p, name: e.target.value }))}
                    disabled={isSparepartAdmin}
                  />
                  {isSparepartAdmin && <div style={{ marginTop: 6, fontSize: 12, color: BRAND.textMuted }}>Nama barang hanya dapat diubah oleh Owner, Admin, atau Staf.</div>}
                </div>
                <label style={{ display: "grid", gap: 6, gridColumn: "1 / -1", color: BRAND.text, fontWeight: 500 }}>
                  <span style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted }}>Kategori barang</span>
                  <select
                    style={{ ...selectPill, width: "100%" }}
                    value={editItemForm.category}
                    onChange={(e) => setEditItemForm((p) => ({ ...p, category: e.target.value, isSerialized: e.target.value === "TIRE" ? true : e.target.value === "OIL" ? false : p.isSerialized }))}
                  >
                    <option value="GENERAL_SPAREPART">Sparepart Umum</option>
                    <option value="TIRE">Ban</option>
                    <option value="BATTERY">Aki/Baterai</option>
                    <option value="OIL">Oli</option>
                    <option value="OTHER">Lainnya</option>
                  </select>
                </label>
                <label style={{ display: "flex", alignItems: "center", gap: 10, gridColumn: "1 / -1", color: BRAND.text, fontWeight: 500 }}>
                  <input type="checkbox" checked={editItemForm.isSerialized} disabled={editItemForm.category === "TIRE" || editItemForm.category === "OIL"} onChange={(e) => setEditItemForm((p) => ({ ...p, isSerialized: e.target.checked }))} />
                  Serialized — setiap unit memiliki nomor seri
                </label>
              </div>
              {editItemForm.isSerialized !== editItemForm.originalSerialized && (
                <div style={{ marginTop: 14, padding: 12, borderRadius: 7, background: BRAND.warningLight, color: "#92400E", fontSize: 12, lineHeight: 1.5 }}>
                  Perubahan tipe serialized hanya diperbolehkan jika barang belum memiliki stok atau riwayat pergerakan.
                </div>
              )}
              <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 18 }}>
                <Btn style={btn} onClick={() => setEditItemForm(null)}>Batal</Btn>
                <Btn style={btnPrimary} onClick={updateItem}>Simpan Perubahan</Btn>
              </div>
            </>
          ) : null}
        </Modal>

        <Modal open={openReceive} eyebrow="STOK MASUK" title="Terima stok" description="Catat barang yang masuk, lokasi penyimpanan, jumlah, dan nilai pembelian." onClose={() => setOpenReceive(false)}>
          {err ? <div style={{ ...errorBox, marginBottom: 14 }}>{err}</div> : null}
          {locations.length === 0 ? (
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontWeight: 600, color: BRAND.text }}>Lokasi tidak ditemukan</div>
              <div style={{ marginTop: 6, color: BRAND.textMuted }}>
                Buat minimal satu lokasi gudang sebelum menerima stok.
              </div>
              <div style={{ marginTop: 12 }}>
                <Btn style={btnPrimary} onClick={() => setOpenCreateLocation(true)}>
                  + Tambah Lokasi
                </Btn>
              </div>
              <div style={{ marginTop: 12, height: 1, background: BRAND.border }} />
            </div>
          ) : null}

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <div className="inventory-receive-field-head">Barang</div>
              <ItemSearchSelect
                items={receiveItems}
                value={receiveForm.itemId}
                onChange={(itemId) => {
                  setReceiveForm((p) => itemId === p.itemId ? p : ({ ...p, itemId, qty: 1, unitPurchasePrice: "", totalPurchasePrice: "", unitLines: "" }));
                  if (itemId !== receiveForm.itemId) setReceiveUnitRows([{ serialNumber: "", purchasePrice: "" }]);
                }}
              />
            </div>

            <div>
              <div className="inventory-receive-field-head">
                Lokasi penyimpanan{" "}
                {locations.length > 0 ? (
                  <Btn
                    style={{ ...btn, height: 28, padding: "0 10px", marginLeft: 8, fontSize: 12 }}
                    type="button"
                    onClick={() => setOpenCreateLocation(true)}
                  >
                    + Baru
                  </Btn>
                ) : null}
              </div>
              <select
                style={{ ...selectPill, minWidth: 0, width: "100%", boxSizing: "border-box" }}
                value={receiveForm.locationId}
                onChange={(e) => setReceiveForm((p) => ({ ...p, locationId: e.target.value }))}
                disabled={locations.length === 0}
              >
                {locations.length === 0 ? (
                  <option value="">Belum ada lokasi</option>
                ) : (
                  <>
                    <option value="">Pilih lokasi...</option>
                    {locations.map((l) => (
                      <option key={l.id} value={l.id}>
                        {l.name}
                      </option>
                    ))}
                  </>
                )}
              </select>
            </div>

            <div style={{ gridColumn: "1 / -1" }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>Catatan</div>
              <input
                style={{ ...inputPill, minWidth: 0, width: "100%", boxSizing: "border-box" }}
                value={receiveForm.note}
                onChange={(e) => setReceiveForm((p) => ({ ...p, note: e.target.value }))}
              />
            </div>

            {selectedReceiveItem?.isSerialized && <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>Jumlah</div>
              <input
                style={{ ...inputPill, minWidth: 0, width: "100%", boxSizing: "border-box" }}
                type="number"
                step={selectedReceiveItem?.isSerialized ? "1" : "0.01"}
                min={selectedReceiveItem?.isSerialized ? "1" : "0.01"}
                value={receiveForm.qty}
                onChange={(e) => {
                  const value = e.target.value;
                  setReceiveForm((p) => ({ ...p, qty: value }));
                  if (selectedReceiveItem?.isSerialized && value !== "") {
                    const wanted = Math.max(1, Math.min(500, Math.floor(Number(value) || 1)));
                    setReceiveUnitRows((rows) => Array.from({ length: wanted }, (_, index) => rows[index] || { serialNumber: "", purchasePrice: "" }));
                  }
                }}
              />
              <div style={{ marginTop: 6, fontSize: 12, color: BRAND.textMuted }}>
                Nomor seri boleh dikosongkan sekarang dan diisi saat ban dipasang.
              </div>
            </div>}

            {(() => {
              const item = receiveItems.find((x) => x.id === receiveForm.itemId) || items.find((x) => x.id === receiveForm.itemId);
              if (!item?.isSerialized) return null;

              return (
                <div style={{ gridColumn: "1 / -1" }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>
                    Total harga pembelian (Rp) — opsional
                  </div>
                  <input
                    style={{ ...inputPill, minWidth: 0, width: "100%", boxSizing: "border-box" }}
                    type="number"
                    min="0"
                    value={receiveForm.totalPurchasePrice || ""}
                    disabled={Boolean(item.isSerialized && receiveUnitRows.some((row) => String(row.purchasePrice).trim() !== ""))}
                    onChange={(e) => setReceiveForm((p) => ({ ...p, totalPurchasePrice: e.target.value }))}
                    placeholder="e.g. 20000000"
                  />
                  <div style={{ marginTop: 6, fontSize: 12, color: BRAND.textMuted }}>
                    {item.isSerialized
                      ? "Gunakan harga per unit pada daftar atau total harga ini—pilih salah satu."
                      : `Harga per ${item.unit || "unit"} dihitung otomatis dari total harga ÷ jumlah.`}
                  </div>
                </div>
              );
            })()}

            {selectedReceiveItem && !selectedReceiveItem.isSerialized ? <div className="inventory-serial-editor inventory-nonserial-editor" style={{ gridColumn: "1 / -1" }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted }}>Rincian stok non-serialized</div>
              <div className="inventory-serial-help">Masukkan jumlah dan harga satuan. Sistem menghitung total pembelian secara otomatis.</div>
              <div className="inventory-nonserial-table">
                <div className="inventory-nonserial-head"><span>No.</span><span>Jumlah</span><span>Harga/unit (Rp)</span><span>Total (Rp)</span></div>
                <div className="inventory-nonserial-row"><b>1</b><label><input type="number" min="0.01" step="0.01" value={receiveForm.qty} onChange={(e) => setReceiveForm((form) => ({ ...form, qty: e.target.value }))}/><small>{selectedReceiveItem.unit || "unit"}</small></label><input type="number" min="0" value={receiveForm.unitPurchasePrice} onChange={(e) => setReceiveForm((form) => ({ ...form, unitPurchasePrice: e.target.value }))} placeholder="Contoh: 200000"/><strong>{Number(receiveForm.qty) > 0 && String(receiveForm.unitPurchasePrice).trim() !== "" ? new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(Number(receiveForm.qty) * Number(receiveForm.unitPurchasePrice)) : "—"}</strong></div>
              </div>
            </div> : null}

            {(() => {
              const item = receiveItems.find((x) => x.id === receiveForm.itemId) || items.find((x) => x.id === receiveForm.itemId);
              if (!item?.isSerialized) return null;
              return <div className="inventory-serial-editor" style={{ gridColumn: "1 / -1" }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted }}>
                Daftar nomor seri (opsional saat stok masuk)
              </div>
              <div className="inventory-serial-help">Untuk input cepat, cukup isi Jumlah dan Total Harga. Nomor seri dapat dicatat nanti ketika unit dipasang.</div>
              <div className="inventory-serial-table"><div className="inventory-serial-head"><span>No.</span><span>Nomor seri</span><span>Harga/unit (Rp)</span><span/></div>{receiveUnitRows.map((row, index) => <div className="inventory-serial-row" key={index}><b>{index + 1}</b><input value={row.serialNumber} onChange={(e) => setReceiveUnitRows((rows) => rows.map((current, rowIndex) => rowIndex === index ? { ...current, serialNumber: e.target.value } : current))} placeholder="Contoh: SN001"/><input type="number" min="0" value={row.purchasePrice} disabled={String(receiveForm.totalPurchasePrice || "").trim() !== ""} onChange={(e) => setReceiveUnitRows((rows) => rows.map((current, rowIndex) => rowIndex === index ? { ...current, purchasePrice: e.target.value } : current))} placeholder={receiveForm.totalPurchasePrice ? "Pakai total harga" : "Contoh: 2000000"}/><button type="button" aria-label={`Hapus baris ${index + 1}`} disabled={receiveUnitRows.length === 1} onClick={() => { setReceiveUnitRows((rows) => rows.filter((_, rowIndex) => rowIndex !== index)); setReceiveForm((form) => ({ ...form, qty: Math.max(1, receiveUnitRows.length - 1) })); }}><FiX/></button></div>)}</div>
              <button type="button" className="inventory-add-serial" onClick={() => { setReceiveUnitRows((rows) => [...rows, { serialNumber: "", purchasePrice: "" }]); setReceiveForm((form) => ({ ...form, qty: receiveUnitRows.length + 1 })); }}><FiPlus/> Tambah unit</button>
            </div>})()}
          </div>

          <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 16 }}>
            <Btn style={btn} onClick={() => setOpenReceive(false)}>
              Batal
            </Btn>
            <Btn style={btnPrimary} onClick={receiveStock} disabled={locations.length === 0}>
              Simpan Stok Masuk
            </Btn>
          </div>
        </Modal>

        <Modal open={openConsume} eyebrow="STOK KELUAR" title="Gunakan stok" description="Gunakan untuk operasional umum atau masukkan langsung ke stok mobil tanpa membuat servis." tone="red" onClose={() => setOpenConsume(false)}>
          {err ? <div style={{ ...errorBox, marginBottom: 14 }}>{err}</div> : null}
          {locations.length === 0 ? (
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontWeight: 600, color: BRAND.text }}>Lokasi tidak ditemukan</div>
              <div style={{ marginTop: 6, color: BRAND.textMuted }}>
                Buat minimal satu lokasi gudang sebelum menggunakan stok.
              </div>
              <div style={{ marginTop: 12 }}>
                <Btn style={btnPrimary} onClick={() => setOpenCreateLocation(true)}>
                  + Tambah Lokasi
                </Btn>
              </div>
              <div style={{ marginTop: 12, height: 1, background: BRAND.border }} />
            </div>
          ) : null}

          <div className="inventory-receive-mode" style={{ marginBottom: 16 }}>
            <button type="button" className={consumeForm.destinationType === "OPERATIONAL" ? "active" : ""} onClick={() => setConsumeForm(form => ({ ...form, destinationType: "OPERATIONAL", truckId: "" }))}><span>01</span><div><strong>Operasional umum</strong><small>Dipakai untuk kantor atau kebutuhan umum</small></div></button>
            <button type="button" className={consumeForm.destinationType === "TRUCK" ? "active" : ""} onClick={() => setConsumeForm(form => ({ ...form, destinationType: "TRUCK" }))}><span>02</span><div><strong>Masukkan ke mobil</strong><small>Menambah stok barang pada armada</small></div></button>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            {consumeForm.destinationType === "TRUCK" && <div style={{ gridColumn: "1 / -1" }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>Mobil tujuan</div>
              <TruckSearchSelect trucks={trucks} value={consumeForm.truckId} onChange={(truckId) => setConsumeForm(form => ({ ...form, truckId }))} placeholder="Ketik nomor polisi, merek, atau model..."/>
            </div>}
            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>Barang tanpa nomor seri</div>
              <ItemSearchSelect
                items={receiveItems.filter((item) => !item.isSerialized)}
                value={consumeForm.itemId}
                onChange={(nextItemId) => {
                  const item = receiveItems.find((x) => x.id === nextItemId) || items.find((x) => x.id === nextItemId);
                  const firstLocWithStock = (item?.stocks || []).find((s) => Number(s.qty || 0) > 0)?.locationId || "";
                  setConsumeForm((p) => ({
                    ...p,
                    itemId: nextItemId,
                    locationId: firstLocWithStock || p.locationId || "",
                  }));
                }}
              />
            </div>

            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>
                Lokasi asal{" "}
                <Btn
                  style={{ ...btn, height: 28, padding: "0 10px", marginLeft: 8, fontSize: 12 }}
                  type="button"
                  onClick={() => setOpenCreateLocation(true)}
                >
                  + Baru
                </Btn>
              </div>
              <select
                style={{ ...selectPill, minWidth: 0, width: "100%", boxSizing: "border-box" }}
                value={consumeForm.locationId}
                onChange={(e) => setConsumeForm((p) => ({ ...p, locationId: e.target.value }))}
                disabled={locations.length === 0}
              >
                <option value="">Pilih lokasi...</option>
                {locations.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>Jumlah yang digunakan</div>
              <input
                style={{ ...inputPill, minWidth: 0, width: "100%", boxSizing: "border-box" }}
                type="number"
                step="0.01"
                value={consumeForm.qty}
                onChange={(e) => setConsumeForm((p) => ({ ...p, qty: e.target.value }))}
              />
            </div>

            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>Catatan</div>
              <input
                style={{ ...inputPill, minWidth: 0, width: "100%", boxSizing: "border-box" }}
                value={consumeForm.note}
                onChange={(e) => setConsumeForm((p) => ({ ...p, note: e.target.value }))}
                placeholder="Alasan (opsional)"
              />
            </div>
          </div>

          <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 16 }}>
            <Btn style={btn} onClick={() => setOpenConsume(false)}>
              Batal
            </Btn>
            <Btn style={btnPrimary} onClick={consumeStock} disabled={locations.length === 0}>
              {consumeForm.destinationType === "TRUCK" ? "Masukkan ke Mobil" : "Simpan Stok Keluar"}
            </Btn>
          </div>
        </Modal>

        <Modal open={openCreateLocation} title="Create Location" onClose={() => setOpenCreateLocation(false)}>
          <div style={{ marginBottom: 12 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>Location Name</div>
            <input
              style={{ ...inputPill, minWidth: 0, width: "100%", boxSizing: "border-box" }}
              value={newLocationName}
              onChange={(e) => setNewLocationName(e.target.value)}
              placeholder="e.g. Main Warehouse"
            />
          </div>

          <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
            <Btn style={btn} onClick={() => setOpenCreateLocation(false)}>
              Cancel
            </Btn>
            <Btn style={btnPrimary} onClick={createLocation}>
              Create
            </Btn>
          </div>
        </Modal>

        <Modal open={openAssign} title="Assign Unit to Truck" onClose={() => setOpenAssign(false)}>
          <div style={{ display: "grid", gap: 12 }}>
            <div>
              <Pill variant="green">Unit ID: {assignForm.unitId || "-"}</Pill>
            </div>

            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>Nomor seri</div>
              <input
                style={{ ...inputPill, minWidth: 0, width: "100%", boxSizing: "border-box" }}
                value={assignForm.serialNumber}
                onChange={(e) => setAssignForm((p) => ({ ...p, serialNumber: e.target.value }))}
                placeholder="Wajib jika belum dicatat saat stok masuk"
              />
            </div>

            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>Select Truck</div>
              <TruckSearchSelect
                trucks={trucks}
                value={assignForm.truckId}
                onChange={(val) => setAssignForm((p) => ({ ...p, truckId: val }))}
                placeholder="Cari nomor polisi..."
              />
            </div>

            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>Tanggal Pemasangan</div>
              <input
                style={{ ...inputPill, minWidth: 0, width: "100%", boxSizing: "border-box" }}
                value={assignForm.installedAt}
                onChange={(e) => setAssignForm((p) => ({ ...p, installedAt: e.target.value }))}
                placeholder="e.g. Front Left Tire"
              />
            </div>

            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: BRAND.textMuted, marginBottom: 6 }}>Catatan</div>
              <input
                style={{ ...inputPill, minWidth: 0, width: "100%", boxSizing: "border-box" }}
                value={assignForm.note}
                onChange={(e) => setAssignForm((p) => ({ ...p, note: e.target.value }))}
                placeholder="Catatan (opsional)"
              />
            </div>

            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <Btn style={btn} onClick={() => setOpenAssign(false)}>
                Cancel
              </Btn>
              <Btn style={btnPrimary} onClick={assignUnit}>
                Assign
              </Btn>
            </div>
          </div>
        </Modal>
      </div>
    </div>
  );
}

//////////////////////
// TABLE COMPONENTS
//////////////////////
function BatchesTable({ batches, loading }) {
  if (loading) return <LoadingState compact label="Memuat harga masuk" note="Menelusuri batch, harga, dan sisa persediaan…" rows={4} />;
  if (!batches.length) return <div style={{ padding: 20, color: BRAND.textMuted }}>Belum ada batch stok yang tercatat.</div>;
  return (
    <div style={tableWrap}>
      <table style={{ ...table, minWidth: 1080 }}>
        <thead><tr>
          <th style={th}>Barang</th><th style={th}>Jenis</th><th style={th}>Supplier</th><th style={th}>PO / GR</th>
          <th style={th}>Tanggal Beli</th><th style={th}>Diterima</th><th style={th}>Tersisa</th>
          <th style={th}>Harga/Unit</th><th style={th}>Total Masuk</th>
        </tr></thead>
        <tbody>{batches.map((batch) => {
          const po = batch.purchaseOrderItem?.purchaseOrder;
          const receivedQty = Number(batch.receivedQty || 0);
          const totalValue = batch.unitPrice == null ? null : Math.round(receivedQty * Number(batch.unitPrice));
          return <tr key={batch.id}>
            <td style={td}><div>{batch.item?.name || "-"}</div><div style={{ fontSize: 12, color: BRAND.textMuted }}>{batch.item?.sku || "-"}</div></td>
            <td style={tdSoft}><Pill variant={batch.item?.isSerialized ? "green" : "grey"}>{batch.item?.isSerialized ? "Ban berserial" : "Stok jumlah"}</Pill></td>
            <td style={td}>{po?.supplier?.name || <span style={{ color: BRAND.textMuted }}>Tidak tercatat</span>}</td>
            <td style={td}><div>{po?.number || "Manual"}</div><div style={{ fontSize: 12, color: BRAND.textMuted }}>{batch.goodsReceipt?.number || "Tanpa GR"}</div></td>
            <td style={tdSoft}>{fmtDate(batch.receivedAt)}</td>
            <td style={td}>{receivedQty} {batch.item?.unit || ""}</td>
            <td style={td}>{batch.remainingQty == null ? <Pill>Belum diketahui</Pill> : <Pill variant={Number(batch.remainingQty) > 0 ? "green" : "grey"}>{batch.remainingQty} {batch.item?.unit || ""}</Pill>}</td>
            <td style={tdSoft}>{batch.unitPrice == null ? "-" : new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(batch.unitPrice)}</td>
            <td style={{ ...td, fontWeight: 700 }}>{totalValue == null ? "-" : new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(totalValue)}</td>
          </tr>;
        })}</tbody>
      </table>
    </div>
  );
}

function Pagination({ pagination, onChange }) {
  const { page = 1, totalPages = 1, total = 0, limit = 20 } = pagination || {};
  if (totalPages <= 1) return total ? <div style={{ marginTop: 12, color: BRAND.textMuted, fontSize: 12 }}>{total} data</div> : null;
  const from = (page - 1) * limit + 1;
  const to = Math.min(page * limit, total);
  return <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap", marginTop: 14 }}>
    <div style={{ color: BRAND.textMuted, fontSize: 12 }}>Menampilkan {from}–{to} dari {total} data</div>
    <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
      <Btn style={{ ...btn, height: 32, padding: "0 12px", opacity: page <= 1 ? 0.5 : 1 }} disabled={page <= 1} onClick={() => onChange(page - 1)}>← Sebelumnya</Btn>
      <span style={{ color: BRAND.textMuted, fontSize: 12 }}>Halaman {page} / {totalPages}</span>
      <Btn style={{ ...btn, height: 32, padding: "0 12px", opacity: page >= totalPages ? 0.5 : 1 }} disabled={page >= totalPages} onClick={() => onChange(page + 1)}>Berikutnya →</Btn>
    </div>
  </div>;
}

function ItemsTable({ items, loading, onUse, onEdit, onInspect }) {
  if (loading) {
    return <LoadingState compact label="Memuat detail barang" note="Mengambil stok, unit, dan riwayat pergerakan…" rows={5} />;
  }

  if (items.length === 0) {
    return <div style={{ padding: 20, color: BRAND.textMuted }}>Barang tidak ditemukan.</div>;
  }

  return (
    <div style={tableWrap}>
      <table style={table}>
        <thead>
          <tr>
            <th style={th}>SKU</th>
            <th style={th}>Nama</th>
            <th style={th}>Unit</th>
            <th style={th}>Kategori</th>
            <th style={th}>Serialized</th>
            <th style={th}>Total Stok</th>
            <th style={th}>Tindakan</th>
          </tr>
        </thead>
        <tbody>
          {items.map((it) => (
            <tr className="inventory-item-row" key={it.id} role="button" tabIndex={0} onClick={() => onInspect(it)} onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); onInspect(it); } }}>
              <td style={td}>{it.sku || "-"}</td>
              <td style={td}>{it.name || "-"}</td>
              <td style={tdSoft}>{it.unit || "-"}</td>
              <td style={tdSoft}>{({ GENERAL_SPAREPART: "Sparepart Umum", TIRE: "Ban", BATTERY: "Aki/Baterai", OIL: "Oli", OTHER: "Lainnya" })[it.category] || "Sparepart Umum"}</td>
              <td style={tdSoft}>{it.isSerialized ? "Yes" : "No"}</td>
              <td style={td}>{sumStocks(it.stocks)}</td>
              <td style={td} onClick={(event) => event.stopPropagation()} onKeyDown={(event) => event.stopPropagation()}>
                <div style={{ display: "flex", alignItems: "center", gap: 7, flexWrap: "wrap" }}>
                  <Btn style={{ ...btn, height: 32, padding: "0 12px", fontSize: 12 }} onClick={() => onEdit(it)}>
                    Edit
                  </Btn>
                {!it.isSerialized ? (
                  <Btn
                    style={{ ...btn, height: 32, padding: "0 12px", fontSize: 12 }}
                    onClick={() => onUse(it.id)}
                  >
                    Use
                  </Btn>
                ) : (
                  null
                )}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function UnitsTable({
  units,
  loading,
  items,
  locations,
  unitStatus,
  setUnitStatus,
  unitItemId,
  setUnitItemId,
  unitLocationId,
  setUnitLocationId,
  onAssign,
  onBarcode,
  onScrap,
  onCompleteRetread,
  onApplyFilters,
}) {
  return (
    <div>
      {/* Filters */}
      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 16 }}>
        <select
          style={{ ...selectPill, minWidth: 140 }}
          value={unitStatus}
          onChange={(e) => setUnitStatus(e.target.value)}
        >
          <option value="">Semua Status</option>
          <option value="IN_STOCK">IN_STOCK</option>
          <option value="ASSIGNED">ASSIGNED</option>
          <option value="RETREADING">RETREADING</option>
          <option value="SCRAPPED">SCRAPPED</option>
        </select>

        <ItemSearchSelect items={items} value={unitItemId} onChange={setUnitItemId} />

        <select
          style={{ ...selectPill, minWidth: 160 }}
          value={unitLocationId}
          onChange={(e) => setUnitLocationId(e.target.value)}
        >
          <option value="">All Locations</option>
          {locations.map((l) => (
            <option key={l.id} value={l.id}>
              {l.name}
            </option>
          ))}
        </select>

        <Btn style={btn} onClick={onApplyFilters}>
          Apply
        </Btn>
      </div>

      {loading ? (
        <LoadingState compact label="Memuat unit stok" note="Mengambil serial dan status pemasangan…" rows={5} />
      ) : units.length === 0 ? (
        <div style={{ padding: 20, color: BRAND.textMuted }}>Unit tidak ditemukan.</div>
      ) : (
        <div style={tableWrap}>
          <table style={table}>
            <thead>
              <tr>
                <th style={th}>Serial</th>
                <th style={th}>Barang</th>
                <th style={th}>Barcode</th>
                <th style={th}>Status</th>
                <th style={th}>Location</th>
                <th style={th}>Asal Pembelian</th>
                <th style={th}>Kendaraan</th>
                <th style={{ ...th, minWidth: 190 }}>Tindakan</th>
              </tr>
            </thead>
            <tbody>
              {units.map((u) => {
                const currentAssign = (u.assignments || [])[0];
                const truck = currentAssign?.truck;
                const originPo = u.inventoryBatch?.purchaseOrderItem?.purchaseOrder;
                const latestRetread = (u.tireRetreads || [])[0];
                return (
                  <tr key={u.id}>
                    <td style={td}>{u.serialNumber || "-"}</td>
                    <td style={td}>{u.item?.sku || "-"} — {u.item?.name || ""}</td>
                    <td style={tdSoft}>{u.barcode || "-"}</td>
                    <td style={td}>
                      <Pill variant={u.status === "IN_STOCK" ? "green" : u.status === "SCRAPPED" ? "red" : u.status === "RETREADING" ? "yellow" : "grey"}>
                        {u.status || "-"}
                      </Pill>
                    </td>
                    <td style={tdSoft}>{u.location?.name || "-"}</td>
                    <td style={tdSoft}>
                      <div>{originPo?.supplier?.name || "Tidak tercatat"}</div>
                      <div style={{ fontSize: 12 }}>{originPo?.number || "-"}{u.inventoryBatch?.goodsReceipt?.number ? ` / ${u.inventoryBatch.goodsReceipt.number}` : ""}</div>
                      {u.retreadCount > 0 || latestRetread ? <div style={{ fontSize: 12, marginTop: 4, color: BRAND.primary }}>Masak {u.retreadCount || 0}×{latestRetread?.supplier?.name ? ` · ${latestRetread.supplier.name}` : ""}</div> : null}
                    </td>
                    <td style={tdSoft}>{truck?.plateNumber || "-"}</td>
                    <td style={{ ...td, minWidth: 190 }}>
                      <div className="inventory-unit-actions">
                        {u.status === "IN_STOCK" ? (
                          <Btn
                            style={{ ...btn, height: 30, padding: "0 10px", fontSize: 11 }}
                            onClick={() => onAssign(u)}
                          >
                            Assign
                          </Btn>
                        ) : null}
                        {u.status === "RETREADING" ? (
                          <Btn style={{ ...btnPrimary, height: 30, padding: "0 10px", fontSize: 11 }} onClick={() => onCompleteRetread(u)}>
                            Selesai Masak
                          </Btn>
                        ) : null}
                        <Btn
                          style={{ ...btn, height: 30, padding: "0 10px", fontSize: 11 }}
                          onClick={() => onBarcode(u)}
                        >
                          Barcode
                        </Btn>
                        {u.status !== "SCRAPPED" && u.status !== "RETREADING" ? (
                          <Btn
                            style={{ ...btnDanger, height: 30, padding: "0 10px", fontSize: 11 }}
                            onClick={() => onScrap(u)}
                          >
                            {u.status === "ASSIGNED" ? "Lepas & Scrap" : "Scrap"}
                          </Btn>
                        ) : null}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function MovementsTable({ movements, loading, from, to, onFromChange, onToChange, onApply, onReset }) {
  const filters = (
    <div className="inventory-movement-filters" style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 16, alignItems: "end" }}>
      <label style={{ display: "grid", gap: 6, fontSize: 12, fontWeight: 600, color: BRAND.textMuted }}>
        Dari tanggal
        <span className={`date-placeholder-wrap ${from ? "has-value" : ""}`} data-placeholder="Pilih tanggal awal"><input className="tablet-date-input" aria-label="Tanggal awal pergerakan" type="date" value={from} onChange={(e) => onFromChange(e.target.value)} style={{ ...inputPill, minWidth: 180 }} /></span>
      </label>
      <label style={{ display: "grid", gap: 6, fontSize: 12, fontWeight: 600, color: BRAND.textMuted }}>
        Sampai tanggal
        <span className={`date-placeholder-wrap ${to ? "has-value" : ""}`} data-placeholder="Pilih tanggal akhir"><input className="tablet-date-input" aria-label="Tanggal akhir pergerakan" type="date" value={to} onChange={(e) => onToChange(e.target.value)} style={{ ...inputPill, minWidth: 180 }} /></span>
      </label>
      <Btn style={btn} onClick={onApply} disabled={loading}>{loading ? "Memuat..." : "Terapkan"}</Btn>
      {(from || to) && <Btn style={btn} onClick={onReset} disabled={loading}>Reset</Btn>}
    </div>
  );

  if (loading) {
    return <>{filters}<LoadingState compact label="Memuat pergerakan stok" note="Menelusuri penerimaan dan penggunaan barang…" rows={5} /></>;
  }

  if (movements.length === 0) {
    return <>{filters}<div style={{ padding: 20, color: BRAND.textMuted }}>Mutasi stok tidak ditemukan.</div></>;
  }

  return (
    <>
      {filters}
      <div style={tableWrap}>
      <table style={table}>
        <thead>
          <tr>
            <th style={th}>Jenis</th>
            <th style={th}>Barang</th>
            <th style={th}>Jumlah</th>
            <th style={th}>Dari</th>
            <th style={th}>Ke</th>
            <th style={th}>Catatan</th>
            <th style={th}>Tanggal</th>
          </tr>
        </thead>
        <tbody>
          {movements.map((m) => (
            <tr key={m.id}>
              <td style={td}>
                <Pill variant={m.type === "IN" ? "green" : m.type === "OUT" ? "red" : "grey"}>
                  {m.type || "-"}
                </Pill>
              </td>
              <td style={td}>{m.item?.sku || "-"} — {m.item?.name || ""}</td>
              <td style={td}>{m.qty ?? "-"}</td>
              <td style={tdSoft}>{m.fromLocation?.name || "-"}</td>
              <td style={tdSoft}>{m.toLocation?.name || "-"}</td>
              <td style={tdSoft}>{m.note || "-"}</td>
              <td style={tdSoft}>{fmtDate(m.createdAt)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      </div>
    </>
  );
}
