const express = require("express");
const bcrypt = require("bcrypt");
const { prisma } = require("../prisma");
const { signToken, requireAuth } = require("../auth");
const { rateLimit } = require("../middleware/rateLimit");
const { notifyOwnerSafely } = require("../services/emailNotifications");

const router = express.Router();

function authCookieOptions(req) {
  const forwardedProto = String(req.get("x-forwarded-proto") || "").split(",")[0].trim();
  const secure = req.secure || forwardedProto === "https" || process.env.NODE_ENV === "production";
  return { httpOnly: true, secure, sameSite: secure ? "none" : "lax", maxAge: 7 * 24 * 60 * 60 * 1000, path: "/" };
}

// Register (INVITE CODE REQUIRED)
router.post("/register", rateLimit({ windowMs: 60 * 60 * 1000, max: 10 }), async (req, res) => {
  try {
    const { name, email, password, confirmPassword, inviteCode } = req.body || {};

    const emailNorm = String(email || "").trim().toLowerCase();
    const nm = String(name || "").trim() || null;
    const pwd = String(password || "");
    const cpwd = String(confirmPassword || "");
    const code = String(inviteCode || "").trim();

    if (!emailNorm || !pwd) {
      return res.status(400).json({ ok: false, error: "email and password required" });
    }

    if (!cpwd) {
      return res.status(400).json({ ok: false, error: "confirm password required" });
    }
    if (pwd !== cpwd) {
      return res.status(400).json({ ok: false, error: "passwords do not match" });
    }
    if (pwd.length < 10) {
      return res.status(400).json({ ok: false, error: "password must be at least 10 characters" });
    }

    if (!process.env.INVITE_CODE) {
      return res.status(500).json({ ok: false, error: "server missing INVITE_CODE" });
    }
    if (code !== process.env.INVITE_CODE) {
      return res.status(403).json({ ok: false, error: "invalid invitation code" });
    }

    const existing = await prisma.user.findUnique({ where: { email: emailNorm } });
    if (existing) {
      return res.status(409).json({ ok: false, error: "Email already used" });
    }

    const hashed = await bcrypt.hash(pwd, 12);

    const user = await prisma.user.create({
      data: {
        name: nm,
        email: emailNorm,
        password: hashed,
        role: "STAFF",
        isActive: true,
        status: "ACTIVE",
      },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        isActive: true,
        createdAt: true,
      },
    });

    const registeredAt = new Intl.DateTimeFormat("id-ID", {
      dateStyle: "full",
      timeStyle: "short",
      timeZone: "Asia/Jakarta",
    }).format(user.createdAt);

    await notifyOwnerSafely({
      event: "User baru terdaftar",
      title: user.name || user.email,
      details: [
        `Nama: ${user.name || "Belum diisi"}`,
        `Email: ${user.email}`,
        `Role: ${user.role}`,
        `Status: ${user.isActive ? "Aktif" : "Tidak aktif"}`,
        `Waktu daftar: ${registeredAt} WIB`,
      ].join("\n"),
      path: "/users",
    });

    return res.json({ ok: true, user });
  } catch (e) {
    // Log the real cause on the server; never send internal details to the browser.
    console.error("[auth/register]", e);
    return res.status(500).json({ ok: false, error: "Registration failed. Please try again later." });
  }
});

router.post(
  "/login",
  rateLimit({ windowMs: 15 * 60 * 1000, max: 50, key: (req) => req.ip }),
  rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 10,
    key: (req) => String(req.body?.email || "").trim().toLowerCase(),
    message: "Terlalu banyak percobaan login. Coba lagi dalam 15 menit.",
  }),
  async (req, res) => {
  try {
    const { email, password } = req.body || {};
    const emailNorm = String(email || "").trim().toLowerCase();
    const pwd = String(password || "");

    if (!emailNorm || !pwd) {
      return res.status(400).json({ ok: false, error: "email and password required" });
    }

    const user = await prisma.user.findUnique({ where: { email: emailNorm } });
    if (!user) {
      return res.status(401).json({ ok: false, error: "Invalid credentials" });
    }

    if (!user.isActive) {
      return res.status(403).json({ ok: false, error: "Account inactive" });
    }

    if (user.status !== "ACTIVE") {
      return res.status(403).json({ ok: false, error: `Account is ${user.status}. Contact admin.` });
    }

    const match = await bcrypt.compare(pwd, user.password);
    if (!match) {
      return res.status(401).json({ ok: false, error: "Invalid credentials" });
    }

    const token = signToken({
      id: user.id,
      email: user.email,
      role: user.role,
    });

    // Expose the authenticated actor to the audit middleware for this request.
    req.user = { id: user.id, name: user.name, email: user.email, role: user.role };

    res.cookie("token", token, authCookieOptions(req));

    return res.json({
      ok: true,
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    });
  } catch (e) {
    console.error("[auth/login]", e);
    return res.status(500).json({ ok: false, error: "Login failed. Please try again later." });
  }
  }
);

router.post("/logout", requireAuth, (req, res) => {
  const cookie = authCookieOptions(req);
  res.clearCookie("token", {
    secure: cookie.secure,
    sameSite: cookie.sameSite,
    path: "/",
  });
  res.json({ ok: true });
});

router.get("/me", requireAuth, async (req, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.user.id },
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      isActive: true,
      createdAt: true,
    },
  });

  if (!user || !user.isActive) {
    const cookie = authCookieOptions(req);
    res.clearCookie("token", {
      secure: cookie.secure,
      sameSite: cookie.sameSite,
      path: "/",
    });
    return res.status(401).json({ ok: false, error: "Unauthorized" });
  }

  res.json({ ok: true, user });
});

module.exports = router;
