const express = require("express");
const ExcelJS = require("exceljs");
const { prisma } = require("../prisma");
const { authRequired } = require("../middleware/authRequired");
const { SYSTEM_ACCOUNTS, cashCode, postJournal } = require("../services/accounting");
const { esc, money, date: fmtDate, documentHtml } = require("../utils/printDocument");
const { cashVoucherHtml, cashVoucherBatchHtml } = require("../utils/cashVoucher");

const router = express.Router();

const allowedRoles = ["OWNER", "ADMIN", "STAFF"];
const proofRoles = ["OWNER", "ADMIN", "STAFF"];
const TRIP_EXPENSE_LIMIT = Number(process.env.TRIP_EXPENSE_LIMIT || 0);
const EXPENSE_CATEGORIES = ["PANJAR", "TRIP_ALLOWANCE", "REMAINING_TRIP_ALLOWANCE", "UNLOADING_FEE", "FUEL_LOAN", "LOADING_LOAN", "DRIVER_SALARY", "FUEL", "TOLL_PARKING", "LOADING_UNLOADING", "REPAIR_MAINTENANCE", "SPAREPART", "OFFICE_OPERATIONAL", "EMPLOYEE_SALARY", "OPERATIONAL_COST", "ELECTRICITY", "WATER", "TELECOMMUNICATION", "OFFICE_EQUIPMENT", "COMMISSION_FEE", "DOCUMENT_ADMINISTRATION", "BPJS", "TAX", "EMPLOYEE_RECEIVABLE", "FINANCE_DEBT_PAYMENT", "OTHER"];

function ensureRole(req, res) {
  const role = req.user?.role;
  if (!allowedRoles.includes(role)) {
    res.status(403).json({ error: "Forbidden" });
    return false;
  }
  return true;
}

function cleanStr(v) {
  if (v === undefined || v === null) return undefined;
  const s = String(v).trim();
  return s.length ? s : undefined;
}

function serializeExpense(expense) {
  if (!expense) return expense;
  return {
    ...expense,
    financeDebt: expense.financeDebt ? {
      ...expense.financeDebt,
      originalAmount: Number(expense.financeDebt.originalAmount),
    } : null,
  };
}

function cashOutVoucherData(expense) {
  const dateKey = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Jakarta", year: "numeric", month: "2-digit", day: "2-digit" }).format(expense.expenseDate).replaceAll("-", "");
  const party = expense.clientName || expense.accountName || expense.employee?.name || expense.employeeParty?.name || expense.trip?.driverUser?.name || expense.truck?.driverUser?.name || "-";
  const allocation = expense.trip?.order?.orderNo || expense.trip?.truck?.plateNumber || expense.truck?.plateNumber;
  const purpose = [expense.reason, allocation].filter(Boolean).join(" · ");
  const method = expense.paymentMethod === "CASH" ? "Tunai" : expense.paymentMethod === "BANK_TRANSFER" ? `Transfer${expense.bankName ? ` - ${expense.bankName}` : ""}` : expense.paymentMethod === "GIRO" ? `Giro${expense.bankName ? ` - ${expense.bankName}` : ""}${expense.accountNumber ? ` · No. ${expense.accountNumber}` : ""}${expense.giroDueAt ? ` · Jatuh tempo ${fmtDate(expense.giroDueAt)}` : ""}` : "Lainnya";
  return {
    type: "OUT",
    number: `BKK-${dateKey}-${expense.id.slice(-6).toUpperCase()}`,
    date: expense.expenseDate,
    party,
    amount: expense.amount,
    purpose,
    method,
    notes: expense.notes,
    signatures: [expense.proofUploadedBy?.name || expense.createdBy?.name, expense.approvedBy?.name, expense.createdBy?.name, party],
  };
}

function parseExpenseDate(value) {
  const text = cleanStr(value);
  if (!text || !/^\d{4}-\d{2}-\d{2}$/.test(text)) return null;
  const date = new Date(`${text}T00:00:00+07:00`);
  if (Number.isNaN(date.getTime())) return null;
  const [year, month, day] = text.split("-").map(Number);
  const formatter = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Jakarta", year: "numeric", month: "2-digit", day: "2-digit" });
  const parts = Object.fromEntries(formatter.formatToParts(date).map(part => [part.type, part.value]));
  return Number(parts.year) === year && Number(parts.month) === month && Number(parts.day) === day ? date : null;
}

// Cash returned by a driver reduces the previously recognized operating cost.
router.get("/returns", authRequired, async (req, res) => {
  if (!ensureRole(req, res)) return;
  const items = await prisma.expenseReturn.findMany({
    orderBy: [{ returnDate: "desc" }, { createdAt: "desc" }],
    take: 100,
    include: { truck: { select: { id: true, plateNumber: true, brand: true, model: true } }, createdBy: { select: { id: true, name: true } } },
  });
  res.json({ items, total: items.length, amount: items.reduce((sum, item) => sum + item.amount, 0) });
});

router.post("/returns", authRequired, async (req, res) => {
  if (!ensureRole(req, res)) return;
  const truckId = cleanStr(req.body.truckId);
  const reason = cleanStr(req.body.reason);
  const notes = cleanStr(req.body.notes);
  const paymentMethod = cleanStr(req.body.paymentMethod) || "BANK_TRANSFER";
  const amount = Math.round(Number(req.body.amount));
  const returnDate = parseExpenseDate(cleanStr(req.body.returnDate));
  if (!truckId) return res.status(400).json({ error: "Armada wajib dipilih" });
  if (!returnDate) return res.status(400).json({ error: "Tanggal retur tidak valid" });
  if (!Number.isSafeInteger(amount) || amount <= 0) return res.status(400).json({ error: "Jumlah retur harus lebih besar dari 0" });
  if (!reason) return res.status(400).json({ error: "Alasan retur wajib diisi" });
  if (!['BANK_TRANSFER', 'CASH', 'OTHER'].includes(paymentMethod)) return res.status(400).json({ error: "Metode penerimaan retur tidak valid" });
  const truck = await prisma.truck.findUnique({ where: { id: truckId }, select: { id: true, plateNumber: true } });
  if (!truck) return res.status(404).json({ error: "Armada tidak ditemukan" });

  const eligibleCategories = ["PANJAR", "TRIP_ALLOWANCE", "REMAINING_TRIP_ALLOWANCE", "FUEL_LOAN", "LOADING_LOAN"];
  const [direct, tripExpenses, priorReturns] = await Promise.all([
    prisma.expense.aggregate({ where: { truckId, status: { in: ["PAID", "APPROVED"] }, category: { in: eligibleCategories } }, _sum: { amount: true } }),
    prisma.expense.aggregate({ where: { trip: { is: { truckId } }, status: { in: ["PAID", "APPROVED"] }, category: { in: eligibleCategories } }, _sum: { amount: true } }),
    prisma.expenseReturn.aggregate({ where: { truckId }, _sum: { amount: true } }),
  ]);
  const available = Number(direct._sum.amount || 0) + Number(tripExpenses._sum.amount || 0) - Number(priorReturns._sum.amount || 0);
  if (amount > available) return res.status(400).json({ error: `Retur melebihi saldo panjar/uang jalan armada. Maksimal Rp${Math.max(0, available).toLocaleString("id-ID")}` });

  const created = await prisma.$transaction(async tx => {
    const item = await tx.expenseReturn.create({ data: { truckId, returnDate, amount, paymentMethod, reason, notes, createdById: req.user.id }, include: { truck: true, createdBy: { select: { id: true, name: true } } } });
    await postJournal(tx, { date: returnDate, description: `Retur pengeluaran ${truck.plateNumber}: ${reason}`, sourceType: "EXPENSE_RETURN", sourceId: item.id, createdById: req.user.id, lines: [{ code: cashCode(paymentMethod), debit: amount }, { code: SYSTEM_ACCOUNTS.EXPENSE, credit: amount }] });
    return item;
  });
  res.status(201).json({ item: created, availableAfter: available - amount });
});

const categoryLabels = { PANJAR: "Panjar", TRIP_ALLOWANCE: "Uang jalan", REMAINING_TRIP_ALLOWANCE: "Sisa uang jalan", UNLOADING_FEE: "Uang bongkar", FUEL_LOAN: "Pinjaman minyak", LOADING_LOAN: "Pinjaman muat", DRIVER_SALARY: "Gaji pengemudi", FUEL: "Bahan bakar", TOLL_PARKING: "Tol & parkir", LOADING_UNLOADING: "Bongkar muat", REPAIR_MAINTENANCE: "Perbaikan & servis", SPAREPART: "Sparepart", OFFICE_OPERATIONAL: "Operasional kantor", EMPLOYEE_SALARY: "Gaji karyawan", OPERATIONAL_COST: "Biaya operasional", ELECTRICITY: "Listrik", WATER: "Air", TELECOMMUNICATION: "Telkom / komunikasi", OFFICE_EQUIPMENT: "Peralatan kantor", COMMISSION_FEE: "Komisi / fee", DOCUMENT_ADMINISTRATION: "Pengurusan surat", BPJS: "BPJS", TAX: "Pajak", EMPLOYEE_RECEIVABLE: "Piutang karyawan", FINANCE_DEBT_PAYMENT: "Pembayaran utang finance", OTHER: "Lainnya" };
const methodLabels = { BANK_TRANSFER: "Transfer bank", CASH: "Tunai", GIRO: "Giro", OTHER: "Lainnya" };
const statusLabels = { SUBMITTED: "Diajukan", APPROVED: "Disetujui", PAID: "Dibayar", REJECTED: "Ditolak" };

function expenseMonthRange(month) {
  const match = String(month || "").trim().match(/^(\d{4})-(\d{1,2})(?:-\d{1,2})?$/);
  if (!match) return null;
  const year = Number(match[1]);
  const monthNumber = Number(match[2]);
  if (!Number.isInteger(year) || !Number.isInteger(monthNumber) || monthNumber < 1 || monthNumber > 12) return null;
  const normalizedMonth = `${year}-${String(monthNumber).padStart(2, "0")}`;
  const nextYear = monthNumber === 12 ? year + 1 : year;
  const nextMonth = monthNumber === 12 ? 1 : monthNumber + 1;
  return {
    gte: new Date(`${normalizedMonth}-01T00:00:00+07:00`),
    lt: new Date(`${nextYear}-${String(nextMonth).padStart(2, "0")}-01T00:00:00+07:00`),
  };
}

function expenseFilterWhere({ q, paymentMethod, status, month } = {}) {
  const monthRange = expenseMonthRange(month);
  return {
    AND: [
      ...(paymentMethod ? [{ paymentMethod }] : []),
      ...(status ? [{ status }] : []),
      ...(monthRange ? [{ expenseDate: monthRange }] : []),
      ...(q ? [{ OR: [
        { reason: { contains: q, mode: "insensitive" } },
        { clientName: { contains: q, mode: "insensitive" } },
        { bankName: { contains: q, mode: "insensitive" } },
        { accountName: { contains: q, mode: "insensitive" } },
        { accountNumber: { contains: q, mode: "insensitive" } },
        { employee: { name: { contains: q, mode: "insensitive" } } },
        { employeeParty: { name: { contains: q, mode: "insensitive" } } },
      ] }] : []),
    ],
  };
}

// List expenses
router.get("/", authRequired, async (req, res) => {
  if (!ensureRole(req, res)) return;

  const q = cleanStr(req.query.q || "");
  const paymentMethod = cleanStr(req.query.paymentMethod || "");
  const month = cleanStr(req.query.month || "");
  if (month && !expenseMonthRange(month)) return res.status(400).json({ error: "Periode bulan tidak valid" });
  const showAll = req.query.all === "true";
  const take = showAll ? undefined : Math.min(parseInt(req.query.take || "50", 10), 200);
  const skip = Math.max(parseInt(req.query.skip || "0", 10), 0);

  const where = expenseFilterWhere({ q, paymentMethod, month });

  const [items, total, pendingApprovalTotal, groupedStatuses] = await Promise.all([
    prisma.expense.findMany({
      where,
      orderBy: [{ expenseDate: "desc" }, { createdAt: "desc" }],
      ...(showAll ? {} : { skip, take }),
      include: {
        truck: {
          select: {
            id: true,
            plateNumber: true,
            brand: true,
            model: true,
            driverUser: { select: { id: true, name: true } },
          },
        },
        employee: { select: { id: true, name: true, email: true } },
        employeeParty: { select: { id: true, name: true, phone: true } },
        financeDebt: { include: { truck: { select: { id: true, plateNumber: true, brand: true, model: true } } } },
        trip: {
          include: {
            truck: true,
            driverUser: true,
            order: {
              select: {
                id: true,
                orderNo: true,
                customerName: true,
                fromText: true,
                toText: true,
                status: true,
              },
            },
          },
        },
        createdBy: { select: { id: true, name: true, email: true } },
        proofUploadedBy: { select: { id: true, name: true, email: true } },
        approvedBy: { select: { id: true, name: true, email: true } },
      },
    }),
    prisma.expense.count({ where }),
    prisma.expense.count({ where: expenseFilterWhere({ q, paymentMethod, status: "PAID", month }) }),
    prisma.expense.groupBy({ by: ["status"], where, _count: { _all: true } }),
  ]);

  // Load duplicate candidates in one query instead of one query per visible row.
  // A trip has one driver, so grouping by trip preserves the previous behavior.
  const tripIds = [...new Set(items.map(x => x.tripId).filter(Boolean))];
  const duplicateRows = tripIds.length ? await prisma.expense.findMany({
    where: { tripId: { in: tripIds } },
    orderBy: { createdAt: "desc" },
    select: {
      id: true, tripId: true, expenseDate: true, createdAt: true, amount: true, currency: true,
      reason: true, status: true, accountName: true, accountNumber: true, bankName: true,
    },
  }) : [];
  const duplicatesByTrip = duplicateRows.reduce((map, row) => {
    if (!map.has(row.tripId)) map.set(row.tripId, []);
    map.get(row.tripId).push(row);
    return map;
  }, new Map());
  const supplierPaymentIds = items.map(item => String(item.notes || "").match(/^AUTO_SUPPLIER_PAYMENT:(.+)$/)?.[1]).filter(Boolean);
  const supplierPayments = supplierPaymentIds.length ? await prisma.purchasePayment.findMany({
    where: { id: { in: supplierPaymentIds } },
    select: {
      id: true,
      supplierBill: {
        select: {
          items: {
            select: {
              receiptItem: { select: { inventoryBatch: { select: { remainingQty: true } } } },
            },
          },
        },
      },
    },
  }) : [];
  const supplierPaymentById = new Map(supplierPayments.map(payment => [payment.id, payment]));
  const withDup = items.map(x => {
    const duplicates = x.tripId ? (duplicatesByTrip.get(x.tripId) || []) : [];
    const paymentId = String(x.notes || "").match(/^AUTO_SUPPLIER_PAYMENT:(.+)$/)?.[1];
    const payment = paymentId ? supplierPaymentById.get(paymentId) : null;
    const includesInventory = payment?.supplierBill?.items?.some(line => Number(line.receiptItem?.inventoryBatch?.remainingQty || 0) > 0);
    const allocationLabel = includesInventory
      ? [x.truck?.plateNumber, "Inventory"].filter(Boolean).join(" + ")
      : null;
    return serializeExpense({ ...x, allocationLabel, duplicateFlag: duplicates.length > 1, duplicateCount: duplicates.length, duplicates });
  });

  const statusCounts = Object.fromEntries(groupedStatuses.map(row => [row.status, row._count._all]));
  res.json({ items: withDup, total, pendingApprovalTotal, statusCounts, skip: showAll ? 0 : skip, take: showAll ? total : take });
});

function excelDate(value) {
  if (!value) return null;
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Jakarta", year: "numeric", month: "2-digit", day: "2-digit" })
    .formatToParts(value)
    .reduce((result, part) => ({ ...result, [part.type]: part.value }), {});
  return new Date(Date.UTC(Number(parts.year), Number(parts.month) - 1, Number(parts.day)));
}

// Export every expense as a native Excel workbook.
router.get("/export", authRequired, async (req, res) => {
  if (!ensureRole(req, res)) return;

  const items = await prisma.expense.findMany({
    orderBy: [{ expenseDate: "asc" }, { createdAt: "asc" }],
    select: {
      expenseDate: true,
      category: true,
      reason: true,
      clientName: true,
      paymentMethod: true,
      bankName: true,
      accountName: true,
      accountNumber: true,
      giroIssuedAt: true,
      giroDueAt: true,
      currency: true,
      amount: true,
      status: true,
      notes: true,
      truck: { select: { plateNumber: true } },
      trip: { select: { truck: { select: { plateNumber: true } }, driverUser: { select: { name: true } }, order: { select: { orderNo: true, fromText: true, toText: true } } } },
      createdBy: { select: { name: true, email: true } },
      approvedBy: { select: { name: true, email: true } },
    },
  });

  const workbook = new ExcelJS.Workbook();
  workbook.creator = "Mitra Setia ERP";
  workbook.created = new Date();
  const sheet = workbook.addWorksheet("Semua Pengeluaran", {
    views: [{ state: "frozen", ySplit: 1 }],
    pageSetup: { orientation: "landscape", fitToPage: true, fitToWidth: 1, fitToHeight: 0 },
  });
  sheet.columns = [
    { header: "No", key: "number", width: 8 },
    { header: "Tanggal", key: "expenseDate", width: 13 },
    { header: "Kategori", key: "category", width: 24 },
    { header: "Keperluan", key: "reason", width: 36 },
    { header: "Klien / Referensi", key: "clientName", width: 24 },
    { header: "Trip", key: "trip", width: 18 },
    { header: "Rute", key: "route", width: 34 },
    { header: "Armada", key: "truck", width: 16 },
    { header: "Pengemudi", key: "driver", width: 22 },
    { header: "Metode", key: "paymentMethod", width: 18 },
    { header: "Bank", key: "bankName", width: 18 },
    { header: "Nama Rekening / Penerima", key: "accountName", width: 28 },
    { header: "Nomor Rekening / Giro", key: "accountNumber", width: 24 },
    { header: "Tanggal Terbit Giro", key: "giroIssuedAt", width: 19 },
    { header: "Jatuh Tempo Giro", key: "giroDueAt", width: 19 },
    { header: "Mata Uang", key: "currency", width: 12 },
    { header: "Nominal", key: "amount", width: 18 },
    { header: "Status", key: "status", width: 15 },
    { header: "Catatan", key: "notes", width: 34 },
    { header: "Dibuat Oleh", key: "createdBy", width: 24 },
    { header: "Disetujui Oleh", key: "approvedBy", width: 24 },
  ];

  items.forEach((item, index) => {
    const trip = item.trip;
    sheet.addRow({
      number: index + 1,
      expenseDate: excelDate(item.expenseDate),
      category: categoryLabels[item.category] || item.category,
      reason: item.reason,
      clientName: item.clientName || "",
      trip: trip?.order?.orderNo || "",
      route: trip?.order ? `${trip.order.fromText || "-"} → ${trip.order.toText || "-"}` : "",
      truck: trip?.truck?.plateNumber || item.truck?.plateNumber || "",
      driver: trip?.driverUser?.name || "",
      paymentMethod: methodLabels[item.paymentMethod] || item.paymentMethod,
      bankName: item.bankName || "",
      accountName: item.accountName || "",
      accountNumber: item.accountNumber || "",
      giroIssuedAt: excelDate(item.giroIssuedAt),
      giroDueAt: excelDate(item.giroDueAt),
      currency: item.currency,
      amount: item.amount,
      status: statusLabels[item.status] || item.status,
      notes: item.notes || "",
      createdBy: item.createdBy?.name || item.createdBy?.email || "",
      approvedBy: item.approvedBy?.name || item.approvedBy?.email || "",
    });
  });

  const header = sheet.getRow(1);
  header.height = 28;
  header.font = { bold: true, color: { argb: "FFFFFFFF" } };
  header.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1F4E78" } };
  header.alignment = { vertical: "middle", horizontal: "center", wrapText: true };
  sheet.autoFilter = { from: "A1", to: "U1" };
  sheet.getColumn("expenseDate").numFmt = "dd/mm/yyyy";
  sheet.getColumn("giroIssuedAt").numFmt = "dd/mm/yyyy";
  sheet.getColumn("giroDueAt").numFmt = "dd/mm/yyyy";
  sheet.getColumn("amount").numFmt = "#,##0";
  sheet.getColumn("amount").alignment = { horizontal: "right" };
  sheet.eachRow((row, rowNumber) => {
    if (rowNumber === 1) return;
    row.alignment = { vertical: "top", wrapText: true };
    row.getCell(1).alignment = { vertical: "top", horizontal: "center" };
    row.getCell(17).alignment = { vertical: "top", horizontal: "right" };
    if (rowNumber % 2 === 0) row.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFF3F6F9" } };
  });

  const output = await workbook.xlsx.writeBuffer();
  const filename = `semua-pengeluaran-${new Date().toISOString().slice(0, 10)}.xlsx`;
  res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
  res.setHeader("Content-Length", output.length);
  res.end(output);
});

// Monthly report (HTML)
// GET /expenses/report?month=YYYY-MM
router.get("/report", authRequired, async (req, res) => {
  if (!ensureRole(req, res)) return;

  const month = cleanStr(req.query.month);
  if (!month || !/^\d{4}-\d{2}$/.test(month)) {
    return res.status(400).send("Invalid month format. Use YYYY-MM.");
  }

  const [yearStr, monthStr] = month.split("-");
  const year = Number(yearStr);
  const mon = Number(monthStr);
  if (!Number.isFinite(year) || !Number.isFinite(mon) || mon < 1 || mon > 12) {
    return res.status(400).send("Invalid month value.");
  }

  const start = new Date(`${month}-01T00:00:00+07:00`);
  const nextYear = mon === 12 ? year + 1 : year;
  const nextMonth = mon === 12 ? 1 : mon + 1;
  const end = new Date(`${nextYear}-${String(nextMonth).padStart(2, "0")}-01T00:00:00+07:00`);

  const items = await prisma.expense.findMany({
    where: { expenseDate: { gte: start, lt: end } },
    orderBy: { expenseDate: "asc" },
    include: {
      trip: {
        include: {
          truck: true,
          driverUser: true,
          order: {
            select: {
              id: true,
              orderNo: true,
              customerName: true,
              fromText: true,
              toText: true,
              status: true,
            },
          },
        },
      },
      truck: { select: { plateNumber: true, brand: true, model: true } },
      createdBy: { select: { id: true, name: true, email: true } },
      proofUploadedBy: { select: { id: true, name: true, email: true } },
      approvedBy: { select: { id: true, name: true, email: true } },
    },
  });

  const total = items.reduce((sum, x) => sum + Number(x.amount || 0), 0);
  const approved = items.filter(x => ["APPROVED", "PAID"].includes(x.status)).length;
  const monthLabel = new Intl.DateTimeFormat("id-ID", { month: "long", year: "numeric", timeZone: "Asia/Jakarta" }).format(start);
  const rows = items.map((x, index) => {
    const trip = x.trip || {};
    const truck = trip.truck || x.truck;
    const tripNumber = trip.order?.orderNo || trip.tripNo || trip.id || "-";
    const route = trip.order ? `${trip.order.fromText || "-"} → ${trip.order.toText || "-"}` : "Tidak terkait trip";
    const assignment = truck?.plateNumber ? `${truck.plateNumber}${trip.driverUser?.name ? ` · ${trip.driverUser.name}` : ""}` : "-";
    return `<tr><td class="center">${index + 1}</td><td>${fmtDate(x.expenseDate)}</td><td>${esc(categoryLabels[x.category] || "Lainnya")}</td><td><b>${esc(x.reason || "-")}</b><br><span class="muted">${esc(tripNumber)} · ${esc(route)}</span></td><td>${esc(assignment)}</td><td>${esc(methodLabels[x.paymentMethod] || x.paymentMethod || "-")}</td><td>${esc(x.createdBy?.name || "-")}</td><td>${esc(statusLabels[x.status] || x.status || "Diajukan")}</td><td class="right">${money(x.amount)}</td></tr>`;
  }).join("");

  res.type("html").send(documentHtml({
    title: "LAPORAN PENGELUARAN BULANAN",
    subtitle: monthLabel,
    meta: `Periode: 1–${new Date(year, mon, 0).getDate()} ${esc(monthLabel)}<br>Jumlah data: ${items.length}`,
    landscape: true,
    body: `<div class="summary"><div class="box">Total pengeluaran<b>${money(total)}</b><span>Seluruh transaksi periode ini</span></div><div class="box">Jumlah transaksi<b>${items.length}</b><span>Catatan pengeluaran</span></div><div class="box">Disetujui / dibayar<b>${approved}</b><span>Dari ${items.length} transaksi</span></div></div><table><thead><tr><th class="center">No</th><th>Tanggal</th><th>Kategori</th><th>Keterangan / Trip</th><th>Armada / Pengemudi</th><th>Metode</th><th>Dibuat oleh</th><th>Status</th><th class="right">Nominal</th></tr></thead><tbody>${rows || `<tr><td colspan="9" class="center">Belum ada pengeluaran pada periode ini.</td></tr>`}</tbody><tfoot><tr><td colspan="8" class="right"><b>TOTAL PENGELUARAN</b></td><td class="right"><b>${money(total)}</b></td></tr></tfoot></table><div class="signatures"><div>Dibuat oleh</div><div>Diperiksa oleh</div><div>Disetujui oleh</div></div>`,
  }));
});

// Print every cash-out voucher matching the active list filters.
router.get("/vouchers-print", authRequired, async (req, res) => {
  if (!ensureRole(req, res)) return;
  const q = cleanStr(req.query.q || "");
  const paymentMethod = cleanStr(req.query.paymentMethod || "");
  const month = cleanStr(req.query.month || "");
  if (paymentMethod && !["BANK_TRANSFER", "CASH", "GIRO", "OTHER"].includes(paymentMethod)) return res.status(400).send("Metode pembayaran tidak valid");
  if (!month || !/^\d{4}-\d{2}$/.test(month)) return res.status(400).send("Pilih periode bulan yang valid");
  const [yearText, monthText] = month.split("-");
  const year = Number(yearText);
  const monthNumber = Number(monthText);
  if (!Number.isInteger(year) || !Number.isInteger(monthNumber) || monthNumber < 1 || monthNumber > 12) return res.status(400).send("Periode bulan tidak valid");
  const start = new Date(`${month}-01T00:00:00+07:00`);
  const nextYear = monthNumber === 12 ? year + 1 : year;
  const nextMonth = monthNumber === 12 ? 1 : monthNumber + 1;
  const end = new Date(`${nextYear}-${String(nextMonth).padStart(2, "0")}-01T00:00:00+07:00`);
  const items = await prisma.expense.findMany({
    where: { ...expenseFilterWhere({ q, paymentMethod }), expenseDate: { gte: start, lt: end } },
    orderBy: [{ expenseDate: "asc" }, { createdAt: "asc" }],
    include: {
      employee: { select: { name: true } },
      employeeParty: { select: { name: true } },
      truck: { select: { plateNumber: true, driverUser: { select: { name: true } } } },
      trip: { include: { truck: { select: { plateNumber: true } }, driverUser: { select: { name: true } }, order: { select: { orderNo: true } } } },
      createdBy: { select: { name: true } },
      proofUploadedBy: { select: { name: true } },
      approvedBy: { select: { name: true } },
    },
  });
  const monthLabel = new Intl.DateTimeFormat("id-ID", { month: "long", year: "numeric", timeZone: "Asia/Jakarta" }).format(start);
  res.type("html").send(cashVoucherBatchHtml(items.map(cashOutVoucherData), `BUKTI PENGELUARAN KAS - ${monthLabel}`));
});

// Dot-matrix cash-out voucher, sized for 9.5 x 5.5 inch continuous forms.
router.get("/:id/voucher-print", authRequired, async (req, res) => {
  if (!ensureRole(req, res)) return;
  const expense = await prisma.expense.findUnique({
    where: { id: req.params.id },
    include: {
      employee: { select: { name: true, email: true } },
      employeeParty: { select: { name: true, phone: true } },
      truck: { select: { plateNumber: true, driverUser: { select: { name: true } } } },
      trip: { include: { truck: { select: { plateNumber: true } }, driverUser: { select: { name: true } }, order: { select: { orderNo: true } } } },
      createdBy: { select: { name: true } },
      proofUploadedBy: { select: { name: true } },
      approvedBy: { select: { name: true } },
    },
  });
  if (!expense) return res.status(404).send("Pengeluaran tidak ditemukan");
  res.type("html").send(cashVoucherHtml(cashOutVoucherData(expense)));
});

router.get("/employees", authRequired, async (req, res) => {
  if (!ensureRole(req, res)) return;
  const [employees, employeeParties] = await Promise.all([
    prisma.user.findMany({ where: { isActive: true }, orderBy: { name: "asc" }, select: { id: true, name: true, email: true, role: true } }),
    prisma.employeeReceivableParty.findMany({ where: { isActive: true }, orderBy: { name: "asc" }, select: { id: true, name: true, phone: true } }),
  ]);
  res.json({ employees, employeeParties });
});

router.get("/finance-debts", authRequired, async (req, res) => {
  if (!ensureRole(req, res)) return;
  const debts = await prisma.financeDebt.findMany({ where: { isActive: true }, include: { truck: { select: { id: true, plateNumber: true, brand: true, model: true } }, expenses: { where: { category: "FINANCE_DEBT_PAYMENT", status: { in: ["PAID", "APPROVED"] } }, select: { id: true, amount: true, expenseDate: true, status: true } } }, orderBy: [{ leasingName: "asc" }, { createdAt: "desc" }] });
  res.json({ debts: debts.map(debt => { const originalAmount = Number(debt.originalAmount); const paid = debt.expenses.reduce((sum, item) => sum + item.amount, 0); return { ...debt, originalAmount, paid, balance: Math.max(0, originalAmount - paid) }; }) });
});

router.post("/finance-debts", authRequired, async (req, res) => {
  if (!ensureRole(req, res)) return;
  const leasingName = cleanStr(req.body.leasingName);
  const contractNumber = cleanStr(req.body.contractNumber);
  const originalAmount = Math.round(Number(req.body.originalAmount));
  if (!leasingName || !Number.isFinite(originalAmount) || originalAmount <= 0) return res.status(400).json({ error: "Leasing dan jumlah utang awal wajib diisi" });
  if (!Number.isSafeInteger(originalAmount)) return res.status(400).json({ error: "Jumlah utang terlalu besar atau tidak valid" });

  try {
    const debt = await prisma.$transaction(async tx => {
      const created = await tx.financeDebt.create({
        data: { leasingName, contractNumber, originalAmount: BigInt(originalAmount), notes: cleanStr(req.body.notes), createdById: req.user.id },
        include: { truck: true },
      });
      await postJournal(tx, {
        date: created.createdAt,
        description: `Saldo awal utang finance ${created.leasingName}`,
        sourceType: "FINANCE_DEBT",
        sourceId: created.id,
        createdById: req.user.id,
        lines: [{ code: SYSTEM_ACCOUNTS.EQUITY, debit: created.originalAmount }, { code: SYSTEM_ACCOUNTS.FINANCE_AP, credit: created.originalAmount }],
      });
      return created;
    }, { maxWait: 10_000, timeout: 20_000 });
    res.status(201).json({ ...debt, originalAmount: Number(debt.originalAmount), paid: 0, balance: Number(debt.originalAmount) });
  } catch (error) {
    console.error("Failed to create finance debt:", error);
    const message = error?.code === "P2003"
      ? "Akun pengguna atau data referensi tidak valid. Silakan login ulang lalu coba lagi."
      : error?.message === "Akun sistem accounting belum lengkap"
        ? error.message
        : "Utang finance gagal disimpan. Silakan coba kembali.";
    res.status(500).json({ error: message });
  }
});

// Create expense
router.post("/", authRequired, async (req, res) => {
  if (!ensureRole(req, res)) return;

  const paymentMethod = cleanStr(req.body.paymentMethod) || "BANK_TRANSFER";
  const amount = Number(req.body.amount || 0);
  const currency = cleanStr(req.body.currency) || "IDR";
  const category = cleanStr(req.body.category) || "OTHER";
  const reason = cleanStr(req.body.reason);
  const clientName = cleanStr(req.body.clientName);
  const bankName = cleanStr(req.body.bankName);
  const accountName = cleanStr(req.body.accountName);
  const accountNumber = cleanStr(req.body.accountNumber);
  const giroIssuedAt = parseExpenseDate(cleanStr(req.body.giroIssuedAt));
  const giroDueAt = parseExpenseDate(cleanStr(req.body.giroDueAt));
  const notes = cleanStr(req.body.notes);
  const tripId = cleanStr(req.body.tripId);
  const truckId = cleanStr(req.body.truckId);
  const employeeId = cleanStr(req.body.employeeId);
  const employeePartyId = cleanStr(req.body.employeePartyId);
  const employeeName = cleanStr(req.body.employeeName);
  const employeePhone = cleanStr(req.body.employeePhone);
  const financeDebtId = cleanStr(req.body.financeDebtId);
  const expenseDateInput = cleanStr(req.body.expenseDate);
  const expenseDate = parseExpenseDate(expenseDateInput);

  if (!expenseDateInput) {
    return res.status(400).json({ error: "Tanggal pengeluaran wajib diisi" });
  }
  if (!expenseDate) {
    return res.status(400).json({ error: "Tanggal pengeluaran tidak valid" });
  }

  if (tripId && truckId) {
    return res.status(400).json({ error: "Pilih perjalanan atau armada langsung, bukan keduanya" });
  }

  const allowedMethods = ["BANK_TRANSFER", "CASH", "GIRO", "OTHER"];
  if (!allowedMethods.includes(paymentMethod)) {
    return res.status(400).json({ error: "Invalid payment method" });
  }
  if (!EXPENSE_CATEGORIES.includes(category)) {
    return res.status(400).json({ error: "Kategori pengeluaran tidak valid" });
  }
  if (!Number.isFinite(amount) || amount <= 0) {
    return res.status(400).json({ error: "Amount must be greater than 0" });
  }
  if (!reason) {
    return res.status(400).json({ error: "Reason is required" });
  }
  if (tripId && paymentMethod === "BANK_TRANSFER" && (!bankName || !accountName || !accountNumber)) {
    return res.status(400).json({ error: "Nama bank, nama pemilik rekening, dan nomor rekening wajib diisi untuk transfer bank" });
  }
  if (paymentMethod === "GIRO" && (!bankName || !accountName || !accountNumber || !giroIssuedAt || !giroDueAt)) {
    return res.status(400).json({ error: "Bank penerbit, nomor giro, nama penerima, tanggal terbit, dan tanggal jatuh tempo wajib diisi" });
  }
  if (paymentMethod === "GIRO" && giroDueAt < giroIssuedAt) return res.status(400).json({ error: "Tanggal jatuh tempo giro tidak boleh sebelum tanggal terbit" });
  let employee = null;
  let employeeParty = null;
  if (category === "EMPLOYEE_RECEIVABLE") {
    if (![employeeId, employeePartyId, employeeName].filter(Boolean).length) return res.status(400).json({ error: "Pilih karyawan atau isi nama orang baru yang akan ditagih" });
    if ([employeeId, employeePartyId, employeeName].filter(Boolean).length > 1) return res.status(400).json({ error: "Pilih satu penanggung piutang saja" });
    if (employeeId) {
      employee = await prisma.user.findFirst({ where: { id: employeeId, isActive: true }, select: { id: true, name: true, email: true } });
      if (!employee) return res.status(400).json({ error: "Karyawan tidak ditemukan atau sudah tidak aktif" });
    }
    if (employeePartyId) {
      employeeParty = await prisma.employeeReceivableParty.findFirst({ where: { id: employeePartyId, isActive: true }, select: { id: true, name: true, phone: true } });
      if (!employeeParty) return res.status(400).json({ error: "Nama orang tidak ditemukan atau sudah tidak aktif" });
    }
  }
  let financeDebt = null;
  if (category === "FINANCE_DEBT_PAYMENT") {
    if (!financeDebtId) return res.status(400).json({ error: "Pilih kontrak leasing yang akan dibayar" });
    financeDebt = await prisma.financeDebt.findFirst({ where: { id: financeDebtId, isActive: true }, include: { expenses: { where: { category: "FINANCE_DEBT_PAYMENT" }, select: { amount: true } } } });
    if (!financeDebt) return res.status(404).json({ error: "Kontrak leasing tidak ditemukan" });
    const balance = Number(financeDebt.originalAmount) - financeDebt.expenses.reduce((sum, item) => sum + item.amount, 0);
    if (Math.round(amount) > balance) return res.status(400).json({ error: `Pembayaran melebihi sisa utang leasing Rp${balance.toLocaleString("id-ID")}` });
  }
  let trip = null;
  if (tripId) {
    trip = await prisma.trip.findUnique({
      where: { id: tripId },
      select: { id: true, driverUserId: true, status: true },
    });
    if (!trip) {
      return res.status(404).json({ error: "Trip not found" });
    }
    if (["COMPLETED", "CANCELLED"].includes(trip.status)) {
      return res.status(400).json({
        error: "Pengeluaran hanya dapat ditambahkan sebelum perjalanan diselesaikan",
      });
    }
  }
  if (truckId) {
    const truck = await prisma.truck.findUnique({ where: { id: truckId }, select: { id: true } });
    if (!truck) return res.status(404).json({ error: "Armada tidak ditemukan" });
  }

  const created = await prisma.$transaction(async tx => {
    const createdParty = category === "EMPLOYEE_RECEIVABLE" && employeeName
      ? await tx.employeeReceivableParty.create({ data: { name: employeeName, phone: employeePhone || null, createdById: req.user?.id || null } })
      : null;
    const expense = await tx.expense.create({ data: {
      status: "SUBMITTED",
      paymentMethod,
      bankName,
      accountName,
      accountNumber,
      giroIssuedAt: paymentMethod === "GIRO" ? giroIssuedAt : null,
      giroDueAt: paymentMethod === "GIRO" ? giroDueAt : null,
      amount: Math.round(amount),
      currency,
      category,
      reason,
      clientName,
      notes,
      expenseDate,
      tripId: tripId || null,
      truckId: truckId || null,
      employeeId: category === "EMPLOYEE_RECEIVABLE" ? (employee?.id || null) : null,
      employeePartyId: category === "EMPLOYEE_RECEIVABLE" ? (employeeParty?.id || createdParty?.id || null) : null,
      financeDebtId: category === "FINANCE_DEBT_PAYMENT" ? financeDebt.id : null,
      createdById: req.user?.id,
    }, include: {
      truck: { select: { id: true, plateNumber: true, brand: true, model: true } },
      employee: { select: { id: true, name: true, email: true } },
      employeeParty: { select: { id: true, name: true, phone: true } },
      financeDebt: { include: { truck: { select: { id: true, plateNumber: true, brand: true, model: true } } } },
      trip: {
        include: {
          truck: true,
          driverUser: true,
          order: { select: { id: true, orderNo: true, customerName: true, fromText: true, toText: true, status: true } },
        },
      },
      createdBy: { select: { id: true, name: true, email: true } },
      proofUploadedBy: { select: { id: true, name: true, email: true } },
      approvedBy: { select: { id: true, name: true, email: true } },
    } });
    return expense;
  });

  let duplicateFlag = false;
  if (trip?.id && trip?.driverUserId) {
    const dupCount = await prisma.expense.count({
      where: { tripId: trip.id, trip: { is: { driverUserId: trip.driverUserId } } },
    });
    duplicateFlag = dupCount > 1;
  }

  res.status(201).json({ ...serializeExpense(created), duplicateFlag });
});

// Update expense
router.patch("/:id", authRequired, async (req, res) => {
  if (!ensureRole(req, res)) return;

  const { id } = req.params;

  const paymentMethod = cleanStr(req.body.paymentMethod);
  const amount = req.body.amount !== undefined ? Number(req.body.amount) : undefined;
  const currency = cleanStr(req.body.currency);
  const category = cleanStr(req.body.category);
  const reason = cleanStr(req.body.reason);
  const clientName = cleanStr(req.body.clientName);
  const bankName = cleanStr(req.body.bankName);
  const accountName = cleanStr(req.body.accountName);
  const accountNumber = cleanStr(req.body.accountNumber);
  const notes = cleanStr(req.body.notes);

  if (paymentMethod) {
    const allowedMethods = ["BANK_TRANSFER", "CASH", "GIRO", "OTHER"];
    if (!allowedMethods.includes(paymentMethod)) {
      return res.status(400).json({ error: "Invalid payment method" });
    }
  }
  if (category && !EXPENSE_CATEGORIES.includes(category)) {
    return res.status(400).json({ error: "Kategori pengeluaran tidak valid" });
  }
  if (amount !== undefined && (!Number.isFinite(amount) || amount <= 0)) {
    return res.status(400).json({ error: "Amount must be greater than 0" });
  }

  const updated = await prisma.expense.update({
    where: { id },
    data: {
      ...(paymentMethod && { paymentMethod }),
      ...(bankName !== undefined && { bankName }),
      ...(accountName !== undefined && { accountName }),
      ...(accountNumber !== undefined && { accountNumber }),
      ...(amount !== undefined && { amount: Math.round(amount) }),
      ...(currency && { currency }),
      ...(category && { category }),
      ...(reason && { reason }),
      ...(clientName !== undefined && { clientName }),
      ...(notes !== undefined && { notes }),
    },
    include: {
      trip: {
        include: {
          truck: true,
          driverUser: true,
          order: { select: { id: true, orderNo: true, customerName: true, fromText: true, toText: true, status: true } },
        },
      },
      createdBy: { select: { id: true, name: true, email: true } },
      proofUploadedBy: { select: { id: true, name: true, email: true } },
      approvedBy: { select: { id: true, name: true, email: true } },
    },
  });

  res.json(updated);
});

// Upload proof + mark as PAID. The creator may upload their own proof;
// OWNER approval remains the separate verification step.
router.post("/:id/proof", authRequired, async (req, res) => {
  const role = req.user?.role;
  if (!proofRoles.includes(role)) {
    return res.status(403).json({ error: "Forbidden" });
  }

  const { id } = req.params;
  const proofUrl = cleanStr(req.body.proofUrl);
  const proofFileName = cleanStr(req.body.proofFileName);
  const proofMimeType = cleanStr(req.body.proofMimeType);
  const proofSize = req.body.proofSize !== undefined ? Number(req.body.proofSize) : undefined;

  if (!proofUrl) {
    return res.status(400).json({ error: "proofUrl is required" });
  }

  const existing = await prisma.expense.findUnique({
    where: { id },
    select: { id: true, status: true, category: true },
  });
  if (!existing) return res.status(404).json({ error: "Not found" });
  if (existing.status !== "SUBMITTED") {
    return res.status(400).json({ error: "Only SUBMITTED expenses can be marked as PAID" });
  }
  const updated = await prisma.$transaction(async tx => {
    const paid = await tx.expense.update({
      where: { id },
      data: {
        proofUrl,
        proofFileName,
        proofMimeType,
        ...(Number.isFinite(proofSize) ? { proofSize: proofSize } : {}),
        status: "PAID",
        paidAt: new Date(),
        proofUploadedById: req.user?.id,
      },
      include: {
        trip: {
          include: {
            truck: true,
            driverUser: true,
            order: { select: { id: true, orderNo: true, customerName: true, fromText: true, toText: true, status: true } },
          },
        },
        createdBy: { select: { id: true, name: true, email: true } },
        proofUploadedBy: { select: { id: true, name: true, email: true } },
        approvedBy: { select: { id: true, name: true, email: true } },
      },
    });
    const debitCode = existing.category === "EMPLOYEE_RECEIVABLE" ? SYSTEM_ACCOUNTS.AR : existing.category === "FINANCE_DEBT_PAYMENT" ? SYSTEM_ACCOUNTS.FINANCE_AP : SYSTEM_ACCOUNTS.EXPENSE;
    await postJournal(tx, { date: paid.paidAt, description: paid.reason, sourceType: "EXPENSE_PAYMENT", sourceId: paid.id, createdById: req.user.id, lines: [{ code: debitCode, debit: paid.amount }, { code: cashCode(paid.paymentMethod), credit: paid.amount }] });
    return paid;
  });

  res.json(updated);
});

// Replace an incorrect proof before owner approval. Financial values/status and
// the accounting journal remain unchanged.
router.patch("/:id/proof", authRequired, async (req, res) => {
  if (!proofRoles.includes(req.user?.role)) return res.status(403).json({ error: "Forbidden" });
  const proofUrl = cleanStr(req.body.proofUrl);
  if (!proofUrl) return res.status(400).json({ error: "Bukti pembayaran wajib diisi" });
  const existing = await prisma.expense.findUnique({ where: { id: req.params.id }, select: { id: true, status: true } });
  if (!existing) return res.status(404).json({ error: "Pengeluaran tidak ditemukan" });
  if (existing.status !== "PAID") return res.status(400).json({ error: existing.status === "APPROVED" ? "Bukti pengeluaran yang sudah disetujui tidak dapat diganti" : "Bukti hanya dapat diganti setelah pembayaran" });
  const proofSize = req.body.proofSize !== undefined ? Number(req.body.proofSize) : undefined;
  const updated = await prisma.expense.update({
    where: { id: existing.id },
    data: {
      proofUrl,
      proofFileName: cleanStr(req.body.proofFileName),
      proofMimeType: cleanStr(req.body.proofMimeType),
      ...(Number.isFinite(proofSize) ? { proofSize } : {}),
      proofUploadedById: req.user.id,
    },
  });
  res.json({ ok: true, expense: updated });
});

// Approve all paid expenses matching the current list filters (OWNER only).
router.post("/approve-all", authRequired, async (req, res) => {
  const approver = await prisma.user.findUnique({
    where: { id: req.user?.id },
    select: { id: true, role: true, isActive: true, status: true },
  });
  if (!approver || !approver.isActive || approver.status !== "ACTIVE") return res.status(403).json({ error: "Akun tidak aktif" });
  if (approver.role !== "OWNER") return res.status(403).json({ error: "Hanya OWNER yang dapat menyetujui semua pengeluaran" });

  const q = cleanStr(req.body?.q || "");
  const paymentMethod = cleanStr(req.body?.paymentMethod || "");
  const month = cleanStr(req.body?.month || "");
  if (paymentMethod && !["BANK_TRANSFER", "CASH", "GIRO", "OTHER"].includes(paymentMethod)) return res.status(400).json({ error: "Metode pembayaran tidak valid" });
  if (month && !expenseMonthRange(month)) return res.status(400).json({ error: "Periode bulan tidak valid" });
  const approvedAt = new Date();
  const result = await prisma.expense.updateMany({
    where: expenseFilterWhere({ q, paymentMethod, status: "PAID", month }),
    data: { status: "APPROVED", approvedAt, approvedById: approver.id },
  });
  res.json({ ok: true, approvedCount: result.count, approvedAt });
});

// Approve expense (OWNER only)
router.post("/:id/approve", authRequired, async (req, res) => {
  const approver = await prisma.user.findUnique({
    where: { id: req.user?.id },
    select: { id: true, role: true, isActive: true, status: true },
  });
  if (!approver || !approver.isActive || approver.status !== "ACTIVE") {
    return res.status(403).json({ error: "Akun tidak aktif" });
  }
  if (approver.role !== "OWNER") {
    return res.status(403).json({ error: `Hanya OWNER yang dapat menyetujui pengeluaran. Role akun saat ini: ${approver.role}` });
  }

  const { id } = req.params;
  const existing = await prisma.expense.findUnique({ where: { id } });
  if (!existing) return res.status(404).json({ error: "Not found" });
  if (existing.status !== "PAID") {
    return res.status(400).json({ error: "Only PAID expenses can be approved" });
  }

  const updated = await prisma.expense.update({
    where: { id },
    data: {
      status: "APPROVED",
      approvedAt: new Date(),
      approvedById: approver.id,
    },
    include: {
      trip: {
        include: {
          truck: true,
          driverUser: true,
          order: { select: { id: true, orderNo: true, customerName: true, fromText: true, toText: true, status: true } },
        },
      },
      createdBy: { select: { id: true, name: true, email: true } },
      proofUploadedBy: { select: { id: true, name: true, email: true } },
      approvedBy: { select: { id: true, name: true, email: true } },
    },
  });

  res.json(updated);
});

// Delete expense
router.delete("/:id", authRequired, async (req, res) => {
  if (!ensureRole(req, res)) return;

  const { id } = req.params;
  const existing = await prisma.expense.findUnique({ where: { id } });
  if (!existing) return res.status(404).json({ error: "Pengeluaran tidak ditemukan" });
  if (existing.status !== "SUBMITTED") return res.status(400).json({ error: "Pengeluaran yang sudah dibayar tidak dapat dihapus" });
  await prisma.expense.delete({ where: { id } });
  res.json({ ok: true });
});

module.exports = router;
