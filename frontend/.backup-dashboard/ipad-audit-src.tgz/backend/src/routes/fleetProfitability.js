const express = require("express");
const { prisma } = require("../prisma");
const { authRequired } = require("../middleware/authRequired");
const { requireRole } = require("../middleware/requireRole");

const router = express.Router();
router.use(authRequired, requireRole("OWNER", "ADMIN", "STAFF"));

const COST_FIELDS = ["depreciation", "insurance", "taxPermit", "driverSalary", "lease", "overhead"];
const round = (value, digits = 1) => Number((Number(value) || 0).toFixed(digits));
const ratio = (value, total) => total > 0 ? round((value / total) * 100) : 0;

function period(value) {
  const normalized = String(Array.isArray(value) ? value[0] : value ?? "").trim();
  const match = /^(\d{4})-(\d{2})$/.exec(normalized);
  if (!match) throw new Error("Periode harus dalam format YYYY-MM");
  const year = Number(match[1]);
  const monthIndex = Number(match[2]) - 1;
  if (monthIndex < 0 || monthIndex > 11) throw new Error("Bulan tidak valid");
  const month = monthIndex + 1;
  const nextYear = month === 12 ? year + 1 : year;
  const nextMonth = month === 12 ? 1 : month + 1;
  const start = new Date(`${year}-${String(month).padStart(2, "0")}-01T00:00:00+07:00`);
  const end = new Date(`${nextYear}-${String(nextMonth).padStart(2, "0")}-01T00:00:00+07:00`);
  const days = new Date(Date.UTC(year, monthIndex + 1, 0)).getUTCDate();
  return { start, end, days };
}

function tripDate(trip) {
  return trip.completedAt;
}

function allocatedRevenue(trip) {
  const activeStatuses = ["SENT", "PARTIALLY_PAID", "PAID"];
  const singleRevenue = (trip.invoiceLines || []).reduce((sum, line) =>
    activeStatuses.includes(line.invoice?.status) ? sum + Number(line.amount || 0) : sum
  , 0);
  const materialRevenue = (trip.materialInvoices || []).reduce((sum, materialInvoice) => {
    if (!activeStatuses.includes(materialInvoice.billedInvoice?.status)) return sum;
    return sum + (materialInvoice.lines || []).reduce((lineSum, line) => lineSum + Number(line.totalAmount || 0), 0);
  }, 0);
  const supplementalRevenue = singleRevenue + materialRevenue;
  const invoice = trip.order?.invoices?.find(item => item.sourceType === "ORDER" && item.status !== "VOID");
  if (!invoice || !activeStatuses.includes(invoice.status)) return supplementalRevenue;
  const plannedQuantity = Math.max(0, Number(trip.qtyPlanned || 0));
  const deliveredQuantity = Math.max(0, Number(trip.qtyActual ?? trip.qtyPlanned ?? 0));
  const loss = Math.max(0, plannedQuantity - deliveredQuantity);
  const tolerance = Math.max(0, Number(invoice.tolerancePercent || 0));
  const billableQuantity = plannedQuantity > 0 && loss <= plannedQuantity * tolerance / 100 + 1e-9 ? plannedQuantity : deliveredQuantity;
  const unitMultiplier = String(trip.unitSnap || trip.order?.unit || "").toUpperCase() === "TON" ? 1000 : 1;
  if (Number(invoice.billableQuantity || 0) > 0) return supplementalRevenue + invoice.total * billableQuantity * unitMultiplier / Number(invoice.billableQuantity);
  const orderedQuantity = Math.max(0, Number(trip.order.qty || 0));
  if (orderedQuantity > 0) return supplementalRevenue + invoice.total * deliveredQuantity / orderedQuantity;

  // Legacy orders without an order quantity retain the previous proportional
  // allocation so their historical profitability does not disappear.
  const eligible = trip.order.trips.filter(item => item.status !== "CANCELLED");
  if (!eligible.length) return supplementalRevenue;
  const quantities = eligible.map(item => Math.max(0, Number(item.qtyActual ?? item.qtyPlanned ?? 0)));
  const totalQuantity = quantities.reduce((sum, value) => sum + value, 0);
  const index = eligible.findIndex(item => item.id === trip.id);
  if (index < 0) return supplementalRevenue;
  const orderRevenue = totalQuantity > 0 ? invoice.total * quantities[index] / totalQuantity : invoice.total / eligible.length;
  return supplementalRevenue + orderRevenue;
}

function revenueDocuments(trip) {
  const activeStatuses = ["SENT", "PARTIALLY_PAID", "PAID"];
  const documents = new Map();
  const add = invoice => {
    if (invoice?.id && activeStatuses.includes(invoice.status)) documents.set(invoice.id, invoice);
  };
  add(trip.order?.invoices?.find(invoice => invoice.sourceType === "ORDER" && invoice.status !== "VOID"));
  (trip.invoiceLines || []).forEach(line => add(line.invoice));
  (trip.materialInvoices || []).forEach(invoice => add(invoice.billedInvoice));
  return [...documents.values()];
}

function cargoLossValue(trip) {
  const invoice = trip.order?.invoices?.find(item => item.sourceType === "ORDER" && item.status !== "VOID");
  const orderedQuantity = Math.max(0, Number(trip.order?.qty || 0));
  if (!invoice || !["SENT", "PARTIALLY_PAID", "PAID"].includes(invoice.status) || orderedQuantity <= 0 || trip.qtyActual == null) return 0;
  const plannedQuantity = Math.max(0, Number(trip.qtyPlanned || 0));
  const deliveredQuantity = Math.max(0, Number(trip.qtyActual || 0));
  const loss = Math.max(0, plannedQuantity - deliveredQuantity);
  const multiplier = String(trip.unitSnap || trip.order?.unit || "").toUpperCase() === "TON" ? 1000 : 1;
  if (Number(invoice.ratePerKg || 0) > 0) return loss * multiplier * Number(invoice.ratePerKg);
  return invoice.total * loss / orderedQuantity;
}

router.get("/", async (req, res) => {
  try {
    const current = new Date();
    const month = req.query.month || `${current.getFullYear()}-${String(current.getMonth() + 1).padStart(2, "0")}`;
    const { start, end, days } = period(month);
    const dateRange = { gte: start, lt: end };
    const trucks = await prisma.truck.findMany({
      orderBy: { plateNumber: "asc" },
      include: {
        trips: {
          where: { status: "COMPLETED", completedAt: dateRange },
          include: {
            expenses: {
              where: { status: { in: ["PAID", "APPROVED"] }, expenseDate: dateRange, NOT: { notes: { startsWith: "AUTO_SUPPLIER_PAYMENT:" } } },
              orderBy: { expenseDate: "asc" },
            },
            order: { include: { invoices: true, trips: { select: { id: true, status: true, qtyActual: true, qtyPlanned: true } } } },
            invoiceLines: { include: { invoice: true } },
            materialInvoices: { include: { billedInvoice: true, lines: true } },
          },
        },
        manualInvoiceLines: {
          // Manual invoices may be created after the actual transport date.
          // Attribute each truck line to its recorded operational date instead
          // of moving all revenue into the invoice issue month.
          where: {
            invoice: { status: { in: ["SENT", "PARTIALLY_PAID", "PAID"] } },
            data: { path: ["date"], string_starts_with: month },
          },
          include: { invoice: { select: { number: true, status: true, issuedAt: true, customerName: true, sourceType: true, manualData: true } } },
          orderBy: { createdAt: "asc" },
        },
        manualRevenues: {
          where: { revenueDate: dateRange },
          include: { createdBy: { select: { id: true, name: true, email: true } } },
          orderBy: [{ revenueDate: "asc" }, { createdAt: "asc" }],
        },
        sparePartAssignments: { where: { installedAt: dateRange }, include: { stockUnit: { select: { purchasePrice: true, item: { select: { name: true, sku: true } } } } } },
        stockMovesTo: {
          where: {
            createdAt: dateRange,
            type: "OUT",
            stockUnitId: null,
            maintenanceId: null,
            fromLocationId: { not: null },
          },
          include: { item: { select: { name: true, sku: true, unit: true } }, fromLocation: { select: { name: true } } },
          orderBy: { createdAt: "asc" },
        },
        maintenances: {
          where: {
            movements: {
              some: {
                createdAt: dateRange,
                stockUnitId: null,
                OR: [{ type: "OUT" }, { type: "IN", note: { startsWith: "RETURN_OF:" } }, { type: "IN", note: { startsWith: "REPAIR_SECOND_OF:" } }],
              },
            },
          },
          select: {
            title: true,
            movements: {
              where: {
                createdAt: dateRange,
                stockUnitId: null,
                OR: [{ type: "OUT" }, { type: "IN", note: { startsWith: "RETURN_OF:" } }, { type: "IN", note: { startsWith: "REPAIR_SECOND_OF:" } }],
              },
              include: { item: { select: { name: true, sku: true, unit: true } } },
              orderBy: { createdAt: "asc" },
            },
          },
        },
        monthlyCosts: { where: { month: start } },
        expenses: {
          where: {
            status: { in: ["PAID", "APPROVED"] },
            expenseDate: dateRange,
            NOT: { notes: { startsWith: "AUTO_SUPPLIER_PAYMENT:" } },
          },
          orderBy: { expenseDate: "asc" },
        },
        expenseReturns: { where: { returnDate: dateRange }, orderBy: { returnDate: "asc" } },
      },
    });

    const rows = trucks.map(truck => {
      const operationalTrips = truck.trips.filter(item => item.status !== "CANCELLED");
      const completedTrips = operationalTrips.filter(item => item.status === "COMPLETED").length;
      const tripRevenue = Math.round(operationalTrips.reduce((sum, item) => sum + allocatedRevenue(item), 0));
      const manualInvoiceRevenue = truck.manualInvoiceLines.reduce((sum, item) => sum + Number(item.amount || 0), 0);
      const directManualRevenue = truck.manualRevenues.reduce((sum, item) => sum + Number(item.amount || 0), 0);
      const manualRevenue = manualInvoiceRevenue + directManualRevenue;
      const revenue = tripRevenue + manualRevenue;
      const cargoLoss = Math.round(operationalTrips.reduce((sum, item) => sum + cargoLossValue(item), 0));
      const tripExpenses = operationalTrips.reduce((sum, item) => sum + item.expenses.reduce((cost, expense) => cost + expense.amount, 0), 0);
      const expenseReturns = truck.expenseReturns.reduce((sum, item) => sum + item.amount, 0);
      const vehicleExpenses = truck.expenses.reduce((sum, expense) => sum + expense.amount, 0) - expenseReturns;
      const nonSerializedPartMovements = truck.maintenances.flatMap(maintenance =>
        maintenance.movements.map(movement => ({ ...movement, maintenanceTitle: maintenance.title }))
      );
      const serializedSpareParts = truck.sparePartAssignments.reduce((sum, item) => sum + (item.installCost ?? item.stockUnit.purchasePrice ?? 0), 0);
      const nonSerializedSpareParts = nonSerializedPartMovements.reduce((sum, movement) => {
        const cost = Number(movement.totalCost || 0);
        const isRepairCost = movement.type === "IN" && String(movement.note || "").startsWith("REPAIR_SECOND_OF:");
        return movement.type === "IN" && !isRepairCost ? sum - cost : sum + cost;
      }, 0);
      const directInventorySpareParts = truck.stockMovesTo.reduce((sum, movement) => sum + Number(movement.totalCost || 0), 0);
      const spareParts = serializedSpareParts + nonSerializedSpareParts + directInventorySpareParts;
      const fixedCosts = truck.monthlyCosts[0] || Object.fromEntries(COST_FIELDS.map(field => [field, 0]));
      const fixedTotal = COST_FIELDS.reduce((sum, field) => sum + (fixedCosts[field] || 0), 0);
      const totalCost = tripExpenses + vehicleExpenses + spareParts + fixedTotal;
      const profit = revenue - totalCost;
      const margin = revenue > 0 ? round((profit / revenue) * 100) : (totalCost > 0 ? -100 : 0);
      const activeDays = new Set(operationalTrips.map(item => tripDate(item)?.toISOString().slice(0, 10)).filter(Boolean)).size;
      const contributionPerTrip = operationalTrips.length ? (revenue - tripExpenses - spareParts) / operationalTrips.length : 0;
      const tripDetails = operationalTrips.map(item => {
        const tripRevenue = Math.round(allocatedRevenue(item));
        const expenseTotal = item.expenses.reduce((sum, expense) => sum + expense.amount, 0);
        const revenueInvoices = revenueDocuments(item);
        const invoiceTotal = revenueInvoices.reduce((sum, invoice) => sum + Number(invoice.total || 0), 0);
        const tripCargoLoss = Math.round(cargoLossValue(item));
        return {
          id: item.id,
          purpose: item.purpose,
          status: item.status,
          date: tripDate(item),
          fromText: item.fromText || item.order?.fromText,
          toText: item.toText || item.order?.toText,
          orderNo: item.order?.orderNo || null,
          customerName: item.order?.customerName || null,
          invoiceNumber: revenueInvoices.map(invoice => invoice.number).filter(Boolean).join(" + ") || null,
          invoiceTotal,
          allocatedRevenue: tripRevenue,
          allocationPercent: invoiceTotal > 0 ? round((tripRevenue / invoiceTotal) * 100) : 0,
          quantity: item.qtyActual ?? item.qtyPlanned ?? null,
          orderedQuantity: item.order?.qty ?? null,
          plannedQuantity: item.qtyPlanned ?? null,
          cargoLoss: tripCargoLoss,
          unit: item.unitSnap || item.order?.unit || null,
          expenseTotal,
          netContribution: tripRevenue - expenseTotal,
          expenses: item.expenses.map(expense => ({ id: expense.id, reason: expense.reason, amount: expense.amount, status: expense.status, expenseDate: expense.expenseDate })),
        };
      });
      for (const line of truck.manualInvoiceLines) {
        const data = line.data || {};
        tripDetails.push({
          id: `manual:${line.id}`,
          purpose: "MANUAL_INVOICE",
          status: "COMPLETED",
          date: data.date || line.invoice.issuedAt,
          fromText: line.invoice.manualData?.fromText || "Data historis",
          toText: line.invoice.manualData?.toText || "Tagihan langsung",
          orderNo: "Tagihan Tunggal",
          customerName: line.invoice.customerName,
          invoiceNumber: line.invoice.number,
          invoiceTotal: line.amount,
          allocatedRevenue: line.amount,
          allocationPercent: 100,
          quantity: line.quantity,
          plannedQuantity: null,
          cargoLoss: 0,
          unit: line.unit,
          expenseTotal: 0,
          netContribution: line.amount,
          historical: true,
          cargoName: data.cargoName || null,
          expenses: [],
        });
      }
      const sparePartDetails = truck.sparePartAssignments.map(item => ({
        id: item.id,
        name: item.stockUnit.item?.name || "Sparepart",
        sku: item.stockUnit.item?.sku || null,
        installedAt: item.installedAt,
        cost: item.installCost ?? item.stockUnit.purchasePrice ?? 0,
      }));
      sparePartDetails.push(...nonSerializedPartMovements.map(movement => ({
        id: `movement:${movement.id}`,
        name: movement.item?.name || "Sparepart",
        sku: movement.item?.sku || null,
        unit: movement.item?.unit || null,
        quantity: movement.qty,
        installedAt: movement.createdAt,
        cost: movement.type === "IN" && !String(movement.note || "").startsWith("REPAIR_SECOND_OF:") ? -Number(movement.totalCost || 0) : Number(movement.totalCost || 0),
        maintenanceTitle: movement.maintenanceTitle,
        isReturn: movement.type === "IN" && !String(movement.note || "").startsWith("REPAIR_SECOND_OF:"),
        isRepairCost: movement.type === "IN" && String(movement.note || "").startsWith("REPAIR_SECOND_OF:"),
      })));
      sparePartDetails.push(...truck.stockMovesTo.map(movement => ({
        id: `direct-movement:${movement.id}`,
        name: movement.item?.name || "Sparepart",
        sku: movement.item?.sku || null,
        unit: movement.item?.unit || null,
        quantity: movement.qty,
        installedAt: movement.createdAt,
        cost: Number(movement.totalCost || 0),
        maintenanceTitle: `Langsung dari ${movement.fromLocation?.name || "Inventory"}`,
        isDirectInventory: true,
      })));
      return {
        truck: { id: truck.id, plateNumber: truck.plateNumber, brand: truck.brand, model: truck.model, status: truck.status },
        trips: { total: operationalTrips.length, completed: completedTrips, cancelled: truck.trips.length - operationalTrips.length },
        revenue, tripRevenue, manualRevenue, manualInvoiceRevenue, directManualRevenue, cargoLoss, tripExpenses, vehicleExpenses, expenseReturns, spareParts, fixedCosts: Object.fromEntries(COST_FIELDS.map(field => [field, fixedCosts[field] || 0])),
        fixedTotal, totalCost, profit, margin,
        tripDetails, sparePartDetails,
        manualRevenueDetails: truck.manualRevenues.map(item => ({ id: item.id, revenueDate: item.revenueDate, amount: item.amount, description: item.description, notes: item.notes, createdAt: item.createdAt, createdBy: item.createdBy })),
        vehicleExpenseDetails: truck.expenses.map(expense => ({ id: expense.id, reason: expense.reason, amount: expense.amount, status: expense.status, expenseDate: expense.expenseDate })),
        costRatio: revenue > 0 ? ratio(totalCost, revenue) : (totalCost > 0 ? 100 : 0),
        completionRate: ratio(completedTrips, operationalTrips.length),
        utilizationRate: round(Math.min(100, (activeDays / days) * 100)), activeDays,
        breakEvenTrips: contributionPerTrip > 0 ? Math.ceil(fixedTotal / contributionPerTrip) : null,
        health: margin >= 20 ? "HEALTHY" : margin >= 0 ? "WATCH" : "LOSS",
      };
    });
    const summary = rows.reduce((result, row) => ({
      revenue: result.revenue + row.revenue, cargoLoss: result.cargoLoss + row.cargoLoss, totalCost: result.totalCost + row.totalCost,
      profit: result.profit + row.profit, trips: result.trips + row.trips.total,
    }), { revenue: 0, cargoLoss: 0, totalCost: 0, profit: 0, trips: 0 });
    summary.margin = summary.revenue > 0 ? round((summary.profit / summary.revenue) * 100) : 0;
    rows.forEach(row => { row.revenueContribution = ratio(row.revenue, summary.revenue); });
    res.json({ ok: true, month, summary, rows });
  } catch (error) {
    res.status(400).json({ error: error.message || "Gagal menghitung profit armada" });
  }
});

router.post("/manual-revenues", requireRole("OWNER", "ADMIN"), async (req, res) => {
  try {
    const truckId = String(req.body.truckId || "").trim();
    const description = String(req.body.description || "").trim();
    const notes = String(req.body.notes || "").trim() || null;
    const amount = Math.round(Number(req.body.amount));
    const rawDate = String(req.body.revenueDate || "").trim();
    if (!truckId) throw new Error("Mobil wajib dipilih");
    if (!description) throw new Error("Sumber atau keterangan pendapatan wajib diisi");
    if (!Number.isFinite(amount) || amount <= 0) throw new Error("Nominal pendapatan harus lebih besar dari 0");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(rawDate)) throw new Error("Tanggal pendapatan tidak valid");
    const revenueDate = new Date(`${rawDate}T12:00:00.000Z`);
    if (Number.isNaN(revenueDate.getTime())) throw new Error("Tanggal pendapatan tidak valid");
    const truck = await prisma.truck.findUnique({ where: { id: truckId }, select: { id: true } });
    if (!truck) throw new Error("Mobil tidak ditemukan");
    const revenue = await prisma.truckManualRevenue.create({ data: { truckId, revenueDate, amount, description, notes, createdById: req.user.id } });
    res.status(201).json({ ok: true, revenue });
  } catch (error) {
    res.status(400).json({ error: error.message || "Gagal menyimpan pendapatan manual" });
  }
});

router.delete("/manual-revenues/:id", requireRole("OWNER", "ADMIN"), async (req, res) => {
  try {
    const existing = await prisma.truckManualRevenue.findUnique({ where: { id: req.params.id }, select: { id: true } });
    if (!existing) return res.status(404).json({ error: "Pendapatan manual tidak ditemukan" });
    await prisma.truckManualRevenue.delete({ where: { id: req.params.id } });
    res.json({ ok: true });
  } catch (error) {
    res.status(400).json({ error: error.message || "Gagal menghapus pendapatan manual" });
  }
});

router.put("/fixed-costs", requireRole("OWNER", "ADMIN"), async (req, res) => {
  try {
    const { truckId, month, notes = null } = req.body;
    if (!truckId) throw new Error("Truk wajib dipilih");
    const { start } = period(month);
    const data = { notes: notes?.trim() || null };
    for (const field of COST_FIELDS) {
      const value = Math.round(Number(req.body[field] || 0));
      if (!Number.isFinite(value) || value < 0) throw new Error("Biaya tidak boleh negatif");
      data[field] = value;
    }
    const cost = await prisma.truckMonthlyCost.upsert({
      where: { truckId_month: { truckId, month: start } },
      create: { truckId, month: start, ...data }, update: data,
    });
    res.json({ ok: true, cost });
  } catch (error) {
    res.status(400).json({ error: error.message || "Gagal menyimpan biaya tetap" });
  }
});

module.exports = router;
