// backend/src/routes/dispatch.js
// Generates "Surat Pengantar Muat" PDF for a Trip using HTML -> PDF (Puppeteer)

const express = require("express");
const path = require("path");
const fs = require("fs");
const puppeteer = require("puppeteer");
const { prisma } = require("../prisma");
const { authRequired } = require("../middleware/authRequired");
const { nextDailyNumber } = require("../utils/documentNumber");

const router = express.Router();

function canWrite(user) {
  return ["OWNER", "ADMIN", "STAFF"].includes(user?.role);
}

// Format: SP-YYYY-DD/MM-0001, with a sequence that restarts each Jakarta day.
async function nextDispatchNo(tx) {
  return nextDailyNumber(tx, "dispatchLetter", "SP");
}

async function nextLoadDispatchNo(tx) {
  return nextDailyNumber(tx, "dispatchDocument", "SJ");
}

function fmtDateId(d) {
  if (!d) return "";
  const dt = new Date(d);
  if (Number.isNaN(dt.getTime())) return "";
  return dt.toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
}

function esc(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function buildHtmlTemplate(data) {
  const {
    companyName,
    companyAddress,
    companyPhone,
    dispatchNo,
    city,
    recipientName,
    cargoName,
    qtyText,
    driverName,
    plateNumber,
    loadDateText,
    destination,
  } = data;

  return `<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<style>
@page { size: A4; margin: 25mm 20mm; }
body { font-family: "Times New Roman", serif; font-size: 12pt; color: #000; }
.center { text-align: center; }
.header-title { font-weight: bold; font-size: 18pt; }
.header-sub { font-size: 11pt; margin-top: 4px; }
hr { border: none; border-top: 1.5px solid #000; margin: 10px 0 18px; }
.row { display: flex; justify-content: space-between; }
.mt-20 { margin-top: 20px; }
.sign {
  margin-top: 60px;
}

.sign-space {
  height: 90px;   /* 👈 controls signature space */
}

.label { width: 140px; display: inline-block; }
.dots { display: inline-block; border-bottom: 1px dotted #000; min-width: 250px; }
</style>
</head>
<body>
  <div class="center">
    <div class="header-title">${esc(companyName || "CV. MITRA SETIA")}</div>
    <div class="header-sub">
      ${esc(companyAddress || "")}<br/>
      ${esc(companyPhone || "")}
    </div>
  </div>

  <hr/>

  <div class="row">
    <div><b>No :</b> ${esc(dispatchNo)}</div>
    <div>${esc(city || "")},</div>
  </div>

  <div class="mt-20">
    <div><b>Kepada Yth.</b></div>
    <div class="dots">${esc(recipientName || "")}</div>
  </div>

  <div class="mt-20">
    Dengan Hormat,<br/><br/>
    Melalui surat ini, agar dapat dimuat
    <span class="dots">${esc(cargoName || "")}</span>
    unit mobil sbb :
  </div>

  <div class="mt-20">
    <div><span class="label">Nama Supir</span>: ${esc(driverName || "")}</div>
    <div><span class="label">No. Polisi</span>: ${esc(plateNumber || "")}</div>
    <div><span class="label">Tanggal Muat</span>: ${esc(loadDateText || "")}</div>
    <div><span class="label">Jumlah Muatan</span>: ${esc(qtyText || "")}</div>
    <div><span class="label">Tujuan</span>: ${esc(destination || "")}</div>
  </div>

  <div class="mt-20">
    Demikian surat pengantar muat ini kami buat, atas dan perhatian dan kerjasamanya
    kami ucapkan terima kasih.
  </div>

  <div class="sign">
    Hormat Kami,
    <div class="sign-space"></div>
    <b>( ${companyName || "CV. MITRA SETIA"} )</b>
  </div>

</body>
</html>`;
}

function getBackendOrigin(req) {
  // Prefer env if you deploy later
  if (process.env.BACKEND_URL) return process.env.BACKEND_URL.replace(/\/$/, "");

  // Fallback: derive from request
  const proto =
    (req.headers["x-forwarded-proto"] ? String(req.headers["x-forwarded-proto"]).split(",")[0].trim() : null) ||
    req.protocol;

  const host =
    (req.headers["x-forwarded-host"] ? String(req.headers["x-forwarded-host"]).split(",")[0].trim() : null) ||
    req.get("host");

  return `${proto}://${host}`;
}

/**
 * POST /dispatch/trips/:tripId
 */
router.post("/trips/:tripId", authRequired, async (req, res) => {
  try {
    if (!canWrite(req.user)) return res.status(403).json({ error: "Forbidden" });

    const tripId = req.params.tripId;
    const body = req.body || {};

    // Ensure output folder exists
    const outDir = path.join(process.cwd(), "public", "dispatch");
    fs.mkdirSync(outDir, { recursive: true });

    const backendOrigin = getBackendOrigin(req);

    // Do not keep an interactive database transaction open while Chromium
    // starts and renders the PDF. On production this can exceed Prisma's
    // transaction timeout even though the PDF itself is generated correctly.
    const trip = await prisma.trip.findUnique({
        where: { id: tripId },
        include: { truck: true, driverUser: true, order: true, dispatchLetter: true, materialInvoices: { include: { lines: true, destinationLocation: true }, orderBy: [{ stopSequence: "asc" }, { createdAt: "asc" }] }, orderAllocations: { include: { order: { include: { customer: true, destinationLocation: true } } }, orderBy: [{ stopSequence: "asc" }, { createdAt: "asc" }] } },
    });
    if (!trip) return res.status(404).json({ error: "Trip tidak ditemukan" });

      const order = trip.order;

      const allocations = trip.orderAllocations || [];
      const materialInvoices = trip.materialInvoices || [];
      const recipientName = allocations.length
        ? [...new Set(allocations.map((item) => item.order.customer?.name || item.order.customerName).filter(Boolean))].join(" / ")
        : materialInvoices.length
          ? [...new Set(materialInvoices.map((item) => item.billingCustomerName).filter(Boolean))].join(" / ")
          : trip.billingCustomerName || order?.customerName || "";
      const materialLines = materialInvoices.flatMap((item) => item.lines?.length
        ? item.lines
        : [{ itemName: item.materialName, qty: item.qty, unit: item.unit }]);
      const cargoName = allocations.length
        ? allocations.map((item) => `${item.order.cargoName || "Muatan"} (${item.order.orderNo} · DO ${item.order.deliveryOrderNo || "-"})`).join("; ")
        : materialInvoices.length
          ? [...new Set(materialLines.map((line) => line.itemName).filter(Boolean))].join("; ")
          : trip.cargoNameSnap || order?.cargoName || "";
      const qtyText = allocations.length
        ? allocations.map((item) => item.sackCount && item.kgPerSack
          ? `${Number(item.sackCount)} sak × ${Number(item.kgPerSack)} kg = ${Number(item.plannedWeightKg || 0)} kg`
          : `${Number(item.qtyPlanned || 0)} ${item.unitSnap || ""}`.trim()).join("; ")
        : materialInvoices.length
          ? materialLines.map((line) => `${line.itemName}: ${Number(line.qty || 0)} ${line.unit || ""}`.trim()).join("; ")
          : (trip.qtyPlanned != null ? `${Number(trip.qtyPlanned)} ${trip.unitSnap || order?.unit || ""}`.trim() : "");

      const driverName = trip.driverNameSnap || trip.driverUser?.name || "";
      const plateNumber = trip.plateNumberSnap || trip.truck?.plateNumber || "";
      const destination = allocations.length
        ? allocations.map((item) => `${item.stopSequence}. ${item.order.destinationLocation?.name || item.order.toText || "Tujuan"}`).join("; ")
        : materialInvoices.length
          ? materialInvoices.map((item, index) => `${item.stopSequence || index + 1}. ${item.destinationLocation?.name || trip.toText || "Tujuan"}`).join("; ")
          : trip.toText || order?.toText || "";

      const issuedAt = new Date();
      const dispatchNo = trip.dispatchLetter?.number || (await prisma.$transaction((tx) => nextDispatchNo(tx)));

      const loadDateText =
        body.loadDateText ||
        fmtDateId(trip.dispatchedAt || trip.plannedDepartAt || issuedAt);

      const html = buildHtmlTemplate({
        companyName: body.companyName || "CV. Mitra Setia",
        companyAddress: body.companyAddress || "",
        companyPhone: body.companyPhone || "",
        city: body.city || "",
        dispatchNo,
        recipientName,
        cargoName,
        qtyText,
        driverName,
        plateNumber,
        loadDateText,
        destination,
      });

      // Generate PDF
      const fileName = `${dispatchNo}.pdf`.replace(/[^\w\-\.]/g, "_");
      const filePath = path.join(outDir, fileName);

      const browser = await puppeteer.launch({
        headless: "new",
        args: ["--no-sandbox", "--disable-setuid-sandbox"],
      });

      try {
        const page = await browser.newPage();
        await page.setContent(html, { waitUntil: "networkidle0" });
        await page.pdf({
          path: filePath,
          format: "A4",
          printBackground: true,
          margin: { top: "18mm", right: "16mm", bottom: "18mm", left: "16mm" },
        });
      } finally {
        await browser.close();
      }

      // ✅ IMPORTANT: ABSOLUTE URL so frontend opens backend, not React
      // A changing query string prevents Safari/Chrome from reopening the old
      // PDF after a letter is regenerated with additional cargo.
      const pdfUrl = `${backendOrigin}/dispatch/${fileName}?v=${issuedAt.getTime()}`;

      const saved = await prisma.dispatchLetter.upsert({
        where: { tripId: trip.id },
        create: {
          tripId: trip.id,
          number: dispatchNo,
          city: body.city || null,
          issuedAt,
          pdfUrl,
          recipientName: recipientName || null,
          cargoName: cargoName || null,
          driverName: driverName || null,
          plateNumber: plateNumber || null,
          loadDateText: loadDateText || null,
          destination: destination || null,
        },
        update: {
          city: body.city || null,
          issuedAt,
          pdfUrl,
          recipientName: recipientName || null,
          cargoName: cargoName || null,
          driverName: driverName || null,
          plateNumber: plateNumber || null,
          loadDateText: loadDateText || null,
          destination: destination || null,
        },
      });

      const orderSources = allocations
        .filter((item) => item.plannedWeightKg != null || item.sackCount != null || item.order.cargoCategory !== "MATERIAL")
        .map((item) => ({
          sourceType: "ORDER_ALLOCATION",
          sourceId: item.id,
          recipientName: item.order.customer?.name || item.order.customerName || "",
          cargoName: `${item.order.cargoName || "Muatan"} (${item.order.orderNo} · DO ${item.order.deliveryOrderNo || "-"})`,
          qtyText: item.sackCount && item.kgPerSack
            ? `${Number(item.sackCount)} sak × ${Number(item.kgPerSack)} kg = ${Number(item.plannedWeightKg || 0)} kg`
            : `${Number(item.qtyPlanned || 0)} ${item.unitSnap || ""}`.trim(),
          destination: item.order.destinationLocation?.name || item.order.toText || "Tujuan",
        }));
      const materialSources = materialInvoices.map((item) => {
        const lines = item.lines?.length ? item.lines : [{ itemName: item.materialName, qty: item.qty, unit: item.unit }];
        return {
          sourceType: "MATERIAL_INVOICE",
          sourceId: item.id,
          recipientName: item.billingCustomerName || "",
          cargoName: lines.map((line) => line.itemName).filter(Boolean).join("; ") || item.materialName || "Material",
          qtyText: lines.map((line) => `${line.itemName}: ${Number(line.qty || 0)} ${line.unit || ""}`.trim()).join("; "),
          destination: item.destinationLocation?.name || trip.toText || "Tujuan",
        };
      });
      const documentSources = [...orderSources, ...materialSources];
      if (!documentSources.length) documentSources.push({ sourceType: "TRIP", sourceId: trip.id, recipientName, cargoName, qtyText, destination });

      const documents = [];
      const documentBrowser = await puppeteer.launch({ headless: "new", args: ["--no-sandbox", "--disable-setuid-sandbox"] });
      try {
        for (const source of documentSources) {
          const existing = await prisma.dispatchDocument.findUnique({ where: { sourceType_sourceId: { sourceType: source.sourceType, sourceId: source.sourceId } } });
          const number = existing?.number || await prisma.$transaction((tx) => nextLoadDispatchNo(tx));
          const sourceHtml = buildHtmlTemplate({
            companyName: body.companyName || "CV. Mitra Setia",
            companyAddress: body.companyAddress || "",
            companyPhone: body.companyPhone || "",
            city: body.city || "",
            dispatchNo: number,
            recipientName: source.recipientName,
            cargoName: source.cargoName,
            qtyText: source.qtyText,
            driverName,
            plateNumber,
            loadDateText,
            destination: source.destination,
          });
          const sourceFileName = `${number}.pdf`.replace(/[^\w\-\.]/g, "_");
          const page = await documentBrowser.newPage();
          try {
            await page.setContent(sourceHtml, { waitUntil: "networkidle0" });
            await page.pdf({ path: path.join(outDir, sourceFileName), format: "A4", printBackground: true, margin: { top: "18mm", right: "16mm", bottom: "18mm", left: "16mm" } });
          } finally {
            await page.close();
          }
          const sourcePdfUrl = `${backendOrigin}/dispatch/${sourceFileName}?v=${issuedAt.getTime()}`;
          documents.push(await prisma.dispatchDocument.upsert({
            where: { sourceType_sourceId: { sourceType: source.sourceType, sourceId: source.sourceId } },
            create: { tripId: trip.id, sourceType: source.sourceType, sourceId: source.sourceId, number, city: body.city || null, issuedAt, pdfUrl: sourcePdfUrl, recipientName: source.recipientName || null, cargoName: source.cargoName || null, driverName: driverName || null, plateNumber: plateNumber || null, loadDateText: loadDateText || null, destination: source.destination || null },
            update: { city: body.city || null, issuedAt, pdfUrl: sourcePdfUrl, recipientName: source.recipientName || null, cargoName: source.cargoName || null, driverName: driverName || null, plateNumber: plateNumber || null, loadDateText: loadDateText || null, destination: source.destination || null },
          }));
        }
      } finally {
        await documentBrowser.close();
      }

    res.json({ legacy: saved, documents });
  } catch (e) {
    console.error(e);
    res.status(400).json({ error: e.message || "Failed to generate dispatch letter" });
  }
});

module.exports = router;
