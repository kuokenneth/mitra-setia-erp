const express = require("express");
const { prisma } = require("../prisma");
const { authRequired } = require("../middleware/authRequired");
const { requireRole } = require("../middleware/requireRole");
const { SYSTEM_ACCOUNTS, cashCode, postJournal } = require("../services/accounting");
const { esc, num: fmtNum, money, date: fmtDate, documentHtml } = require("../utils/printDocument");
const { notifyOwnerSafely } = require("../services/emailNotifications");
const { nextDailyNumber } = require("../utils/documentNumber");
const router = express.Router();
const PERSAUDARAAN_RETREAD_PRICE = 900000;
const isPersaudaraan = supplier => String(supplier?.name || "").trim().toLocaleUpperCase("id-ID") === "PERSAUDARAAN";

async function backfillLegacyConsumptionAllocations(tx, batch) {
  const consumedQty = Math.max(0, Number(batch.receivedQty || 0) - Number(batch.remainingQty || 0));
  const existing = await tx.stockMovementBatchAllocation.aggregate({
    where: { batchId: batch.id },
    _sum: { qty: true },
  });
  let qtyToLink = consumedQty - Number(existing._sum.qty || 0);
  if (qtyToLink <= 0.000001 || batch.unitPrice == null) return;

  const candidates = await tx.stockMovement.findMany({
    where: {
      type: "OUT",
      itemId: batch.itemId,
      fromLocationId: batch.locationId,
      stockUnitId: null,
      maintenanceId: { not: null },
      createdAt: { gte: batch.receivedAt },
      unitPrice: batch.unitPrice,
    },
    include: { batchAllocations: { select: { batchId: true, qty: true } } },
    orderBy: { createdAt: "asc" },
  });
  for (const movement of candidates) {
    if (qtyToLink <= 0.000001) break;
    if (movement.batchAllocations.some(allocation => allocation.batchId === batch.id)) continue;
    const alreadyLinked = movement.batchAllocations.reduce((sum, allocation) => sum + Number(allocation.qty), 0);
    const availableQty = Math.max(0, Number(movement.qty) - alreadyLinked);
    const linkedQty = Math.min(availableQty, qtyToLink);
    if (linkedQty <= 0.000001) continue;
    await tx.stockMovementBatchAllocation.create({ data: { movementId: movement.id, batchId: batch.id, qty: linkedQty } });
    qtyToLink -= linkedQty;
  }
}

async function refreshAllocatedMovementCosts(tx, batchId) {
  const allocations = await tx.stockMovementBatchAllocation.findMany({
    where: { batchId },
    select: { movementId: true },
    distinct: ["movementId"],
  });
  for (const { movementId } of allocations) {
    const movement = await tx.stockMovement.findUnique({
      where: { id: movementId },
      include: { batchAllocations: { include: { batch: { select: { unitPrice: true } } } } },
    });
    if (!movement) continue;
    const allocatedQty = movement.batchAllocations.reduce((sum, allocation) => sum + Number(allocation.qty), 0);
    if (allocatedQty + 0.000001 < Number(movement.qty)) continue;
    const fullyPriced = movement.batchAllocations.every(allocation => allocation.batch.unitPrice != null);
    const totalCost = fullyPriced
      ? Math.round(movement.batchAllocations.reduce((sum, allocation) => sum + Number(allocation.qty) * Number(allocation.batch.unitPrice), 0))
      : null;
    const unitPrice = totalCost == null || Number(movement.qty) <= 0 ? null : Math.round(totalCost / Number(movement.qty));
    await tx.stockMovement.update({ where: { id: movement.id }, data: { totalCost, unitPrice } });

    const returns = await tx.stockMovement.findMany({
      where: { type: "IN", note: { startsWith: `RETURN_OF:${movement.id}` } },
      select: { id: true, qty: true },
    });
    for (const returned of returns) {
      await tx.stockMovement.update({
        where: { id: returned.id },
        data: { unitPrice, totalCost: unitPrice == null ? null : Math.round(Number(returned.qty) * unitPrice) },
      });
    }
  }
}

const includePO = { supplier: true, request: { include: { maintenance: { include: { truck: true } } } }, requestLinks: { include: { request: { include: { maintenance: { include: { truck: true } } } } } }, cancelledBy: { select: { id: true, name: true, email: true } }, items: { include: { item: true, tireRetread: { include: { stockUnit: true, fromItem: true, toItem: true } }, partRepair: { include: { stockUnit: true } } } }, receipts: { include: { items: { include: { purchaseOrderItem: { include: { item: true } }, supplierBillItems: { include: { bill: true } } } }, location: true, createdBy: { select: { name: true } }, supplierBillLines: { include: { bill: true } } } }, payments: { include: { createdBy: { select: { name: true } }, approvedBy: { select: { name: true } } } } };

async function syncSupplierPaymentExpense(tx, paymentId, approvedById) {
  const marker = `AUTO_SUPPLIER_PAYMENT:${paymentId}`;
  const existing = await tx.expense.findFirst({ where: { notes: marker } });
  if (existing) return existing;
  const payment = await tx.purchasePayment.findUnique({
    where: { id: paymentId },
    include: {
      supplierBill: {
        include: {
          supplier: true,
          receipts: { include: { receipt: { include: { purchaseOrder: { include: { request: { include: { maintenance: true } } } } } } } },
          repairItems: { include: { movement: { select: { maintenance: { select: { truckId: true } } } } } },
        },
      },
    },
  });
  if (!payment || payment.status !== "PAID" || !payment.supplierBill) return null;
  const truckIds = [...new Set(payment.supplierBill.receipts.map(row => {
    const request = row.receipt?.purchaseOrder?.request;
    return request?.maintenance?.truckId || (request?.purpose === "TRUCK" ? request.truckId : null);
  }).concat(payment.supplierBill.repairItems.map(row => row.movement?.maintenance?.truckId)).filter(Boolean))];
  const bill = payment.supplierBill;
  return tx.expense.create({
    data: {
      status: "APPROVED",
      paymentMethod: ["BANK_TRANSFER", "CASH", "OTHER"].includes(payment.method) ? payment.method : "OTHER",
      amount: payment.amount,
      currency: "IDR",
      category: "SPAREPART",
      reason: `Pembayaran sparepart ${bill.supplier?.name || "supplier"} · ${bill.invoiceNumber}`,
      clientName: bill.supplier?.name || null,
      notes: marker,
      truckId: truckIds.length === 1 ? truckIds[0] : null,
      proofUrl: payment.proofUrl,
      proofFileName: payment.proofFileName,
      proofMimeType: payment.proofMimeType,
      proofSize: payment.proofSize,
      paidAt: payment.paidAt || payment.approvedAt || new Date(),
      proofUploadedById: payment.createdById,
      createdById: payment.createdById,
      approvedById: approvedById || payment.approvedById,
      approvedAt: payment.approvedAt || new Date(),
      expenseDate: payment.paidAt || payment.approvedAt || new Date(),
    },
  });
}

router.use(authRequired, requireRole("OWNER", "ADMIN", "STAFF", "SPAREPART_ADMIN"));
router.get("/overview", async (_req, res) => {
  const [requests, orders, suppliers, locations, items, retreadingUnits, repairingUnits, bills, trucks, nonSerializedRepairs, nonSerializedRepairReceipts, directRetreadReceipts] = await Promise.all([
    prisma.purchaseRequest.findMany({ include: { maintenance: { include: { truck: true } }, damageProofs: true, items: { include: { item: true, tireRetread: { include: { stockUnit: true, fromItem: true, toItem: true } }, partRepair: { include: { stockUnit: true } } } }, createdBy: { select: { name: true } }, approvedBy: { select: { name: true } } }, orderBy: { createdAt: "desc" } }),
    prisma.purchaseOrder.findMany({ include: includePO, orderBy: { createdAt: "desc" } }),
    prisma.supplier.findMany({ orderBy: { name: "asc" } }), prisma.inventoryLocation.findMany({ orderBy: { name: "asc" } }), prisma.item.findMany({ orderBy: { name: "asc" } }),
    prisma.stockUnit.findMany({
      where: { status: "RETREADING", tireRetreads: { some: { status: "SENT" } } },
      include: {
        item: true,
        tireRetreads: {
          where: { status: "SENT" },
          include: { toItem: true, supplier: true },
          orderBy: { sentAt: "desc" },
          take: 1,
        },
      },
      orderBy: { updatedAt: "asc" },
    }),
    prisma.stockUnit.findMany({
      where: { status: "REPAIRING", partRepairs: { some: { status: "SENT", purchaseRequestItems: { none: { request: { status: { notIn: ["REJECTED", "CANCELLED"] } } } } } } },
      include: { item: true, partRepairs: { where: { status: "SENT", purchaseRequestItems: { none: { request: { status: { notIn: ["REJECTED", "CANCELLED"] } } } } }, include: { supplier: true, maintenance: { include: { truck: true } } }, orderBy: { sentAt: "desc" }, take: 1 } },
      orderBy: { updatedAt: "asc" },
    }),
    prisma.supplierBill.findMany({
      include: {
        supplier: true,
        receipts: { include: { receipt: { include: { purchaseOrder: true } } } },
        items: { include: { receiptItem: { include: { purchaseOrderItem: { include: { item: true } }, receipt: true } } } },
        repairItems: { include: { movement: { include: { item: true, maintenance: { include: { truck: true } } } } } },
        attachments: true,
        payments: { include: { createdBy: { select: { name: true } }, approvedBy: { select: { name: true } } } },
      },
      orderBy: { invoiceDate: "desc" },
    }),
    prisma.truck.findMany({ orderBy: { plateNumber: "asc" }, select: { id: true, plateNumber: true, brand: true, model: true } }),
    prisma.stockMovement.findMany({
      where: { type: "ADJUST", stockUnitId: null, note: { startsWith: "NON_SERIAL_REPAIR_OF:" } },
      include: { item: true, maintenance: { include: { truck: true } }, fromTruck: true, toLocation: true, createdBy: { select: { name: true } } },
      orderBy: { createdAt: "desc" },
    }),
    prisma.stockMovement.findMany({
      where: { type: "IN", stockUnitId: null, note: { startsWith: "REPAIR_SECOND_OF:" } },
      select: { id: true, qty: true, unitPrice: true, totalCost: true, note: true, createdAt: true, item: true, toLocation: true, createdBy: { select: { name: true } }, supplierBillRepairItem: { include: { bill: true } } },
      orderBy: { createdAt: "desc" },
    }),
    prisma.stockMovement.findMany({
      where: { type: "IN", stockUnitId: { not: null }, note: { startsWith: "Ban selesai dimasak" } },
      include: {
        item: true,
        toLocation: true,
        createdBy: { select: { name: true } },
        supplierBillRepairItem: { include: { bill: true } },
        stockUnit: {
          select: {
            serialNumber: true,
            tireRetreads: {
              where: { status: "COMPLETED", purchaseOrderItems: { none: {} } },
              select: { supplierId: true, supplier: true, completedAt: true },
              orderBy: { completedAt: "desc" },
              take: 1,
            },
          },
        },
      },
      orderBy: { createdAt: "desc" },
    }),
  ]);
  const repairReceiptsByMovement = nonSerializedRepairReceipts.reduce((map, receipt) => {
    const movementId = String(receipt.note || "").match(/^REPAIR_SECOND_OF:([^ ·]+)/)?.[1];
    if (!movementId) return map;
    const rows = map.get(movementId) || [];
    rows.push(receipt);
    map.set(movementId, rows);
    return map;
  }, new Map());
  const suppliersById = new Map(suppliers.map(supplier => [supplier.id, supplier]));
  const nonSerializedRepairQueue = nonSerializedRepairs.map((repair) => {
    const receipts = repairReceiptsByMovement.get(repair.id) || [];
    const receivedQty = receipts.reduce((sum, receipt) => sum + Number(receipt.qty || 0), 0);
    const encodedVendor = String(repair.note || "").match(/REPAIR_VENDOR:([^ ·]+)/)?.[1];
    let repairVendor = "Belum ditentukan";
    try { if (encodedVendor) repairVendor = decodeURIComponent(encodedVendor); } catch { repairVendor = encodedVendor || repairVendor; }
    const repairSupplierId = String(repair.note || "").match(/REPAIR_SUPPLIER_ID:([^ ·]+)/)?.[1] || null;
    const repairSupplier = repairSupplierId ? suppliersById.get(repairSupplierId) || null : null;
    return { ...repair, repairSupplierId, repairSupplier, repairVendor: repairSupplier?.name || repairVendor, receipts, receivedQty, remainingQty: Math.max(0, Number(repair.qty) - receivedQty), status: receivedQty >= Number(repair.qty) ? "COMPLETED" : receivedQty > 0 ? "PARTIALLY_RECEIVED" : "SENT" };
  });
  const repairBillCandidates = nonSerializedRepairQueue.flatMap(repair => repair.receipts.map(receipt => ({
    ...receipt,
    repairSourceId: repair.id,
    repairSupplierId: repair.repairSupplierId,
    repairSupplier: repair.repairSupplier,
    repairVendor: repair.repairVendor,
    maintenance: repair.maintenance,
  }))).filter(receipt => receipt.repairSupplierId);
  const directRetreadReceiptRows = directRetreadReceipts.map(receipt => {
    const retread = receipt.stockUnit?.tireRetreads?.[0];
    return {
      ...receipt,
      repairSupplierId: retread?.supplierId || null,
      repairSupplier: retread?.supplier || null,
      repairVendor: retread?.supplier?.name || "Vendor masak ban",
      retreadSerialNumber: receipt.stockUnit?.serialNumber || null,
      isDirectRetread: true,
    };
  }).filter(receipt => receipt.repairSupplierId);
  res.json({ ok: true, requests, orders, suppliers, locations, items, retreadingUnits, repairingUnits, bills, trucks, nonSerializedRepairQueue, directRetreadReceipts: directRetreadReceiptRows, repairBillCandidates });
});

async function receiveNonSerializedRepair(tx, { movementId, qty, unitPrice, locationId, notes, userId }) {
  const repair = await tx.stockMovement.findFirst({ where: { id: movementId, type: "ADJUST", stockUnitId: null, note: { startsWith: "NON_SERIAL_REPAIR_OF:" } }, include: { item: true, maintenance: true } });
  if (!repair) throw new Error("Data perbaikan non-serial tidak ditemukan");
  const priorReceipts = await tx.stockMovement.aggregate({ where: { type: "IN", stockUnitId: null, note: { startsWith: `REPAIR_SECOND_OF:${repair.id}` } }, _sum: { qty: true } });
  const remainingQty = Number(repair.qty) - Number(priorReceipts._sum.qty || 0);
  if (qty > remainingQty + 0.000001) throw new Error(`Maksimal penerimaan ${repair.item.name}: ${remainingQty} ${repair.item.unit}`);
  const totalCost = Math.round(qty * unitPrice);
  const isManualRepairItem = String(repair.note || "").includes("MANUAL_REPAIR_ITEM:TRUE");
  if (isManualRepairItem) {
    return tx.stockMovement.create({
      data: {
        type: "IN", itemId: repair.itemId, qty, unitPrice, totalCost,
        note: `REPAIR_SECOND_OF:${repair.id} · MANUAL_REPAIR_COMPLETED · Pekerjaan ${repair.item.name} selesai${notes ? ` · ${notes}` : ""}`,
        createdById: userId, toLocationId: locationId, maintenanceId: repair.maintenanceId,
      },
    });
  }
  const secondSku = repair.item.sku.endsWith("_SECOND") ? repair.item.sku : `${repair.item.sku}_SECOND`;
  let secondItem = await tx.item.findUnique({ where: { sku: secondSku } });
  if (!secondItem) secondItem = await tx.item.create({ data: { sku: secondSku, name: `${repair.item.name} (SECOND)`, unit: repair.item.unit, isSerialized: false, category: repair.item.category } });
  if (secondItem.isSerialized) throw new Error(`Item ${secondSku} harus berupa barang non-serial`);
  await tx.inventoryStock.upsert({ where: { itemId_locationId: { itemId: secondItem.id, locationId } }, create: { itemId: secondItem.id, locationId, qty }, update: { qty: { increment: qty } } });
  await tx.inventoryBatch.create({ data: { itemId: secondItem.id, locationId, receivedQty: qty, remainingQty: qty, unitPrice, receivedAt: new Date() } });
  return tx.stockMovement.create({ data: { type: "IN", itemId: secondItem.id, qty, unitPrice, totalCost, note: `REPAIR_SECOND_OF:${repair.id} · Hasil perbaikan ${repair.item.sku} menjadi ${secondSku}${notes ? ` · ${notes}` : ""}`, createdById: userId, toLocationId: locationId, maintenanceId: repair.maintenanceId } });
}

router.post("/repairs/non-serialized/receive-batch", async (req, res) => {
  try {
    const items = Array.isArray(req.body?.items) ? req.body.items : [];
    const locationId = String(req.body?.locationId || "");
    const notes = String(req.body?.notes || "").trim();
    if (!items.length) throw new Error("Pilih minimal satu hasil perbaikan");
    if (!locationId) throw new Error("Lokasi penerimaan wajib dipilih");
    const prepared = items.map((row) => ({ movementId: String(row.movementId || ""), qty: Number(row.qty), unitPrice: Math.round(Number(row.unitPrice)) }));
    if (prepared.some(row => !row.movementId || !Number.isFinite(row.qty) || row.qty <= 0 || !Number.isFinite(row.unitPrice) || row.unitPrice <= 0)) throw new Error("Jumlah dan harga perbaikan setiap barang wajib diisi");
    const receipts = await prisma.$transaction(async tx => {
      const location = await tx.inventoryLocation.findUnique({ where: { id: locationId }, select: { id: true } });
      if (!location) throw new Error("Lokasi Inventory tidak ditemukan");
      const repairs = await tx.stockMovement.findMany({ where: { id: { in: prepared.map(row => row.movementId) } }, select: { id: true, note: true } });
      if (repairs.length !== prepared.length) throw new Error("Sebagian data perbaikan tidak ditemukan");
      const vendors = new Set(repairs.map(repair => String(repair.note || "").match(/REPAIR_SUPPLIER_ID:([^ ·]+)/)?.[1] || String(repair.note || "").match(/REPAIR_VENDOR:([^ ·]+)/)?.[1] || "LEGACY"));
      if (vendors.size !== 1) throw new Error("Checklist hanya boleh berisi barang dari tempat perbaikan yang sama");
      const created = [];
      for (const row of prepared) created.push(await receiveNonSerializedRepair(tx, { ...row, locationId, notes, userId: req.user.id }));
      return created;
    }, { timeout: 30000 });
    res.status(201).json({ ok: true, receipts });
  } catch (error) { res.status(400).json({ error: error.message || "Gagal menerima hasil perbaikan gabungan" }); }
});

router.post("/repairs/non-serialized/:movementId/receive", async (req, res) => {
  try {
    const movementId = String(req.params.movementId || "");
    const qty = Number(req.body?.qty);
    const unitPrice = Math.round(Number(req.body?.unitPrice));
    const locationId = String(req.body?.locationId || "");
    const notes = String(req.body?.notes || "").trim();
    if (!movementId || !Number.isFinite(qty) || qty <= 0) return res.status(400).json({ error: "Jumlah penerimaan wajib lebih dari 0" });
    if (!Number.isFinite(unitPrice) || unitPrice <= 0) return res.status(400).json({ error: "Harga perbaikan per unit wajib lebih dari Rp0" });
    if (!locationId) return res.status(400).json({ error: "Lokasi penerimaan wajib dipilih" });

    const receipt = await prisma.$transaction(async (tx) => {
      const location = await tx.inventoryLocation.findUnique({ where: { id: locationId }, select: { id: true } });
      if (!location) throw new Error("Lokasi Inventory tidak ditemukan");
      return receiveNonSerializedRepair(tx, { movementId, qty, unitPrice, locationId, notes, userId: req.user.id });
    });
    res.status(201).json({ ok: true, receipt });
  } catch (error) {
    res.status(400).json({ error: error.message || "Gagal menerima hasil perbaikan" });
  }
});
router.get("/orders/:id/print", async (req, res) => {
  const po = await prisma.purchaseOrder.findUnique({ where: { id: req.params.id }, include: includePO });
  if (!po) return res.status(404).json({ error: "Purchase Order tidak ditemukan" });
  const subtotal = po.items.reduce((sum, item) => sum + Number(item.qty) * Number(item.unitPrice), 0);
  const total = subtotal + Number(po.tax) + Number(po.shippingCost) - Number(po.discount);
  const rows = po.items.map((item, index) => `<tr><td class="center">${index + 1}</td><td>${esc(item.item.sku)}</td><td>${esc(item.item.name)}</td><td class="right">${fmtNum(item.qty)}</td><td>${esc(item.item.unit)}</td><td class="right">${money(item.unitPrice)}</td><td class="right">${money(Number(item.qty) * Number(item.unitPrice))}</td></tr>`).join("");
  res.type("html").send(documentHtml({
    title: "PURCHASE ORDER",
    subtitle: po.number,
    meta: `Status: ${esc(po.status)}<br>Tanggal: ${fmtDate(po.createdAt)}${po.status === "CANCELLED" ? `<br>Dibatalkan: ${fmtDate(po.cancelledAt, true)}<br>Alasan: ${esc(po.cancellationReason || "-")}` : ""}`,
    body: `<div class="summary"><div class="box">Supplier<b>${esc(po.supplier.name)}</b><span>${esc(po.supplier.address || "-")}</span></div><div class="box">Pengiriman<b>${esc(po.deliveryAddress || "-")}</b><span>Estimasi: ${fmtDate(po.estimatedArrival)}</span></div><div class="box">Termin<b>${esc(po.paymentTerms || "-")}</b><span>PR: ${esc((po.requestLinks?.length ? po.requestLinks.map(link => link.request.number) : [po.request?.number]).filter(Boolean).join(", ") || "-")}</span></div></div><table><thead><tr><th>No</th><th>SKU</th><th>Barang</th><th class="right">Qty</th><th>Satuan</th><th class="right">Harga</th><th class="right">Jumlah</th></tr></thead><tbody>${rows}</tbody><tfoot><tr><td colspan="6" class="right">Subtotal</td><td class="right">${money(subtotal)}</td></tr><tr><td colspan="6" class="right">Ongkir + Pajak - Diskon</td><td class="right">${money(Number(po.shippingCost) + Number(po.tax) - Number(po.discount))}</td></tr><tr><td colspan="6" class="right"><b>TOTAL</b></td><td class="right"><b>${money(total)}</b></td></tr></tfoot></table><div class="signatures"><div>Dibuat oleh</div><div>Supplier</div><div>Disetujui oleh</div></div>`,
  }));
});
router.get("/receipts/group/print", async (req, res) => {
  const ids = [...new Set(String(req.query.ids || "").split(",").map(id => id.trim()).filter(Boolean))];
  if (!ids.length) return res.status(400).json({ error: "Penerimaan barang wajib dipilih" });
  const receipts = await prisma.goodsReceipt.findMany({
    where: { id: { in: ids } },
    include: { purchaseOrder: { include: { supplier: true } }, location: true, createdBy: { select: { name: true } }, items: { include: { purchaseOrderItem: { include: { item: true } } } } },
    orderBy: [{ receivedAt: "asc" }, { createdAt: "asc" }],
  });
  if (receipts.length !== ids.length) return res.status(404).json({ error: "Sebagian penerimaan barang tidak ditemukan" });
  if (new Set(receipts.map(receipt => receipt.purchaseOrder.supplierId)).size !== 1) return res.status(400).json({ error: "Penerimaan gabungan harus berasal dari supplier yang sama" });
  const first = receipts[0];
  const rows = receipts.flatMap(receipt => receipt.items.map(item => ({ receipt, item }))).map((row, index) => `<tr><td class="center">${index + 1}</td><td>${esc(row.receipt.number)}<br><span class="muted">${esc(row.receipt.purchaseOrder.number)}</span></td><td>${esc(row.item.purchaseOrderItem.item.sku)}</td><td>${esc(row.item.purchaseOrderItem.item.name)}</td><td class="right">${fmtNum(row.item.qty)}</td><td>${esc(row.item.purchaseOrderItem.item.unit)}</td><td>${esc(row.item.condition)}</td></tr>`).join("");
  const receiptDetails = receipts.map(receipt => `<tr><td>${esc(receipt.number)}</td><td>${fmtDate(receipt.receivedAt, true)}</td><td>${esc(receipt.purchaseOrder.number)}</td><td>${esc(receipt.location.name)}</td><td>${esc(receipt.createdBy?.name || "-")}</td></tr>`).join("");
  res.type("html").send(documentHtml({
    title: "BUKTI PENERIMAAN BARANG",
    subtitle: `Surat jalan ${esc(first.deliveryNote || "-")}`,
    meta: `Tanggal terima: ${fmtDate(first.receivedAt, true)}<br>${receipts.length} penerimaan · ${new Set(receipts.map(receipt => receipt.purchaseOrderId)).size} PO`,
    body: `<div class="summary"><div class="box">Supplier<b>${esc(first.purchaseOrder.supplier.name)}</b></div><div class="box">Surat jalan<b>${esc(first.deliveryNote || "-")}</b></div><div class="box">Bukti penerimaan<b>${esc(first.deliveryNoteFileName || "Foto tersimpan")}</b></div></div><table><thead><tr><th>No</th><th>GR / PO</th><th>SKU</th><th>Barang</th><th class="right">Diterima</th><th>Satuan</th><th>Kondisi</th></tr></thead><tbody>${rows}</tbody></table><h3>Rincian penerimaan</h3><table><thead><tr><th>Nomor GR</th><th>Tanggal</th><th>PO</th><th>Lokasi</th><th>Penerima</th></tr></thead><tbody>${receiptDetails}</tbody></table><table><tbody><tr><th style="width:28%">Catatan</th><td>${esc(receipts.map(receipt => receipt.notes).filter(Boolean).join(" · ") || "-")}</td></tr></tbody></table><div class="signatures"><div>Pengirim / Supplier</div><div>Penerima</div><div>Diperiksa oleh</div></div>`,
  }));
});
router.get("/receipts/:id/print", async (req, res) => {
  const receipt = await prisma.goodsReceipt.findUnique({
    where: { id: req.params.id },
    include: { purchaseOrder: { include: { supplier: true } }, location: true, createdBy: { select: { name: true } }, items: { include: { purchaseOrderItem: { include: { item: true } } } } },
  });
  if (!receipt) return res.status(404).json({ error: "Penerimaan barang tidak ditemukan" });
  const rows = receipt.items.map((row, index) => `<tr><td class="center">${index + 1}</td><td>${esc(row.purchaseOrderItem.item.sku)}</td><td>${esc(row.purchaseOrderItem.item.name)}</td><td class="right">${fmtNum(row.qty)}</td><td>${esc(row.purchaseOrderItem.item.unit)}</td><td>${esc(row.condition)}</td></tr>`).join("");
  res.type("html").send(documentHtml({
    title: "BUKTI PENERIMAAN BARANG",
    subtitle: receipt.number,
    meta: `Tanggal terima: ${fmtDate(receipt.receivedAt, true)}<br>PO: ${esc(receipt.purchaseOrder.number)}`,
    body: `<div class="summary"><div class="box">Supplier<b>${esc(receipt.purchaseOrder.supplier.name)}</b></div><div class="box">Lokasi penerimaan<b>${esc(receipt.location.name)}</b></div><div class="box">Penerima<b>${esc(receipt.createdBy?.name || "-")}</b></div></div><table><thead><tr><th>No</th><th>SKU</th><th>Barang</th><th class="right">Diterima</th><th>Satuan</th><th>Kondisi</th></tr></thead><tbody>${rows}</tbody></table><table><tbody><tr><th style="width:28%">Surat jalan supplier</th><td>${esc(receipt.deliveryNote || "-")}</td></tr><tr><th>Bukti surat penerimaan</th><td>${receipt.deliveryNoteProofUrl ? esc(receipt.deliveryNoteFileName || "Foto bukti tersimpan") : "-"}</td></tr><tr><th>Catatan</th><td>${esc(receipt.notes || "-")}</td></tr></tbody></table><div class="signatures"><div>Pengirim / Supplier</div><div>Penerima</div><div>Diperiksa oleh</div></div>`,
  }));
});
router.get("/bills/:id/receipt-print", async (req, res) => {
  const bill = await prisma.supplierBill.findUnique({
    where: { id: req.params.id },
    include: {
      supplier: true,
      createdBy: { select: { name: true } },
      items: {
        include: {
          receiptItem: {
            include: {
              purchaseOrderItem: { include: { item: true, purchaseOrder: true } },
              receipt: { include: { location: true, createdBy: { select: { name: true } }, purchaseOrder: true } },
            },
          },
        },
      },
      repairItems: { include: { movement: { include: { item: true, toLocation: true, maintenance: { include: { truck: true } } } } } },
    },
  });
  if (!bill) return res.status(404).json({ error: "Tagihan supplier tidak ditemukan" });
  const selectedRows = bill.items.map(line => ({ line, receiptItem: line.receiptItem, receipt: line.receiptItem.receipt, poItem: line.receiptItem.purchaseOrderItem }));
  const receipts = [...new Map(selectedRows.map(row => [row.receipt.id, row.receipt])).values()];
  const poNumbers = [...new Set(selectedRows.map(row => row.poItem.purchaseOrder.number))];
  const locations = [...new Set(receipts.map(receipt => receipt.location?.name).filter(Boolean))];
  const receivers = [...new Set(receipts.map(receipt => receipt.createdBy?.name).filter(Boolean))];
  const goodsRows = selectedRows.map((row, index) => `<tr><td class="center">${index + 1}</td><td>${esc(row.receipt.number)}<br><span class="muted">${esc(row.poItem.purchaseOrder.number)}</span></td><td>${esc(row.poItem.item.sku)}</td><td>${esc(row.poItem.item.name)}</td><td class="right">${fmtNum(row.line.qty)}</td><td>${esc(row.poItem.item.unit)}</td><td>${esc(row.receiptItem.condition)}</td></tr>`);
  const repairRows = bill.repairItems.map((line, index) => `<tr><td class="center">${goodsRows.length + index + 1}</td><td>Jasa perbaikan<br><span class="muted">${esc(line.movement.maintenance?.number || "-")}</span></td><td>${esc(line.movement.item.sku)}</td><td>${esc(line.movement.item.name)}${line.movement.maintenance?.truck?.plateNumber ? `<br><span class="muted">${esc(line.movement.maintenance.truck.plateNumber)}</span>` : ""}</td><td class="right">${fmtNum(line.qty)}</td><td>${esc(line.movement.item.unit)}</td><td>Selesai</td></tr>`);
  const rows = [...goodsRows, ...repairRows].join("");
  const receiptDetails = receipts.map(receipt => `<tr><td>${esc(receipt.number)}</td><td>${fmtDate(receipt.receivedAt, true)}</td><td>${esc(receipt.purchaseOrder.number)}</td><td>${esc(receipt.deliveryNote || "-")}</td><td>${esc(receipt.location?.name || "-")}</td><td>${esc(receipt.notes || "-")}</td></tr>`).join("");
  res.type("html").send(documentHtml({
    title: "BUKTI PENERIMAAN BARANG",
    subtitle: `${bill.number} · Invoice ${bill.invoiceNumber}`,
    meta: `Tanggal invoice: ${fmtDate(bill.invoiceDate)}<br>PO: ${esc(poNumbers.join(", ") || "-")}<br>${selectedRows.length + bill.repairItems.length} barang/jasa diterima`,
    body: `<div class="summary"><div class="box">Supplier<b>${esc(bill.supplier.name)}</b></div><div class="box">Lokasi penerimaan<b>${esc(locations.join(", ") || "-")}</b></div><div class="box">Penerima<b>${esc(receivers.join(", ") || bill.createdBy?.name || "-")}</b></div></div><table><thead><tr><th>No</th><th>GR / PO</th><th>SKU</th><th>Barang</th><th class="right">Diterima</th><th>Satuan</th><th>Kondisi</th></tr></thead><tbody>${rows}</tbody></table><h3>Rincian penerimaan</h3><table><thead><tr><th>Nomor GR</th><th>Tanggal terima</th><th>PO</th><th>Surat jalan</th><th>Lokasi</th><th>Catatan</th></tr></thead><tbody>${receiptDetails}</tbody></table><div class="signatures"><div>Pengirim / Supplier</div><div>Penerima</div><div>Diperiksa oleh</div></div>`,
  }));
});
router.post("/suppliers", async (req, res) => res.json({ ok: true, supplier: await prisma.supplier.create({ data: req.body }) }));
router.post("/retreads/create-order", async (req, res) => {
  const items = Array.isArray(req.body?.items) ? req.body.items : [];
  if (!items.length) return res.status(400).json({ error: "Pilih minimal satu ban masak" });
  const unitIds = items.map(row => String(row?.unitId || "").trim());
  if (unitIds.some(id => !id) || new Set(unitIds).size !== unitIds.length) return res.status(400).json({ error: "Daftar ban masak tidak valid atau duplikat" });
  const outcomes = new Map(items.map(row => [String(row.unitId), {
    outcome: String(row?.outcome || "RECEIVED").toUpperCase(),
    scrapReason: String(row?.scrapReason || "").trim(),
  }]));
  if ([...outcomes.values()].some(row => !["RECEIVED", "SCRAPPED"].includes(row.outcome))) return res.status(400).json({ error: "Hasil ban masak tidak valid" });
  if ([...outcomes.values()].some(row => row.outcome === "SCRAPPED" && !row.scrapReason)) return res.status(400).json({ error: "Alasan scrap wajib diisi" });

  try {
    const result = await prisma.$transaction(async tx => {
      const units = await tx.stockUnit.findMany({
        where: { id: { in: unitIds } },
        include: {
          tireRetreads: {
            where: { status: "SENT" }, orderBy: { sentAt: "desc" }, take: 1,
            include: { supplier: true, toItem: true, purchaseRequestItems: { where: { request: { status: { notIn: ["REJECTED", "CANCELLED"] } } }, select: { id: true } } },
          },
        },
      });
      if (units.length !== unitIds.length) throw new Error("Salah satu ban masak tidak ditemukan");
      const received = [];
      const scrapped = [];
      for (const unit of units) {
        const retread = unit.tireRetreads[0];
        if (unit.status !== "RETREADING" || !retread) throw new Error(`${unit.serialNumber || unit.id} tidak lagi dalam proses masak`);
        if (retread.purchaseRequestItems.length) throw new Error(`${unit.serialNumber || unit.id} sudah memiliki permintaan atau PO aktif`);
        const resultRow = outcomes.get(unit.id);
        if (resultRow.outcome === "SCRAPPED") {
          const note = `Tidak dapat dimasak / SCRAP: ${resultRow.scrapReason}`;
          await tx.stockUnit.update({ where: { id: unit.id }, data: { status: "SCRAPPED", locationId: null, scrappedAt: new Date() } });
          await tx.tireRetread.update({ where: { id: retread.id }, data: { status: "COMPLETED", completedAt: new Date(), cost: 0, notes: [retread.notes, note].filter(Boolean).join(" · ") } });
          await tx.stockMovement.create({ data: { type: "ADJUST", itemId: unit.itemId, qty: 1, note, createdById: req.user.id, stockUnitId: unit.id } });
          scrapped.push(unit.id);
        } else {
          if (!retread.supplierId) throw new Error(`${unit.serialNumber || unit.id} belum memiliki vendor masak ban`);
          received.push({ unit, retread });
        }
      }

      const orders = [];
      const bySupplier = new Map();
      for (const row of received) {
        const group = bySupplier.get(row.retread.supplierId) || [];
        group.push(row);
        bySupplier.set(row.retread.supplierId, group);
      }
      for (const [supplierId, rows] of bySupplier) {
        const request = await tx.purchaseRequest.create({
          data: {
            number: await nextDailyNumber(tx, "purchaseRequest", "PR"), status: "APPROVED", urgency: "NORMAL", purpose: "STOCK",
            reason: `Penerimaan hasil ban masak · ${rows.length} unit`, createdById: req.user.id, approvedById: req.user.id,
            approvedAt: new Date(), approvalNotes: "Dibuat otomatis dari proses hasil ban masak.",
            items: { create: rows.map(({ retread }) => ({ itemId: retread.toItemId, originalQty: 1, approvedQty: 1, tireRetreadId: retread.id })) },
          },
          include: { items: true },
        });
        const requestItemByRetread = new Map(request.items.map(item => [item.tireRetreadId, item]));
        const order = await tx.purchaseOrder.create({
          data: {
            number: await nextDailyNumber(tx, "purchaseOrder", "PO"), requestId: request.id, supplierId, status: "SENT_TO_SUPPLIER",
            paymentTerms: "Ditagihkan kemudian", createdById: req.user.id,
            items: { create: rows.map(({ retread }) => ({ itemId: retread.toItemId, purchaseRequestItemId: requestItemByRetread.get(retread.id).id, qty: 1, unitPrice: isPersaudaraan(retread.supplier) ? PERSAUDARAAN_RETREAD_PRICE : 0, tireRetreadId: retread.id })) },
          },
          include: includePO,
        });
        orders.push(order);
      }
      return { orders, orderedCount: received.length, scrappedCount: scrapped.length };
    }, { timeout: 30000 });
    res.json({ ok: true, ...result });
  } catch (error) {
    res.status(400).json({ error: error.message || "Gagal membuat PO ban masak" });
  }
});
router.post("/requests", async (req, res) => {
  const { urgency, purpose, truckId, reason, notes, items = [], submit = true, acknowledgeAvailableStock = false, damageProofUrl, damageProofFileName, damageProofMimeType, damageProofSize } = req.body;
  if (!reason || !items.length) return res.status(400).json({ error: "Alasan dan minimal satu item wajib diisi" });
  if (!['STOCK', 'TRUCK'].includes(purpose)) return res.status(400).json({ error: "Tujuan permintaan tidak valid" });
  if (purpose === "TRUCK" && !truckId) return res.status(400).json({ error: "Pilih truk tujuan permintaan" });
  if (purpose === "TRUCK" && !(await prisma.truck.findUnique({ where: { id: String(truckId) }, select: { id: true } }))) {
    return res.status(400).json({ error: "Truk tujuan tidak ditemukan" });
  }
  const damageProofs = (Array.isArray(req.body.damageProofs) && req.body.damageProofs.length
    ? req.body.damageProofs
    : damageProofUrl ? [{ url: damageProofUrl, fileName: damageProofFileName, mimeType: damageProofMimeType, size: damageProofSize }] : [])
    .filter(proof => proof?.url && String(proof.mimeType || "").startsWith("image/"));
  const primaryProof = damageProofs[0];
  const regularItemIds = items.filter(row => row.itemId && !row.retreadUnitId && !row.partRepairId).map(row => String(row.itemId));
  if (regularItemIds.length && !acknowledgeAvailableStock) {
    const catalogItems = await prisma.item.findMany({
      where: { id: { in: regularItemIds } },
      include: { stocks: true },
    });
    const serializedCounts = await prisma.stockUnit.groupBy({
      by: ["itemId"],
      where: { itemId: { in: regularItemIds }, status: "IN_STOCK" },
      _count: { _all: true },
    });
    const serializedByItem = new Map(serializedCounts.map(row => [row.itemId, row._count._all]));
    const available = catalogItems
      .map(item => ({
        item,
        qty: item.isSerialized
          ? Number(serializedByItem.get(item.id) || 0)
          : item.stocks.reduce((sum, stock) => sum + Number(stock.qty || 0), 0),
      }))
      .filter(row => row.qty > 0);
    if (available.length) {
      return res.status(409).json({
        error: `Stok masih tersedia: ${available.map(row => `${row.item.name} (${row.qty.toLocaleString("id-ID")} ${row.item.unit})`).join(", ")}. Periksa Inventory atau konfirmasi untuk tetap membuat permintaan.`,
        code: "STOCK_AVAILABLE",
      });
    }
  }
  const preparedItems = [];
  for (const row of items) {
    if (row.retreadUnitId) {
      const unit = await prisma.stockUnit.findUnique({
        where: { id: String(row.retreadUnitId) },
        include: { tireRetreads: { where: { status: "SENT" }, orderBy: { sentAt: "desc" }, take: 1 } },
      });
      const retread = unit?.tireRetreads?.[0];
      if (!unit || unit.status !== "RETREADING" || !retread) throw new Error("Ban tidak lagi berstatus retreading");
      const existingRequest = await prisma.purchaseRequestItem.findFirst({
        where: { tireRetreadId: retread.id, request: { status: { not: "REJECTED" } } },
      });
      if (existingRequest) throw new Error(`${unit.serialNumber || unit.id} sudah memiliki Permintaan Pembelian retreading`);
      preparedItems.push({ itemId: retread.toItemId, originalQty: 1, notes: row.notes, tireRetreadId: retread.id });
    } else if (row.partRepairId) {
      const repair = await prisma.partRepair.findFirst({ where: { id: String(row.partRepairId), status: "SENT" }, include: { stockUnit: true } });
      if (!repair || repair.stockUnit.status !== "REPAIRING") throw new Error("Barang tidak lagi berstatus dalam perbaikan");
      const existingRequest = await prisma.purchaseRequestItem.findFirst({ where: { partRepairId: repair.id, request: { status: { notIn: ["REJECTED", "CANCELLED"] } } } });
      if (existingRequest) throw new Error(`${repair.stockUnit.serialNumber || repair.stockUnit.id} sudah memiliki Permintaan Pembelian perbaikan`);
      preparedItems.push({ itemId: repair.stockUnit.itemId, originalQty: 1, notes: row.notes, partRepairId: repair.id });
    } else {
      const requestedQty = purpose === "STOCK" ? 0 : Number(row.qty);
      if (purpose !== "STOCK" && (!Number.isFinite(requestedQty) || requestedQty <= 0)) {
        return res.status(400).json({ error: "Jumlah kebutuhan untuk truk wajib lebih dari 0" });
      }
      preparedItems.push({ itemId: row.itemId, originalQty: requestedQty, notes: row.notes });
    }
  }
  const request = await prisma.$transaction(async tx => tx.purchaseRequest.create({ data: { number: await nextDailyNumber(tx, "purchaseRequest", "PR"), urgency, purpose, truckId, reason, notes, damageProofUrl: primaryProof?.url || null, damageProofFileName: primaryProof?.fileName || null, damageProofMimeType: primaryProof?.mimeType || null, damageProofSize: Number.isFinite(Number(primaryProof?.size)) ? Number(primaryProof.size) : null, status: submit ? "WAITING_APPROVAL" : "DRAFT", createdById: req.user.id, items: { create: preparedItems }, ...(damageProofs.length ? { damageProofs: { create: damageProofs.map(proof => ({ url: proof.url, fileName: proof.fileName || null, mimeType: proof.mimeType || null, size: Number.isFinite(Number(proof.size)) ? Number(proof.size) : null })) } } : {}) }, include: { items: { include: { item: true } }, damageProofs: true } }));
  if (request.status === "WAITING_APPROVAL") {
    await notifyOwnerSafely({
      event: "Permintaan pembelian baru",
      title: request.number,
      details: `${request.items.map(row => `${row.item.name} · ${purpose === "STOCK" && !row.tireRetreadId ? "jumlah ditentukan saat PO" : `${row.originalQty} ${row.item.unit}`}`).join(", ")} · ${reason}`,
      path: `/purchasing?approveRequest=${encodeURIComponent(request.id)}`,
      actionLabel: "Setujui Permintaan",
      proof: request.damageProofUrl ? { url: request.damageProofUrl, fileName: request.damageProofFileName, mimeType: request.damageProofMimeType } : undefined,
    });
  }
  res.json({ ok: true, request });
});
router.post("/orders/direct", requireRole("OWNER"), async (req, res) => {
  try {
    const {
      itemId,
      items,
      supplierId,
      qty,
      reason,
      notes,
      paymentTerms = "Ditagihkan kemudian",
      deliveryAddress,
      estimatedArrival,
    } = req.body || {};
    const requestedItems = Array.isArray(items) && items.length ? items : [{ itemId, qty }];
    if (!supplierId || !requestedItems.length || requestedItems.some(row => !row.itemId)) return res.status(400).json({ error: "Barang dan supplier wajib dipilih" });
    const normalizedItems = requestedItems.map(row => ({ itemId: String(row.itemId), qty: Number(row.qty) }));
    if (normalizedItems.some(row => !Number.isFinite(row.qty) || row.qty <= 0)) return res.status(400).json({ error: "Jumlah setiap barang wajib lebih dari 0" });
    if (new Set(normalizedItems.map(row => row.itemId)).size !== normalizedItems.length) return res.status(400).json({ error: "Barang yang sama tidak boleh dimasukkan dua kali" });

    const [catalogItems, supplier] = await Promise.all([
      prisma.item.findMany({ where: { id: { in: normalizedItems.map(row => row.itemId) } } }),
      prisma.supplier.findUnique({ where: { id: String(supplierId) } }),
    ]);
    if (catalogItems.length !== normalizedItems.length) return res.status(404).json({ error: "Salah satu barang tidak ditemukan" });
    if (!supplier) return res.status(404).json({ error: "Supplier tidak ditemukan" });
    const itemById = new Map(catalogItems.map(item => [item.id, item]));
    const orderItems = normalizedItems.map(row => ({ ...row, item: itemById.get(row.itemId) }));

    const result = await prisma.$transaction(async tx => {
      const request = await tx.purchaseRequest.create({
        data: {
          number: await nextDailyNumber(tx, "purchaseRequest", "PR"),
          status: "APPROVED",
          urgency: "NORMAL",
          purpose: "STOCK",
          reason: String(reason || `Pembelian langsung ${orderItems.map(row => row.item.name).join(", ")}`).trim(),
          notes: notes ? String(notes).trim() : null,
          createdById: req.user.id,
          approvedById: req.user.id,
          approvedAt: new Date(),
          approvalNotes: "Pembelian langsung oleh owner; persetujuan dilewati.",
          items: { create: orderItems.map(row => ({ itemId: row.itemId, originalQty: row.qty, approvedQty: row.qty })) },
        },
      });
      const order = await tx.purchaseOrder.create({
        data: {
          number: await nextDailyNumber(tx, "purchaseOrder", "PO"),
          requestId: request.id,
          supplierId: supplier.id,
          status: "SENT_TO_SUPPLIER",
          paymentTerms: String(paymentTerms || "Ditagihkan kemudian").trim(),
          deliveryAddress: deliveryAddress ? String(deliveryAddress).trim() : null,
          estimatedArrival: estimatedArrival ? new Date(estimatedArrival) : null,
          createdById: req.user.id,
          items: { create: orderItems.map(row => ({ itemId: row.itemId, qty: row.qty, unitPrice: 0 })) },
        },
        include: includePO,
      });
      return { request, order };
    });
    res.json({ ok: true, ...result });
  } catch (error) {
    res.status(500).json({ error: error.message || "Gagal membuat PO langsung" });
  }
});
router.patch("/requests/:id/approval", requireRole("OWNER", "ADMIN"), async (req, res) => {
  const { approved, notes, quantities = {}, acknowledgeAvailableStock = false } = req.body;
  if (approved && !acknowledgeAvailableStock) {
    const request = await prisma.purchaseRequest.findUnique({
      where: { id: req.params.id },
      include: { items: { include: { item: { include: { stocks: true } } } } },
    });
    if (!request) return res.status(404).json({ error: "Purchase Request tidak ditemukan" });
    const regularRows = request.items.filter(row => !row.tireRetreadId && !row.partRepairId);
    const serializedIds = regularRows.filter(row => row.item.isSerialized).map(row => row.itemId);
    const serializedCounts = serializedIds.length
      ? await prisma.stockUnit.groupBy({
          by: ["itemId"],
          where: { itemId: { in: serializedIds }, status: "IN_STOCK" },
          _count: { _all: true },
        })
      : [];
    const serializedByItem = new Map(serializedCounts.map(row => [row.itemId, row._count._all]));
    const available = regularRows
      .map(row => ({
        item: row.item,
        qty: row.item.isSerialized
          ? Number(serializedByItem.get(row.itemId) || 0)
          : row.item.stocks.reduce((sum, stock) => sum + Number(stock.qty || 0), 0),
      }))
      .filter(row => row.qty > 0);
    if (available.length) {
      return res.status(409).json({
        error: `Stok masih tersedia: ${available.map(row => `${row.item.name} (${row.qty.toLocaleString("id-ID")} ${row.item.unit})`).join(", ")}. Konfirmasi untuk tetap menyetujui permintaan.`,
        code: "STOCK_AVAILABLE",
      });
    }
  }
  const result = await prisma.$transaction(async tx => {
    for (const [id, qty] of Object.entries(quantities)) {
      const item = await tx.purchaseRequestItem.findUnique({ where: { id } });
      await tx.purchaseRequestItem.update({ where: { id }, data: { approvedQty: item?.tireRetreadId || item?.partRepairId ? 1 : Number(qty) } });
    }
    return tx.purchaseRequest.update({ where: { id: req.params.id }, data: { status: approved ? "APPROVED" : "REJECTED", approvedById: req.user.id, approvedAt: new Date(), approvalNotes: notes } });
  }); res.json({ ok: true, request: result });
});
router.post("/orders", async (req, res) => {
  try {
    const { requestId, supplierId, tax = 0, shippingCost = 0, discount = 0, paymentTerms, deliveryAddress, estimatedArrival, items = [] } = req.body;
    if (!requestId || !supplierId || !items.length) return res.status(400).json({ error: "Request, supplier, dan item wajib diisi" });
    const request = await prisma.purchaseRequest.findUnique({ where: { id: requestId }, include: { items: { include: { tireRetread: true, partRepair: true } } } });
    if (!request || request.status !== "APPROVED") return res.status(400).json({ error: "Purchase Request belum disetujui" });
    const poItems = items.map(i => {
      const requestItem = request.items.find(row => row.id === i.purchaseRequestItemId) || request.items.find(row => row.itemId === i.itemId);
      if (!requestItem) throw new Error("Item PO tidak sesuai dengan Purchase Request");
      const qty = requestItem.tireRetreadId || requestItem.partRepairId
        ? 1
        : request.purpose === "STOCK"
          ? Number(i.qty)
          : Number(requestItem.approvedQty ?? requestItem.originalQty);
      if (!Number.isFinite(qty) || qty <= 0) throw new Error(request.purpose === "STOCK" ? "Jumlah PO persediaan umum wajib lebih dari 0" : "Jumlah item tidak valid");
      return { itemId: requestItem.itemId, purchaseRequestItemId: requestItem.id, qty, unitPrice: 0, tireRetreadId: requestItem.tireRetreadId, partRepairId: requestItem.partRepairId };
    });
    const wrongSupplier = request.items.find(row => row.tireRetread?.supplierId && row.tireRetread.supplierId !== supplierId);
    if (wrongSupplier) throw new Error("Supplier PO harus sama dengan vendor yang dipilih saat Lepas & Masak");
    const po = await prisma.$transaction(async tx => tx.purchaseOrder.create({ data: { number: await nextDailyNumber(tx, "purchaseOrder", "PO"), requestId, supplierId, status: "SENT_TO_SUPPLIER", tax: Number(tax), shippingCost: Number(shippingCost), discount: Number(discount), paymentTerms, deliveryAddress, estimatedArrival: estimatedArrival ? new Date(estimatedArrival) : null, createdById: req.user.id, items: { create: poItems } }, include: includePO }));
    await prisma.partRepair.updateMany({ where: { id: { in: request.items.map(row => row.partRepairId).filter(Boolean) } }, data: { supplierId } });
    res.json({ ok: true, order: po });
  } catch (e) { res.status(500).json({ error: e.message || "Gagal membuat Purchase Order" }); }
});
router.post("/orders/bulk", async (req, res) => {
  try {
    const { supplierId, orders = [], tax = 0, shippingCost = 0, discount = 0, paymentTerms, deliveryAddress, estimatedArrival } = req.body || {};
    if (!supplierId || !Array.isArray(orders) || !orders.length) return res.status(400).json({ error: "Supplier dan minimal satu permintaan wajib dipilih" });
    const requestIds = orders.map(row => String(row.requestId || ""));
    if (requestIds.some(id => !id) || new Set(requestIds).size !== requestIds.length) return res.status(400).json({ error: "Daftar permintaan tidak valid" });
    const [supplier, requests, existingOrders] = await Promise.all([
      prisma.supplier.findUnique({ where: { id: String(supplierId) } }),
      prisma.purchaseRequest.findMany({ where: { id: { in: requestIds } }, include: { items: { include: { tireRetread: true, partRepair: true } } } }),
      prisma.purchaseOrder.findMany({ where: { status: { not: "CANCELLED" }, OR: [{ requestId: { in: requestIds } }, { requestLinks: { some: { requestId: { in: requestIds } } } }] }, select: { requestId: true } }),
    ]);
    if (!supplier) return res.status(404).json({ error: "Supplier tidak ditemukan" });
    if (requests.length !== requestIds.length) return res.status(404).json({ error: "Salah satu permintaan tidak ditemukan" });
    if (existingOrders.length) return res.status(409).json({ error: "Salah satu permintaan sudah memiliki PO aktif" });
    const requestById = new Map(requests.map(request => [request.id, request]));
    const prepared = orders.map(orderInput => {
      const request = requestById.get(String(orderInput.requestId));
      if (request.status !== "APPROVED") throw new Error(`${request.number} belum disetujui`);
      const suppliedItems = new Map((orderInput.items || []).map(item => [String(item.purchaseRequestItemId || ""), item]));
      const items = request.items.map(requestItem => {
        const input = suppliedItems.get(requestItem.id) || {};
        const qty = requestItem.tireRetreadId || requestItem.partRepairId ? 1 : request.purpose === "STOCK" ? Number(input.qty) : Number(requestItem.approvedQty ?? requestItem.originalQty);
        if (!Number.isFinite(qty) || qty <= 0) throw new Error(`Jumlah item pada ${request.number} wajib lebih dari 0`);
        return { itemId: requestItem.itemId, purchaseRequestItemId: requestItem.id, qty, unitPrice: 0, tireRetreadId: requestItem.tireRetreadId, partRepairId: requestItem.partRepairId };
      });
      return { request, items };
    });
    const routingKeys = new Set(prepared.map(({ request }) => request.directUse || request.purpose === "MAINTENANCE_STOCK_REQUEST" ? `MAINTENANCE:${request.maintenanceId || ""}` : request.purpose === "TRUCK" ? `TRUCK:${request.truckId || ""}` : "STOCK"));
    if (routingKeys.size > 1) throw new Error("Permintaan dengan tujuan stok, mobil, atau pekerjaan bengkel yang berbeda tidak dapat digabung dalam satu PO");
    const created = await prisma.$transaction(async tx => {
      const order = await tx.purchaseOrder.create({
        data: {
          number: await nextDailyNumber(tx, "purchaseOrder", "PO"), requestId: prepared[0].request.id,
          supplierId: supplier.id, status: "SENT_TO_SUPPLIER", tax: Number(tax), shippingCost: Number(shippingCost),
          discount: Number(discount), paymentTerms, deliveryAddress,
          estimatedArrival: estimatedArrival ? new Date(estimatedArrival) : null, createdById: req.user.id,
          requestLinks: { create: prepared.map(entry => ({ requestId: entry.request.id })) },
          items: { create: prepared.flatMap(entry => entry.items) },
        },
        include: includePO,
      });
      await tx.partRepair.updateMany({ where: { id: { in: prepared.flatMap(entry => entry.request.items.map(item => item.partRepairId).filter(Boolean)) } }, data: { supplierId: supplier.id } });
      return order;
    });
    res.json({ ok: true, order: created, orders: [created] });
  } catch (error) {
    res.status(400).json({ error: error.message || "Gagal membuat beberapa Purchase Order" });
  }
});
router.patch("/orders/:id/status", requireRole("OWNER", "ADMIN"), async (req, res) => {
  const allowed = ["APPROVED", "SENT_TO_SUPPLIER"];
  if (!allowed.includes(req.body.status)) return res.status(400).json({ error: "Status PO tidak valid" });
  res.json({ ok: true, order: await prisma.purchaseOrder.update({ where: { id: req.params.id }, data: { status: req.body.status } }) });
});
router.patch("/orders/:id/supplier", requireRole("OWNER", "ADMIN"), async (req, res) => {
  try {
    const supplierId = String(req.body.supplierId || "").trim();
    if (!supplierId) throw new Error("Supplier baru wajib dipilih");
    const [order, supplier] = await Promise.all([
      prisma.purchaseOrder.findUnique({
        where: { id: req.params.id },
        include: { receipts: { select: { id: true } }, payments: { select: { id: true } }, items: { select: { receivedQty: true, tireRetreadId: true, partRepairId: true } } },
      }),
      prisma.supplier.findUnique({ where: { id: supplierId } }),
    ]);
    if (!order) return res.status(404).json({ error: "Purchase Order tidak ditemukan" });
    if (!supplier) throw new Error("Supplier baru tidak ditemukan");
    if (!["DRAFT", "APPROVED", "SENT_TO_SUPPLIER"].includes(order.status)) throw new Error("Supplier PO dengan status ini tidak dapat diganti");
    if (order.receipts.length || order.items.some(item => Number(item.receivedQty || 0) > 0)) throw new Error("Supplier tidak dapat diganti setelah barang diterima");
    if (order.payments.length) throw new Error("Supplier tidak dapat diganti setelah pembayaran dibuat");
    if (order.supplierId === supplierId) throw new Error("Supplier baru masih sama dengan supplier sebelumnya");
    const updated = await prisma.$transaction(async tx => {
      const tireRetreadIds = order.items.map(item => item.tireRetreadId).filter(Boolean);
      const partRepairIds = order.items.map(item => item.partRepairId).filter(Boolean);
      if (tireRetreadIds.length) await tx.tireRetread.updateMany({ where: { id: { in: tireRetreadIds } }, data: { supplierId } });
      if (partRepairIds.length) await tx.partRepair.updateMany({ where: { id: { in: partRepairIds } }, data: { supplierId } });
      return tx.purchaseOrder.update({ where: { id: order.id }, data: { supplierId }, include: includePO });
    });
    res.json({ ok: true, order: updated });
  } catch (error) {
    res.status(400).json({ error: error.message || "Gagal mengganti supplier Purchase Order" });
  }
});
router.patch("/orders/:id/cancel", requireRole("OWNER", "ADMIN"), async (req, res) => {
  try {
    const reason = String(req.body.reason || "").trim();
    if (reason.length < 3) throw new Error("Alasan pembatalan wajib diisi");
    const order = await prisma.purchaseOrder.findUnique({
      where: { id: req.params.id },
      include: { receipts: { select: { id: true } }, payments: { select: { id: true } }, items: { select: { receivedQty: true } } },
    });
    if (!order) return res.status(404).json({ error: "Purchase Order tidak ditemukan" });
    if (order.status === "CANCELLED") throw new Error("Purchase Order sudah dibatalkan");
    if (!["DRAFT", "APPROVED", "SENT_TO_SUPPLIER"].includes(order.status)) throw new Error("PO dengan status ini tidak dapat dibatalkan");
    if (order.receipts.length || order.items.some(item => Number(item.receivedQty || 0) > 0)) throw new Error("PO yang sudah menerima barang tidak dapat dibatalkan");
    if (order.payments.length) throw new Error("PO yang sudah memiliki pembayaran tidak dapat dibatalkan");
    const updated = await prisma.$transaction(async tx => {
      const cancelledAt = new Date();
      const linkedRequests = await tx.purchaseOrderRequest.findMany({ where: { purchaseOrderId: order.id }, select: { requestId: true } });
      await tx.purchaseRequest.updateMany({
        where: { id: { in: [...new Set([order.requestId, ...linkedRequests.map(link => link.requestId)])] } },
        data: { status: "CANCELLED", approvalNotes: reason, approvedById: req.user.id, approvedAt: cancelledAt },
      });
      return tx.purchaseOrder.update({ where: { id: order.id }, data: { status: "CANCELLED", cancelledAt, cancellationReason: reason, cancelledById: req.user.id }, include: includePO });
    });
    res.json({ ok: true, order: updated });
  } catch (error) {
    res.status(400).json({ error: error.message || "Gagal membatalkan Purchase Order" });
  }
});
async function createGoodsReceipt(tx, payload, userId) {
    const { purchaseOrderId, locationId, deliveryNote, deliveryNoteProofUrl, deliveryNoteFileName, deliveryNoteMimeType, deliveryNoteSize, notes, supplierInvoiceNumber, supplierInvoiceDate, supplierInvoiceAmount, supplierInvoiceProofUrl, supplierInvoiceFileName, supplierInvoiceMimeType, supplierInvoiceSize, items = [] } = payload;
    const po = await tx.purchaseOrder.findUnique({ where: { id: purchaseOrderId }, include: { supplier: true, request: { include: { maintenance: true } }, items: { include: { item: true, tireRetread: true, partRepair: true } } } });
    if (!po) throw new Error("Purchase Order tidak ditemukan");
    if (!["SENT_TO_SUPPLIER", "PARTIALLY_RECEIVED"].includes(po.status)) throw new Error(po.status === "CANCELLED" ? "Purchase Order sudah dibatalkan" : "Purchase Order belum siap menerima barang");
    // Service requests marked for direct use still enter the receiving location
    // first, then leave it immediately for the linked truck. This preserves the
    // auditable IN -> OUT stock trail without leaving artificial warehouse stock.
    const isDirectServiceRequest = Boolean(po.request?.directUse || po.request?.purpose === "MAINTENANCE_STOCK_REQUEST");
    if (isDirectServiceRequest && po.request?.maintenance?.status !== "OPEN") throw new Error("Servis tujuan sudah tidak terbuka; barang tidak dapat langsung dipakai ke mobil");
    const directMaintenance = isDirectServiceRequest ? po.request.maintenance : null;
    const directTruckId = directMaintenance?.truckId || (po.request?.purpose === "TRUCK" ? po.request.truckId : null);
    const directTruck = directTruckId ? await tx.truck.findUnique({ where: { id: directTruckId }, select: { id: true, plateNumber: true } }) : null;
    if (po.request?.purpose === "TRUCK" && !directTruck) throw new Error("Truk tujuan pembelian tidak ditemukan");
    const directToTruck = Boolean(directTruck);
    if (!locationId || !items.length) throw new Error("Lokasi dan item penerimaan wajib diisi");
    const invoiceAmount = supplierInvoiceAmount === "" || supplierInvoiceAmount == null ? null : Number(supplierInvoiceAmount);
    if (invoiceAmount != null && (!Number.isFinite(invoiceAmount) || invoiceAmount < 0)) throw new Error("Nilai invoice supplier tidak valid");
    const invoiceDate = supplierInvoiceDate ? new Date(supplierInvoiceDate) : null;
    if (invoiceDate && Number.isNaN(invoiceDate.getTime())) throw new Error("Tanggal invoice supplier tidak valid");
    const rec = await tx.goodsReceipt.create({ data: { number: await nextDailyNumber(tx, "goodsReceipt", "GR"), purchaseOrderId, locationId, deliveryNote, deliveryNoteProofUrl, deliveryNoteFileName: deliveryNoteFileName || null, deliveryNoteMimeType: deliveryNoteMimeType || null, deliveryNoteSize: Number.isFinite(Number(deliveryNoteSize)) ? Number(deliveryNoteSize) : null, notes, supplierInvoiceNumber: supplierInvoiceNumber ? String(supplierInvoiceNumber).trim() : null, supplierInvoiceDate: invoiceDate, supplierInvoiceAmount: invoiceAmount == null ? null : Math.round(invoiceAmount), supplierInvoiceProofUrl: supplierInvoiceProofUrl || null, supplierInvoiceFileName: supplierInvoiceFileName || null, supplierInvoiceMimeType: supplierInvoiceMimeType || null, supplierInvoiceSize: Number.isFinite(Number(supplierInvoiceSize)) ? Number(supplierInvoiceSize) : null, createdById: userId } });
    for (const row of items) {
      const poi = po.items.find(i => i.id === row.purchaseOrderItemId); const qty = Number(row.qty); const unitPrice = poi?.tireRetreadId && isPersaudaraan(po.supplier) ? PERSAUDARAAN_RETREAD_PRICE : Math.round(Number(row.unitPrice));
      if (!poi || qty <= 0 || poi.receivedQty + qty > poi.qty) throw new Error("Jumlah penerimaan melebihi sisa PO");
      if (!Number.isFinite(unitPrice) || unitPrice <= 0) throw new Error(`${poi.item.name}: harga satuan sementara wajib lebih dari Rp0`);
      poi.unitPrice = unitPrice;
      const receiptItem = await tx.goodsReceiptItem.create({ data: { receiptId: rec.id, purchaseOrderItemId: poi.id, qty, condition: row.condition || "GOOD" } });
      const batch = await tx.inventoryBatch.create({ data: { itemId: poi.itemId, locationId, goodsReceiptId: rec.id, goodsReceiptItemId: receiptItem.id, purchaseOrderItemId: poi.id, receivedQty: qty, remainingQty: qty, unitPrice: poi.unitPrice, receivedAt: rec.receivedAt } });
      await tx.inventoryStock.upsert({ where: { itemId_locationId: { itemId: poi.itemId, locationId } }, create: { itemId: poi.itemId, locationId, qty }, update: { qty: { increment: qty } } });
      await tx.stockMovement.create({ data: { type: "IN", itemId: poi.itemId, qty, unitPrice: poi.unitPrice, totalCost: Math.round(qty * poi.unitPrice), toLocationId: locationId, maintenanceId: directMaintenance?.id || null, createdById: userId, note: `${directMaintenance ? `Penerimaan untuk servis ${directMaintenance.title}` : directTruck ? `Penerimaan untuk ${directTruck.plateNumber}` : "Penerimaan"} · ${po.number}` } });
      if (poi.item.isSerialized) {
        const units = poi.tireRetreadId
          ? [{ retreadUnitId: poi.tireRetread.stockUnitId }]
          : poi.partRepairId
            ? [{ repairUnitId: poi.partRepair.stockUnitId }]
          : (Array.isArray(row.units) ? row.units : []);
        if (!Number.isInteger(qty)) throw new Error(`${poi.item.name}: jumlah unit harus berupa angka bulat`);
        if (!poi.tireRetreadId && !poi.partRepairId && units.length === 0) units.push(...Array.from({ length: qty }, () => ({})));
        if (units.length !== qty) throw new Error(`${poi.item.name}: jumlah data unit harus sama dengan qty diterima`);
        for (const unit of units) {
          if (unit.retreadUnitId) {
            if (poi.item.category !== "TIRE") throw new Error(`${poi.item.name}: hasil retreading hanya dapat diterima sebagai item kategori Ban`);
            const existingUnit = await tx.stockUnit.findUnique({
              where: { id: String(unit.retreadUnitId) },
              include: {
                tireRetreads: {
                  where: { status: "SENT" },
                  orderBy: { sentAt: "desc" },
                  take: 1,
                },
              },
            });
            if (!existingUnit || existingUnit.status !== "RETREADING") throw new Error("Unit retreading tidak ditemukan atau sudah diterima");
            const retread = existingUnit.tireRetreads[0];
            if (!retread) throw new Error(`Proses retreading aktif untuk ${existingUnit.serialNumber || existingUnit.id} tidak ditemukan`);
            if (retread.toItemId !== poi.itemId) throw new Error(`${existingUnit.serialNumber || existingUnit.id}: item Ban Masak tidak sesuai dengan item PO`);
            if (retread.supplierId && retread.supplierId !== po.supplierId) throw new Error(`${existingUnit.serialNumber || existingUnit.id}: vendor retreading tidak sama dengan supplier PO`);

            await tx.stockUnit.update({
              where: { id: existingUnit.id },
              data: {
                itemId: poi.itemId,
                locationId,
                inventoryBatchId: batch.id,
                purchasePrice: poi.unitPrice,
                status: "IN_STOCK",
                retreadCount: { increment: 1 },
                lastRetreadAt: rec.receivedAt,
                totalRetreadCost: { increment: poi.unitPrice },
              },
            });
            await tx.tireRetread.update({
              where: { id: retread.id },
              data: {
                status: "COMPLETED",
                completedAt: rec.receivedAt,
                cost: poi.unitPrice,
                supplierId: retread.supplierId || po.supplierId,
              },
            });
            continue;
          }
          if (unit.repairUnitId) {
            const existingUnit = await tx.stockUnit.findUnique({ where: { id: String(unit.repairUnitId) }, include: { partRepairs: { where: { status: "SENT" }, orderBy: { sentAt: "desc" }, take: 1 } } });
            if (!existingUnit || existingUnit.status !== "REPAIRING") throw new Error("Unit perbaikan tidak ditemukan atau sudah diterima");
            const repair = existingUnit.partRepairs[0];
            if (!repair || repair.id !== poi.partRepairId) throw new Error("Proses perbaikan unit tidak sesuai dengan PO");
            await tx.stockUnit.update({ where: { id: existingUnit.id }, data: { locationId, inventoryBatchId: batch.id, purchasePrice: poi.unitPrice, status: "IN_STOCK" } });
            await tx.partRepair.update({ where: { id: repair.id }, data: { status: "COMPLETED", completedAt: rec.receivedAt, cost: poi.unitPrice, supplierId: repair.supplierId || po.supplierId } });
            continue;
          }
          const serialNumber = String(unit.serialNumber || "").trim();
          if (directToTruck && !serialNumber) throw new Error(`${poi.item.name}: nomor seri wajib diisi karena barang langsung dipasang`);
          const stockUnit = await tx.stockUnit.create({ data: { itemId: poi.itemId, locationId, inventoryBatchId: batch.id, serialNumber: serialNumber || null, barcode: unit.barcode ? String(unit.barcode).trim() : null, purchasePrice: poi.unitPrice, purchasedAt: rec.receivedAt, currency: "IDR", status: "IN_STOCK" } });
          if (directToTruck) {
            await tx.truckSparePartAssignment.create({ data: { truckId: directTruck.id, stockUnitId: stockUnit.id, installedAt: rec.receivedAt, installCost: poi.unitPrice, currency: "IDR", note: `Pembelian langsung ${po.number}`, maintenanceId: directMaintenance?.id || null, createdById: userId } });
            await tx.stockUnit.update({ where: { id: stockUnit.id }, data: { status: "ASSIGNED", locationId: null } });
            await tx.stockMovement.create({ data: { type: "OUT", itemId: poi.itemId, qty: 1, unitPrice: poi.unitPrice, totalCost: poi.unitPrice, fromLocationId: locationId, toTruckId: directTruck.id, maintenanceId: directMaintenance?.id || null, stockUnitId: stockUnit.id, createdById: userId, note: `${directMaintenance ? `Langsung dipasang pada ${directMaintenance.title}` : `Langsung masuk ke ${directTruck.plateNumber}`} · ${po.number}` } });
          }
        }
      }
      await tx.purchaseOrderItem.update({ where: { id: poi.id }, data: { receivedQty: { increment: qty }, unitPrice } });
      if (directToTruck) {
        await tx.inventoryStock.update({ where: { itemId_locationId: { itemId: poi.itemId, locationId } }, data: { qty: { decrement: qty } } });
        await tx.inventoryBatch.update({ where: { id: batch.id }, data: { remainingQty: { decrement: qty } } });
        if (!poi.item.isSerialized) {
          const existingTruckStock = await tx.truckPartStock.findUnique({ where: { truckId_itemId: { truckId: directTruck.id, itemId: poi.itemId } } });
          const oldQty = Number(existingTruckStock?.qty || 0);
          const oldValue = existingTruckStock?.unitPrice == null ? 0 : oldQty * Number(existingTruckStock.unitPrice);
          const nextUnitPrice = oldQty > 0 && existingTruckStock?.unitPrice == null ? null : Math.round((oldValue + qty * poi.unitPrice) / (oldQty + qty));
          await tx.truckPartStock.upsert({ where: { truckId_itemId: { truckId: directTruck.id, itemId: poi.itemId } }, create: { truckId: directTruck.id, itemId: poi.itemId, qty, unitPrice: poi.unitPrice }, update: { qty: { increment: qty }, unitPrice: nextUnitPrice } });
          const outMovement = await tx.stockMovement.create({ data: { type: "OUT", itemId: poi.itemId, qty, unitPrice: poi.unitPrice, totalCost: Math.round(qty * poi.unitPrice), fromLocationId: locationId, toTruckId: directTruck.id, maintenanceId: directMaintenance?.id || null, createdById: userId, note: `${directMaintenance ? `Pembelian langsung & dipakai pada ${directMaintenance.title}` : `Pembelian langsung untuk ${directTruck.plateNumber}`} · ${po.number}` } });
          await tx.stockMovementBatchAllocation.create({ data: { movementId: outMovement.id, batchId: batch.id, qty } });
        }
      }
    }
    const all = await tx.purchaseOrderItem.findMany({ where: { purchaseOrderId } });
    const fullyReceived = all.every(i => i.receivedQty >= i.qty);
    const receiptValue = items.reduce((sum, row) => {
      const poi = po.items.find(i => i.id === row.purchaseOrderItemId);
      return sum + Number(row.qty) * Number(poi?.unitPrice || 0);
    }, 0) + (fullyReceived ? Number(po.tax) + Number(po.shippingCost) - Number(po.discount) : 0);
    if (receiptValue > 0) await postJournal(tx, { date: rec.receivedAt, description: `${directToTruck ? "Pembelian langsung armada" : "Penerimaan barang"} ${rec.number}`, sourceType: "GOODS_RECEIPT", sourceId: rec.id, createdById: userId, lines: [{ code: directToTruck ? SYSTEM_ACCOUNTS.EXPENSE : SYSTEM_ACCOUNTS.INVENTORY, debit: receiptValue }, { code: SYSTEM_ACCOUNTS.AP, credit: receiptValue }] });
    await tx.purchaseOrder.update({ where: { id: purchaseOrderId }, data: { status: fullyReceived ? "FULLY_RECEIVED" : "PARTIALLY_RECEIVED" } }); return rec;
}

router.post("/receipts", async (req, res) => {
  try {
    const receipt = await prisma.$transaction(tx => createGoodsReceipt(tx, req.body, req.user.id), { timeout: 30000 });
    res.json({ ok: true, receipt });
  } catch (e) {
    res.status(400).json({ error: e.message || "Gagal menerima barang" });
  }
});

router.post("/receipts/batch", async (req, res) => {
  try {
    const entries = Array.isArray(req.body.receipts) ? req.body.receipts : [];
    if (!entries.length) throw new Error("Pilih minimal satu Purchase Order untuk diterima");
    const ids = [...new Set(entries.map(entry => String(entry.purchaseOrderId || "")).filter(Boolean))];
    if (ids.length !== entries.length) throw new Error("Daftar Purchase Order penerimaan tidak valid");
    const receipts = await prisma.$transaction(async tx => {
      const orders = await tx.purchaseOrder.findMany({ where: { id: { in: ids } }, select: { id: true, supplierId: true } });
      if (orders.length !== ids.length) throw new Error("Salah satu Purchase Order tidak ditemukan");
      if (new Set(orders.map(order => order.supplierId)).size !== 1) throw new Error("Penerimaan gabungan hanya dapat dibuat untuk supplier yang sama");
      const created = [];
      for (const entry of entries) {
        created.push(await createGoodsReceipt(tx, { ...req.body, purchaseOrderId: entry.purchaseOrderId, items: entry.items, receipts: undefined }, req.user.id));
      }
      return created;
    }, { timeout: 30000 });
    res.json({ ok: true, receipts });
  } catch (e) {
    res.status(400).json({ error: e.message || "Gagal menerima beberapa Purchase Order" });
  }
});
router.post("/bills", async (req, res) => {
  try {
    const { supplierId, invoiceNumber, invoiceDate, dueDate, notes, proofUrl, proofFileName, proofMimeType, proofSize, proofs = [], receiptIds = [], itemIds = [], itemPrices = {}, itemQuantities = {}, repairMovementIds = [] } = req.body;
    const attachments = (Array.isArray(proofs) && proofs.length ? proofs : proofUrl ? [{ url: proofUrl, fileName: proofFileName, mimeType: proofMimeType, size: proofSize }] : []).filter(file => file?.url);
    if (!supplierId || !String(invoiceNumber || "").trim() || !invoiceDate || (!itemIds.length && !repairMovementIds.length) || !attachments.length) throw new Error("Supplier, nomor invoice, tanggal, barang/jasa penerimaan, dan minimal satu lampiran invoice wajib diisi");
    const ids = [...new Set(receiptIds.map(String))];
    const selectedItemIds = new Set(itemIds.map(String));
    const records = await prisma.goodsReceipt.findMany({ where: { id: { in: ids } }, include: { purchaseOrder: true, items: { include: { purchaseOrderItem: { include: { item: true } }, inventoryBatch: { include: { stockUnits: true } }, supplierBillItems: true } } } });
    if (records.length !== ids.length) throw new Error("Sebagian penerimaan barang tidak ditemukan");
    if (records.some(row => row.purchaseOrder.supplierId !== supplierId)) throw new Error("Semua penerimaan harus berasal dari supplier yang sama");
    const lines = records.flatMap(receipt => receipt.items.filter(item => selectedItemIds.has(item.id)).map(item => {
      if (item.condition === "RETURNED_TO_SUPPLIER") throw new Error(`${item.purchaseOrderItem.item.name} sudah diretur ke supplier dan tidak dapat ditagihkan`);
      const billedQty = item.supplierBillItems.reduce((sum, line) => sum + Number(line.qty || 0), 0);
      const availableQty = Math.max(0, Number(item.qty || 0) - billedQty);
      const requestedQty = Number(itemQuantities[item.id] ?? availableQty);
      if (!Number.isFinite(requestedQty) || requestedQty <= 0 || requestedQty > availableQty) throw new Error(`Qty ditagih ${item.purchaseOrderItem.item.name} harus antara 0 dan ${availableQty}`);
      if (!Object.prototype.hasOwnProperty.call(itemPrices, item.id) || itemPrices[item.id] === "") throw new Error(`Harga ${item.purchaseOrderItem.item.name} wajib diisi`);
      const unitPrice = Math.round(Number(itemPrices[item.id]));
      const isRepair = Boolean(item.purchaseOrderItem.partRepairId);
      if (!Number.isFinite(unitPrice) || unitPrice < 0 || (!isRepair && unitPrice === 0)) throw new Error(isRepair ? `Harga perbaikan ${item.purchaseOrderItem.item.name} tidak valid` : `Harga ${item.purchaseOrderItem.item.name} harus lebih dari Rp0`);
      return { receipt, item, qty: requestedQty, unitPrice, amount: Math.round(requestedQty * unitPrice) };
    }));
    if (lines.length !== selectedItemIds.size) throw new Error("Sebagian barang penerimaan tidak ditemukan atau tidak sesuai supplier");
    const repairIds = [...new Set(repairMovementIds.map(String))];
    const repairMovements = await prisma.stockMovement.findMany({
      where: { id: { in: repairIds }, type: "IN", stockUnitId: null, note: { startsWith: "REPAIR_SECOND_OF:" } },
      include: { item: true, supplierBillRepairItem: true },
    });
    if (repairMovements.length !== repairIds.length) throw new Error("Sebagian penerimaan jasa perbaikan tidak ditemukan");
    for (const movement of repairMovements) {
      if (movement.supplierBillRepairItem) throw new Error(`${movement.item.name} sudah pernah ditagihkan`);
      const sourceId = String(movement.note || "").match(/^REPAIR_SECOND_OF:([^ ·]+)/)?.[1];
      const source = sourceId ? await prisma.stockMovement.findUnique({ where: { id: sourceId }, select: { note: true } }) : null;
      const sourceSupplierId = String(source?.note || "").match(/REPAIR_SUPPLIER_ID:([^ ·]+)/)?.[1];
      if (!sourceSupplierId || sourceSupplierId !== supplierId) throw new Error(`${movement.item.name} tidak berasal dari supplier yang dipilih`);
    }
    const repairLines = repairMovements.map(movement => ({ movement, qty: Number(movement.qty), unitPrice: Number(movement.unitPrice || 0), amount: Number(movement.totalCost || 0) }));
    if (repairLines.some(line => line.unitPrice <= 0 || line.amount <= 0)) throw new Error("Harga penerimaan jasa perbaikan tidak valid");
    const goodsTotal = lines.reduce((sum, line) => sum + line.amount, 0);
    const repairTotal = repairLines.reduce((sum, line) => sum + line.amount, 0);
    const total = goodsTotal + repairTotal;
    const allocations = records.map(receipt => ({ receiptId: receipt.id, amount: lines.filter(line => line.receipt.id === receipt.id).reduce((sum, line) => sum + line.amount, 0) })).filter(allocation => allocation.amount > 0);
    const previousValue = lines.reduce((sum, line) => sum + line.qty * Number(line.item.purchaseOrderItem.unitPrice || 0), 0);
    const bill = await prisma.$transaction(async tx => {
      const primaryProof = attachments[0];
      const created = await tx.supplierBill.create({ data: { number: await nextDailyNumber(tx, "supplierBill", "BILL"), supplierId, invoiceNumber: String(invoiceNumber).trim(), invoiceDate: new Date(invoiceDate), dueDate: dueDate ? new Date(dueDate) : null, amount: total, status: total === 0 ? "PAID" : "OPEN", notes: notes || null, proofUrl: primaryProof.url, proofFileName: primaryProof.fileName || null, proofMimeType: primaryProof.mimeType || null, proofSize: Number.isFinite(Number(primaryProof.size)) ? Number(primaryProof.size) : null, createdById: req.user.id, receipts: { create: allocations }, items: { create: lines.map(line => ({ receiptItemId: line.item.id, qty: line.qty, unitPrice: line.unitPrice, amount: line.amount })) }, repairItems: { create: repairLines.map(line => ({ movementId: line.movement.id, qty: line.qty, unitPrice: line.unitPrice, amount: line.amount })) }, attachments: { create: attachments.map(file => ({ url: file.url, fileName: file.fileName || null, mimeType: file.mimeType || null, size: Number.isFinite(Number(file.size)) ? Number(file.size) : null })) } } });
      for (const line of lines) {
        await tx.purchaseOrderItem.update({ where: { id: line.item.purchaseOrderItemId }, data: { unitPrice: line.unitPrice } });
        if (line.item.purchaseOrderItem.partRepairId) {
          await tx.partRepair.update({ where: { id: line.item.purchaseOrderItem.partRepairId }, data: { cost: line.unitPrice } });
        }
        if (line.item.inventoryBatch) {
          await backfillLegacyConsumptionAllocations(tx, line.item.inventoryBatch);
          await tx.inventoryBatch.update({ where: { id: line.item.inventoryBatch.id }, data: { unitPrice: line.unitPrice } });
          await tx.stockUnit.updateMany({ where: { inventoryBatchId: line.item.inventoryBatch.id }, data: { purchasePrice: line.unitPrice } });
          await tx.truckSparePartAssignment.updateMany({ where: { stockUnit: { inventoryBatchId: line.item.inventoryBatch.id } }, data: { installCost: line.unitPrice } });
          await refreshAllocatedMovementCosts(tx, line.item.inventoryBatch.id);
        }
        await tx.stockMovement.updateMany({ where: { note: `Penerimaan ${line.receipt.number}`, itemId: line.item.purchaseOrderItem.itemId }, data: { unitPrice: line.unitPrice, totalCost: Math.round(Number(line.item.qty) * line.unitPrice) } });
      }
      const difference = goodsTotal - previousValue;
      if (difference !== 0) await postJournal(tx, { date: new Date(invoiceDate), description: `Tagihan supplier ${invoiceNumber}`, sourceType: "SUPPLIER_BILL", sourceId: created.id, createdById: req.user.id, lines: difference > 0 ? [{ code: SYSTEM_ACCOUNTS.INVENTORY, debit: difference }, { code: SYSTEM_ACCOUNTS.AP, credit: difference }] : [{ code: SYSTEM_ACCOUNTS.AP, debit: Math.abs(difference) }, { code: SYSTEM_ACCOUNTS.INVENTORY, credit: Math.abs(difference) }] });
      if (repairTotal > 0) await postJournal(tx, { date: new Date(invoiceDate), description: `Jasa perbaikan supplier ${invoiceNumber}`, sourceType: "SUPPLIER_BILL_REPAIR", sourceId: created.id, createdById: req.user.id, lines: [{ code: SYSTEM_ACCOUNTS.EXPENSE, debit: repairTotal }, { code: SYSTEM_ACCOUNTS.AP, credit: repairTotal }] });
      return tx.supplierBill.findUnique({ where: { id: created.id }, include: { supplier: true, receipts: { include: { receipt: { include: { purchaseOrder: true } } } }, items: true, repairItems: true, attachments: true, payments: true } });
    });
    res.status(201).json({ ok: true, bill });
  } catch (e) { res.status(e.code === "P2002" ? 409 : 400).json({ error: e.code === "P2002" ? "Nomor invoice supplier sudah pernah dicatat" : e.message || "Gagal mencatat tagihan supplier" }); }
});

router.post("/payments", async (req, res) => {
  const bill = await prisma.supplierBill.findUnique({ where: { id: req.body.supplierBillId }, include: { payments: true } });
  if (!bill || ["PAID", "VOID"].includes(bill.status)) return res.status(400).json({ error: "Tagihan supplier tidak tersedia untuk dibayar" });
  const committed = bill.payments.filter(p => p.status !== "UNPAID").reduce((sum, p) => sum + p.amount, 0);
  const amount = Math.round(Number(req.body.amount));
  if (!amount || amount <= 0 || amount > bill.amount - committed) return res.status(400).json({ error: "Jumlah pembayaran melebihi sisa tagihan supplier" });
  if (!req.body.proofUrl) return res.status(400).json({ error: "Bukti pembayaran wajib dilampirkan" });
  const payment = await prisma.$transaction(async tx => {
    const created = await tx.purchasePayment.create({ data: { number: await nextDailyNumber(tx, "purchasePayment", "PAY"), supplierBillId: bill.id, amount, method: req.body.method, reference: req.body.reference, proofUrl: req.body.proofUrl, proofFileName: req.body.proofFileName || null, proofMimeType: req.body.proofMimeType || null, proofSize: Number.isFinite(Number(req.body.proofSize)) ? Number(req.body.proofSize) : null, createdById: req.user.id } });
    await tx.supplierBill.update({ where: { id: bill.id }, data: { status: "WAITING_PAYMENT_APPROVAL" } });
    return created;
  });
  res.json({ ok: true, payment });
});
router.patch("/payments/:id/approve", requireRole("OWNER", "ADMIN"), async (req, res) => {
  const payment = await prisma.$transaction(async tx => {
    const current = await tx.purchasePayment.findUnique({ where: { id: req.params.id }, select: { id: true, status: true } });
    if (!current) throw new Error("Pembayaran supplier tidak ditemukan");
    if (current.status === "PAID") throw new Error("Pembayaran supplier sudah disetujui");
    const updated = await tx.purchasePayment.update({ where: { id: req.params.id }, data: { status: "PAID", paidAt: new Date(), approvedAt: new Date(), approvedById: req.user.id } });
    await postJournal(tx, { date: updated.paidAt, description: `Pembayaran supplier ${updated.number}`, sourceType: "SUPPLIER_PAYMENT", sourceId: updated.id, createdById: req.user.id, lines: [{ code: SYSTEM_ACCOUNTS.AP, debit: updated.amount }, { code: cashCode(updated.method), credit: updated.amount }] });
    if (updated.supplierBillId) {
      const bill = await tx.supplierBill.findUnique({ where: { id: updated.supplierBillId }, include: { payments: true } });
      const paid = bill.payments.filter(row => row.status === "PAID").reduce((sum, row) => sum + row.amount, 0);
      await tx.supplierBill.update({ where: { id: bill.id }, data: { status: paid >= bill.amount ? "PAID" : "PARTIALLY_PAID" } });
    }
    await syncSupplierPaymentExpense(tx, updated.id, req.user.id);
    return updated;
  });
  res.json({ ok: true, payment });
});
module.exports = router;
