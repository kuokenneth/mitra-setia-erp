import { useEffect, useId, useMemo, useState } from "react";
import { FiAlertCircle, FiArrowRight, FiCheck, FiCreditCard, FiDownload, FiEye, FiFileText, FiPlus, FiPrinter, FiRefreshCw, FiSearch, FiSend, FiX } from "react-icons/fi";
import { API_BASE, api, getAccessToken, openPrintDocument } from "../api";
import { useAuth } from "../AuthContext";
import { useLiveRefresh } from "../liveUpdates";
import LoadingState from "../components/LoadingState";
import { openProtectedFile } from "../components/ProtectedFile";
import "./Receivables.css";

const rupiah = value => new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(Number(value) || 0);
const tanggal = value => value ? new Date(value).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" }) : "—";
const statusLabel = { DRAFT: "Draft", SENT: "Terkirim", PARTIALLY_PAID: "Dibayar Sebagian", PAID: "Lunas", OVERDUE: "Jatuh Tempo", VOID: "Dibatalkan" };
const initialData = { customers: [], trucks: [], invoices: [], employeeReceivables: [], eligibleOrders: [], eligibleSources: [], stats: { invoiced: 0, received: 0, outstanding: 0, overdue: 0 } };
const afterDays = days => { const d = new Date(); d.setDate(d.getDate() + days); return d.toISOString().slice(0, 10); };
const currentMonth = () => new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Jakarta", year: "numeric", month: "2-digit" }).format(new Date());
const customerKey = source => source?.customerId ? `id:${source.customerId}` : `name:${String(source?.customerName || "").trim().toLocaleLowerCase("id-ID")}`;
const sourcePlateNumbers = source => {
  const plates = source?.type === "ORDER"
    ? (source.order?.tripAllocations?.length
      ? source.order.tripAllocations.map(row => row.trip?.truck?.plateNumber || row.trip?.plateNumberSnap)
      : (source.order?.trips || []).map(trip => trip.truck?.plateNumber || trip.plateNumberSnap))
    : source?.type === "MATERIAL"
      ? (source.invoices || []).map(invoice => invoice.trip?.truck?.plateNumber || invoice.trip?.plateNumberSnap)
      : (source?.trips || []).map(trip => trip.truck?.plateNumber || trip.plateNumberSnap);
  return [...new Set(plates.filter(Boolean))];
};
const materialEvidence = invoices => [...new Map((invoices || []).flatMap(invoice => (invoice.lines || []).flatMap(line => (line.stockAllocations || []).map(allocation => allocation.receipt))).filter(Boolean).map(receipt => [receipt.id, receipt])).values()];
const deliveryEvidence = invoice => {
  const trips = invoice?.singleTripLines?.length
    ? invoice.singleTripLines.map(line => line.trip)
    : invoice?.singleTrip ? [invoice.singleTrip]
      : invoice?.order?.tripAllocations?.length ? invoice.order.tripAllocations.map(row => row.trip)
        : invoice?.order?.trips || [];
  return trips.flatMap(trip => (trip?.arrivalProofs || []).map(proof => ({ ...proof, trip })));
};
const manualLine = type => type === "MATERIAL" ? { date: new Date().toISOString().slice(0,10), truckId: "", documentNo: "", cargoName: "", qty: "", unit: "PCS", rate: "" } : { date: new Date().toISOString().slice(0,10), truckId: "", unloadingDate: "", cargoName: type === "CANGKANG" ? "Cangkang" : "Pupuk", sentPackages: "", sentKg: "", receivedPackages: "", receivedKg: "", billableKg: "", rate: "" };
const manualSubtotal = form => form.lines.reduce((sum, line) => sum + (form.type === "MATERIAL" ? Number(line.qty || 0) : Number(line.billableKg || line.receivedKg || line.sentKg || 0)) * Number(line.rate || 0), 0);
const manualPph23 = form => Math.round(manualSubtotal(form) * Number(form.pph23Rate || 0) / 100);
const invoiceWithoutPph23 = invoice => Math.max(0, Number(invoice?.total || 0) - Number(invoice?.discount || 0));
const paymentNet = payment => Math.max(0, Number(payment?.amount || 0) - Number(payment?.pph23Amount || 0) - Number(payment?.claimAmount || 0) - Number(payment?.adminFee || 0));
const emptyManualForm = () => ({ type: "FERTILIZER", customerId: "", dueAt: afterDays(30), title: "Rincian ongkos angkut pupuk", fromText: "", toText: "", reference: "", receipt: "", taxRate: "", pph23Rate: 2, claim: 0, notes: "", lines: [manualLine("FERTILIZER")] });

function TruckSearch({ trucks, value, onChange }) {
  const listId = useId();
  const selected = trucks.find(truck => truck.id === value);
  const truckLabel = truck => `${truck.plateNumber}${truck.brand || truck.model ? ` · ${[truck.brand, truck.model].filter(Boolean).join(" ")}` : ""}`;
  const [query, setQuery] = useState(selected ? truckLabel(selected) : "");
  useEffect(() => {
    // Keep typed search text aligned when the selected truck changes externally.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setQuery(selected ? truckLabel(selected) : "");
  }, [selected]);
  return <div className="ar-truck-search">
    <input required list={listId} value={query} placeholder="Cari no. polisi..." autoComplete="off" onChange={event => { const text = event.target.value; const match = trucks.find(truck => truckLabel(truck).toLocaleLowerCase("id-ID") === text.trim().toLocaleLowerCase("id-ID")); setQuery(text); onChange(match?.id || ""); }}/>
    <datalist id={listId}>{trucks.map(truck => <option key={truck.id} value={truckLabel(truck)}/>)}</datalist>
  </div>;
}

export default function Receivables() {
  const { user } = useAuth();
  const canVoid = ["OWNER", "ADMIN"].includes(user?.role);
  const [data, setData] = useState(initialData);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState("ALL");
  const [query, setQuery] = useState("");
  const [invoicePage, setInvoicePage] = useState(1);
  const [modal, setModal] = useState("");
  const [selected, setSelected] = useState(null);
  const [busy, setBusy] = useState(false);
  const [reportMonth, setReportMonth] = useState(currentMonth);
  const [reportBusy, setReportBusy] = useState(false);
  const [exportBusy, setExportBusy] = useState(false);
  const [employeeView, setEmployeeView] = useState(false);
  const [employeeDetail, setEmployeeDetail] = useState(null);
  const [invoiceForm, setInvoiceForm] = useState({ billingCustomerKey: "", sourceKey: "", sourceType: "ORDER", orderId: "", orderTripIds: [], customerId: "", materialInvoiceIds: [], materialLineAmounts: {}, singleTripId: "", singleTripIds: [], ratePerKg: "", tolerancePercent: "0", customerName: "", customerPhone: "", billingAddress: "", receipt: "", dueAt: afterDays(30), contractSubtotal: "", taxRate: "", pph23Rate: 2, claim: 0, notes: "" });
  const [paymentForm, setPaymentForm] = useState({ amount: "", claimAmount: "", adminFee: "", method: "BANK_TRANSFER", reference: "", receivedAt: new Date().toISOString().slice(0, 10), notes: "" });
  const [batchPaymentForm, setBatchPaymentForm] = useState({ customerKey: "", invoices: {}, method: "BANK_TRANSFER", reference: "", receivedAt: new Date().toISOString().slice(0, 10), notes: "" });
  const [employeePayment, setEmployeePayment] = useState(null);
  const [pricingForm, setPricingForm] = useState({ contractSubtotal: "", ratePerKg: "", tolerancePercent: "0", materialLineRates: {}, receipt: "", taxRate: "", pph23Rate: 2, claim: 0, dueAt: afterDays(30), notes: "" });
  const [manualForm, setManualForm] = useState(emptyManualForm);

  async function load() {
    setLoading(true); setError("");
    try { setData(await api("/receivables/overview")); }
    catch (err) { setError(err.message || "Gagal memuat piutang"); }
    finally { setLoading(false); }
  }
  useEffect(() => { load(); }, []);
  useLiveRefresh(load);

  const rows = useMemo(() => data.invoices.filter(invoice => {
    const matchesStatus = filter === "ALL" || invoice.displayStatus === filter;
    const needle = query.trim().toLowerCase();
    const matchesQuery = !needle || [invoice.number, invoice.customerName, invoice.order?.orderNo, invoice.manualData?.receipt].some(value => String(value || "").toLowerCase().includes(needle));
    return matchesStatus && matchesQuery;
  }), [data.invoices, filter, query]);
  const invoicePageSize = 10;
  const invoicePageCount = Math.max(1, Math.ceil(rows.length / invoicePageSize));
  const activeInvoicePage = Math.min(invoicePage, invoicePageCount);
  const pagedInvoiceRows = rows.slice((activeInvoicePage - 1) * invoicePageSize, activeInvoicePage * invoicePageSize);

  function openInvoice() {
    setInvoiceForm({ billingCustomerKey: "", sourceKey: "", sourceType: "ORDER", orderId: "", orderTripIds: [], customerId: "", materialInvoiceIds: [], materialLineAmounts: {}, singleTripId: "", singleTripIds: [], ratePerKg: "", tolerancePercent: "0", customerName: "", customerPhone: "", billingAddress: "", receipt: "", dueAt: afterDays(30), contractSubtotal: "", taxRate: "", pph23Rate: 2, claim: 0, notes: "" });
    setError(""); setModal("invoice");
  }
  function openManualInvoice() { setManualForm(emptyManualForm()); setError(""); setModal("manual-invoice"); }
  function openEmployeeDetail(row) { setEmployeeDetail(row); setModal("employee-detail"); }
  function changeManualType(type) { setManualForm(form => ({ ...form, type, title: type === "FERTILIZER" ? "Rincian ongkos angkut pupuk" : type === "CANGKANG" ? "Rekap ongkos angkut cangkang" : "Rincian ongkos angkut ambang / material", lines: [manualLine(type)] })); }
  function updateManualLine(index, key, value) { setManualForm(form => ({ ...form, lines: form.lines.map((line, i) => i === index ? { ...line, [key]: value } : line) })); }
  async function createManualInvoice(event) { event.preventDefault(); setBusy(true); setError(""); try { const lines = manualForm.lines.map(line => { const quantity = manualForm.type === "MATERIAL" ? Number(line.qty || 0) : Number(line.billableKg || line.receivedKg || line.sentKg || 0); return { ...line, billableKg: quantity, amount: Math.round(quantity * Number(line.rate || 0)) }; }); await api("/receivables/manual-invoices", { method: "POST", body: JSON.stringify({ ...manualForm, lines }) }); setModal(""); await load(); } catch (err) { setError(err.message); } finally { setBusy(false); } }
  function chooseCustomer(key) {
    const customer = data.customers.find(item => `id:${item.id}` === key);
    const source = data.eligibleSources.find(item => customerKey(item) === key);
    setInvoiceForm(form => ({ ...form, billingCustomerKey: key, sourceKey: "", sourceType: "ORDER", orderId: "", orderTripIds: [], customerId: customer?.id || source?.customerId || "", materialInvoiceIds: [], materialLineAmounts: {}, singleTripId: "", singleTripIds: [], ratePerKg: "", tolerancePercent: String(customer?.cargoLossTolerancePercent ?? 0), customerName: customer?.name || source?.customerName || "", customerPhone: customer?.phone || source?.customerPhone || "", billingAddress: customer?.address || source?.billingAddress || "", contractSubtotal: "" }));
  }
  function chooseOrder(sourceKey) {
    const source = data.eligibleSources.find(item => `${item.type}:${item.id}` === sourceKey);
    setInvoiceForm(form => ({ ...form, sourceKey, sourceType: source?.type || "ORDER", orderId: source?.type === "ORDER" ? source.id : "", orderTripIds: source?.type === "ORDER" ? (source.order?.availableLoads || []).map(load => load.id) : [], customerId: source?.customerId || "", materialInvoiceIds: source?.materialInvoiceIds || [], materialLineAmounts: {}, singleTripId: source?.singleTripId || "", singleTripIds: source?.singleTripIds || [], ratePerKg: "", customerName: source?.customerName || "", customerPhone: source?.customerPhone || "", billingAddress: source?.billingAddress || "", contractSubtotal: ["MATERIAL", "SINGLE_TRIP_GROUP"].includes(source?.type) ? "0" : "" }));
  }
  async function createInvoice(event) {
    event.preventDefault(); setBusy(true); setError("");
    try { await api("/receivables/invoices", { method: "POST", body: JSON.stringify(invoiceForm) }); setModal(""); await load(); }
    catch (err) { setError(err.message); }
    finally { setBusy(false); }
  }
  async function sendInvoice(invoice) {
    setBusy(true); setError("");
    try {
      const result = await api(`/receivables/invoices/${invoice.id}/send`, { method: "PATCH" });
      setData(current => ({ ...current, invoices: current.invoices.map(item => item.id === result.invoice.id ? result.invoice : item) }));
    }
    catch (err) { setError(err.message); }
    finally { setBusy(false); }
  }
  function openInvoiceDetail(invoice) {
    const rates = {};
    (invoice.materialInvoices || []).flatMap(row => row.lines || []).forEach(line => { rates[line.id] = line.qty > 0 && line.totalAmount > 0 ? String(Math.round(line.totalAmount / line.qty)) : ""; });
    setSelected(invoice);
    setPricingForm({ contractSubtotal: invoice.contractSubtotal > 0 ? String(invoice.contractSubtotal) : "", ratePerKg: invoice.singleTripLines?.[0]?.ratePerKg > 0 ? String(invoice.singleTripLines[0].ratePerKg) : invoice.ratePerKg > 0 ? String(invoice.ratePerKg) : "", tolerancePercent: String(invoice.tolerancePercent ?? invoice.customer?.cargoLossTolerancePercent ?? 0), materialLineRates: rates, receipt: invoice.manualData?.receipt || "", taxRate: invoice.manualData?.taxRate ?? "", pph23Rate: invoice.manualData?.pph23Rate ?? 2, claim: invoice.manualData?.claim || 0, dueAt: String(invoice.dueAt || "").slice(0, 10) || afterDays(30), notes: invoice.notes || "" });
    setError(""); setModal("invoice-detail");
  }
  function openInvoiceView(invoice) {
    setSelected(invoice);
    setError("");
    setModal("invoice-view");
  }
  async function saveInvoicePricing(event) {
    event.preventDefault(); setBusy(true); setError("");
    try { await api(`/receivables/invoices/${selected.id}/draft`, { method: "PATCH", body: JSON.stringify(pricingForm) }); setModal(""); setSelected(null); await load(); }
    catch (err) { setError(err.message); }
    finally { setBusy(false); }
  }
  function openPayment(invoice) {
    openBatchPayment(invoice);
  }
  function openBatchPayment(invoice = null) {
    setBatchPaymentForm({ customerKey: invoice ? customerKey(invoice) : "", invoices: invoice ? { [invoice.id]: { selected: true, amount: String(invoice.balance), claimAmount: "", adminFee: "" } } : {}, method: "BANK_TRANSFER", reference: "", receivedAt: new Date().toISOString().slice(0, 10), notes: "" });
    setError(""); setModal("batch-payment");
  }
  function chooseBatchCustomer(key) { setBatchPaymentForm(form => ({ ...form, customerKey: key, invoices: {} })); }
  function updateBatchInvoice(invoiceId, field, value) {
    const invoice = data.invoices.find(row => row.id === invoiceId);
    setBatchPaymentForm(form => ({ ...form, invoices: { ...form.invoices, [invoiceId]: { selected: false, amount: String(invoice?.balance || ""), claimAmount: "", adminFee: "", ...(form.invoices[invoiceId] || {}), [field]: value } } }));
  }
  async function saveBatchPayment(event) {
    event.preventDefault(); setBusy(true); setError("");
    try {
      const invoices = Object.entries(batchPaymentForm.invoices).filter(([, value]) => value.selected).map(([invoiceId, value]) => ({ invoiceId, amount: value.amount, claimAmount: value.claimAmount || 0, adminFee: value.adminFee || 0 }));
      await api("/receivables/payments/batch", { method: "POST", body: JSON.stringify({ ...batchPaymentForm, invoices }) });
      setModal(""); await load();
    } catch (err) { setError(err.message || "Gagal mencatat pembayaran gabungan"); }
    finally { setBusy(false); }
  }
  function openEmployeePayment(row) {
    setEmployeePayment(row); setPaymentForm({ amount: String(row.balance), method: "BANK_TRANSFER", reference: "", receivedAt: new Date().toISOString().slice(0, 10), notes: "" }); setError(""); setModal("employee-payment");
  }
  async function saveEmployeePayment(event) {
    event.preventDefault(); setBusy(true); setError("");
    const printPopup = window.open("", "_blank");
    if (printPopup) { printPopup.document.open(); printPopup.document.write('<!doctype html><html><body style="font-family:Arial,sans-serif;padding:28px;color:#385447">Menyiapkan bukti penerimaan kas…</body></html>'); printPopup.document.close(); }
    try { const kind = employeePayment.employee.kind || "USER"; const result = await api(`/receivables/employee-debtors/${kind}/${employeePayment.employee.id}/payments`, { method: "POST", body: JSON.stringify(paymentForm) }); setModal(""); setEmployeePayment(null); await load(); if (result.payment?.id) await openPrintDocument(`/receivables/employee-payments/${result.payment.id}/voucher-print`, printPopup); }
    catch (err) { printPopup?.close(); setError(err.message); }
    finally { setBusy(false); }
  }
  async function voidInvoice(invoice) {
    if (!window.confirm(`Batalkan ${invoice.number}?`)) return;
    setBusy(true); setError("");
    try { await api(`/receivables/invoices/${invoice.id}/void`, { method: "PATCH" }); await load(); }
    catch (err) { setError(err.message); }
    finally { setBusy(false); }
  }

  async function printInvoice(invoice) {
    setError("");
    try { await openPrintDocument(`/receivables/invoices/${invoice.id}/print`); }
    catch (err) { setError(err.message || "Gagal membuka invoice"); }
  }

  async function printReport() {
    if (!reportMonth) return setError("Pilih periode laporan terlebih dahulu");
    setReportBusy(true); setError("");
    try { await openPrintDocument(`/receivables/report?month=${encodeURIComponent(reportMonth)}`); }
    catch (err) { setError(err.message || "Gagal membuka laporan piutang"); }
    finally { setReportBusy(false); }
  }

  async function printOutstandingReport() {
    setReportBusy(true); setError("");
    try { await openPrintDocument("/receivables/report?scope=outstanding"); }
    catch (err) { setError(err.message || "Gagal membuka laporan piutang belum bayar"); }
    finally { setReportBusy(false); }
  }

  async function printMonthlyCashReceipts() {
    if (!reportMonth) return setError("Pilih periode penerimaan terlebih dahulu");
    setReportBusy(true); setError("");
    try { await openPrintDocument(`/receivables/cash-receipts/vouchers-print?month=${encodeURIComponent(reportMonth)}`); }
    catch (err) { setError(err.message || "Gagal membuka bukti penerimaan kas"); }
    finally { setReportBusy(false); }
  }

  async function exportReceivables() {
    if (!reportMonth) return setError("Pilih periode export terlebih dahulu");
    setExportBusy(true); setError("");
    try {
      const token = getAccessToken();
      const response = await fetch(`${API_BASE}/receivables/export?month=${encodeURIComponent(reportMonth)}`, { credentials: "include", headers: token ? { Authorization: `Bearer ${token}` } : {} });
      if (!response.ok) throw new Error(await response.text() || "Gagal mengekspor piutang");
      const data = await response.arrayBuffer();
      const signature = new Uint8Array(data, 0, Math.min(4, data.byteLength));
      if (!(signature.length === 4 && signature[0] === 0x50 && signature[1] === 0x4b && signature[2] === 0x03 && signature[3] === 0x04)) throw new Error("File Excel yang diterima tidak valid");
      const disposition = response.headers.get("content-disposition") || "";
      const filename = disposition.match(/filename="?([^";]+)"?/i)?.[1] || `piutang-${reportMonth}.xlsx`;
      const url = URL.createObjectURL(new Blob([data], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }));
      const anchor = document.createElement("a"); anchor.href = url; anchor.download = filename; document.body.appendChild(anchor); anchor.click(); anchor.remove(); URL.revokeObjectURL(url);
    } catch (err) { setError(err.message || "Gagal mengekspor piutang"); }
    finally { setExportBusy(false); }
  }

  function toggleMaterialInvoice(id) {
    setInvoiceForm(form => ({ ...form, materialInvoiceIds: form.materialInvoiceIds.includes(id) ? form.materialInvoiceIds.filter(item => item !== id) : [...form.materialInvoiceIds, id] }));
  }
  function toggleSingleTrip(id) {
    setInvoiceForm(form => ({ ...form, singleTripIds: form.singleTripIds.includes(id) ? form.singleTripIds.filter(item => item !== id) : [...form.singleTripIds, id] }));
  }
  function toggleOrderTrip(id) {
    setInvoiceForm(form => ({ ...form, orderTripIds: form.orderTripIds.includes(id) ? form.orderTripIds.filter(item => item !== id) : [...form.orderTripIds, id] }));
  }

  const selectedSource = data.eligibleSources?.find(source => `${source.type}:${source.id}` === invoiceForm.sourceKey);
  const billingCustomers = useMemo(() => {
    const values = new Map();
    (data.customers || []).forEach(customer => values.set(`id:${customer.id}`, { key: `id:${customer.id}`, name: customer.name, count: 0 }));
    (data.eligibleSources || []).forEach(source => { const key = customerKey(source); if (source.customerName && !values.has(key)) values.set(key, { key, name: source.customerName, count: 0 }); values.get(key) && (values.get(key).count += 1); });
    return [...values.values()].sort((a, b) => a.name.localeCompare(b.name, "id"));
  }, [data.customers, data.eligibleSources]);
  const customerSources = (data.eligibleSources || []).filter(source => customerKey(source) === invoiceForm.billingCustomerKey);
  const invoiceOrder = selectedSource?.order;
  const selectedOrderLoads = selectedSource?.type === "ORDER" ? (invoiceOrder?.availableLoads || []).filter(load => invoiceForm.orderTripIds.includes(load.id)) : [];
  const selectedOrderWeightKg = selectedOrderLoads.reduce((sum, load) => sum + Number(load.quantityKg || 0), 0);
  const plannedQuantity = selectedSource?.type === "ORDER" ? selectedOrderWeightKg : Number(invoiceOrder?.shipment?.readyToBillKg || invoiceOrder?.shipment?.planned || invoiceOrder?.qty || 0);
  const deliveredQuantity = selectedSource?.type === "ORDER" ? selectedOrderWeightKg : Number(invoiceOrder?.shipment?.readyToBillKg || invoiceOrder?.shipment?.delivered || 0);
  const billableRatio = plannedQuantity > 0 ? Math.min(1, Math.max(0, deliveredQuantity / plannedQuantity)) : 1;
  const billableSubtotal = Math.round(Number(invoiceForm.contractSubtotal || 0) * billableRatio);
  const selectedMaterialInvoices = selectedSource?.type === "MATERIAL"
    ? (selectedSource.invoices || []).filter(invoice => invoiceForm.materialInvoiceIds.includes(invoice.id))
    : [];
  const selectedMaterialSubtotal = selectedMaterialInvoices.flatMap(invoice => invoice.lines || []).reduce((sum, line) => sum + (invoiceForm.materialLineAmounts[line.id] !== undefined ? Number(line.qty || 0) * Number(invoiceForm.materialLineAmounts[line.id] || 0) : Number(line.totalAmount || 0)), 0);
  const materialSubtotal = selectedSource?.type === "MATERIAL" ? selectedMaterialSubtotal : Number(invoiceOrder?.materialSubtotal ?? 0);
  const selectedSingleTrips = selectedSource?.type === "SINGLE_TRIP_GROUP" ? (selectedSource.trips || []).filter(trip => invoiceForm.singleTripIds.includes(trip.id)) : [];
  const tripWeightKg = trip => String(trip.unitSnap || "").toUpperCase() === "TON" ? Number(trip.qtyActual || 0) * 1000 : Number(trip.qtyActual || 0);
  const selectedSingleWeightKg = selectedSingleTrips.reduce((sum, trip) => sum + tripWeightKg(trip), 0);
  const singleTripSubtotal = Math.round(selectedSingleWeightKg * Number(invoiceForm.ratePerKg || 0));
  const draftSubtotal = selectedSource?.type === "SINGLE_TRIP_GROUP" ? singleTripSubtotal : billableSubtotal + materialSubtotal;
  const pph23 = Math.round(draftSubtotal * Number(invoiceForm.pph23Rate || 0) / 100);
  const total = draftSubtotal - Math.round(draftSubtotal * Number(invoiceForm.taxRate || 0) / 100);
  const invoiceBlockReason = !invoiceForm.billingCustomerKey ? "Pilih customer tagihan terlebih dahulu" : !selectedSource ? "Pilih sumber tagihan customer ini" : selectedSource.type === "ORDER" && !invoiceForm.orderTripIds.length ? "Pilih minimal satu armada yang hendak ditagih" : selectedSource.type === "MATERIAL" && !invoiceForm.materialInvoiceIds.length ? "Pilih minimal satu Faktur Muatan" : selectedSource.type === "SINGLE_TRIP_GROUP" && !invoiceForm.singleTripIds.length ? "Pilih minimal satu Trip Tunggal" : "";
  const canSaveInvoice = !busy && !invoiceBlockReason;
  const safeEmployeeReceivables = (data.employeeReceivables || []).map((row, index) => ({
    ...row,
    employee: row?.employee || { id: `unknown-${index}`, name: "Data orang tidak tersedia", email: "", phone: "", kind: "UNKNOWN" },
    expenses: Array.isArray(row?.expenses) ? row.expenses : [],
    payments: Array.isArray(row?.payments) ? row.payments : [],
  }));
  const employeeReceivableStats = safeEmployeeReceivables.reduce((totals, row) => ({ employees: totals.employees + 1, transactions: totals.transactions + row.expenses.length, total: totals.total + Number(row.total || 0), paid: totals.paid + Number(row.paid || 0), balance: totals.balance + Number(row.balance || 0) }), { employees: 0, transactions: 0, total: 0, paid: 0, balance: 0 });
  const employeeQuery = query.trim().toLocaleLowerCase("id-ID");
  const filteredEmployeeReceivables = safeEmployeeReceivables.filter(row => !employeeQuery || [row.employee.name, row.employee.email, row.employee.phone, row.expenses.map(expense => expense?.reason)].flat(Infinity).filter(Boolean).join(" ").toLocaleLowerCase("id-ID").includes(employeeQuery));
  const batchEligibleInvoices = data.invoices.filter(invoice => ["SENT", "PARTIALLY_PAID"].includes(invoice.status));
  const batchCustomers = [...new Map(batchEligibleInvoices.map(invoice => [customerKey(invoice), { key: customerKey(invoice), name: invoice.customerName }])).values()].sort((a, b) => a.name.localeCompare(b.name, "id"));
  const batchCustomerInvoices = batchEligibleInvoices.filter(invoice => customerKey(invoice) === batchPaymentForm.customerKey);
  const batchSelectedInvoices = batchCustomerInvoices.filter(invoice => batchPaymentForm.invoices[invoice.id]?.selected);
  const batchPaymentPph = invoice => { const input = batchPaymentForm.invoices[invoice.id] || {}; const amount = Number(input.amount || 0); const remaining = Math.max(0, Number(invoice.discount || 0) - Number(invoice.pph23Paid || 0)); return amount === Number(invoice.balance) ? remaining : Math.min(remaining, Math.round(Number(invoice.discount || 0) * amount / Math.max(1, Number(invoice.total || 0)))); };
  const batchTotals = batchSelectedInvoices.reduce((totals, invoice) => { const input = batchPaymentForm.invoices[invoice.id] || {}; const gross = Number(input.amount || 0); const pph = batchPaymentPph(invoice); const claim = Number(input.claimAmount || 0); const admin = Number(input.adminFee || 0); return { gross: totals.gross + gross, pph: totals.pph + pph, claim: totals.claim + claim, admin: totals.admin + admin, cash: totals.cash + Math.max(0, gross - pph - claim - admin) }; }, { gross: 0, pph: 0, claim: 0, admin: 0, cash: 0 });
  const batchHasInvalidDeduction = batchSelectedInvoices.some(invoice => { const input = batchPaymentForm.invoices[invoice.id] || {}; const amount = Number(input.amount || 0); return amount <= 0 || amount > Number(invoice.balance || 0) || batchPaymentPph(invoice) + Number(input.claimAmount || 0) + Number(input.adminFee || 0) > amount; });
  return <div className="ar-page">
    <header className="ar-head"><div className="ar-head-copy"><span className="ar-eyebrow">KEUANGAN · PIUTANG</span><h1>{employeeView ? "Piutang Karyawan" : "Piutang Pelanggan"}</h1><p>{employeeView ? "Daftar karyawan yang masih memiliki utang beserta saldo dan pembayarannya." : "Pantau invoice pelanggan, pembayaran, dan sisa tagihan."}</p></div><div className="ar-head-side">{!employeeView && <><span><small>Sumber siap ditagih</small><strong>{data.eligibleSources?.length || 0}</strong></span><button className="ar-primary ar-create-invoice ar-manual-button" onClick={openManualInvoice}><FiPlus/> Tagihan Tunggal</button><button className="ar-primary ar-create-invoice" onClick={openInvoice}><FiPlus/> Buat Draft Invoice</button></>}<button className="ar-primary ar-create-invoice ar-manual-button ar-employee-switch" onClick={() => setEmployeeView(value => !value)}><FiCreditCard/> {employeeView ? "Piutang Pelanggan" : "Piutang Karyawan"}</button></div></header>
    {!employeeView ? <>
    <section className="ar-stats">
      <article className="billed"><i>01</i><div><span>Total Ditagih</span><strong>{rupiah(data.stats.invoiced)}</strong><small>Seluruh invoice aktif</small></div></article>
      <article className="received"><i>02</i><div><span>Kas Masuk</span><strong>{rupiah(data.stats.received)}</strong><small>Setelah seluruh potongan</small></div></article>
      <article className="outstanding"><i>03</i><div><span>Sisa Piutang</span><strong>{rupiah(data.stats.outstanding)}</strong><small>Belum dilunasi</small></div></article>
      <article className={`overdue ${data.stats.overdue ? "danger" : ""}`}><i>04</i><div><span>Jatuh Tempo</span><strong>{rupiah(data.stats.overdue)}</strong><small>Perlu ditindaklanjuti</small></div></article>
    </section>
    </> : <section className="ar-stats ar-employee-stats">
      <article><i>01</i><div><span>Karyawan Berutang</span><strong>{employeeReceivableStats.employees}</strong><small>{employeeReceivableStats.transactions} transaksi tercatat</small></div></article>
      <article><i>02</i><div><span>Total Piutang</span><strong>{rupiah(employeeReceivableStats.total)}</strong><small>Seluruh pinjaman karyawan</small></div></article>
      <article className="received"><i>03</i><div><span>Sudah Dibayar</span><strong>{rupiah(employeeReceivableStats.paid)}</strong><small>Pembayaran yang diterima</small></div></article>
      <article className="outstanding"><i>04</i><div><span>Sisa Piutang</span><strong>{rupiah(employeeReceivableStats.balance)}</strong><small>Masih harus ditagih</small></div></article>
    </section>}
    {error && <div className="ar-alert"><FiAlertCircle/><span>{error}</span><button onClick={() => setError("")}><FiX/></button></div>}
    {employeeView ? <section className="ar-panel ar-employee-panel">
      <div className="ar-panel-heading"><div><span>DAFTAR PIUTANG</span><h2>Saldo piutang per karyawan</h2><p>{filteredEmployeeReceivables.length} dari {safeEmployeeReceivables.length} karyawan ditampilkan · tanpa jatuh tempo</p></div></div>
      <div className="ar-employee-tools"><label><FiSearch aria-hidden="true"/><input className="ar-employee-search-input" aria-label="Cari piutang karyawan" value={query} onChange={event => setQuery(event.target.value)} placeholder="Cari nama, email, atau keterangan piutang…"/></label><button className="ar-refresh" onClick={load} aria-label="Muat ulang"><FiRefreshCw className={loading ? "ar-spin" : ""}/></button></div>
      <div className={`ar-table-wrap ${loading && !filteredEmployeeReceivables.length ? "initial-loading" : ""}`}>{loading && !filteredEmployeeReceivables.length && <LoadingState label="Memuat piutang karyawan" note="Menghitung transaksi, pembayaran, dan sisa saldo…" rows={4}/>}<table className="ar-invoice-table ar-employee-table"><colgroup><col className="employee"/><col className="count"/><col className="money"/><col className="money"/><col className="balance"/><col className="actions"/></colgroup><thead><tr><th>Karyawan / Orang</th><th>Jumlah Transaksi</th><th>Total Piutang</th><th>Sudah Dibayar</th><th>Sisa</th><th>Tindakan</th></tr></thead><tbody>{filteredEmployeeReceivables.map(row => <tr key={`${row.employee.kind || "USER"}:${row.employee.id}`} className="ar-clickable-row" tabIndex="0" role="button" aria-label={`Lihat rincian piutang ${row.employee.name || "karyawan"}`} onClick={() => openEmployeeDetail(row)} onKeyDown={event => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); openEmployeeDetail(row); } }}><td data-label="Karyawan / Orang" className="ar-customer-cell"><b>{row.employee.name || "Tanpa nama"}</b><small>{row.employee.email || row.employee.phone || "Kontak tanpa akun ERP"}</small></td><td data-label="Jumlah Transaksi"><span className="ar-employee-count">{row.expenses.length}</span> pengeluaran</td><td data-label="Total Piutang" className="ar-money-cell">{rupiah(row.total)}</td><td data-label="Sudah Dibayar" className="ar-money-cell paid">{rupiah(row.paid)}</td><td data-label="Sisa" className="ar-money-cell ar-balance-cell"><b>{rupiah(row.balance)}</b></td><td data-label="Tindakan" className="ar-action-cell" onClick={event => event.stopPropagation()} onKeyDown={event => event.stopPropagation()}><div className="ar-actions"><button onClick={() => openEmployeePayment(row)}><FiCreditCard/> Catat Pembayaran</button>{row.payments?.[0] && <button onClick={() => openProtectedFile(`/receivables/employee-payments/${row.payments[0].id}/voucher-print`).catch(err => setError(err.message))}><FiPrinter/> Bukti Kas</button>}</div></td></tr>)}</tbody></table></div>
      {!loading && !filteredEmployeeReceivables.length && <div className="ar-empty ar-employee-empty"><span><FiCreditCard/></span><h3>{employeeQuery ? "Karyawan tidak ditemukan" : "Belum ada piutang karyawan"}</h3><p>{employeeQuery ? "Coba gunakan nama atau email yang berbeda." : "Piutang akan muncul setelah pengeluaran berkategori Piutang Karyawan dibuat."}</p></div>}
    </section> :
    <section className="ar-panel">
      <div className="ar-panel-heading"><div><span>DAFTAR INVOICE</span><h2>Tagihan & pembayaran</h2><p>{rows.length} invoice ditampilkan</p></div><div className="ar-panel-head-actions"><div className="ar-status-legend"><span><i className="draft"/>Draft</span><span><i className="sent"/>Terkirim</span><span><i className="paid"/>Lunas</span></div><div className="ar-report-controls"><input className="ar-report-period" aria-label="Periode laporan piutang" type="month" value={reportMonth} onChange={event => setReportMonth(event.target.value)}/><button type="button" disabled={exportBusy} onClick={exportReceivables}><FiDownload/> {exportBusy ? "Mengekspor…" : "Export Excel"}</button><button type="button" disabled={reportBusy} onClick={printMonthlyCashReceipts}><FiPrinter/> {reportBusy ? "Menyiapkan…" : "Penerimaan Kas"}</button><button type="button" disabled={reportBusy} onClick={printOutstandingReport}><FiPrinter/> {reportBusy ? "Menyiapkan…" : "Semua Belum Bayar"}</button><button type="button" disabled={reportBusy} onClick={printReport}><FiPrinter/> {reportBusy ? "Menyiapkan…" : "Cetak Periode"}</button></div></div></div>
      <div className="ar-tools"><input className="ar-search" value={query} onChange={e => { setQuery(e.target.value); setInvoicePage(1); }} placeholder="Cari nomor invoice, pesanan, atau pelanggan..."/><select className="ar-filter" value={filter} onChange={e => { setFilter(e.target.value); setInvoicePage(1); }}><option value="ALL">Semua Status</option><option value="DRAFT">Draft</option><option value="SENT">Terkirim</option><option value="PARTIALLY_PAID">Dibayar Sebagian</option><option value="PAID">Lunas</option><option value="OVERDUE">Jatuh Tempo</option><option value="VOID">Dibatalkan</option></select><button className="ar-refresh" onClick={load} aria-label="Muat ulang"><FiRefreshCw className={loading ? "ar-spin" : ""}/></button></div>
      <div className={`ar-table-wrap ${loading && !rows.length ? "initial-loading" : ""}`}>{loading && !rows.length && <LoadingState label="Memuat piutang" note="Menghitung invoice, pembayaran, dan sisa tagihan…" rows={5} />}<table className="ar-invoice-table"><colgroup><col className="invoice"/><col className="customer"/><col className="due"/><col className="money"/><col className="money"/><col className="money"/><col className="status"/><col className="actions"/></colgroup><thead><tr><th>Invoice</th><th>Pelanggan</th><th>Jatuh Tempo</th><th>Total</th><th>Dibayar</th><th>Sisa</th><th>Status</th><th>Tindakan</th></tr></thead><tbody>
        {pagedInvoiceRows.map(invoice => <tr key={invoice.id} className="ar-clickable-row" tabIndex="0" role="button" aria-label={`Lihat rincian piutang ${invoice.number}`} onClick={() => openInvoiceView(invoice)} onKeyDown={event => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); openInvoiceView(invoice); } }}>
          <td className="ar-invoice-cell" data-label="Kwitansi / Invoice">{invoice.manualData?.receipt && <strong className="ar-receipt-number"><small>Kwitansi</small>{invoice.manualData.receipt}</strong>}<button type="button" className={`ar-invoice-link ${invoice.manualData?.receipt ? "ar-invoice-link-secondary" : ""}`} onClick={event => { event.stopPropagation(); openInvoiceView(invoice); }}><b>{invoice.number}</b><FiEye aria-hidden="true"/></button><small>{invoice.sourceType?.startsWith("MANUAL_") ? `Tagihan Tunggal · ${invoice.sourceType.replace("MANUAL_FERTILIZER","Pupuk").replace("MANUAL_CANGKANG","Cangkang").replace("MANUAL_MATERIAL","Ambang / Material")}` : invoice.order?.orderNo || (invoice.materialInvoices?.length ? `${invoice.materialInvoices.length} Faktur Muatan` : invoice.singleTrip?.tripNo)}</small>{invoice.order?.shipment?.loss > 0 && <small className="ar-loss">Selisih {invoice.order.shipment.loss.toLocaleString("id-ID")} {invoice.order.shipment.unit || ""}</small>}</td>
          <td className="ar-customer-cell" data-label="Pelanggan"><b>{invoice.customerName}</b><small>{invoice.order?.fromText} {invoice.order && "→"} {invoice.order?.toText}</small></td>
          <td data-label="Jatuh Tempo"><span className="ar-date-value">{tanggal(invoice.dueAt)}</span></td>
          <td className="ar-money-cell ar-total-cell" data-label="Total"><b>{rupiah(invoice.total)}</b>{Number(invoice.discount || 0) > 0 && <small>Tanpa PPh 23: {rupiah(invoiceWithoutPph23(invoice))}</small>}</td>
          <td className="ar-money-cell paid" data-label="Dibayar"><b>{rupiah(invoice.paid)}</b>{invoice.payments?.length > 0 && <small>Masuk kas: {rupiah(invoice.cashReceived)}</small>}</td>
          <td className="ar-money-cell ar-balance-cell" data-label="Sisa"><b>{rupiah(invoice.balance)}</b></td>
          <td data-label="Status"><span className={`ar-status ${invoice.displayStatus}`}>{statusLabel[invoice.displayStatus]}</span></td>
          <td className="ar-action-cell" data-label="Tindakan" onClick={event => event.stopPropagation()} onKeyDown={event => event.stopPropagation()}><div className="ar-actions">{invoice.status === "DRAFT" && !invoice.sourceType?.startsWith("MANUAL_") && <button onClick={() => openInvoiceDetail(invoice)}><FiFileText/> Ubah</button>}<button onClick={() => printInvoice(invoice)}><FiPrinter/> Cetak</button>{invoice.payments?.[0] && <button onClick={() => openPrintDocument(`/receivables/payments/${invoice.payments[0].id}/voucher-print`).catch(err => setError(err.message))}><FiPrinter/> Bukti Kas</button>}{invoice.status === "DRAFT" && <button onClick={() => sendInvoice(invoice)} disabled={busy || invoice.total <= 0} title={invoice.total <= 0 ? "Lengkapi harga terlebih dahulu" : "Kirim invoice"}><FiSend/> Kirim</button>}{["SENT", "PARTIALLY_PAID"].includes(invoice.status) && <button onClick={() => openPayment(invoice)}><FiCreditCard/> Bayar</button>}{canVoid && !invoice.payments.length && !["PAID", "VOID"].includes(invoice.status) && <button className="void" onClick={() => voidInvoice(invoice)}>Batalkan</button>}</div></td>
        </tr>)}
      </tbody></table></div>
      {rows.length > invoicePageSize && <nav className="ar-pagination" aria-label="Pagination daftar invoice"><span>Menampilkan {(activeInvoicePage - 1) * invoicePageSize + 1}–{Math.min(activeInvoicePage * invoicePageSize, rows.length)} dari {rows.length} invoice</span><div><button type="button" disabled={activeInvoicePage === 1} onClick={() => setInvoicePage(page => Math.max(1, page - 1))}>Sebelumnya</button><strong>Halaman {activeInvoicePage} dari {invoicePageCount}</strong><button type="button" disabled={activeInvoicePage === invoicePageCount} onClick={() => setInvoicePage(page => Math.min(invoicePageCount, page + 1))}>Berikutnya</button></div></nav>}
      {!loading && !rows.length && <div className="ar-empty"><FiFileText/><h3>Belum ada invoice</h3><p>{data.eligibleSources?.length ? "Buat invoice dari order, Faktur Muatan, atau Trip Tunggal yang siap ditagih." : "Selesaikan perjalanan terlebih dahulu agar dapat ditagih."}</p></div>}
    </section>}

    {modal === "manual-invoice" && <div className="ar-overlay" onMouseDown={() => setModal("")}><form className="ar-modal ar-manual-modal" onSubmit={createManualInvoice} onMouseDown={e => e.stopPropagation()}><div className="ar-modal-head"><div><span className="ar-eyebrow">TAGIHAN TANPA PESANAN / TRIP</span><h2>Buat Tagihan Tunggal</h2><p>Masukkan rincian angkutan secara manual sesuai dokumen customer.</p></div><button type="button" onClick={() => setModal("")}><FiX/></button></div><div className="ar-form">
      <div className="ar-manual-types"><button type="button" className={manualForm.type==="FERTILIZER"?"active":""} onClick={()=>changeManualType("FERTILIZER")}><b>Pupuk</b><small>Zak, KG kirim dan diterima</small></button><button type="button" className={manualForm.type==="CANGKANG"?"active":""} onClick={()=>changeManualType("CANGKANG")}><b>Cangkang</b><small>Timbang kebun dan bongkar</small></button><button type="button" className={manualForm.type==="MATERIAL"?"active":""} onClick={()=>changeManualType("MATERIAL")}><b>Ambang / Material</b><small>Beberapa barang dan satuan</small></button></div>
      <section className="ar-form-section ar-manual-info"><div className="ar-section-title"><span>1</span><div><strong>Customer dan keterangan</strong><small>Invoice tetap terhubung ke Master Customer.</small></div></div><div className="ar-grid2"><label>Customer tagihan<select required value={manualForm.customerId} onChange={e=>setManualForm({...manualForm,customerId:e.target.value})}><option value="">Pilih customer</option>{data.customers.map(customer=><option key={customer.id} value={customer.id}>{customer.name}</option>)}</select></label><label>Jatuh tempo<input required type="date" value={manualForm.dueAt} onChange={e=>setManualForm({...manualForm,dueAt:e.target.value})}/></label></div><label>Judul tagihan<input required value={manualForm.title} onChange={e=>setManualForm({...manualForm,title:e.target.value})}/></label><div className="ar-grid2"><label>Angkut dari<input value={manualForm.fromText} onChange={e=>setManualForm({...manualForm,fromText:e.target.value})}/></label><label>Tujuan<input value={manualForm.toText} onChange={e=>setManualForm({...manualForm,toText:e.target.value})}/></label></div><div className="ar-grid2"><label>Referensi <small className="ar-optional">SO / PO / DO</small><input value={manualForm.reference} onChange={e=>setManualForm({...manualForm,reference:e.target.value})}/></label><label>Kwitansi <small className="ar-optional">Nomor / keterangan kwitansi</small><input value={manualForm.receipt} onChange={e=>setManualForm({...manualForm,receipt:e.target.value})}/></label></div></section>
      <section className="ar-form-section ar-manual-lines"><div className="ar-section-title"><span>2</span><div><strong>Rincian tagihan</strong><small>Tambahkan satu baris untuk setiap kendaraan atau barang.</small></div></div><div className="ar-manual-table"><div className={`ar-manual-row heading ${manualForm.type.toLowerCase()}`}>{manualForm.type==="MATERIAL"?<><span>Tanggal</span><span>No. Polisi</span><span>Surat/Faktur</span><span>Nama barang</span><span>Qty</span><span>Satuan</span><span>Harga</span><span/></>:manualForm.type==="FERTILIZER"?<><span>Tanggal</span><span>No. Polisi</span><span>Zak kirim</span><span>KG kirim</span><span>Zak terima</span><span>KG terima</span><span>KG ditagih</span><span>Harga/KG</span><span/></>:<><span>Tgl SP</span><span>No. Polisi</span><span>Tgl bongkar</span><span>KG kirim</span><span>KG bongkar</span><span>KG ditagih</span><span>Harga/KG</span><span/></>}</div>{manualForm.lines.map((line,index)=><div className={`ar-manual-row ${manualForm.type.toLowerCase()}`} key={index}>{manualForm.type==="MATERIAL"?<><input required type="date" value={line.date} onChange={e=>updateManualLine(index,"date",e.target.value)}/><TruckSearch trucks={data.trucks} value={line.truckId} onChange={value=>updateManualLine(index,"truckId",value)}/><input value={line.documentNo} onChange={e=>updateManualLine(index,"documentNo",e.target.value)} placeholder="No. surat"/><input required value={line.cargoName} onChange={e=>updateManualLine(index,"cargoName",e.target.value)} placeholder="Nama barang"/><input required min="0.01" step="0.01" type="number" value={line.qty} onChange={e=>updateManualLine(index,"qty",e.target.value)}/><input required value={line.unit} onChange={e=>updateManualLine(index,"unit",e.target.value)}/><input required min="1" type="number" value={line.rate} onChange={e=>updateManualLine(index,"rate",e.target.value)}/></>:manualForm.type==="FERTILIZER"?<><input required type="date" value={line.date} onChange={e=>updateManualLine(index,"date",e.target.value)}/><TruckSearch trucks={data.trucks} value={line.truckId} onChange={value=>updateManualLine(index,"truckId",value)}/><input min="0" type="number" value={line.sentPackages} onChange={e=>updateManualLine(index,"sentPackages",e.target.value)}/><input required min="0" type="number" value={line.sentKg} onChange={e=>updateManualLine(index,"sentKg",e.target.value)}/><input min="0" type="number" value={line.receivedPackages} onChange={e=>updateManualLine(index,"receivedPackages",e.target.value)}/><input required min="0" type="number" value={line.receivedKg} onChange={e=>updateManualLine(index,"receivedKg",e.target.value)}/><input required min="0" type="number" value={line.billableKg} onChange={e=>updateManualLine(index,"billableKg",e.target.value)}/><input required min="1" type="number" value={line.rate} onChange={e=>updateManualLine(index,"rate",e.target.value)}/></>:<><input required type="date" value={line.date} onChange={e=>updateManualLine(index,"date",e.target.value)}/><TruckSearch trucks={data.trucks} value={line.truckId} onChange={value=>updateManualLine(index,"truckId",value)}/><input required type="date" value={line.unloadingDate} onChange={e=>updateManualLine(index,"unloadingDate",e.target.value)}/><input required min="0" type="number" value={line.sentKg} onChange={e=>updateManualLine(index,"sentKg",e.target.value)}/><input required min="0" type="number" value={line.receivedKg} onChange={e=>updateManualLine(index,"receivedKg",e.target.value)}/><input required min="0" type="number" value={line.billableKg} onChange={e=>updateManualLine(index,"billableKg",e.target.value)}/><input required min="1" type="number" value={line.rate} onChange={e=>updateManualLine(index,"rate",e.target.value)}/></>}<button type="button" className="ar-remove-line" disabled={manualForm.lines.length===1} onClick={()=>setManualForm(form=>({...form,lines:form.lines.filter((_,i)=>i!==index)}))}><FiX/></button></div>)}</div><button type="button" className="ar-add-line" onClick={()=>setManualForm(form=>({...form,lines:[...form.lines,manualLine(form.type)]}))}><FiPlus/> Tambah baris</button></section>
      <section className="ar-form-section ar-manual-summary"><div className="ar-grid2"><label>Pajak (%)<input min="0" max="100" step="0.01" type="number" value={manualForm.taxRate} onChange={e=>setManualForm({...manualForm,taxRate:e.target.value})} placeholder="Kosongkan jika tidak ada"/><small className="ar-optional">Opsional. Persentase pajak mengurangi subtotal.</small></label><label>PPH23 (%)<input min="0" max="100" step="0.01" type="number" value={manualForm.pph23Rate} onChange={e=>setManualForm({...manualForm,pph23Rate:e.target.value})}/><small className="ar-optional">Otomatis 2% dari subtotal, dapat diubah.</small></label></div><label>Catatan<textarea rows="2" value={manualForm.notes} onChange={e=>setManualForm({...manualForm,notes:e.target.value})}/></label><div className="ar-manual-total"><span><small>ESTIMASI TOTAL TAGIHAN</small><b>{rupiah(manualSubtotal(manualForm)-Math.round(manualSubtotal(manualForm)*Number(manualForm.taxRate||0)/100))}</b><small>Estimasi masuk kas setelah PPh 23: {rupiah(manualSubtotal(manualForm)-Math.round(manualSubtotal(manualForm)*Number(manualForm.taxRate||0)/100)-manualPph23(manualForm))}</small></span><em>{manualForm.lines.length} baris rincian</em></div></section></div><div className="ar-modal-actions"><span className="ar-manual-action-note">Invoice disimpan sebagai Draft dan dapat diperiksa sebelum dikirim.</span><button type="button" className="secondary" onClick={()=>setModal("")}>Batal</button><button className="ar-primary" disabled={busy}><FiCheck/> {busy?"Menyimpan...":"Buat Tagihan Tunggal"}</button></div></form></div>}

    {modal === "invoice" && <div className="ar-overlay" onMouseDown={() => setModal("")}><form noValidate className="ar-modal ar-invoice-modal ar-create-modal" onSubmit={createInvoice} onMouseDown={e => e.stopPropagation()}>
      <div className="ar-modal-head"><div><span className="ar-eyebrow">INVOICE BARU</span><h2>Buat tagihan pelanggan</h2><p>Pilih sumber dan pastikan rincian tagihan sudah benar.</p></div><button type="button" aria-label="Tutup" onClick={() => setModal("")}><FiX/></button></div>
      <div className="ar-form ar-invoice-form">
        <section className="ar-form-section">
          <div className="ar-section-title"><span>1</span><div><strong>Pilih customer dan sumber tagihan</strong><small>Hanya pesanan, trip, dan Faktur Muatan customer terpilih yang belum ditagih akan ditampilkan.</small></div></div>
          <div className="ar-source-guide"><span><b>Customer tagihan</b><small>Perusahaan yang menerima invoice</small></span><FiArrowRight/><span><b>Checklist sumber</b><small>Pilih pekerjaan yang akan dibuatkan Draft</small></span></div>
          <label>Customer tagihan<select required value={invoiceForm.billingCustomerKey} onChange={e => chooseCustomer(e.target.value)}><option value="">Pilih customer</option>{billingCustomers.map(customer => <option key={customer.key} value={customer.key}>{customer.name} · {customer.count} sumber</option>)}</select></label>
          <div className="ar-source-picker"><div className="ar-source-picker-title"><span>Sumber yang siap ditagih</span><small>{invoiceForm.billingCustomerKey ? `${customerSources.length} kelompok tersedia` : "Pilih customer terlebih dahulu"}</small></div>
            {!invoiceForm.billingCustomerKey ? <div className="ar-source-empty">Customer belum dipilih.</div> : !customerSources.length ? <div className="ar-source-empty">Belum ada order, trip, atau Faktur Muatan yang sudah selesai dan siap ditagih.</div> : customerSources.map(source => {
              const sourceKey = `${source.type}:${source.id}`;
              const selected = invoiceForm.sourceKey === sourceKey;
              const isOrder = source.type === "ORDER";
              const isMaterial = source.type === "MATERIAL";
              const category = isMaterial ? "Ambang / Material" : source.type === "SINGLE_TRIP_GROUP" ? (source.cargoCategory === "FERTILIZER" ? "Pupuk" : "Cangkang") : (source.order?.cargoName || "Pesanan");
              const numbers = isOrder ? (source.order?.deliveryOrderNo || source.order?.spkNo || "Nomor DO belum diisi") : isMaterial ? (source.invoices || []).map(row => row.number).join(", ") : (source.trips || []).map(row => row.tripNo).join(", ");
              const weight = isOrder ? `${Number(source.order?.shipment?.readyToBillKg || 0).toLocaleString("id-ID")} kg siap ditagih` : isMaterial ? (source.invoices || []).flatMap(row => row.lines || []).map(line => `${line.qty} ${line.unit}`).join(" · ") : `${Number(source.totalWeightKg || 0).toLocaleString("id-ID")} kg`;
              const count = isOrder ? `${Number(source.order?.shipment?.billedKg || 0).toLocaleString("id-ID")} kg sudah ditagih` : `${isMaterial ? source.invoices?.length : source.trips?.length} ${isMaterial ? "faktur" : "trip"}`;
              const plateNumbers = sourcePlateNumbers(source);
              return <button type="button" key={sourceKey} className={`ar-source-choice ${selected ? "selected" : ""}`} onClick={() => chooseOrder(sourceKey)}><i>{selected && <FiCheck/>}</i><span><small>{category}</small><b>{numbers || source.label}</b><em>{count}{plateNumbers.length ? ` · Armada: ${plateNumbers.join(", ")}` : " · Armada belum tercatat"}</em></span><strong>{weight || "—"}</strong></button>;
            })}
          </div>
          {invoiceOrder && <div className="ar-order-summary"><span><small>Rute pengiriman</small><strong>{invoiceOrder.fromText || "—"} → {invoiceOrder.toText || "—"}</strong></span><span><small>Progres penagihan DO</small><strong>{Number(invoiceOrder.shipment?.billedKg || 0).toLocaleString("id-ID")} kg sudah ditagih</strong><small>{Number(invoiceOrder.shipment?.readyToBillKg || 0).toLocaleString("id-ID")} kg siap ditagih · total DO {Number(invoiceOrder.shipment?.orderedKg || 0).toLocaleString("id-ID")} kg</small></span></div>}
          {selectedSource?.type === "ORDER" && <div className="ar-material-picker">
            <div className="ar-material-picker-head"><div><small>ARMADA YANG HENDAK DITAGIH</small><strong>{invoiceOrder?.deliveryOrderNo || invoiceOrder?.spkNo || "DO belum diisi"}</strong><span>{invoiceForm.orderTripIds.length} dari {(invoiceOrder?.availableLoads || []).length} armada dipilih</span></div><button type="button" onClick={() => setInvoiceForm(form => ({ ...form, orderTripIds: form.orderTripIds.length === (invoiceOrder?.availableLoads || []).length ? [] : (invoiceOrder?.availableLoads || []).map(load => load.id) }))}>{invoiceForm.orderTripIds.length === (invoiceOrder?.availableLoads || []).length ? "Batalkan semua" : "Pilih semua"}</button></div>
            <div className="ar-material-list">{(invoiceOrder?.availableLoads || []).map(load => <label className={`ar-material-item ${invoiceForm.orderTripIds.includes(load.id) ? "selected" : ""}`} key={load.id}><input type="checkbox" checked={invoiceForm.orderTripIds.includes(load.id)} onChange={() => toggleOrderTrip(load.id)}/><span><b>{load.plateNumber || "Tanpa nomor polisi"}</b><small>{load.tripNo || "Trip"} · selesai {tanggal(load.completedAt)}</small></span><strong>{Number(load.quantityKg || 0).toLocaleString("id-ID")} kg</strong></label>)}</div>
            <div className="ar-material-subtotal"><span>Total berat armada terpilih</span><strong>{selectedOrderWeightKg.toLocaleString("id-ID")} kg</strong></div>
          </div>}
          {selectedSource?.type === "MATERIAL" && <div className="ar-material-picker">
            <div className="ar-material-picker-head"><div><small>FAKTUR CUSTOMER</small><strong>{selectedSource.customerName}</strong><span>{invoiceForm.materialInvoiceIds.length} dari {selectedSource.materialInvoiceIds.length} faktur dipilih</span></div><button type="button" onClick={() => setInvoiceForm(form => ({ ...form, materialInvoiceIds: form.materialInvoiceIds.length === selectedSource.materialInvoiceIds.length ? [] : [...selectedSource.materialInvoiceIds] }))}>{invoiceForm.materialInvoiceIds.length === selectedSource.materialInvoiceIds.length ? "Batalkan semua" : "Pilih semua"}</button></div>
            <div className="ar-material-list">{(selectedSource.invoices || []).map(invoice => {
              const invoiceTotal = (invoice.lines || []).reduce((sum, line) => sum + Number(line.totalAmount || 0), 0);
              const itemNames = [...new Set((invoice.lines || []).map(line => line.itemName).filter(Boolean))].join(", ");
              return <label className={`ar-material-item ${invoiceForm.materialInvoiceIds.includes(invoice.id) ? "selected" : ""}`} key={invoice.id}><input type="checkbox" checked={invoiceForm.materialInvoiceIds.includes(invoice.id)} onChange={() => toggleMaterialInvoice(invoice.id)}/><span><b>{invoice.number}</b><small>{tanggal(invoice.issuedAt)} · {invoice.trip?.truck?.plateNumber || "Tanpa armada"}</small><small>{invoice.destinationLocation?.name || invoice.destinationText || "Tujuan belum dicatat"}</small><em>{itemNames || "Ambang / Material"}</em>{invoiceForm.materialInvoiceIds.includes(invoice.id)&&(invoice.lines||[]).map(line=><span className="ar-material-rate" key={line.id}><small>{line.itemName} · {line.qty} {line.unit}</small><input required min="1" type="number" value={invoiceForm.materialLineAmounts[line.id]??""} onClick={e=>e.stopPropagation()} onChange={e=>setInvoiceForm(form=>({...form,materialLineAmounts:{...form.materialLineAmounts,[line.id]:e.target.value}}))} placeholder={`Harga per ${line.unit}`}/></span>)}</span><strong>{rupiah(invoiceForm.materialInvoiceIds.includes(invoice.id)?(invoice.lines||[]).reduce((sum,line)=>sum+Number(line.qty||0)*Number(invoiceForm.materialLineAmounts[line.id]||0),0):invoiceTotal)}</strong></label>;
            })}</div>
            <div className="ar-material-subtotal"><span>Subtotal faktur terpilih</span><strong>{rupiah(selectedMaterialSubtotal)}</strong></div>
          </div>}
          {selectedSource?.type === "SINGLE_TRIP_GROUP" && <div className="ar-material-picker">
            <div className="ar-material-picker-head"><div><small>TRIP SIAP DITAGIH</small><strong>{selectedSource.customerName} · {selectedSource.cargoCategory === "FERTILIZER" ? "Pupuk" : "Cangkang"}</strong><span>{invoiceForm.singleTripIds.length} dari {selectedSource.singleTripIds.length} trip dipilih</span></div><button type="button" onClick={() => setInvoiceForm(form => ({ ...form, singleTripIds: form.singleTripIds.length === selectedSource.singleTripIds.length ? [] : [...selectedSource.singleTripIds] }))}>{invoiceForm.singleTripIds.length === selectedSource.singleTripIds.length ? "Batalkan semua" : "Pilih semua"}</button></div>
            <div className="ar-material-list">{(selectedSource.trips || []).map(trip => <label className={`ar-material-item ${invoiceForm.singleTripIds.includes(trip.id) ? "selected" : ""}`} key={trip.id}><input type="checkbox" checked={invoiceForm.singleTripIds.includes(trip.id)} onChange={() => toggleSingleTrip(trip.id)}/><span><b>{trip.tripNo}</b><small>{tanggal(trip.completedAt)} · {trip.truck?.plateNumber || "Tanpa armada"}</small><small>{trip.fromText || "—"} → {trip.toText || "—"}</small><em>{trip.cargoNameSnap || "Muatan"}</em></span><strong>{tripWeightKg(trip).toLocaleString("id-ID")} kg</strong></label>)}</div>
            <div className="ar-material-subtotal"><span>Total berat aktual terpilih</span><strong>{selectedSingleWeightKg.toLocaleString("id-ID")} kg</strong></div>
          </div>}
          {selectedSource?.type === "SINGLE_TRIP" && <div className="ar-order-summary"><span><small>{selectedSource.trip?.tripNo || "TRIP TANPA PESANAN"}</small><strong>{selectedSource.trip?.truck?.plateNumber || "Armada"}</strong></span><span><small>Muatan</small><strong>{selectedSource.trip?.cargoNameSnap || "Muatan"}</strong></span></div>}
        </section>
        <section className="ar-form-section">
          <div className="ar-section-title"><span>2</span><div><strong>Informasi pelanggan</strong><small>Data ini akan dicantumkan pada invoice.</small></div></div>
          <div className="ar-grid2"><label>Nama pelanggan<input required readOnly={["MATERIAL", "SINGLE_TRIP_GROUP"].includes(selectedSource?.type)} value={invoiceForm.customerName} onChange={e => setInvoiceForm({...invoiceForm, customerName:e.target.value})} placeholder="Nama perusahaan atau pelanggan"/></label><label>Nomor telepon<input value={invoiceForm.customerPhone} onChange={e => setInvoiceForm({...invoiceForm, customerPhone:e.target.value})} placeholder="Contoh: 0812 3456 7890"/></label></div>
          <label>Alamat penagihan<textarea rows="2" value={invoiceForm.billingAddress} onChange={e => setInvoiceForm({...invoiceForm, billingAddress:e.target.value})} placeholder="Alamat lengkap untuk penagihan"/></label>
          <label>Kwitansi<input value={invoiceForm.receipt} onChange={e => setInvoiceForm({...invoiceForm, receipt:e.target.value})} placeholder="Nomor / keterangan kwitansi"/></label>
        </section>
        <section className="ar-form-section">
          <div className="ar-section-title"><span>3</span><div><strong>Rincian tagihan</strong><small>Isi nominal dalam Rupiah.</small></div></div>
          <div className="ar-grid2"><label>Jatuh tempo<input required type="date" value={invoiceForm.dueAt} onChange={e => setInvoiceForm({...invoiceForm, dueAt:e.target.value})}/></label>{selectedSource?.type !== "MATERIAL" && <label>Persentase susut (%)<input required min="0" max="100" step="0.01" type="number" value={invoiceForm.tolerancePercent} onChange={e => setInvoiceForm({...invoiceForm, tolerancePercent:e.target.value})}/><small className="ar-optional">Default customer; dapat diubah untuk penagihan ini.</small></label>}</div>
          {selectedSource?.type !== "MATERIAL" && <div className="ar-order-summary"><span><small>HARGA DIISI SETELAH DRAFT</small><strong>Berat ditagih × harga per kg</strong></span><span><small>Susut yang digunakan</small><strong>{Number(invoiceForm.tolerancePercent || 0).toLocaleString("id-ID")} %</strong></span></div>}
          {materialSubtotal > 0 && <div className="ar-order-summary"><span><small>FAKTUR MUATAN</small><strong>Tambahan material</strong></span><span><small>Subtotal material</small><strong>{rupiah(materialSubtotal)}</strong></span></div>}
          <div className="ar-grid2"><label>Pajak (%)<input min="0" max="100" step="0.01" type="number" value={invoiceForm.taxRate} onChange={e => setInvoiceForm({...invoiceForm, taxRate:e.target.value})} placeholder="Kosongkan jika tidak ada"/><small className="ar-optional">Opsional, mengurangi subtotal.</small></label><label>PPH23 (%)<input min="0" max="100" step="0.01" type="number" value={invoiceForm.pph23Rate} onChange={e => setInvoiceForm({...invoiceForm, pph23Rate:e.target.value})}/><small className="ar-optional">Otomatis 2%, dapat diubah.</small></label></div>
          <label>Catatan <small className="ar-optional">Opsional</small><textarea rows="2" value={invoiceForm.notes} onChange={e => setInvoiceForm({...invoiceForm, notes:e.target.value})} placeholder="Keterangan tambahan untuk pelanggan"/></label>
          <div className="ar-total"><span><small>DRAFT TAGIHAN</small>Harga dilengkapi melalui Detail &amp; Harga setelah Draft dibuat{selectedSource?.type === "MATERIAL" && pph23 > 0 && <small>Tanpa PPh 23: {rupiah(total - pph23)}</small>}</span><strong>{selectedSource?.type === "MATERIAL" ? rupiah(total) : "Belum dihitung"}</strong></div>
        </section>
      </div>
      <div className="ar-modal-actions"><span className={`ar-save-hint ${invoiceBlockReason ? "waiting" : "ready"}`}>{invoiceBlockReason || "Sumber siap disimpan sebagai Draft"}</span><button type="button" className="secondary" onClick={() => setModal("")}>Batal</button><button className="ar-primary ar-save-invoice" disabled={!canSaveInvoice} title={invoiceBlockReason || "Buat Draft Invoice"}>{busy ? <><FiRefreshCw className="ar-spin"/> Menyimpan...</> : <><FiCheck/> Buat Draft</>}</button></div>
    </form></div>}

    {modal === "invoice-view" && selected && <div className="ar-overlay" onMouseDown={() => setModal("")}><div className="ar-modal ar-invoice-view-modal" role="dialog" aria-modal="true" aria-labelledby="invoice-view-title" onMouseDown={e => e.stopPropagation()}>
      <div className="ar-modal-head"><div><span className="ar-eyebrow">RINCIAN PIUTANG</span><h2 id="invoice-view-title">{selected.number}</h2><p>{selected.customerName} · Dibuat {tanggal(selected.issuedAt || selected.createdAt)}</p></div><button type="button" aria-label="Tutup rincian" onClick={() => setModal("")}><FiX/></button></div>
      <div className="ar-invoice-view-body">
        <section className="ar-view-summary">
          <div><small>Status</small><span className={`ar-status ${selected.displayStatus}`}>{statusLabel[selected.displayStatus]}</span></div>
          <div><small>Total tagihan</small><strong>{rupiah(selected.total)}</strong>{Number(selected.discount || 0) > 0 && <span>Tanpa PPh 23: {rupiah(invoiceWithoutPph23(selected))}</span>}</div>
          <div><small>Sudah dibayar</small><strong className="paid">{rupiah(selected.paid)}</strong></div>
          <div className="balance"><small>Sisa piutang</small><strong>{rupiah(selected.balance)}</strong></div>
        </section>
        <section className="ar-view-section"><header><div><span>INFORMASI TAGIHAN</span><h3>Customer dan sumber piutang</h3></div></header><div className="ar-view-grid">
          <div><small>Pelanggan</small><b>{selected.customerName}</b><span>{selected.customerPhone || "Kontak belum dicatat"}</span></div>
          <div><small>Jatuh tempo</small><b>{tanggal(selected.dueAt)}</b><span>{selected.displayStatus === "OVERDUE" ? "Perlu ditindaklanjuti" : "Tanggal pembayaran terakhir"}</span></div>
          <div><small>Sumber tagihan</small><b>{selected.manualData?.title || selected.order?.orderNo || selected.singleTrip?.tripNo || (selected.materialInvoices?.length ? `${selected.materialInvoices.length} Faktur Muatan` : "Tagihan pelanggan")}</b><span>{selected.manualData ? [selected.manualData.fromText, selected.manualData.toText].filter(Boolean).join(" → ") || "Tagihan tunggal" : [selected.order?.fromText, selected.order?.toText].filter(Boolean).join(" → ") || "—"}</span></div>
          <div><small>Kwitansi / referensi</small><b>{selected.manualData?.receipt || selected.manualData?.reference || selected.order?.deliveryOrderNo || "—"}</b><span>{selected.billingAddress || "Alamat penagihan belum dicatat"}</span></div>
        </div>{selected.notes && <div className="ar-view-notes"><small>Catatan</small><p>{selected.notes}</p></div>}</section>
        {!!selected.manualLines?.length && <section className={`ar-view-section ar-view-lines-section ${selected.manualLines.length > 3 ? "scrollable" : ""}`}><header><div><span>RINCIAN TAGIHAN</span><h3>{selected.manualLines.length} baris pekerjaan</h3></div></header><div className={`ar-view-lines ${selected.manualLines.length > 3 ? "scrollable" : ""}`} role="region" aria-label="Daftar rincian tagihan" tabIndex={selected.manualLines.length > 3 ? 0 : undefined}>{selected.manualLines.map((line, index) => <article key={line.id || index}><span><b>{line.data?.cargoName || `Baris ${index + 1}`}</b><small>{line.truck?.plateNumber || line.data?.plateNumber || "Tanpa nopol"} · {tanggal(line.data?.date)}</small></span><span><b>{Number(line.quantity || 0).toLocaleString("id-ID")} {line.unit || ""}</b><small>{rupiah(line.rate)} / {line.unit || "unit"}</small></span><strong>{rupiah(line.amount)}</strong></article>)}</div></section>}
        <section className="ar-view-section"><header><div><span>RIWAYAT PEMBAYARAN</span><h3>{selected.payments?.length ? `${selected.payments.length} pembayaran diterima` : "Belum ada pembayaran"}</h3></div></header>{selected.payments?.length ? <div className="ar-view-payments">{selected.payments.map(payment => <article key={payment.id}><span><b>{tanggal(payment.receivedAt)}</b><small>{payment.method === "BANK_TRANSFER" ? "Transfer Bank" : payment.method === "CASH" ? "Tunai" : "Lainnya"}{payment.reference ? ` · ${payment.reference}` : ""}</small><small>PPh 23: -{rupiah(payment.pph23Amount)} · Klaim: -{rupiah(payment.claimAmount)} · Admin: -{rupiah(payment.adminFee)}</small></span><span className="ar-payment-values"><small>Dibayar {rupiah(payment.amount)}</small><strong>Kas masuk {rupiah(paymentNet(payment))}</strong></span></article>)}</div> : <p className="ar-view-empty">Sisa piutang belum memiliki transaksi pembayaran.</p>}</section>
      </div>
      <div className="ar-modal-actions"><button type="button" className="secondary" onClick={() => setModal("")}>Tutup</button><button type="button" className="secondary" onClick={() => printInvoice(selected)}><FiPrinter/> Cetak Invoice</button>{["SENT", "PARTIALLY_PAID"].includes(selected.status) && <button type="button" className="ar-primary" onClick={() => openPayment(selected)}><FiCreditCard/> Catat Pembayaran</button>}</div>
    </div></div>}

    {modal === "invoice-detail" && selected && <div className="ar-overlay" onMouseDown={() => setModal("")}><form className="ar-modal ar-invoice-modal" onSubmit={saveInvoicePricing} onMouseDown={e => e.stopPropagation()}>
      <div className="ar-modal-head"><div><span className="ar-eyebrow">DETAIL INVOICE DRAFT</span><h2>{selected.number}</h2><p>{selected.customerName} · Lengkapi harga sebelum invoice dikirim.</p></div><button type="button" onClick={() => setModal("")}><FiX/></button></div>
      <div className="ar-form ar-invoice-form">
        <section className="ar-form-section"><div className="ar-section-title"><span>1</span><div><strong>Sumber tagihan</strong><small>Sumber sudah dikunci pada Draft ini.</small></div></div>
          {selected.materialInvoices?.length ? <><div className="ar-material-list">{selected.materialInvoices.flatMap(invoice => (invoice.lines || []).map(line => <div className="ar-material-rate ar-detail-rate" key={line.id}><span><b>{line.itemName}</b><small>{line.qty} {line.unit} · {invoice.number} · {invoice.trip?.truck?.plateNumber || "-"}</small></span><input required min="1" type="number" value={pricingForm.materialLineRates[line.id] ?? ""} onChange={e => setPricingForm(form => ({ ...form, materialLineRates: { ...form.materialLineRates, [line.id]: e.target.value } }))} placeholder={`Harga per ${line.unit}`}/></div>))}</div><div className="ar-material-evidence"><header><strong>Bukti penerimaan material</strong><small>{materialEvidence(selected.materialInvoices).length} bukti sumber alokasi FIFO</small></header><div>{materialEvidence(selected.materialInvoices).map(receipt => <article key={receipt.id}><span><b>{receipt.number}</b><small>{receipt.itemName} · {Number(receipt.qtyReceived).toLocaleString("id-ID")} {receipt.unit}</small><small>{receipt.location?.name || "Tanpa lokasi"} · {tanggal(receipt.receivedAt)}</small></span><button type="button" onClick={()=>openProtectedFile(receipt.proofUrl).catch(error=>setError(error.message))}>Lihat bukti</button></article>)}</div></div></> : selected.singleTripLines?.length ? <><div className="ar-order-summary"><span><small>TRIP TERPILIH</small><strong>{selected.singleTripLines.length} trip · kirim {selected.singleTripLines.reduce((sum,line)=>sum+Number(line.plannedWeightKg ?? line.actualWeightKg ?? 0),0).toLocaleString("id-ID")} kg</strong><small>Diterima {selected.singleTripLines.reduce((sum,line)=>sum+Number(line.actualWeightKg||0),0).toLocaleString("id-ID")} kg</small></span><span><small>BERAT DITAGIH</small><strong>{selected.singleTripLines.reduce((sum,line)=>sum+Number(line.billableWeightKg ?? line.actualWeightKg ?? 0),0).toLocaleString("id-ID")} kg</strong><small>Toleransi {Number(selected.tolerancePercent || 0).toLocaleString("id-ID")} %</small></span></div><label>Harga per kg<input required min="1" type="number" value={pricingForm.ratePerKg} onChange={e=>setPricingForm({...pricingForm,ratePerKg:e.target.value})}/></label></> : <><div className="ar-order-summary"><span><small>PESANAN</small><strong>{selected.order?.orderNo || "Pesanan reguler"}</strong><small>Kirim {Number(selected.plannedQuantity || 0).toLocaleString("id-ID")} kg · diterima {Number(selected.deliveredQuantity || 0).toLocaleString("id-ID")} kg</small></span><span><small>BERAT DITAGIH</small><strong>{Number(selected.billableQuantity || 0).toLocaleString("id-ID")} kg</strong><small>Toleransi {Number(selected.tolerancePercent || 0).toLocaleString("id-ID")} %</small></span></div><label>Harga per kg<input required min="1" type="number" value={pricingForm.ratePerKg} onChange={e=>setPricingForm({...pricingForm,ratePerKg:e.target.value})}/></label></>}
          {!selected.materialInvoices?.length && <label>Toleransi susut customer (%)<input required min="0" max="100" step="0.01" type="number" value={pricingForm.tolerancePercent} onChange={e=>setPricingForm({...pricingForm,tolerancePercent:e.target.value})}/><small className="ar-optional">Disimpan ke Master Customer dan digunakan untuk tagihan berikutnya.</small></label>}
          {!!deliveryEvidence(selected).length && <div className="ar-material-evidence ar-delivery-evidence"><header><strong>Bukti pengiriman / timbangan</strong><small>{deliveryEvidence(selected).length} bukti dari trip yang ditagih</small></header><div>{deliveryEvidence(selected).map(proof => <article key={proof.id}><span><b>{proof.proofType === "LOADING" ? "Timbang muat" : "Timbang sampai"} · {proof.trip?.tripNo || "Trip"}</b><small>{proof.trip?.truck?.plateNumber || proof.trip?.plateNumberSnap || "Tanpa nopol"} · {tanggal(proof.createdAt)}</small><small>{proof.fileName || "Bukti pengiriman"}</small></span><button type="button" onClick={()=>openProtectedFile(proof.url).catch(error=>setError(error.message))}>Lihat bukti</button></article>)}</div></div>}
        </section>
        <section className="ar-form-section"><div className="ar-section-title"><span>2</span><div><strong>Penyesuaian tagihan</strong><small>Atur tanggal, kwitansi, PPh 23, dan catatan.</small></div></div><label>Jatuh tempo<input required type="date" value={pricingForm.dueAt} onChange={e=>setPricingForm({...pricingForm,dueAt:e.target.value})}/></label><label>Kwitansi<input value={pricingForm.receipt} onChange={e=>setPricingForm({...pricingForm,receipt:e.target.value})} placeholder="Nomor / keterangan kwitansi"/></label><div className="ar-grid2"><label>Pajak (%)<input min="0" max="100" step="0.01" type="number" value={pricingForm.taxRate} onChange={e=>setPricingForm({...pricingForm,taxRate:e.target.value})} placeholder="Kosongkan jika tidak ada"/><small className="ar-optional">Opsional, mengurangi subtotal.</small></label><label>PPH23 (%)<input min="0" max="100" step="0.01" type="number" value={pricingForm.pph23Rate} onChange={e=>setPricingForm({...pricingForm,pph23Rate:e.target.value})}/><small className="ar-optional">Otomatis 2%, dapat diubah.</small></label></div><label>Catatan<textarea rows="2" value={pricingForm.notes} onChange={e=>setPricingForm({...pricingForm,notes:e.target.value})}/></label></section>
      </div><div className="ar-modal-actions"><button type="button" className="secondary" onClick={()=>setModal("")}>Batal</button><button className="ar-primary" disabled={busy}><FiCheck/> {busy ? "Menyimpan..." : "Simpan Harga"}</button></div>
    </form></div>}

    {modal === "batch-payment" && <div className="ar-overlay" onMouseDown={() => setModal("")}><form className="ar-modal ar-batch-payment-modal" onSubmit={saveBatchPayment} onMouseDown={event => event.stopPropagation()}><div className="ar-modal-head"><div><span className="ar-eyebrow">PEMBAYARAN PIUTANG</span><h2>Catat pembayaran invoice</h2><p>Pilih satu atau beberapa invoice dalam satu pembayaran.</p></div><button type="button" onClick={() => setModal("")}><FiX/></button></div><div className="ar-form">
      <label>Pelanggan<select required value={batchPaymentForm.customerKey} onChange={event => chooseBatchCustomer(event.target.value)}><option value="">Pilih pelanggan</option>{batchCustomers.map(customer => <option key={customer.key} value={customer.key}>{customer.name}</option>)}</select></label>
      {batchPaymentForm.customerKey && <div className="ar-batch-invoices"><header><span>Invoice yang dibayar</span><small>{batchSelectedInvoices.length} dari {batchCustomerInvoices.length} dipilih</small></header>{batchCustomerInvoices.map(invoice => { const input = batchPaymentForm.invoices[invoice.id] || {}; const pph = input.selected ? batchPaymentPph(invoice) : 0; return <article className={input.selected ? "selected" : ""} key={invoice.id}><label className="ar-batch-check"><input type="checkbox" checked={Boolean(input.selected)} onChange={event => updateBatchInvoice(invoice.id, "selected", event.target.checked)}/><span><b>{invoice.manualData?.receipt || invoice.number}</b><small>{invoice.manualData?.receipt ? `${invoice.number} · ` : ""}Sisa {rupiah(invoice.balance)}</small></span></label>{input.selected && <div className="ar-batch-adjustments"><label>Jumlah dibayar<input required min="1" max={invoice.balance} type="number" value={input.amount ?? invoice.balance} onChange={event => updateBatchInvoice(invoice.id, "amount", event.target.value)}/></label><label>PPh 23<input readOnly type="number" value={pph}/></label><label>Klaim<input min="0" type="number" value={input.claimAmount || ""} onChange={event => updateBatchInvoice(invoice.id, "claimAmount", event.target.value)} placeholder="0"/></label><label>Biaya admin<input min="0" type="number" value={input.adminFee || ""} onChange={event => updateBatchInvoice(invoice.id, "adminFee", event.target.value)} placeholder="0"/></label></div>}</article>; })}</div>}
      <div className="ar-batch-summary"><span><small>Total pelunasan</small><b>{rupiah(batchTotals.gross)}</b></span><span><small>PPh 23</small><b>-{rupiah(batchTotals.pph)}</b></span><span><small>Klaim + admin</small><b>-{rupiah(batchTotals.claim + batchTotals.admin)}</b></span><span className="cash"><small>Total masuk kas</small><strong>{rupiah(batchTotals.cash)}</strong></span></div>
      <div className="ar-grid2"><label>Metode<select value={batchPaymentForm.method} onChange={event => setBatchPaymentForm({...batchPaymentForm, method:event.target.value})}><option value="BANK_TRANSFER">Transfer Bank</option><option value="CASH">Tunai</option><option value="OTHER">Lainnya</option></select></label><label>Tanggal diterima<input required type="date" value={batchPaymentForm.receivedAt} onChange={event => setBatchPaymentForm({...batchPaymentForm, receivedAt:event.target.value})}/></label></div><label>Nomor referensi<input value={batchPaymentForm.reference} onChange={event => setBatchPaymentForm({...batchPaymentForm, reference:event.target.value})} placeholder="Nomor transfer atau kuitansi"/></label><label>Catatan<textarea rows="2" value={batchPaymentForm.notes} onChange={event => setBatchPaymentForm({...batchPaymentForm, notes:event.target.value})}/></label>
    </div><div className="ar-modal-actions"><button type="button" className="secondary" onClick={() => setModal("")}>Batal</button><button className="ar-primary" disabled={busy || !batchSelectedInvoices.length || batchHasInvalidDeduction}><FiCheck/> {busy ? "Menyimpan..." : `Bayar ${batchSelectedInvoices.length} Invoice`}</button></div></form></div>}

    {modal === "employee-detail" && employeeDetail && <div className="ar-overlay" onMouseDown={() => setModal("")}><div className="ar-modal ar-invoice-view-modal ar-employee-detail-modal" role="dialog" aria-modal="true" aria-labelledby="employee-detail-title" onMouseDown={event => event.stopPropagation()}>
      <div className="ar-modal-head"><div><span className="ar-eyebrow">RINCIAN PIUTANG KARYAWAN</span><h2 id="employee-detail-title">{employeeDetail.employee.name || "Tanpa nama"}</h2><p>{employeeDetail.employee.email || employeeDetail.employee.phone || "Kontak tanpa akun ERP"}</p></div><button type="button" aria-label="Tutup rincian" onClick={() => setModal("")}><FiX/></button></div>
      <div className="ar-invoice-view-body">
        <section className="ar-view-summary ar-employee-detail-summary"><div><small>Total piutang</small><strong>{rupiah(employeeDetail.total)}</strong></div><div><small>Sudah dibayar</small><strong className="paid">{rupiah(employeeDetail.paid)}</strong></div><div className="balance"><small>Sisa piutang</small><strong>{rupiah(employeeDetail.balance)}</strong></div></section>
        <section className="ar-view-section"><header><div><span>RIWAYAT PIUTANG</span><h3>{employeeDetail.expenses.length} pengeluaran tercatat</h3></div></header><div className="ar-employee-detail-list">{employeeDetail.expenses.map(expense => <article key={expense.id}><span><b>{expense.reason || "Piutang karyawan"}</b><small>{tanggal(expense.expenseDate)}{expense.notes ? ` · ${expense.notes}` : ""}</small></span><strong>{rupiah(expense.amount)}</strong></article>)}</div></section>
        <section className="ar-view-section"><header><div><span>RIWAYAT PEMBAYARAN</span><h3>{employeeDetail.payments.length ? `${employeeDetail.payments.length} pembayaran diterima` : "Belum ada pembayaran"}</h3></div></header>{employeeDetail.payments.length ? <div className="ar-employee-detail-list">{employeeDetail.payments.map(payment => <article key={payment.id}><span><b>{tanggal(payment.receivedAt)}</b><small>{payment.method === "BANK_TRANSFER" ? "Transfer Bank" : payment.method === "CASH" ? "Tunai" : "Lainnya"}{payment.reference ? ` · ${payment.reference}` : ""}</small><small>{payment.number}{payment.notes ? ` · ${payment.notes}` : ""}</small></span><strong>{rupiah(payment.amount)}</strong></article>)}</div> : <p className="ar-view-empty">Belum ada pembayaran yang tercatat.</p>}</section>
      </div>
      <div className="ar-modal-actions"><button type="button" className="secondary" onClick={() => setModal("")}>Tutup</button><button type="button" className="ar-primary" onClick={() => openEmployeePayment(employeeDetail)}><FiCreditCard/> Catat Pembayaran</button></div>
    </div></div>}

    {modal === "employee-payment" && employeePayment && <div className="ar-overlay" onMouseDown={() => setModal("")}><form className="ar-modal ar-payment-modal" onSubmit={saveEmployeePayment} onMouseDown={e => e.stopPropagation()}><div className="ar-modal-head"><div><span className="ar-eyebrow">PIUTANG KARYAWAN</span><h2>Catat pembayaran</h2><p>{employeePayment.employee.name || employeePayment.employee.email || employeePayment.employee.phone}</p></div><button type="button" onClick={() => setModal("")}><FiX/></button></div><div className="ar-form"><div className="ar-balance"><span>Sisa piutang</span><strong>{rupiah(employeePayment.balance)}</strong></div><label>Jumlah diterima<input required min="1" max={employeePayment.balance} type="number" value={paymentForm.amount} onChange={e => setPaymentForm({...paymentForm, amount:e.target.value})}/></label><div className="ar-grid2"><label>Metode<select value={paymentForm.method} onChange={e => setPaymentForm({...paymentForm, method:e.target.value})}><option value="BANK_TRANSFER">Transfer Bank</option><option value="CASH">Tunai</option><option value="OTHER">Lainnya</option></select></label><label>Tanggal diterima<input required type="date" value={paymentForm.receivedAt} onChange={e => setPaymentForm({...paymentForm, receivedAt:e.target.value})}/></label></div><label>Nomor referensi<input value={paymentForm.reference} onChange={e => setPaymentForm({...paymentForm, reference:e.target.value})} placeholder="Nomor transfer atau kuitansi"/></label><label>Catatan<textarea rows="2" value={paymentForm.notes} onChange={e => setPaymentForm({...paymentForm, notes:e.target.value})}/></label></div><div className="ar-modal-actions"><button type="button" className="secondary" onClick={() => setModal("")}>Batal</button><button className="ar-primary" disabled={busy}><FiCheck/> {busy ? "Menyimpan..." : "Simpan Pembayaran"}</button></div></form></div>}
  </div>;
}
